/* $Id: strmode.h,v 1.3 2001/06/09 02:22:17 mouring Exp $ */

#ifndef HAVE_STRMODE

void strmode(register mode_t mode, register char *p);

#endif
