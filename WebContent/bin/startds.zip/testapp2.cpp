// testapp2.cpp : Defines the entry point for the application.
//

#include "stdafx.h"
#include <process.h>
#include <string>
int APIENTRY WinMain(HINSTANCE hInstance,
                     HINSTANCE hPrevInstance,
                     LPSTR     lpCmdLine,
                     int       nCmdShow)
{

	
	std::string temp = lpCmdLine;
	DWORD dword =STD_INPUT_HANDLE;
	DWORD read = 4096;
	int numread = 0;
	LPSTR buffer = new char[4096];
	LPDWORD wasRead = new DWORD();
	*wasRead = 10;
	char readbuffer[10];
	HANDLE hfile = ::GetStdHandle(dword);
	
	ReadFile(hfile,buffer,read,wasRead,NULL);
	_ltoa(*wasRead,readbuffer,10);
	 numread = int(*wasRead);
//  MessageBox(NULL,buffer,"param0",0);

	 std::string test =std::string(buffer);
	 test[int(*wasRead)] = '\0';
	
	// Trimming the buffer
	std::string param[5];
	test[numread]='\0';
			
	
	
	int pos1=0;
	int found= 0;
		int foundlast= 0;

		// Separating the Parameters
		for (int i=0;i<5; i++){
			found = test.find('\n',pos1);
			_itoa(found,readbuffer,10);
			param[i]=test.substr(pos1,found-pos1);
			pos1=found+1;
//			MessageBox(NULL,param[i].c_str(),"param0",0);
			
		}


		

//	Setting Parsmeters to create the Process
	STARTUPINFO StartupInfo;               // startup information
	PROCESS_INFORMATION ProcessInformation;
	ZeroMemory(&StartupInfo,sizeof(StartupInfo));
	StartupInfo.cb=sizeof(STARTUPINFO);
	StartupInfo.wShowWindow=SW_HIDE;
	std::string argument1 = " ";

	
	// Removing the Quotea
	for(i=0;i<5;i++){
		found =param[i].find('\"',0);
		foundlast =param[i].find('\"',found+1);
	
		param[i] =param[i].substr(found+1,(param[i].size()-3)) ;
		found =param[i].find('\"',0);
		param[i] =param[i].substr(0,found) ;
//	MessageBox(NULL,param[i].c_str(),"param0",0);
	}
	argument1 += param[2]+" "+param[3] +" "+"WIN"+" "+ param[4];
	LPSTR arg1 =const_cast<char *>(argument1.c_str());
	std::string	application= param[0];
	application+= "\\";
	application+= param[1];
//	MessageBox(NULL,application.c_str(),"Application",0);
//	MessageBox(NULL,argument1.c_str(),"Argument",0);
	
  CreateProcess(application.c_str(),arg1,NULL,NULL,false,CREATE_NO_WINDOW,NULL,param[0].c_str(),&StartupInfo,&ProcessInformation);
  
	
	return 0;
}



