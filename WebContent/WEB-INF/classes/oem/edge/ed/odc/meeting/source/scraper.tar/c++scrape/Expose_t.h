#ifndef _EXPOSE_H
#define _EXPOSE_H


class Expose_t {

public:
   int x, y, xe, ye, w, h;
   Expose_t* next;

};

#endif
