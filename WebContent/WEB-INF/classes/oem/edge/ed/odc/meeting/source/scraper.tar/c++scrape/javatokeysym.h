#ifndef _JAVATOKEYSYM_H
#define _JAVATOKEYSYM_H


extern "C" int lookup_unicode16_to_keysym(int v);

extern "C" int lookup_java_to_keysym(int v);

extern "C" int lookup_keysym_to_java(int v);



#endif
