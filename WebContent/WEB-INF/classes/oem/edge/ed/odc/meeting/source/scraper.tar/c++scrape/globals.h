
/* global definitions file */

#ifndef _GLOBALS_H
#define _GLOBALS_H


//#define DOTHREADS 
#ifdef DOTHREADS
#include <pthread.h>
#include <stdio.h>
#endif

#ifdef DOTHREADS

// These are routines called if the thread is cancelled/exists. We push the
//  routine on a stack as we get locks, and pop them off as we release them
//
// The cleanup_push/pop code has to be managed carefully. They are macros on
//  some platforms (Sun), which include scoping (braces) ... SO, can't unlock
//  something that was locked at another scope level (which I was doing in one
//  place to get around problems a Condition bug on Sun). 
//
extern "C" void ptcup_ul (void* v);
extern "C" void ptcup_ulr(void* v);
extern "C" void ptcup_ulw(void* v);

#ifdef VERBOSELOCKS

#define thread_lock(a)   fprintf(stderr,                                 \
                                 "Mlocking addr=0x%x:0x%x %s:%d\n",      \
                                 pthread_self(), a, __FILE__, __LINE__); \
                         pthread_mutex_lock((a));                        \
                         pthread_cleanup_push(ptcup_ul, (a));            \
                         fprintf(stderr, "done Mlocking %x\n", (a));
#define thread_unlock(a) fprintf(stderr,                                 \
                                 "Munlocking addr=0x%x:0x%x %s:%d\n",    \
                                 pthread_self(), a, __FILE__, __LINE__); \
                                 pthread_mutex_unlock((a));              \
                                 pthread_cleanup_pop(0);                 \
                                 fprintf(stderr, "done Munlocking %x\n", (a));

#else

#define thread_lock(a)   pthread_mutex_lock((a));            \
                         pthread_cleanup_push(ptcup_ul, (a));

#define thread_unlock(a) pthread_mutex_unlock((a));          \
                         pthread_cleanup_pop(0);

#endif

#ifdef VERBOSELOCKS

#define thread_lock_read(a)  fprintf(stderr, "Rlocking Thrd:0x%x %s:%d\n", pthread_self(),  __FILE__, __LINE__); \
                             pthread_rwlock_rdlock((a)); \
                             pthread_cleanup_push(ptcup_ulr, (a)); \
                             fprintf(stderr, "done Rlocking %x\n", (a));

#define thread_lock_write(a)   fprintf(stderr, "Wlocking Thrd:0x%x %s:%d\n", pthread_self(), __FILE__, __LINE__); \
                               pthread_rwlock_wrlock((a)); \
                               pthread_cleanup_push(ptcup_ulw, (a)); \
                               fprintf(stderr, "done Wlocking %x\n", (a));

#define thread_unlock_read(a)  fprintf(stderr, "RUnlocking Thrd:0x%x %s:%d\n", pthread_self(), __FILE__, __LINE__); \
                               pthread_rwlock_unlock((a)); \
                               pthread_cleanup_pop(0);     \
                               fprintf(stderr, "done RUnlocking %x\n", (a));

#define thread_unlock_write(a)  fprintf(stderr, "WUnlocking Thrd:0x%x %s:%d\n", pthread_self(), __FILE__, __LINE__); \
                                pthread_rwlock_unlock((a)); \
                                pthread_cleanup_pop(0);     \
                                fprintf(stderr, "done WUnlocking %x\n", (a));
#else

#define thread_lock_read(a)    pthread_rwlock_rdlock((a));           \
                               pthread_cleanup_push(ptcup_ulr, (a));
#define thread_lock_write(a)   pthread_rwlock_wrlock((a));           \
                               pthread_cleanup_push(ptcup_ulw, (a));
#define thread_unlock_read(a)  pthread_rwlock_unlock((a));           \
                               pthread_cleanup_pop(0);
#define thread_unlock_write(a) pthread_rwlock_unlock((a));           \
                               pthread_cleanup_pop(0);

#endif

#else
#define thread_lock_read(a)
#define thread_lock_write(a)
#define thread_unlock_read(a)
#define thread_unlock_write(a)
#define thread_lock(a)
#define thread_unlock(a)
#endif


#define BLOCKPOWEROF2
#if defined(BLOCKPOWEROF2)

/* Change the values of BLOCK_BITS at will (within reason) */
#define BLOCK_BITS       6
#define BLOCK_BITS_MASK  ((1 << ((BLOCK_BITS)))-1)
#define BLOCK_WIDTH      (1 << (BLOCK_BITS))
#define BLOCK_HEIGHT     (1 << (BLOCK_BITS))

#define DIV_BLOCK_WIDTH(v)   ((v) >> (BLOCK_BITS))
#define MULT_BLOCK_WIDTH(v)  ((v) << (BLOCK_BITS))
#define MOD_BLOCK_WIDTH(v)   ((v)  & (BLOCK_BITS_MASK))

#define DIV_BLOCK_HEIGHT(v)  DIV_BLOCK_WIDTH(v)  
#define MULT_BLOCK_HEIGHT(v) MULT_BLOCK_WIDTH(v) 
#define MOD_BLOCK_HEIGHT(v)  MOD_BLOCK_WIDTH(v)  
#else 

/* Change the values of BLOCK_WIDTH and BLOCK_HEIGHT at will */
#define BLOCK_WIDTH  64
#define BLOCK_HEIGHT 64

#define DIV_BLOCK_WIDTH(v)   ((v) / (BLOCK_WIDTH))
#define MULT_BLOCK_WIDTH(v)  ((v) * (BLOCK_WIDTH))
#define MOD_BLOCK_WIDTH(v)   ((v) % (BLOCK_WIDTH))
#define DIV_BLOCK_HEIGHT(v)  ((v) / (BLOCK_HEIGHT))
#define MULT_BLOCK_HEIGHT(v) ((v) * (BLOCK_HEIGHT))
#define MOD_BLOCK_HEIGHT(v)  ((v) % (BLOCK_HEIGHT))
#endif


#endif
