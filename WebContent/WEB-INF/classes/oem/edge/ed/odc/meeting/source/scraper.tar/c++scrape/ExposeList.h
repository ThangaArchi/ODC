#ifndef _EXPOSELIST_H
#define _EXPOSELIST_H

#include "Expose_t.h"


class Expose_cb {
public:
   virtual void handle_expose(int x, int y, int w, int h) = 0;
};


class ExposeList {

private:
  Expose_t* expose_head;
  Expose_t* expose_tail;
  Expose_t* expose_freelist;

public:
     ExposeList();
void free_expose(Expose_t* exp);
void add_expose(int x, int y, int w, int h);
int  check_expose(int x, int y, int w, int h);
void clear_exposes();
void handle_exposes(Expose_cb* cb);

};


#endif
