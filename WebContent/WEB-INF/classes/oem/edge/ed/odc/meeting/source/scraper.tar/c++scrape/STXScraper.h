#ifndef _STXSCRAPER_H
#define _STXSCRAPER_H


#include <X11/Xlib.h>
#include <X11/Intrinsic.h>
#include <string.h>
#include "windows.h"


class STXScraper {
   
protected:
   void* src;
   int   debug;
   void* lastimage;
   int   scrapeDelay;
   
public:
   enum InputType {
      SCRAPE_BUTTONPRESS   = LASTEvent + 10,
      SCRAPE_BUTTONRELEASE = LASTEvent + 11,
      SCRAPE_KEYPRESS      = LASTEvent + 12,
      SCRAPE_KEYRELEASE    = LASTEvent + 13,
      SCRAPE_MOUSEMOTION   = LASTEvent + 14,
      SCRAPE_FORCEUPDATE   = LASTEvent + 15,
      SCRAPE_SELECTWINDOW  = LASTEvent + 16
   };

   STXScraper();
   ~STXScraper();
   
  // Set/Get the delay between scrapes (ms)
   void  scrapingDelay(int v);
   int   scrapingDelay();
   
  // Pause and resume scraping. 
   void pauseScrape();
   void resumeScrape();
   
   int  connect(char* sdisplay, int viewonly);
   int  disconnect();
   int  isConnected();
   int  reconfigure(HWND win);
   int  reconfigure(int sx, int sy, int tw, int th);
   HWND GetDesktopWindow();
   int  IsWindow(HWND);
   int  IsWindowIconic(HWND);
   int  IsWindowVisible(HWND);
   int  GetWindowText(HWND, char*, int);
   int  GetWindowTextUnicode(HWND, char*, int);
   HWND GetParent( HWND );
   int  EnumWindows( WNDENUMPROC, LPARAM);
   int  GetWindowTextLength( HWND );
   int  GetWindowRect(HWND , RECT *);
   int  GetCursorPos( POINT * );
   int  InjectKey(int x, int y, int type, int javacodeOrChar, KeySym ksym);
   int  InjectMouse(int x, int y, int type, int buttonNumber);
   
   HWND windowUnderPoint(POINT);
   
   
   /* Grabs the pixels, stored in outbuf as 32-bit Truecolor.
      
      sx and sy is the starting location of the region to grab.
      tw and th is width and height.
      outbuf is a preallocated array for the pixels to be stored in
      len is the amount of memory allocated for outbuf.
         (it should be equal to tw*th*4)
      If newframe is set, then GetWindowPixels will grab new image, 
         rather than from the stack.
      returns 0 if successful, 1 if unsuccesful. */
   int  GetWindowPixels(int sx, int sy, int tw, int th, 
                        unsigned char* outbuf, int len, int newframe);
   
   void SetDebugLevel(int);  // for debugging: 0 = no debug, 6 highest debug
   
   
/* These functions below don't do anything, they are all stubbed. */
   int  OpenIcon( HWND );
   int  SetForegroundWindow( HWND );
   HRGN CreateRectRgn( int, int, int, int );
   int  GetRgnBox( HRGN, RECT *);
   int  PtInRegion(HRGN , int, int );
   int  DeleteObject( HRGN );
   int  GetSystemMetrics( int );
   int  OffsetRgn( HRGN, int, int);
   HWND GetNextWindow(HWND, int);
   int  IsRectEmpty( RECT * );
   int  GetWindowThreadProcessId( HWND, DWORD *);
   int  CombineRgn(HRGN, HRGN, HRGN, int);
   int  GetWindowRgn( HWND, HRGN);
};


#endif
