
#include <string.h>
#include <stdlib.h>
#include "Node.h"


Node::Node() {
   memset(this, 0, sizeof(*this));
}

/* Decouple from sibling tree, and possibly recurse to do Destroy children */
void Node::destroy(int takeChildren, Hash* hash) {
   Node* node = this;
   if (!node->destroyed) {
      if (takeChildren) {
         while(node->children) {
            node->children->destroy(takeChildren, hash);
         }
      }
      
      node->unchain();
      
      if (hash) {
         hash->remove(node->window, HASHTYPE_ANY);
         node->refcnt--;
      }
      
      if (node->image) {
         XDestroyImage(node->image);
      }
      node->destroyed = 1;
   } 

   if (node->refcnt <= 0) {
      if (node->text) {
         free(node->text);
         node->text = 0;
      }
     delete node;
   }
}


Node* Node::unchain() {
   Node* node = this;
   Node* ret = node;
   
   if (!node->left_sibling) {
      if (node->parentnode) {
         node->parentnode->children = node->right_sibling;
      }
   } else {
      node->left_sibling->right_sibling = node->right_sibling;
   }
   
   if (node->right_sibling) {
      node->right_sibling->left_sibling = node->left_sibling;
   }
   
   node->right_sibling = node->left_sibling = 0;
   node->refcnt--;
   
   return ret;
}

void Node::chainLast(Node* parentNode) {
   Node* node = this;
   if (parentNode->children) {
      Node* t = parentNode->children;
      while(t->right_sibling) t = t->right_sibling;
      
      node->right_sibling = 0;
      node->left_sibling  = t;
      t->right_sibling    = node;
      
   } else {
      parentNode->children = node;
      node->right_sibling = node->left_sibling = 0;
   }
   node->parentnode = parentNode;
   node->refcnt ++;
}

void Node::chainFirst(Node* parentNode) {
   Node* node = this;
   if (parentNode->children) {
      parentNode->children->left_sibling = node;
      node->right_sibling = parentNode->children;
      parentNode->children = node;
   } else {
      parentNode->children = node;
      node->right_sibling = node->left_sibling = 0;
   }
   node->parentnode = parentNode;
   node->refcnt ++;
}

void Node::chainBefore(Node* otherNode) {
   Node* node = this;
   node->right_sibling      = otherNode;
   node->left_sibling       = otherNode->left_sibling;
   if (node->left_sibling) {
      node->left_sibling->right_sibling = node;   
   }
   otherNode->left_sibling  = node;
      
   if (otherNode->parentnode->children == otherNode) {
      otherNode->parentnode->children = node;
   }
   node->parentnode = otherNode->parentnode;
   node->refcnt ++;
}

void Node::chainAfter(Node* otherNode) {
   Node* node = this;
   node->right_sibling       = otherNode->right_sibling;
   node->left_sibling        = otherNode;
   if (otherNode->right_sibling) {
      otherNode->right_sibling->left_sibling = node;   
   }
   otherNode->right_sibling  = node;
      
   node->parentnode = otherNode->parentnode;
   node->refcnt ++;
}

