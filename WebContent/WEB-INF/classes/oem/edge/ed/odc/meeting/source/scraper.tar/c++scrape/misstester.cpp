#include "STXScraper.h"
#include <stdio.h>
#include <stdlib.h>
#include <memory.h>

STXScraper *src = 0;
//int SIZE = 5;

#define MAXLIST 1024

int    ncntHWND;

void doWindow(HWND w) {
   char buf[4096];
   fprintf(stdout, "IsWindow of 0x%X       \t [%s]\n", w, 
           src->IsWindow(w)?"true":"false");
   fprintf(stdout, "IsWindowVisible of 0x%X\t [%s]\n", w, 
           src->IsWindowVisible(w)?"true":"false");
   fprintf(stdout, "IsWindowIconic of 0x%X       \t [%s]\n", w, 
           src->IsWindowIconic(w)?"true":"false");
   
   fprintf(stdout, "Parent of 0x%X         \t [0x%X]\n", w, src->GetParent(w));
   
   int l = src->GetWindowTextLength(w);
   fprintf(stdout, "WindowTextLen of 0x%X  \t [%d]\n", w, l);
   if (l) {
      src->GetWindowText(w, buf, sizeof(buf));
      fprintf(stdout, "WindowText of 0x%X     \t [%s]\n", w, buf);
   }
           
   RECT r;
   if (src->GetWindowRect(w, &r)) {
      fprintf(stderr, "WindowExtents for 0x%x \t ERROR\n", w);
   } else {
      fprintf(stdout, "WindowExtents for 0x%X \t (%d, %d) (%d, %d)\n", 
              w, r.left, r.top, r.right, r.bottom);
   }
   fprintf(stdout, "------------------------------------\n");
}

extern "C" LRESULT enumcb(HWND w, LPARAM p) {
   HWND *alist;
   fprintf(stdout, "In Enum => Doing 0x%X\n", w);
   alist = (HWND *)p;
   alist[ncntHWND] = w;
   ncntHWND++;
   
   /* dynamically increase list */
  /*if (ncntHWND == SIZE) {
      int OLDSIZE = SIZE;
      SIZE += 5;
      HWND *oldlist = alist;
      alist = (HWND *)calloc(1,sizeof(HWND)*SIZE);
      *((HWND**)p) = alist;
      int k;
      // copy into new list
      for (k = 0; k < OLDSIZE; k++) {
         alist[k] = oldlist[k];
      }
      
      // free old list
      for (k = 0; k < OLDSIZE; k++) {
         HWND* temp = oldlist;
         oldlist++;
         free(temp);
      }
      }*/
   return 0;
}

void  doPixelsRoot(HWND hwnd)
{
  RECT wRect;
  int  regioncnt = 3;
  fprintf(stdout,"\nNow in doPixelsRoot\n");
  src->reconfigure(hwnd);
  /* get the size of the window */
  if ( 0 == src->GetWindowRect(hwnd,&wRect))
    {
      int  incX, incY;
      int  windW, windH;
      unsigned char *pPixelBuffer;
      int nBuffSize;
      fprintf(stdout,"Window Rect: left:%d top:%d  right:%d bottom:%d\n",wRect.left,wRect.top, wRect.right,wRect.bottom); 
      windW = (wRect.right - wRect.left);
      windH = (wRect.bottom - wRect.top);
      incX = windW / regioncnt;
      incY = windH / regioncnt;
      fprintf(stdout,"incX:%d (mult:%d) incY:%d (mult:%d) \n",incX,incX*regioncnt,incY,incY*regioncnt);
      nBuffSize = (windW+1)*(windH+1);
      if ( NULL != (pPixelBuffer = (unsigned char *)calloc(4,nBuffSize)))  // buffer size of entire window [four bytes to a pixel]
	{
	  int currX, currY;
	  int currW, currH;
	  int tmp;
	  int newframe = 1;
	  for ( currY = 0; currY < windH; currY += incY)
	    {
	      for (currX = 0; currX < windW; currX += incX)
		{
		  currW = (currX+incX <windW)?incX:windW-currX;
		  currH = (currY+incY <windH)?incY:windH-currY;
		  fprintf(stdout,"l:%04d t:%04d  w:%04d h:%04d \n",currX, currY, currW, currH); 
		  if (0 != (tmp =src->GetWindowPixels(currX, currY, currW, currH, 
						 pPixelBuffer, nBuffSize, newframe)))
		    {
		      fprintf(stdout,"Failed to get pixels return: %d\n",tmp);
		    }
		  newframe = 1;
		}
	    }
	  free(pPixelBuffer);
	} 
    }
  else
    {
      fprintf(stdout,"Failed to get rectangle in doPixelsRootn");
    }
  return;
} 

int main(int argc, char* argv[]) {
  int i;
   src = new STXScraper();
   HWND  *listofHWND;
   if (argc < 2) {
      fprintf(stdout, "MissTester ;-) takes a DISPLAY name as parameter and\n"); 
      fprintf(stdout, "               exercises the functions of STXScraper\n");
   }
   if (argc < 2) {
      fprintf(stderr, "Yo, give me a display! Exit\n");
      return -1;
   }
 
   if (!src->connect(argv[1], 1)) {
      src->SetDebugLevel(2); // Note this will not set the XScrape debuging,need 3 or more
      HWND root = src->GetDesktopWindow();
      HWND garbage = 0x55399343;
      fprintf(stdout, "\nRoot Window is 0x%X\n", root);
      doWindow(root);
      fprintf(stdout, "\nDoing GARBAGE window of 0x%X\n", garbage);
      doWindow(garbage);
      fprintf(stdout, "\nCalling EnumWindows\n");
      listofHWND = (HWND *)calloc(MAXLIST, sizeof(HWND));
      ncntHWND = 0;
      src->EnumWindows(enumcb, (LPARAM)listofHWND);
      fprintf(stdout,"Done with enum of windows\n");
      for ( i = 0; i < ncntHWND; i++) {
         fprintf(stdout,"Info on index: %d\n",i);
         doWindow(listofHWND[i]);
      }
      doPixelsRoot(root);
      
   } else {
      fprintf(stderr, "Error connecting to %s\n", argv[1]);
   }
}
