
#include "ExposeList.h"


ExposeList::ExposeList() {
   expose_head = expose_tail = expose_freelist = 0;
}

void ExposeList::free_expose(Expose_t* exp) {
   exp->next = expose_freelist;
   expose_freelist = exp;
}

void ExposeList::add_expose(int x, int y, int w, int h) {
   Expose_t* exp = new Expose_t();
   exp->x  = x;
   exp->y  = y;
   exp->xe = (x + w) - 1;
   exp->ye = (y + h) - 1;
   exp->w  = w;
   exp->h  = h;
   if (!expose_head) {
      expose_head = exp;
   } else {
      expose_tail->next = exp;
   }
   expose_tail = exp;
}

int ExposeList::check_expose(int x, int y, int w, int h) {
   Expose_t* exp = expose_head;
   if (exp) {
      int xe, ye;
      xe = (x + w) - 1;
      ye = (y + h) - 1;
      while(exp) {
         Expose_t* texp = exp;
         
	 /* This clip code needs help ... wrong */
         if (xe < exp->x || x > exp->xe || ye < exp->y || y > exp->ye) {
            break;
         } 
         exp = texp->next;
         free_expose(texp);
      }
   }
   return exp != 0;
}

void ExposeList::clear_exposes() {
   Expose_t* exp = expose_head;
   while(exp) {
      Expose_t* texp = exp;
      exp = texp->next;
      free_expose(texp);
   }
   expose_head = 0;
}

void ExposeList::handle_exposes(Expose_cb* cb) {
   Expose_t* exp = expose_head;
   while(exp) {
      Expose_t* texp = exp;
      cb->handle_expose(exp->x, exp->y, exp->w, exp->h);
      exp = texp->next;
      free_expose(texp);
   }
   expose_head = 0;
   expose_tail = 0;
}
