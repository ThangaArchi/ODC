#ifndef _NODE_H
#define _NODE_H

#include <X11/Xlib.h>
#include <X11/Intrinsic.h>
#include "Hash.h"

class Node {

public:
   XWindowAttributes  attrs;
   Window             window;
   Window             parent;
   
   XImage            *image;
   int                imgrootx, imgrooty;
   int                imageqx,  imageqy;
   int                imagetick;
   
  /* rootx/y   is upper left  placement of window (Absolute coords)
     rootx2/y2 is lower right placement of window (Absolute coords)
  */
   int                rootx, rooty;
   int                rootx2, rooty2;
   
  /* clipx/y   is upper left  clipwindow, clipped to parent
     clipx2/y2 is lower right clipwindow, clipped to parent
  */
   int                clipx,  clipy;
   int                clipx2, clipy2;
   
  /* Bclipx/y   is upper left  clipwindow (as above) with border 
     Bclipx2/y2 is lower right clipwindow (as above) with border
     bclip_width/height are the associated w/h for the above
  */
   int                Bclipx,  Bclipy;
   int                Bclipx2, Bclipy2;
   int                Bclip_width, Bclip_height;
   
   int                orderval;
   int                quadtick, quadret;
   int                quadx, quady;
   int                refcnt;
   int                destroyed;
   
   char              *text;
   int                wm_state;
   
   int                ancestDepthTick;
   Node              *ancestDepthNode;
   
   Node              *left_sibling, *right_sibling;
   Node              *children;
   Node              *parentnode;


        Node();
void    destroy(int takeChildren, Hash* hash);
void    addChild(Node* parent, Node* child);
Node*   unchain();
void    chainLast(Node* parentNode);
void    chainFirst(Node* parentNode);
void    chainBefore(Node* otherNode);
void    chainAfter(Node* otherNode);

// inline functions not used, too many variables to do
void inc_refcnt()    { refcnt++; }
void dec_refcnt()    { refcnt--; }
int  get_destroyed() { return destroyed; }

};

#endif
