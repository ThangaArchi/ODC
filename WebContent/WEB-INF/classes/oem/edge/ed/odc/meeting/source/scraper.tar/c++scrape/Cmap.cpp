#include <stdio.h>
#include <stdlib.h>
#include "Cmap.h"
#include "globalvars.h"


#define MAXCOLVAL       65535

/* Fast table lookup to cvt 24bit to 8bit */
unsigned char cvt_8_to_2[256];
unsigned char cvt_8_to_3[256];
unsigned char cols_8_3 [8] = {0, 18, 54, 91, 128, 164, 201, 237 };
unsigned char cols_8_2 [4] = {0, 42, 128, 213 };


void cmap_init() {
   int i,j,k;
   // JMC 11/5/98 - Fill in direct lookup tables to convert 24 bit to 8 bit
   for(i=j=k=0; i < 256; i++) {
      if (j < 3 && i >= cols_8_2[j+1]) j++;
      cvt_8_to_2[i] = j;
      
      if (k < 7 && i >= cols_8_3[k+1]) k++;
      cvt_8_to_3[i] = k;
   }
}


#define NORMALIZEBITS(col, pv, ov, cmap) {                       \
               (ov)  = ((pv) >> (cmap)-> col ## shift) &         \
                                (cmap)-> col ## norm;            \
               if (cmap->vis-> col ## _mask != 0xff) {           \
                  unsigned long v = (ov) * 0xff;                 \
                  unsigned long q =    v / (cmap)-> col ## norm; \
                  unsigned long r =    v % (cmap)-> col ## norm; \
                  if (r >= ((cmap)-> col ## norm >> 1))          \
                     q++;                                        \
                  (ov) = q;                                      \
               }                                                 \
       }

#define SCALEBITS24(col, ov, cmap) {                             \
               if (cmap-> col ## norm != 0xff) {                 \
                if (cmap->col ## norm == 0x7) {                  \
                   (ov)=cvt_8_to_3[(ov)];                        \
                } else if (cmap->col ## norm == 0x3) {           \
                   (ov)=cvt_8_to_2[(ov)];                        \
                } else {                                         \
                  unsigned long v = (ov) * (cmap)-> col ## norm; \
                  unsigned long q =    v / 0xff;                 \
                  unsigned long r =    v % 0xff;                 \
                  if (r >= (0xff >> 1))                          \
                     q++;                                        \
                  (ov) = q;                                      \
                }                                                \
              }                                                  \
        }
       
       
#define CALC_SHIFTVALUES(r, col) \
       for((r)->col ## shift = 0,                        \
           (r)->col ## norm  = (r)->vis-> col ## _mask;  \
           !((r)->col ## norm & 1);                      \
           (r)->col ## norm >>=1,                        \
           (r)->col ## shift++)                       


/*--------- Cmap_t class functions ---------*/

Cmap::Cmap(unsigned int cid, Visual* vs) {
   Cmap* ret = this;
   ret->id            = cid;
   ret->vis               = vs;
   ret->colors            = 0;
   ret->tickupdated       = 0;
   ret->isstatic          = 0;
   ret->needsInit         = 1;
   ret->lastlookup_valid  = 0;   /* Last lookup in now invalid */
   ret->numXcolors        = 0;
   ret->mappingNeeded     = 1;
   
   switch (vis->c_class) {
      case TrueColor: 
         ret->needsInit = 0;
         ret->isstatic  = 1;
         CALC_SHIFTVALUES(ret, red);
         CALC_SHIFTVALUES(ret, green);
         CALC_SHIFTVALUES(ret, blue);
         if (vis->red_mask   == 0xff0000 &&
             vis->green_mask == 0xff00   &&
             vis->blue_mask  == 0xff) {
            ret->mappingNeeded = 0;
         }
         break;
      case DirectColor: {
         int idx = 0;
         int i;
         CALC_SHIFTVALUES(ret, red);
         CALC_SHIFTVALUES(ret, green);
         CALC_SHIFTVALUES(ret, blue);
         ret->numXcolors = ret->rednorm + ret->greennorm + ret->bluenorm + 3;
         ret->colors = (XColor*)malloc(sizeof(XColor) * ret->numXcolors);
         
        /* Always use blue, then green, then red */
         for(i=0; i <= ret->bluenorm; i++) {
            ret->colors[idx]  .pixel = i << ret->blueshift; 
            ret->colors[idx++].flags = 0x7; 
         }
         for(i=0; i <= ret->greennorm; i++) {
            ret->colors[idx]  .pixel = i << ret->greenshift; 
            ret->colors[idx++].flags = 0x7; 
         }
         for(i=0; i <= ret->rednorm; i++) {
            ret->colors[idx]  .pixel = i << ret->redshift; 
            ret->colors[idx++].flags = 0x7; 
         }
         break;
      }
      case StaticGray:
      case StaticColor:
         ret->isstatic = 1;
      default: {
            int i;
            ret->numXcolors = vis->map_entries;
            ret->colors = (XColor*)malloc(sizeof(XColor) * ret->numXcolors);
            for(i=0; i < ret->numXcolors; i++) {
               ret->colors[i].pixel = i;
               ret->colors[i].flags = 0x7; 
            }
            break;
         }
   }
}

void Cmap::destroy() {
   Cmap* cmap = this;
   if (cmap) {
      if (cmap->colors) {
         free(cmap->colors);
         cmap->colors = 0;
      }
      delete cmap;
   }
}

void Cmap::update(Display* d, int tick) {
   Cmap* cmap = this;
   if (cmap->tickupdated != tick) {
      cmap->tickupdated = tick;
      if (cmap->needsInit) {
      
         XQueryColors(d, cmap->id, cmap->colors, cmap->numXcolors);
      
         if (cmap->isstatic) {
            cmap->needsInit = 0;
         }
         cmap->lastlookup_valid = 0;   /* Last lookup in now invalid */
      }
   }
}
 
 
unsigned long Cmap::unnormalize_pixel(unsigned long pel) {
   Cmap* cmap = this;
   if (cmap->lastlookup_valid && cmap->lastlookup_Pel == pel) {
      return cmap->lastlookup_MapPel;
   }
   
   cmap->lastlookup_Pel = pel;
   switch(cmap->vis->c_class) {
      case TrueColor:
         if (cmap->mappingNeeded) {
            unsigned long ir, ig, ib;
            unsigned long _or, og, ob;
            
            _or = (pel >> 16) & 0xff;
            og = (pel >>  8) & 0xff;
            ob = (pel)       & 0xff;
            
            SCALEBITS24(red,   _or, cmap);
            SCALEBITS24(green, og, cmap);
            SCALEBITS24(blue,  ob, cmap);
            
            pel = _or << cmap->redshift   | 
                  og << cmap->greenshift | 
                  ob << cmap->blueshift;
         }
         break;
         
      case DirectColor:
      case StaticGray:
      case GrayScale:
      case StaticColor:
      case PseudoColor: 
         fprintf(stderr, "Only TrueColor supported for unnormalize_pixel!\n");
         break;
   }
   
   cmap->lastlookup_MapPel = pel;
   cmap->lastlookup_valid  = 1;
   
   return pel;
}

unsigned long Cmap::normalize_pixel(unsigned long pel) {
   Cmap* cmap = this;
   if (cmap->lastlookup_valid && cmap->lastlookup_Pel == pel) {
      return cmap->lastlookup_MapPel;
   }
   
   cmap->lastlookup_Pel = pel;
   switch(cmap->vis->c_class) {
      case TrueColor:
         if (cmap->mappingNeeded) {
            unsigned long _or, og, ob;
            
            NORMALIZEBITS(red  , pel, _or, cmap);
            NORMALIZEBITS(green, pel, og, cmap);
            NORMALIZEBITS(blue , pel, ob, cmap);
            
            pel = _or << 16 | og << 8 | ob;
         }
         break;
         
      case DirectColor: {
      
         unsigned long ridx, gidx, bidx;
         unsigned long r, g, b;
         unsigned int v, t;
         
         ridx = (pel >> cmap->redshift)   & cmap->rednorm;
         gidx = (pel >> cmap->greenshift) & cmap->greennorm;
         bidx = (pel >> cmap->blueshift)  & cmap->bluenorm;
         
         r = ((unsigned long)cmap->colors[cmap->bluenorm  + 
                                          cmap->greennorm + 2 + ridx].red);
         g = ((unsigned long)cmap->colors[cmap->bluenorm  + 1 + gidx].green);
         b = ((unsigned long)cmap->colors[bidx].blue);
         
         v = (r << 8) - r;
         t = v / MAXCOLVAL; 
         if (v % MAXCOLVAL  >= (MAXCOLVAL >> 1)) t++;
         pel = t << 16;

         v = (g << 8) - g;
         t = v / MAXCOLVAL; 
         if (v % MAXCOLVAL  >= (MAXCOLVAL >> 1)) t++;
         pel |= t << 8;
         
         v = (b << 8) - b;
         t = v / MAXCOLVAL; 
         if (v % MAXCOLVAL  >= (MAXCOLVAL >> 1)) t++;
         pel |= t;
         
         break;
      }
      
      case StaticGray:
      case GrayScale:
      case StaticColor:
      case PseudoColor: {
         unsigned long r, g, b;
         unsigned int v, t;
         
         
         if (pel >= cmap->numXcolors) {
            fprintf(stderr, "Pel out of range %d\n", pel);
            return 0;
         }
         
         r = ((unsigned long)cmap->colors[pel].red);
         g = ((unsigned long)cmap->colors[pel].green);
         b = ((unsigned long)cmap->colors[pel].blue);
         
         v = (r << 8) - r;
         t = v / MAXCOLVAL; 
         if (v % MAXCOLVAL  >= (MAXCOLVAL >> 1)) t++;
         pel = t << 16;

         v = (g << 8) - g;
         t = v / MAXCOLVAL; 
         if (v % MAXCOLVAL  >= (MAXCOLVAL >> 1)) t++;
         pel |= t << 8;
         
         v = (b << 8) - b;
         t = v / MAXCOLVAL; 
         if (v % MAXCOLVAL  >= (MAXCOLVAL >> 1)) t++;
         pel |= t;
         
         break;
      }
   }
   
   cmap->lastlookup_MapPel = pel;
   cmap->lastlookup_valid  = 1;
   
   return pel;
}
