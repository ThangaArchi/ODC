
/* The SDMap stores XScraper-Display pairs, so that when the myerrorhandler
   in XScraper is called, the error handler can get the appropriate XSCraper
   obj from the Display passed in. */

#ifndef _SDMAP_H
#define _SDMAP_H

#include "LinkList.h"
#include "XScraper.h"


class SDPair {
public:
   XScraper *xscraper;
   Display  *display;

   SDPair(XScraper* s, Display* d) {
      xscraper = s;
      display  = d;
   }
};


class SDMap {

private:
   LinkList* map;
   // could make it quicker by not using LinkList_t, but okay for now

public:
          SDMap();
void      add_SDPair(XScraper* s, Display* d);
void      remove_SDPair(XScraper* s);
XScraper* get_XScraper(Display* d);

};

#endif
