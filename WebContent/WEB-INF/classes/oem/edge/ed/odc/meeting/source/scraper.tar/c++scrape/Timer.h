#ifndef _TIMER_H
#define _TIMER_H

#include <time.h>
#include <sys/time.h>

/*
** JMC 3/26/02 - time_update_internal generates the actual time. Returns ms
*/

class Timer {

private:
   time_t starttime;
   time_t lasttime;

public:
   int dbug;

unsigned long gettime();
void timer_startForce();
void timer_start();
void timer_printdeltaForce(const char* s);
void timer_printdelta(const char* s);

};

#endif
