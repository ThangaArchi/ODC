
#include <stdlib.h>
#include <string.h>
#include "Hash.h"


unsigned int Hash::hashit(unsigned int key) {
  key += (key << 12);
  key ^= (key >> 22);
  key += (key << 4);
  key ^= (key >> 9);
  key += (key << 10);
  key ^= (key >> 2);
  key += (key << 7);
  key ^= (key >> 12);
  return key;
}



Hash::Hash(int sz) {
   memset(this, 0, sizeof(*this));
   size = sz;
   tab    = (HashEntry_t**)malloc(sizeof(HashEntry_t) * sz);
   memset(tab, 0, sizeof(HashEntry_t) * sz);
}

void Hash::add(unsigned int val, void* data, int type) {
   Hash* hash = this;
   HashEntry_t* he;
   int idx        = HASH(val, hash->size);
   he             = (HashEntry_t*)malloc(sizeof(HashEntry_t));
   he->val        = val;
   he->type       = type;
   he->data       = data;
   he->next       = hash->tab[idx];
   hash->tab[idx] = he;
}

void* Hash::remove(unsigned int val, int type) {
   Hash* hash = this;
   void* ret          = 0;
   int idx            = HASH(val, hash->size);
   HashEntry_t* he    = hash->tab[idx];
   HashEntry_t** last = &hash->tab[idx];
   
   while(he && !(he->val == val &&
                 (type == HASHTYPE_ANY) || type == he->type)) {
      last = &he;
      he   = he->next;
   }
   
   if (he) {
      ret = he->data;
      *last = he->next;
      free(he);
      he = 0;
   }
   
   return ret;
}

void* Hash::find(unsigned int val, int type) {
   Hash* hash = this;
   void* ret       = 0;
   int idx         = HASH(val, hash->size);
   HashEntry_t* he = hash->tab[idx];
   
   while(he && (he->val != val ||
                 (type != HASHTYPE_ANY) && type != he->type)) {
      he = he->next;
   }
   
   if (he) {
      ret = he->data;
   }
   
   return ret;
}

void Hash::hash_free() {
   Hash* hash = this;
   int i;
   for(i=0; i < hash->size; i++) {
      HashEntry_t* he, *the;
      he = hash->tab[i];
      while(he) {
         the = he;
         he  = the->next;
         free(the);
         the = 0;
      }
   }
}
