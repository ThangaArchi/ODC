
#include <string.h>
#include <stdio.h>
#include <sys/types.h>
#include <unistd.h>
#include <stdlib.h>
#include <stdarg.h>
#include "javatokeysym.h"

#include <netinet/in.h>

#include "XScraper.h"


/*
** This files is used for both a JNI sharedlib AND a main program w/o JNI.
**  In the former case, the scraper runs in the process with the JVM, in the
**  latter, there is a protocol defined in the BScraper.java file which is 
**  used to communicate across a pair of pipes to do the deed. As much code is
**  shared as possible.  To that end, I fake out some of these defines.
*/
#ifndef REALJNI

#define byte       signed char
#define jint       int
#define jboolean   int
#define JNIEXPORT  static
#define jobject    void*
#define JNICALL
#define JNIEnv     void
#define jstring    char*
#define JNI_TRUE   1
#define JNI_FALSE  0
#define jbyteArray byte*
#else

#include "DScraper.h"

#endif



// 150 QUADMAX handles 9600 pels if block size is 64
#define QUADMAX     (150)
#define QUADTOTSIZE (QUADMAX*QUADMAX)
struct QuadrantMap {
   unsigned char map[QUADTOTSIZE];
   QuadrantMap() {
      reset();
   }
   
   int calcquad(int x, int y) {
      return DIV_BLOCK_WIDTH(x) + QUADMAX*(DIV_BLOCK_HEIGHT(y));
   }
   
   unsigned char isSet(int x, int y) {
      return map[calcquad(x, y)];
   }
   unsigned char isSet(int q) {
      return map[q];
   }
   void set(int q) {
      map[q] = 1;
   }
   void clear(int q) {
      map[q] = 0;
   }
   void set(int x, int y) {
      map[calcquad(x, y)] = 1;
   }
   void clear(int x, int y) {
      map[calcquad(x, y)] = 0;
   }
   void reset() {
      memset(map, 0, QUADTOTSIZE);
   }
};

class QuadLink : public Link {
   int quad;
public:
   QuadLink(void* v, int q) : Link(v) {
      quad = q;
   }
   int quadrant() { return quad; }
};

struct DScraperData {        

   void deallocate() {
      if (lastImage) {
         xscraper->freeImageBuffer(lastImage);
         lastImage = 0;
      }
      if (currentImage) {
         xscraper->freeImageBuffer(currentImage);
         currentImage = 0;
      }
      if (xscraper) {
         delete xscraper;
         xscraper = 0;
      }
      
      deallocateUpdateList();
      if (quadmap) {
         delete quadmap;
         quadmap = 0;
      }
      
      if (timer) {
         delete timer;
         timer = 0;
      }
   }
   
   void deallocateUpdateList() {
      if (updateList) {
         Link* link;
         while(link=updateList->get_head()) {
            updateList->unchain(link);
            delete (unsigned long*)link->data;
            delete link;
         }
         delete updateList;
         updateList = 0;
      }
   }
   
   XScraper*    xscraper;
   ImageBuffer* currentImage;
   ImageBuffer* lastImage;
   LinkList*    updateList;
   QuadrantMap* quadmap;
   Timer*       timer;
#ifndef REALJNI
   void*        handler;
#endif
   
};
        
        

//
// If not doing threads, avoid the AttachCurrentThread thing ... If using
//  green threads this throws things off ... AND if we are getting movement
//  here, then the 'only thread' is currently in DScraper
//

#ifdef REALJNI
#ifndef DOTHREADS
static int mousemoved = 0;
static jmethodID mouse_mid  = 0;
void checkMouseUpdated(JNIEnv* env, jobject obj) {
   if (mousemoved) {
      mousemoved = 0;
      if (mouse_mid == 0) {
         jclass cls = env->GetObjectClass(obj);
         mouse_mid  = env->GetMethodID(cls, "newPosAvailable", "()V");
         if (mouse_mid != 0) {
            fprintf(stderr, "MethodID = %d\n", mouse_mid);
         }
      }
      
      if (mouse_mid) {
         env->CallVoidMethod(obj, mouse_mid);
      }
   }
}
#else
#define checkMouseUpdated(a, b)
#endif

#else

// This checkMouseUpdated thing was added for non-threaded case. Also helps
//  to generate asynch event for EXE case
static int mousemoved = 0;
void generateMouseEvent(DScraperData*);
void checkMouseUpdated(JNIEnv* env, jobject obj) {
   if (mousemoved) {
      mousemoved = 0;
      generateMouseEvent((DScraperData*)obj);
   }
}
#endif



#ifdef REALJNI
class MyMouseListener : public MouseListener {

   JNIEnv*   env;
   JavaVM*   vm;
   jobject   obj;
   jclass    cls;
   jmethodID mid;
   int       attachTried;
   
public:

   void attachThread() {
      if (vm && !env && !attachTried) {
         attachTried = 1;
         if (vm->AttachCurrentThread((void**)&env, 0)) {
            fprintf(stderr, "MouseListener: Error attaching current Thread\n");
         } else {
            cls = env->GetObjectClass(obj);
            mid = env->GetMethodID(cls, "newPosAvailable", "()V");
            fprintf(stderr, "MethodID = %d\n", 
                    mid);
         }
      }
   }
   MyMouseListener(JNIEnv* e, jobject o) {
   
      env = 0;
#ifndef DOTHREADS
      attachTried = 1;
#else
      attachTried = 0;
      if (e->GetJavaVM(&vm)) {
         fprintf(stderr, "MouseListener: Error getting VM!\n");
      } else {
         obj = e->NewGlobalRef(o);
      }
#endif
   }
   void locationUpdate(int x, int y) {
//      fprintf(stderr, "MouseListener locateUpdate\n");
      attachThread();
#ifndef DOTHREADS
      mousemoved = 1;
#else
      if (env) {
         env->CallVoidMethod(obj, mid);
      } else {
         fprintf(stderr, "DScraper: localUpdate: ... Not connected to VM!!\n");
      }
#endif
   }
};
#else

// Not using JNI
class MyMouseListener : public MouseListener {
private:
   DScraperData* dsdata;
   
public:
   MyMouseListener(JNIEnv* e, jobject o) {
      dsdata = (DScraperData*)o;
   }
   void locationUpdate(int x, int y) {
#ifndef DOTHREADS
      mousemoved = 1;
#else
     // For now, we simply mark that it moved, and the next proto in, will 
     //  generate a move event as well
      mousemoved = 1;
//      fprintf(stdout, "Generate MouseMotion output\n");
#endif
   }
};
#endif
        
        
class DScraperArrCleanup {        
private:

   jobject obj;
#ifdef REALJNI
   JNIEnv* env;
   jintArray arr;
   jint* dsdata;
#endif
   
public:

   DScraperArrCleanup(JNIEnv* lenv, jobject lobj) {
      obj    = lobj;
      
#ifdef REALJNI
      env    = lenv;
   
      jclass cls = env->GetObjectClass(obj);
      
      jfieldID fid = env->GetFieldID(cls, "jnidata", "[I");
      arr    = (jintArray)(env)->GetObjectField(obj, fid);
      dsdata = (env)->GetIntArrayElements(arr, 0);
#endif
      
      checkMouseUpdated(lenv, lobj);
   }
   
   ~DScraperArrCleanup() {
#ifdef REALJNI
      env->ReleaseIntArrayElements(arr, dsdata, 0);
#endif
   }
   
#ifdef REALJNI
   DScraperData* getData() { return (DScraperData*) dsdata; }
#else
   DScraperData* getData() { return (DScraperData*) obj;    }
#endif
};


#define LALA(v, o) (*(((long*)&(v))+(o)))
#define LA(v, o) (arr[(o)-1])

#undef printf

class DebugMsg {
private: 
   char* msg;
   static int debug;
   unsigned long ett;
   
   unsigned long gettime() {
      struct timeval tv;
      gettimeofday(&tv, 0);
      return tv.tv_sec * 1000 + tv.tv_usec / 1000; 
   }
   
public:
   DebugMsg(char* m) {
      msg = m;
      if (debug > 1) {
         ett = gettime();
         fprintf(stderr, "--> Entering [%s] %d\n", msg, ett);
      }
   }
   ~DebugMsg() {
      if (debug > 1) {
         ett = gettime() - ett;
         fprintf(stderr, "<-- Exiting  [%s] delt %d\n", msg, ett);
      }
   }
   
   static void printf(int lev, const char* m="what?\n", ...) {
      if (debug >= lev) {
         va_list argp;
         char* arr[10];
         va_start(argp, m);
         for(int i=0; i < 10; i++) {
            arr[i] = va_arg(argp, char *);
         }
         fprintf(stderr, m, LA(m, 1), LA(m, 2), LA(m, 3), LA(m, 4), LA(m, 5), 
                            LA(m, 6), LA(m, 7), LA(m, 8), LA(m, 9), LA(m, 10));
      }
   }
   
   static void errorf(const char* m="what?\n", ...) {
      va_list argp;
      char* arr[10];
      va_start(argp, m);
      for(int i=0; i < 10; i++) {
         arr[i] = va_arg(argp, char *);
      }
      fprintf(stderr, m, LA(m, 1), LA(m, 2), LA(m, 3), LA(m, 4), LA(m, 5), 
                         LA(m, 6), LA(m, 7), LA(m, 8), LA(m, 9), LA(m, 10));
   }
};

int DebugMsg::debug = 1;

        
        
static LinkList* check_and_change_pixmap(ImageBuffer* lastimg, 
                                         ImageBuffer* curimg, 
                                         QuadrantMap* quadmap) {
   int quads;
   int x, y, wi, hi, i, rem;
   int wblocks;
   int hblocks;
   int pelsperwblock;
   int lastpelsperwblock;
   int pelsperhblock;
   int lastpelsperhblock;
   int iterperline;
   int bytesperpel;
   int bytes_per_line;
   
   DebugMsg msg("calcDifferences");
   
   bytesperpel = 4;
   
   LinkList* ret = new LinkList();
 
   if (curimg == 0) {
      msg.errorf("check_and_change_pixmap: Returning null LIST\n");
      return ret;
   }
   
  // If images are different sizes, take entire curimg
   if (lastimg && (lastimg->get_width()  != curimg->get_width() ||
                   lastimg->get_height() != curimg->get_height())) {
      lastimg = 0;
   }
   
  /* Calculate number of w and h blocks needed */
   wblocks = curimg->get_width()  / BLOCK_WIDTH;
   rem     = curimg->get_width()  % BLOCK_WIDTH;
   if (wblocks == 0) {
      wblocks = 1;
      pelsperwblock = lastpelsperwblock = curimg->get_width();
   } else if (rem) {
      wblocks++;
      pelsperwblock = BLOCK_WIDTH;
      lastpelsperwblock = rem;
   } else {
      pelsperwblock = lastpelsperwblock = BLOCK_WIDTH;
   }
   
   hblocks = curimg->get_height() / BLOCK_HEIGHT;
   rem     = curimg->get_height() % BLOCK_HEIGHT;
   if (hblocks == 0) {
      hblocks = 1;
      pelsperhblock = lastpelsperhblock = curimg->get_height();
   } else if (rem) {
      hblocks++;
      pelsperhblock = BLOCK_HEIGHT;
      lastpelsperhblock = rem;
   } else {
      pelsperhblock = lastpelsperhblock = BLOCK_HEIGHT;
   }
   
   bytes_per_line = bytesperpel*curimg->get_width();
   
  /* 
  ** Process a row of blocks at a time, repeat hblocks times
  */
   y = 0;
   int q = 0;
   for (hi = hblocks; hi; hi--) {
   
      int th = ((hi == 1)?lastpelsperhblock:pelsperhblock);
      
      x = 0;
      
      int lq = q;
      for (wi = wblocks; wi; wi--, q++) {
         int h, tw;
         unsigned char* od, *nd;
         int ofs;
         int doit = 0;
         
         tw=((wi == 1)?lastpelsperwblock:pelsperwblock);
         
         ofs = (x*bytesperpel)+(bytes_per_line*y);
         if (quadmap && !quadmap->isSet(q)) {
            doit = 1;
         } else if (lastimg) {
            od = IMAGEBUFFER_IMAGE(lastimg) + ofs;
            nd = IMAGEBUFFER_IMAGE(curimg)  + ofs;
            for (h = th; h && !doit; h--, od += bytes_per_line, 
                                          nd += bytes_per_line) {
               if (memcmp(od, nd, tw*bytesperpel)) {
                  doit = 1;
                  break;
               }
            }
         }
         
         if (doit || !lastimg) {
            int lx, ly;
            
            if (quadmap) {
               quadmap->clear(q);
            }
            
            int sz = 4 + (tw*th);
            unsigned long *outproto = new unsigned long[sz];
            Link* link = new QuadLink(outproto, q);
            ret->chainLast(link);
            msg.printf(3, "Chaining block\n");
            *outproto++ = x;
            *outproto++ = y;
            *outproto++ = tw;
            *outproto++ = th;

            for (ly = 0; ly < th; ly++) {
               nd = IMAGEBUFFER_IMAGE(curimg) + ofs + (ly*bytes_per_line);
               for (lx = 0; lx < tw; lx++, nd += 4) {
                  unsigned long pel = *(unsigned long*)nd;
                  *outproto++ = pel | 0xff000000;
               }
            }
         }
         
         x += pelsperwblock;
      }
      q = lq + QUADMAX;
      y += pelsperhblock;
   }
   
   return ret;
}
        
        
#ifdef NOPE
#include "zutil.h"

/*
 * Class:     DScraper
 * Method:    compress
 * Signature: ([BII)LCompressInfo;
 */
#define COMPRESSION_THRESHOLD 1024
#define DSCRAPE_ZLEVEL        6
static z_stream* wzlib = 0;
JNIEXPORT jobject JNICALL 
Java_oem_edge_ed_odc_meeting_client_DScraper_compress(JNIEnv * env, 
                                                      jclass cls, 
                                                      jbyteArray arr, 
                                                      jint ofs, jint len) {
                                                 
   jobject ret = 0;
   
   jclass cicls          = env->FindClass("oem/edge/ed/odc/dsmp/common/CompressInfo");
   jmethodID constructID = env->GetMethodID(cicls, "<init>", "([BII)V");
   
   if (len >= COMPRESSION_THRESHOLD) {
      
      int outlen = len/2 + 10;
      
     // Consider creating and init-ing the deflater just Once
      if (!wzlib) {
         wzlib = (z_stream*)malloc(sizeof(z_stream));
         memset(wzlib, 0, sizeof(z_stream));
         deflateInit(wzlib, DSCRAPE_ZLEVEL);
      } else {
         deflateReset(wzlib);
      }
      
      jbyteArray barr       = env->NewByteArray(outlen);
      
      unsigned char* barrp  = (unsigned char*)(env)->GetByteArrayElements(barr, 0);
      wzlib->next_out       = barrp;
      wzlib->avail_out      = outlen;
      
      unsigned char* arrp   = (unsigned char*)(env)->GetByteArrayElements(arr, 0);
      wzlib->next_in        = arrp;
      wzlib->avail_in       = len;
         
      int err = deflate (wzlib, Z_FULL_FLUSH);
      
      env->ReleaseByteArrayElements(barr, (jbyte*)barrp, 0);
      env->ReleaseByteArrayElements(arr,  (jbyte*)arrp,  0);
      
      if (err != 0) {
         fprintf(stderr, "Decompress error %d\n", err);
      } else if (wzlib->avail_in != 0) {
         fprintf(stderr, "Deflate has non-0 avail_in!! %d\n", wzlib->avail_in);
      } else {
         int newlen = outlen - wzlib->avail_out;
         ret = env->NewObject(cicls, constructID, barr, 0, newlen);
      }
      
     //deflateEnd(wzlib);
     //free(wzlib);
   }
   
   if (ret == 0) {
      ret = env->NewObject(cicls, constructID, arr, ofs, len);
   }
   
   return ret;
}
#endif


/*---------------------------------------------------------------*\
**---------------------------------------------------------------**
**------ Hear Ye Hear ye ... This file supports both JNI AND ----**
**------  non-JNI functioning. The JNIEnv is ignored for non ----**
**--------use. The main jobject is really DScraperData as well --**
**---------------------------------------------------------------**
\*---------------------------------------------------------------*/

/*
 * Class:     DScraper
 * Method:    scrapingDelayI
 * Signature: (I)V
 */
JNIEXPORT void JNICALL 
Java_oem_edge_ed_odc_meeting_client_DScraper_scrapingDelayI(JNIEnv *env, 
                                                            jobject obj, 
                                                            jint v) {
   DebugMsg msg("scrapingDelayI");
   DScraperArrCleanup dsac(env, obj);
   DScraperData*      dsdata = dsac.getData();
   
   if (dsdata->xscraper) {
      dsdata->xscraper->setScrapeDelay(v);
   }
}

/*
 * Class:     DScraper
 * Method:    pause
 * Signature: ()V
 */
JNIEXPORT void JNICALL 
Java_oem_edge_ed_odc_meeting_client_DScraper_pause(JNIEnv * env, 
                                                   jobject obj) {
   DebugMsg msg("pause");
   DScraperArrCleanup dsac(env, obj);
   DScraperData*      dsdata = dsac.getData();
   
   if (dsdata->xscraper) {
      dsdata->xscraper->pauseScrape();
   }
}

/*
 * Class:     DScraper
 * Method:    resume
 * Signature: ()V
 */
JNIEXPORT void JNICALL 
Java_oem_edge_ed_odc_meeting_client_DScraper_resume(JNIEnv * env, 
                                                    jobject obj) {
   DebugMsg msg("resume");
   DScraperArrCleanup dsac(env, obj);
   DScraperData*      dsdata = dsac.getData();
   
   if (dsdata->xscraper) {
      dsdata->xscraper->resumeScrape();
   }
}


#define CANNOTCONNECT \
        "You are attempting to scrape an AIX XWindows Display which has " \
        "backingstore turned on. A bug fix (APAR IY33464/IY35566) is available " \
        "to allow this mode of operation, but it is not currently installed " \
        "on this system. To start a meeting from this Display, you must either " \
        "restart your XServer without backing store (omit the -bs option), or " \
        "obtain and apply the specified APAR (contact your IBM service " \
        "representative"

#define POTENTIALCONNECTERROR \
        "You are attempting to scrape an AIX XWindows Display which has " \
        "backingstore turned on. A bug fix (APAR IY33464/IY35566) is available " \
        "to allow this mode of operation, but it cannot be determined if this fix " \
        "is installed. To start a meeting from this Display, you must either " \
        "restart your XServer without backing store (omit the -bs option), or " \
        "obtain and apply the specified APAR (contact your IBM service " \
        "representative.\n\n If you know that the specified APAR is applied, " \
        "hit the FORCE button to force the start of the meeting. Note that " \
        "this may cause the XServer to hang if in fact the fix is NOT applied"
/*
 * Class:     DScraper
 * Method:    connect
 * Signature: (Ljava/lang/String;ZZ)I
 */
JNIEXPORT jint JNICALL 
Java_oem_edge_ed_odc_meeting_client_DScraper_connect (JNIEnv  *env, 
                                                      jobject  obj, 
                                                      jstring  disp, 
                                                      jboolean viewonly, 
                                                      jboolean force) {
                                              
   DebugMsg msg("connect");
   jint ret = -1;
   DScraperArrCleanup dsac(env, obj);
   DScraperData*      dsdata = dsac.getData();
   
#ifdef REALJNI
   const char* dispStr = (env)->GetStringUTFChars(disp, 0);
#else
   const char* dispStr = disp;
#endif
   
   
   int vonly = viewonly == JNI_TRUE;
   msg.printf(1, "Doing Connect for %s viewonly=%s\n", dispStr,
              (char*)(vonly?"True":"False"));
   if (!dsdata->xscraper) {
   
      dsdata->xscraper = new XScraper();
      
//      dsdata->xscraper->set_debug(3);
//      dsdata->xscraper->set_timerdbug(3);
      
     // Set only 1 image at a time, and 2 free images
      dsdata->xscraper->setImageBuffering(1, 2);
      
#ifdef REALJNI
      jclass cls   = env->GetObjectClass(obj);
      jfieldID fid = env->GetFieldID(cls, "scrapeDelay", "I");
      jint sd      = (jint)(env)->GetIntField(obj, fid);
      dsdata->xscraper->setScrapeDelay(sd);
#endif

      dsdata->quadmap  = new QuadrantMap();
      dsdata->timer = new Timer();
      dsdata->timer->dbug = 0;
   }
   
   ret = dsdata->xscraper->connect((char*)dispStr, vonly | (force?0x80:0));
   
#ifdef REALJNI
   (env)->ReleaseStringUTFChars(disp, dispStr);
#endif
   
#ifdef REALJNI
   if (ret != 0 && ret != 1) {
      switch(ret) {
         case APAR_NOT_INSTALLED: {
            jclass exceptclass   = 
               env->FindClass("oem/edge/ed/odc/meeting/client/BScraper$MissingDependencies");
            jmethodID exceptID = env->GetMethodID(exceptclass, "<init>", 
                                                  "(Loem/edge/ed/odc/meeting/client/BScraper;Ljava/lang/String;)V");
            
            jstring errstr = env->NewStringUTF(CANNOTCONNECT);

            jthrowable exception = (jthrowable)
               env->NewObject(exceptclass, exceptID, env->NewGlobalRef(obj),
                              errstr);
            env->Throw(exception);
            return ret;
         }
            
         case CANT_CHECK_IF_APAR_INSTALLED:
         case INCONCLUSIVE_APAR_CHECK: 
         default: {
            jclass exceptclass   = 
               env->FindClass("oem/edge/ed/odc/meeting/client/BScraper$PossibleMissingDependencies");
            jmethodID exceptID = env->GetMethodID(exceptclass, "<init>", 
                                                  "(Loem/edge/ed/odc/meeting/client/BScraper;Ljava/lang/String;)V");
            
            jstring errstr = env->NewStringUTF(POTENTIALCONNECTERROR);

            jthrowable exception = (jthrowable)
               env->NewObject(exceptclass, exceptID, env->NewGlobalRef(obj),
                              errstr);
            env->Throw(exception);
            return ret;
         }
      }
   }
#endif
   
  // Hook things up so DScraper.getCurrentPosition_Wait works
   dsdata->xscraper->addMouseListener(new MyMouseListener(env, obj));
      
   return ret;
}

/*
 * Class:     DScraper
 * Method:    disconnect
 * Signature: ()V
 */
JNIEXPORT void JNICALL 
Java_oem_edge_ed_odc_meeting_client_DScraper_disconnect (JNIEnv *env, 
                                                         jobject obj) {
   DebugMsg msg("disconnect");
   DScraperArrCleanup dsac(env, obj);
   DScraperData*      dsdata = dsac.getData();
   
   if (dsdata->xscraper) {
      msg.printf(1, "Doing disconnect\n");
      dsdata->xscraper->disconnect();
      msg.printf(1, "Done with disconnect\n");
      
      dsdata->deallocate();
      memset(dsdata, 0, sizeof(*dsdata));
   }
}

/*
 * Class:     DScraper
 * Method:    selectWindow
 * Signature: ()I
 */
JNIEXPORT jint JNICALL 
Java_oem_edge_ed_odc_meeting_client_DScraper_selectWindow(JNIEnv *env, 
                                                          jobject obj) {
   DebugMsg msg("selectWindow");
   DScraperArrCleanup dsac(env, obj);
   DScraperData*      dsdata = dsac.getData();
   
   jint ret  = 0;
   
   if (dsdata->xscraper) {
      ret = dsdata->xscraper->selectWindow();
   }
   return ret;
}
  
/*
 * Class:     DScraper
 * Method:    getDesktopWindow
 * Signature: ()I
 */
JNIEXPORT jint JNICALL 
Java_oem_edge_ed_odc_meeting_client_DScraper_getDesktopWindow (JNIEnv *env, 
                                                               jobject obj) {
   DebugMsg msg("getDesktopWindow");
   jint ret = 0;
   DScraperArrCleanup dsac(env, obj);
   DScraperData*      dsdata = dsac.getData();
   
   if (dsdata->xscraper) {
      ret = dsdata->xscraper->getDesktopWindow();
   }
   return ret;
}

/*
 * Class:     DScraper
 * Method:    getToplevelWindows
 * Signature: ()Ljava/util/Vector;
 */
JNIEXPORT jobject JNICALL 
Java_oem_edge_ed_odc_meeting_client_DScraper_getToplevelWindows (JNIEnv *env, 
                                                                 jobject obj) {
   DebugMsg msg("getToplevelWindows");
   jobject ret = 0;
   DScraperArrCleanup dsac(env, obj);
   DScraperData*      dsdata = dsac.getData();
   
   if (dsdata->xscraper) {
      LinkList* ll = dsdata->xscraper->enumerateWindows();
      
#ifdef REALJNI
      jclass veccls = env->FindClass("java/util/Vector");
      jclass intcls = env->FindClass("java/lang/Integer");
      jmethodID constructVecID  = env->GetMethodID(veccls, "<init>", "()V");
      jmethodID addElementID    = env->GetMethodID(veccls, "addElement", 
                                              "(Ljava/lang/Object;)V");
      jmethodID constructIntID  = env->GetMethodID(intcls, "<init>", "(I)V");
      jobject vec = env->NewObject(veccls, constructVecID);
      ret = vec;
      if (ll) {
         Link* link;
         while(link = ll->get_head()) {
            ll->unchain(link);
            int window = *(int*)link->data;
            free((int*)link->data);
            delete link;
            link = 0;
            
            jobject newint = env->NewObject(intcls, constructIntID, window);
            env->CallVoidMethod(vec, addElementID, newint);
         }
         delete ll;
         ll = 0;
      }
#else 
      ret = ll;
#endif
   }
   return ret;
}

/*
 * Class:     DScraper
 * Method:    configureToWindow
 * Signature: (I)I
 */
JNIEXPORT jint JNICALL 
Java_oem_edge_ed_odc_meeting_client_DScraper_configureToWindow(JNIEnv *env, 
                                                               jobject obj, 
                                                              jint    window) {
   DebugMsg msg("configureToWindow");
   jint ret = 1;
   DScraperArrCleanup dsac(env, obj);
   DScraperData*      dsdata = dsac.getData();
   
   if (dsdata->xscraper) {
      ret = dsdata->xscraper->reconfigure(window);
      
      dsdata->deallocateUpdateList();
   
      if (dsdata->lastImage) {
         dsdata->xscraper->freeImageBuffer(dsdata->lastImage);
         dsdata->lastImage = 0;
      }
      if (dsdata->currentImage) {
         dsdata->xscraper->freeImageBuffer(dsdata->currentImage);
         dsdata->currentImage = 0;
      }
   }
   return ret;
}

/*
 * Class:     DScraper
 * Method:    configureToDesktop
 * Signature: ()I
 */
JNIEXPORT jint JNICALL 
Java_oem_edge_ed_odc_meeting_client_DScraper_configureToDesktop(JNIEnv *env, 
                                                                jobject obj) {
   DebugMsg msg("configureToDesktop");
   jint ret = 1;
   DScraperArrCleanup dsac(env, obj);
   DScraperData*      dsdata = dsac.getData();
   
   if (dsdata->xscraper) {
      ret = 
         dsdata->xscraper->reconfigure(dsdata->xscraper->getDesktopWindow());
         
      dsdata->deallocateUpdateList();
   
      if (dsdata->lastImage) {
         dsdata->xscraper->freeImageBuffer(dsdata->lastImage);
         dsdata->lastImage = 0;
      }
      if (dsdata->currentImage) {
         dsdata->xscraper->freeImageBuffer(dsdata->currentImage);
         dsdata->currentImage = 0;
      }
   }
   return ret;
}


/*
 * Class:     DScraper
 * Method:    configure
 * Signature: (IIII)I
 */
JNIEXPORT jint JNICALL 
Java_oem_edge_ed_odc_meeting_client_DScraper_configure(JNIEnv *env, 
                                                       jobject obj, 
                                                       jint x, jint y, 
                                                       jint w, jint h) {
   DebugMsg msg("configure");
   jint ret = 1;
   DScraperArrCleanup dsac(env, obj);
   DScraperData*      dsdata = dsac.getData();
   
   if (dsdata->xscraper) {
      ret = dsdata->xscraper->reconfigure(x, y, w, h);
      
      dsdata->deallocateUpdateList();
   
      if (dsdata->lastImage) {
         dsdata->xscraper->freeImageBuffer(dsdata->lastImage);
         dsdata->lastImage = 0;
      }
      if (dsdata->currentImage) {
         dsdata->xscraper->freeImageBuffer(dsdata->currentImage);
         dsdata->currentImage = 0;
      }
 }
   return ret;
}

/*
 * Class:     DScraper
 * Method:    getWindowTitle
 * Signature: (I)Ljava/lang/String;
 */
JNIEXPORT jstring JNICALL 
Java_oem_edge_ed_odc_meeting_client_DScraper_getWindowTitle(JNIEnv *env, 
                                                            jobject obj, 
                                                            jint    window) {
   DebugMsg msg("getWindowTitle");
   jstring ret = 0;
   
   DScraperArrCleanup dsac(env, obj);
   DScraperData*      dsdata = dsac.getData();
   
   if (dsdata->xscraper) {
      char s[1024];
      int l;
      l=dsdata->xscraper->getWindowText((Window)window, (char*)s, sizeof(s));
      
      if (!l) {
         XRectangle xrec; memset(&xrec, 0, sizeof(xrec));
         l=dsdata->xscraper->getWindowExtents(window, &xrec, 1);
         sprintf(s, "*Unnamed Window* x,y(%d, %d) w,h(%d, %d) id[0x%x]", 
                 xrec.x, xrec.y, xrec.width, xrec.height, window);
      }
#ifdef REALJNI
      ret = env->NewStringUTF(s);
#else
      ret = new char[strlen(s)+1];
      strcpy (ret, s);
#endif
   }
   
   return ret;
}

/*
 * Class:     DScraper
 * Method:    getCursorPosition
 * Signature: ()Ljava/awt/Point;
 */
JNIEXPORT jobject JNICALL 
Java_oem_edge_ed_odc_meeting_client_DScraper_getCursorPosition(JNIEnv *env, 
                                                               jobject obj) {
   DebugMsg msg("getCursorPosition");
   jobject ret = 0;
   
   DScraperArrCleanup dsac(env, obj);
   DScraperData*      dsdata = dsac.getData();
   
   if (dsdata->xscraper) {
                                               
      XPoint xpoint;
      dsdata->xscraper->getCursorPosition(&xpoint);
      
      msg.printf(2, "DScraper: GCP(%d, %d)", xpoint.x, xpoint.y);
      if (dsdata->currentImage) {
         xpoint.x -= dsdata->currentImage->get_rootx();
         xpoint.y -= dsdata->currentImage->get_rooty();
         msg.printf(2, "  (%d, %d)\n", xpoint.x, xpoint.y);
      }
      
#ifdef REALJNI
      jclass pointcls = env->FindClass("java/awt/Point");
      jmethodID constructPointID = env->GetMethodID(pointcls, 
                                                    "<init>", "(II)V");
      ret = env->NewObject(pointcls, constructPointID, xpoint.x, xpoint.y);
#else
      *((XPoint*)(ret = new XPoint())) = xpoint;
#endif
   }
   return ret;
}

/*
 * Class:     DScraper
 * Method:    getCurrentFrame
 * Signature: ()Ljava/awt/Rectangle;
 */
JNIEXPORT jobject JNICALL 
Java_oem_edge_ed_odc_meeting_client_DScraper_getCurrentFrame(JNIEnv *env, 
                                                             jobject obj) {
   
   DebugMsg msg("getCurrentFrame");
   jobject ret = 0;
   
   DScraperArrCleanup dsac(env, obj);
   DScraperData*      dsdata = dsac.getData();
   
   if (dsdata->currentImage) {
#ifdef REALJNI
      jclass rectcls = env->FindClass("java/awt/Rectangle");
      jmethodID constructRectID = env->GetMethodID(rectcls, 
                                                   "<init>", "(IIII)V");
                                               
      ret = env->NewObject(rectcls, constructRectID,
                           dsdata->currentImage->get_rootx(),       
                           dsdata->currentImage->get_rooty(),       
                           dsdata->currentImage->get_width(),       
                           dsdata->currentImage->get_height());
#else
      XRectangle* lret = new XRectangle();
      lret->x      = dsdata->currentImage->get_rootx();
      lret->y      = dsdata->currentImage->get_rooty();
      lret->width  = dsdata->currentImage->get_width();
      lret->height = dsdata->currentImage->get_height();
      ret = lret;
#endif
   }
   return ret;
}
  
/*
 * Class:     DScraper
 * Method:    getNewFrame
 * Signature: (Z)Ljava/awt/Rectangle;
 */
JNIEXPORT jobject JNICALL 
Java_oem_edge_ed_odc_meeting_client_DScraper_getNewFrame(JNIEnv *env, 
                                                         jobject obj,
                                                       jboolean forceupdate) {
   jobject ret = 0;
   
   DebugMsg msg("getNewFrame");
   DScraperArrCleanup dsac(env, obj);
   DScraperData*      dsdata = dsac.getData();
   
   if (dsdata->xscraper) {
      dsdata->deallocateUpdateList();
   
      if (dsdata->lastImage) {
         dsdata->xscraper->freeImageBuffer(dsdata->lastImage);
         dsdata->lastImage = 0;
      }
      if (forceupdate) {
         dsdata->xscraper->freeImageBuffer(dsdata->currentImage);
      } else {
         dsdata->lastImage    = dsdata->currentImage;
      }
      dsdata->timer->timer_printdelta("Frame Done ... getting new frame");
      dsdata->timer->timer_start();
      dsdata->currentImage = dsdata->xscraper->getImageFromStack();
      if (dsdata->currentImage == 0) {
         msg.printf(2, "Image is NULL!");
      }
      dsdata->timer->timer_printdelta("Got new frame - C&C");
      dsdata->updateList   = check_and_change_pixmap(dsdata->lastImage, 
                                                     dsdata->currentImage,
                                                     dsdata->quadmap);
      dsdata->timer->timer_printdelta("C&C Done");
      
      if (dsdata->currentImage) {
#ifdef REALJNI
         jclass rectcls = env->FindClass("java/awt/Rectangle");
         jmethodID constructRectID = env->GetMethodID(rectcls, 
                                                      "<init>", "(IIII)V");
         
         ret = env->NewObject(rectcls, constructRectID,
                              dsdata->currentImage->get_rootx(),       
                              dsdata->currentImage->get_rooty(),       
                              dsdata->currentImage->get_width(),       
                              dsdata->currentImage->get_height());
#else
         XRectangle* lret = new XRectangle();
         lret->x      = dsdata->currentImage->get_rootx();
         lret->y      = dsdata->currentImage->get_rooty();
         lret->width  = dsdata->currentImage->get_width();
         lret->height = dsdata->currentImage->get_height();
         ret = lret;
#endif
      }
   }
   return ret;
}


/*
 * Class:     DScraper
 * Method:    isModeStillValid
 * Signature: ()Z
 */
JNIEXPORT jboolean JNICALL 
Java_oem_edge_ed_odc_meeting_client_DScraper_isModeStillValid (JNIEnv *env, 
                                                               jobject obj) {
   jboolean ret = JNI_FALSE;
   
   DebugMsg msg("isModeStillValid");
   DScraperArrCleanup dsac(env, obj);
   DScraperData*      dsdata = dsac.getData();
   
   if (dsdata->xscraper ) {
      if (dsdata->xscraper->isCurrentModeStillValid()) {
         ret = JNI_TRUE;
      }
   }   
   return ret;
}

/*
 * Class:     DScraper
 * Method:    replayLastFrame
 * Signature: ()Ljava/awt/Rectangle;
 */
JNIEXPORT jobject JNICALL 
Java_oem_edge_ed_odc_meeting_client_DScraper_replayLastFrame(JNIEnv *env, 
                                                             jobject obj) {
   jobject ret = 0;
   
   DebugMsg msg("getNewFrame");
   DScraperArrCleanup dsac(env, obj);
   DScraperData*      dsdata = dsac.getData();
   
   if (dsdata->xscraper) {
      dsdata->deallocateUpdateList();
   
      if (dsdata->lastImage) {
         dsdata->xscraper->freeImageBuffer(dsdata->lastImage);
         dsdata->lastImage = 0;
      }
      
      if (dsdata->currentImage) {
         dsdata->updateList   = check_and_change_pixmap(dsdata->lastImage, 
                                                        dsdata->currentImage,
                                                        dsdata->quadmap);
#ifdef REALJNI
         jclass rectcls = env->FindClass("java/awt/Rectangle");
         jmethodID constructRectID = env->GetMethodID(rectcls, 
                                                      "<init>", "(IIII)V");
         
         ret = env->NewObject(rectcls, constructRectID,
                              dsdata->currentImage->get_rootx(),       
                              dsdata->currentImage->get_rooty(),       
                              dsdata->currentImage->get_width(),       
                              dsdata->currentImage->get_height());
#else
         XRectangle* lret = new XRectangle();
         lret->x      = dsdata->currentImage->get_rootx();
         lret->y      = dsdata->currentImage->get_rooty();
         lret->width  = dsdata->currentImage->get_width();
         lret->height = dsdata->currentImage->get_height();
         ret = lret;
#endif
      }
   }
   return ret;
}

void tryUpdateUpdateList(DScraperData* dsdata) {
   if (dsdata->updateList && dsdata->updateList->get_numLinks() > 10 && 
       dsdata->currentImage) {
      ImageBuffer* cimg = dsdata->currentImage;
      ImageBuffer* img = dsdata->xscraper->popImageXYWH(cimg);
      if (img) {
         int prenum = dsdata->updateList->get_numLinks();
         if (dsdata->lastImage) {
            dsdata->xscraper->freeImageBuffer(dsdata->lastImage);
            dsdata->lastImage = 0;
         }
         dsdata->lastImage    = dsdata->currentImage;
         dsdata->currentImage = img;
         
        // Remember the quadrant we were on
         QuadLink * qlink = (QuadLink*)dsdata->updateList->get_head();
         int quad = qlink->quadrant();
         
         dsdata->deallocateUpdateList();
         dsdata->updateList   = 
            check_and_change_pixmap(dsdata->lastImage, 
                                    dsdata->currentImage,
                                    dsdata->quadmap);
                                    
        // Reorder the quads to start where we left off
         qlink = (QuadLink*)dsdata->updateList->get_head();
         while(qlink && qlink->quadrant() != quad) {
            qlink = (QuadLink*)qlink->right;
         }
         
        // Found the quadrant we left off on ... make it the head
         if (qlink) {
            dsdata->updateList->make_linkHead(qlink);
         }
         
         int num = dsdata->updateList->get_numLinks();
         fprintf(stderr, "UpdatingUpdateList %d ==> %d\n", prenum, num);
      }
   } 
}

/*
 * Class:     DScraper
 * Method:    getUpdatedPixels
 * Signature: ()[I
 */

union endian_checker_t {
   unsigned short s;
   struct ss {
      unsigned char hi;
      unsigned char lo;
   } bytes;
};



int* runlengthDecode(unsigned char* arr, int ofs, int len, int unencodedLen) {
   int *ret = new int[unencodedLen];
   int i=ofs;
   int o=0;
   len += ofs;
   while(i < len) {
      signed char l = arr[i++];
      if (l < 0) {
         int realL = ((int)(-l)) + 1;
         int v = 0xff000000 | ((((int)arr[i++]) & 0xff) << 16);
         v |= ((((int)arr[i++]) & 0xff) << 8);
         v |= ((((int)arr[i++]) & 0xff));
//         printf("OP = Same[%d] Val[0x%08.8x]\n", realL, v);
         while(realL-- > 0) {
            ret[o++] = v;
         }
      } else {
         int realL = ((int)(l)) + 1;
//         printf("OP = DIFF[%d]\n", realL);
         while(realL-- > 0) {
            int v = 0xff000000 | ((((int)arr[i++]) & 0xff) << 16);
            v |= ((((int)arr[i++]) & 0xff) << 8);
            v |= ((((int)arr[i++]) & 0xff));
            ret[o++] = v;
//            printf("\t[0x%08.8x]\n", v);
         }
      }
   }
   return ret;
}


// Take data 4 bytes at a time
#define BYTES_AT_A_TIME (4)
int runlengthEncode(unsigned char* outp, unsigned char* inp, int len) {

   int ret = 0;
   
  // if len is NOT % 4, return error
   if (len & 0x3) return -1;
   if (!len) return 0;
   
   unsigned char* startp  = inp;
   
   unsigned char* stopinp = inp+len;
   unsigned char*    comp = 0;    // Pointer to compare int
   unsigned char*      lp = 0;    // Pointer to start of inp for copy
   int           sameDiff = 0;    // Processing DIFF < 0 < SAME
   int                num = 0;
   int            flushit = 0;
   
   while(ret < len && inp < stopinp) {
   
      
      if (!num) {
         lp   = inp;
         comp = inp;
         inp += BYTES_AT_A_TIME;
         num++;
      } else {
         
         int compvalue = memcmp(comp, inp, BYTES_AT_A_TIME); 
         if        (sameDiff > 0) {
            if (!compvalue) {
               num++;
               inp += BYTES_AT_A_TIME;
            } else {
               flushit = 1;
            }
         } else if (sameDiff < 0) {
            if (!compvalue) {
               flushit=1;   // Flush it out, 
               num--;       // Take AWAY the last one
               inp -= BYTES_AT_A_TIME;
            } else {
               num++;
               comp = inp;
               inp += BYTES_AT_A_TIME;
            }
         } else {
            comp = inp;
            num++;
            inp += BYTES_AT_A_TIME;
            sameDiff = compvalue?-1:1;
         }
      }
      
     // Flush
      if (flushit || num >= 128 || inp == stopinp) {
         flushit = 0;
         if (num) {
            int cnt = 0;
            if (sameDiff >= 0) {
               cnt  = 1-num;
               num = 1;
            } else {
               cnt = num-1;
            }
            
            ret += 1 + (3*num);
            if (ret >= len) break;
            *outp++  = (unsigned char)cnt;
            
//            fprintf(stderr, "op[%d] [%d]", cnt, num);
            
            while(num--) {
               int t;
               memcpy(&t, lp, 4);
               
//               fprintf(stderr, " 0x%06.6x", t & 0xffffff);
               
               lp += 4;
               *outp++ = (unsigned char)(t >> 16);
               *outp++ = (unsigned char)(t >> 8);
               *outp++ = (unsigned char)(t);
            }
//            fprintf(stderr, "\n");
            
            num = 0;
            sameDiff = 0;
         }         
      }      
   }
   if (inp < stopinp || ret > len) ret = -1;
   
//   if (ret > 0) {
//      fprintf(stderr, "RLE: %d -> %d\n", len, ret);
//   }
   
   return ret;
}

#ifdef RLEDEBUG
int rlemain() {
   int a[] = { 0xff444444, 
                  0xff444444, 
                  0xff444444, 
                  0xff444445, 
                  0xff444444, 
                  0xff444444, 
                  0xff444444, 
                  0xff000000, 
                  0xff444444, 
                  0xff000000, 
                  0xff444444, 
                  0xff000000, 
                  0xff444444, 
                  0xff444444, 
                  0xff444443, 
                  0xff444444};
   unsigned char out[1024];
   int ll = runlengthEncode(out, (unsigned char*)a, sizeof a);
   
   int* uucp = runlengthDecode(out, 0, ll, sizeof a);
   if (!memcmp(uucp, a, sizeof a)) {
      fprintf(stderr, " [SAME]\n");
   } else {
      int tl = (sizeof a)>>2;
      char s1[80], s2[80];
      int k;
      for(k=0; k < tl; k++) {
         if (k % 8 == 0) {
            if (k) {
               fprintf(stderr, "%s%s\n", s1, s2);
            }
            sprintf(s1, "\n%d:\t", k);
            sprintf(s2, "\n%d:\t", k);
         }
         sprintf(s1, " 0x%08.8x", ((int*)a)[k]);
         sprintf(s2, " 0x%08.8x", uucp[k]);
      }
      fprintf(stderr, "%s%s\n", s1, s2);
   }
}
#endif


#ifdef REALJNI

// THIS IS NOT WORKING NOW!!! Needs to be updated with 
// correct return values (size) - Make things network order

JNIEXPORT jintArray JNICALL 
Java_oem_edge_ed_odc_meeting_client_DScraper_getUpdatedPixels(JNIEnv *env, 
                                                              jobject obj,
                                                              jintArray ret) {
   DebugMsg msg("getUpdatedPixels");
   
   DScraperArrCleanup dsac(env, obj);
   DScraperData*      dsdata = dsac.getData();
   
   fprintf(stderr, "DScraper::getUpdatePixels ... UPDATE ME!!!");
   if (dsdata->xscraper) {
      
      tryUpdateUpdateList(dsdata);
      if (dsdata->updateList && dsdata->updateList->get_head()) {
         QuadLink* link = (QuadLink*)dsdata->updateList->get_head();
         
         dsdata->updateList->unchain(link);
         
         dsdata->quadmap->set(link->quadrant());
         
         unsigned long *inarr = (unsigned long*)link->data;
         int sz = 4+(inarr[2] * inarr[3]);
         
         
         if (!ret) {
            ret = env->NewIntArray((BLOCK_WIDTH*BLOCK_HEIGHT) + 4);
         }
         
         msg.printf(2, "updatepixels (%d, %d) (%d, %d)\n", 
                    inarr[0], inarr[1], inarr[2], inarr[3]);
         unsigned long* arr = (unsigned long*)(env)->GetIntArrayElements(ret, 
                                                                         0);
                                                                         
         runlengthEncode((unsigned char*)arr, (unsigned char*)inarr, sz*4);
         
//         memcpy(arr, inarr, sz*4);
         
         delete inarr;
         delete link;
         
         env->ReleaseIntArrayElements(ret, (jint*)arr, 0);
         
      } else {
         ret = 0;
      }
   } else {
      ret = 0;
   }
   return ret;
}

/*
 * Class:     DScraper
 * Method:    getUpdatedPixels
 * Signature: ()[I
 */

JNIEXPORT jbyteArray JNICALL 
Java_oem_edge_ed_odc_meeting_client_DScraper_getUpdatedPixelsInBytes(
   JNIEnv *env, 
   jobject obj,
   jbyteArray ret) {
   
   DebugMsg msg("getUpdatedPixelsInBytes");
   
   DScraperArrCleanup dsac(env, obj);
   DScraperData*      dsdata = dsac.getData();
   
   if (dsdata->xscraper) {
      
      tryUpdateUpdateList(dsdata);
      if (dsdata->updateList && dsdata->updateList->get_head()) {
         
         QuadLink* link = (QuadLink*)dsdata->updateList->get_head();
         
         dsdata->updateList->unchain(link);
         
         dsdata->quadmap->set(link->quadrant());
         
         unsigned long *inarr = (unsigned long*)link->data;
         int sz = (inarr[2] * inarr[3] + 4) ;
         if (!ret) {
            ret = env->NewByteArray((BLOCK_WIDTH*BLOCK_HEIGHT*4) + 20);
         }
         msg.printf(2, "updatepixels (%d, %d) (%d, %d)\n", 
                    inarr[0], inarr[1], inarr[2], inarr[3]);
         unsigned char* arr = (unsigned char*)(env)->GetByteArrayElements(ret, 
                                                                          0);
         memcpy(arr, inarr, sz*4);
         
         delete inarr;
         delete link;
         env->ReleaseByteArrayElements(ret, (jbyte*)arr, 0);
      } else {
         ret = 0;
      }
   } else {
      ret = 0;
   }
   return ret;
}
#endif

/*
 * Class:     DScraper
 * Method:    getUpdatedPixels
 * Signature: ()[I
 */

//
// Returns [   x4   ][   y4   ][   w4   ][   h4   ][flag1][  len3  ][data len]
//
JNIEXPORT jbyteArray JNICALL 
Java_oem_edge_ed_odc_meeting_client_DScraper_getUpdatedPixelsInBytes2(
   JNIEnv *env, 
   jobject obj,
   jbyteArray ret) {
   
   DebugMsg msg("getUpdatedPixelsInBytes2");
   
   DScraperArrCleanup dsac(env, obj);
   DScraperData*      dsdata = dsac.getData();
   
   if (dsdata->xscraper) {
   
      dsdata->timer->timer_printdelta("GUP2 - TOP");
      
      tryUpdateUpdateList(dsdata);
      if (dsdata->updateList && dsdata->updateList->get_head()) {
         
         QuadLink* link = (QuadLink*)dsdata->updateList->get_head();
         
         dsdata->updateList->unchain(link);
         
         dsdata->quadmap->set(link->quadrant());
         
         unsigned long *inarr = (unsigned long*)link->data;
         int sz = (inarr[2] * inarr[3]) * 4;
         if (!ret) {
#ifdef REALJNI
            ret = env->NewByteArray((BLOCK_WIDTH*BLOCK_HEIGHT*4) + 20);
#else
            ret = (jbyteArray)new byte[(BLOCK_WIDTH*BLOCK_HEIGHT*4) + 20];
#endif
         }
         msg.printf(2, "updatepixels (%d, %d) (%d, %d)\n", 
                    inarr[0], inarr[1], inarr[2], inarr[3]);
                    
#ifdef REALJNI
         unsigned char* arr = (unsigned char*)(env)->GetByteArrayElements(ret, 
                                                                          0);
#else
         unsigned char* arr = (unsigned char*)ret;
#endif

         inarr[0] = htonl(inarr[0]);
         inarr[1] = htonl(inarr[1]);
         inarr[2] = htonl(inarr[2]);
         inarr[3] = htonl(inarr[3]);
         memcpy(arr, inarr, 4*4);
         
         dsdata->timer->timer_printdelta("GUP2 - RLE");
         
         int nsz = runlengthEncode(((unsigned char*)arr)+20, 
                                   ((unsigned char*)inarr)+16, sz);
         
         dsdata->timer->timer_printdelta("GUP2 - RLE DONE");
         
//         fprintf(stderr, "GB2: xy(%d, %d) wh(%d, %d) sz/rlesz(%d %d)\n",
//                 inarr[0],inarr[1],inarr[2],inarr[3],sz, nsz);
         
        // Put Network order size in 
         nsz = htonl(nsz);
         memcpy(arr+16, &nsz, 4);
         
         delete inarr;
         delete link;
#ifdef REALJNI
         env->ReleaseByteArrayElements(ret, (jbyte*)arr, 0);
#endif
      } else {
         ret = 0;
      }
      
      dsdata->timer->timer_printdelta("GUP2 - DONE");
      
   } else {
      ret = 0;
   }
   return ret;
}

/*
 * Class:     DScraper
 * Method:    injectKey
 * Signature: (Ljava/awt/Point;ZZI)V
 */
JNIEXPORT void JNICALL 
Java_oem_edge_ed_odc_meeting_client_DScraper_injectKey(JNIEnv *env, 
                                                       jobject obj, 
                                                       jobject point, 
                                                       jboolean pressRelease, 
                                                       jboolean keyCodeOrChar,
                                                       jint keysym) {
   DebugMsg msg("injectKey");
   
   DScraperArrCleanup dsac(env, obj);
   DScraperData*      dsdata = dsac.getData();
   
   if (dsdata->xscraper) {
#ifdef REALJNI
      jclass pointcls = env->FindClass("java/awt/Point");
      jfieldID xID = env->GetFieldID(pointcls, "x", "I");
      jfieldID yID = env->GetFieldID(pointcls, "y", "I");
      jint x = (env)->GetIntField(point, xID);
      jint y = (env)->GetIntField(point, yID);
#else
      jint x = ((XPoint*)point)->x;
      jint y = ((XPoint*)point)->y;
#endif
      msg.printf(2, "injectkey  xy(%d, %d)\n", x, y);
      if (dsdata->currentImage) {
         msg.printf(2, "injectkey  rxry(%d, %d)\n", 
                    dsdata->currentImage->get_rootx(),
                    dsdata->currentImage->get_rooty());
         x += dsdata->currentImage->get_rootx();
         y += dsdata->currentImage->get_rooty();
      }
      
      int newks=0;
      if (keyCodeOrChar) {
         newks = lookup_java_to_keysym(keysym);
      } else {
         newks = lookup_unicode16_to_keysym(keysym);
      }
      msg.printf(2, 
                 "InjectKey(%d,%d) press=%s keysym=%d [%c] newks=%d [%c]\n",
                 x, y, pressRelease?"True":"False", 
                 keysym, keysym, newks, newks);
      dsdata->xscraper->injectKey(x, y, 
                                  pressRelease     ?
                                  SCRAPE_KEYPRESS  :
                                  SCRAPE_KEYRELEASE, 
                                  newks);
   }
}

/*
 * Class:     DScraper
 * Method:    injectMouse
 * Signature: (Ljava/awt/Point;ZI)V
 */
JNIEXPORT void JNICALL 
Java_oem_edge_ed_odc_meeting_client_DScraper_injectMouse(JNIEnv *env, 
                                                         jobject obj, 
                                                         jobject point, 
                                                        jboolean pressRelease, 
                                                         jint butnum) {
   DebugMsg msg("injectMouse");
   
   DScraperArrCleanup dsac(env, obj);
   DScraperData*      dsdata = dsac.getData();
   
   if (dsdata->xscraper) {
#ifdef REALJNI
      jclass pointcls = env->FindClass("java/awt/Point");
      jfieldID xID = env->GetFieldID(pointcls, "x", "I");
      jfieldID yID = env->GetFieldID(pointcls, "y", "I");
      jint x = (env)->GetIntField(point, xID);
      jint y = (env)->GetIntField(point, yID);
#else
      jint x = ((XPoint*)point)->x;
      jint y = ((XPoint*)point)->y;
#endif
      
      
      if (dsdata->currentImage) {
         x += dsdata->currentImage->get_rootx();
         y += dsdata->currentImage->get_rooty();
      }
      
      inputType type = (butnum >= 0) 
                     ? (pressRelease?SCRAPE_BUTTONPRESS:SCRAPE_BUTTONRELEASE) 
                     : SCRAPE_MOUSEMOTION; 
      msg.printf(2,"Inject Mouse (%d, %d) type=%d butnum [%d]\n", 
                 x, y, type, butnum);
      dsdata->xscraper->injectMouse(x, y, 
                                    type, 
                                    butnum);
   }
}

#ifndef REALJNI

#include <errno.h>
#include <stdio.h>
#include <stdlib.h>
#include <stddef.h>
#include <unistd.h>
#include <string.h>
#include <strings.h>

#define PRINTF 
#define FPRINTF

/*
** These are the valid incoming commands ... see BScraper.java for protocol def
*/
#define OP_CONNECT              1
#define OP_DISCONNECT           2
#define OP_SETSCRAPE_DELAY      3
#define OP_PAUSE                4
#define OP_RESUME               5
#define OP_GET_DESKTOP_WINDOW   6
#define OP_IS_MODE_STILL_VALID  7
#define OP_GET_TOPLEVEL_WINDOWS 8
#define OP_CONFIGURE_TO_DESKTOP 9
#define OP_CONFIGURE_TO_WINDOW 10
#define OP_CONFIGURE           11
#define OP_GET_WINDOW_TITLE    12
#define OP_GET_CURSOR_POSITION 13
#define OP_GET_CURRENT_FRAME   14
#define OP_GET_NEW_FRAME       15
#define OP_REPLAY_LAST_FRAME   16
#define OP_GET_UPDATED_PELS    17
#define OP_INJECT_KEY          18
#define OP_INJECT_MOUSE        19
#define OP_SELECT_WINDOW       20

/* Replies generated for their companion commands */
#define OP_CONNECT_REPLY              41
#define OP_GET_DESKTOP_WINDOW_REPLY   42
#define OP_IS_MODE_STILL_VALID_REPLY  43  
#define OP_GET_TOPLEVEL_WINDOWS_REPLY 44  
#define OP_CONFIGURE_TO_DESKTOP_REPLY 45  
#define OP_CONFIGURE_TO_WINDOW_REPLY  46  
#define OP_CONFIGURE_REPLY            47  
#define OP_GET_WINDOW_TITLE_REPLY     48
#define OP_GET_CURSOR_POSITION_REPLY  49
#define OP_GET_CURRENT_FRAME_REPLY    50
#define OP_GET_NEW_FRAME_REPLY        51
#define OP_REPLAY_LAST_FRAME_REPLY    52  
#define OP_GET_UPDATED_PELS_REPLY     53  
#define OP_SELECT_WINDOW_REPLY        54

/* Asynchronous event generated */
#define OP_CURSOR_UPDATE_EVENT 81

class IOException {
  public:
   IOException(char* m) {}
};
class InvalidProtocolException {
  public:
   InvalidProtocolException(char* m) {}
};


#define null    0
#define boolean int
#define true    1
#define false   0

class IString {
   char* buf;
  public:
   IString(char* b) {
      buf = new char[strlen(b)+1];
      strcpy(buf, b);
   }
   IString(IString& b) {
      buf = new char[b.getLength()+1];
      strcpy(buf, b.getString());
   }
   
   ~IString() { if (buf) delete buf; }
   const char* getString() { return buf?buf:""; }
   int         getLength() { return buf?strlen(buf):0; }
};

class InputStream {
  private:
   int fd;
  public:
   InputStream(int infd) {
      fd = infd;
   }
   int getFD() { return fd; }
   void close() throw(IOException) {
      if (::close(fd) == -1) {
         throw(IOException("IS Already closed?"));
      }
   }
   int read(byte* buf, int ofs, int l) throw(IOException) {
      int ret = -1;
      while(1) {
         ret = ::read(fd, buf+ofs, l);
         if (ret == 0) {
            ret = -1;
            break;
         } else if (ret == -1 && (errno != EAGAIN && errno != EINTR)) {
            throw IOException("Some read error");
         } else {
            break;
         }
      }
      return ret;
   }
};

class OutputStream {
  private:
   int fd;
  public:
   OutputStream(int infd) {
      fd = infd;
   }
   int getFD() { return fd; }
   void close() throw(IOException) {
      if (::close(fd) == -1) {
         throw(IOException("OS Already closed?"));
      }
   }
   void write(byte* buf, int ofs, int l) throw(IOException) {
      int tot = 0;
      while(tot < l) {
         int r = ::write(fd, buf+ofs+tot, l-tot);
         if (r == -1 && (errno != EINTR && errno != EAGAIN)) {
            break;
         } else if (r == 0) {
            ;
         } else {
            tot += r;
           /*
             printf(" 0x%02.2x", b);
             fflush(stdout);
           */
         }
      }
   }
};

class CompressInfo {
  public:
   byte* buf;
   int ofs;
   int len;
   CompressInfo(byte* arr, int ofss, int lenn) {
      buf = arr;
      ofs = ofss;
      len = lenn;
   }
};

class DSMPBaseProto {

#define HEADER_SIZE      (6)
#define FLAGS_XTRAINT (0x80)
   
  protected:
   
   byte  inited;
   byte    opcode; 
   byte    handle; 
   byte    flags; 
   int     len; 
   int     bufofs; 
   int     buf_len; 
   byte    *buf; 
   int     cursor; 
   int     xtraInt; 
   
  //long    timeOnQ; 
   
  public:
  
  /*
   void setCurrentTime() {
      timeOnQ = System.currentTimeMillis();
   }
   
   void setTime(long t) {
      timeOnQ = t;
   }
   long getTime() {
      return timeOnQ;
   }
   long getDeltaTime() {
      return  System.currentTimeMillis() - timeOnQ;
   }
  */
   
   int getNonHeaderSize() { return len; }
   
   int size() { return len + HEADER_SIZE + 
                              (((flags & FLAGS_XTRAINT) != 0)?4:0); }
   
   void resetCursor() { cursor = 0; }
   
   void setExtraInt(int i) { xtraInt = i;  flags |= FLAGS_XTRAINT; }
   int  getExtraInt()      { return xtraInt;                       }
   
   void reset() {
      inited =  0;
      opcode =  0;
      handle =  0;
      flags  =  0;
      len    =  0;
      bufofs =  0;
      if (buf) delete buf;
      buf    =  0;
      buf_len=  0;
      cursor =  0;
      xtraInt=  0;
//      timeOnQ = 0;
   }
   
   ~DSMPBaseProto() {
      if (buf) delete buf;
   }
   
   DSMPBaseProto() {
      buf = 0;
      reset();
   }
   
   DSMPBaseProto(byte op, byte f, byte h, byte *arr, int ofs, int l) {
      buf = 0;
      reset();
      inited = true;
      opcode = op;
      flags  = f;
      handle = h;
      buf    = arr;
      bufofs = ofs;
      buf_len = l+ofs;
      len    = l;
   }
   
   DSMPBaseProto(byte op, byte f, byte h) {
      buf = 0;
      reset();
      inited = true;
      opcode = op;
      flags  = f;
      handle = h;
      buf    = new byte[16484];
      buf_len = 16484;
      bufofs = 0;
      len    = 0;
   }
   DSMPBaseProto(int sz, byte op, byte f, byte h) {
      buf = 0;
      reset();
      inited = true;
      opcode = op;
      flags  = f;
      handle = h;
      buf    = new byte[sz];
      bufofs = 0;
      buf_len = sz;
      len    = 0;
   }
   
   
  /* Not now ... not into vectors
   void addSentListener(ProtoSentListener v) {
      if (listeners == null) listeners = new Vector(); 
      
      (listeners) {
         removeSentListener(v);
         listeners.addElement(v);
      }
   }
   
   public boolean removeSentListener(ProtoSentListener v) {
      if (listeners != null) {
         (listeners) {
            int sz = listeners.size();
            for(int i = 0; i < sz; i++) {
               ProtoSentListener x = (ProtoSentListener)listeners.elementAt(i);
               if (x == v) {
                  listeners.removeElementAt(i);
                  return true;
               }
            }
         }
      }
      return false;
   }
   
   void fireProtocolSent() {
      try {
         if (listeners != null) {
            (listeners) {
               int sz = listeners.size();
               for(int i = 0; i < sz; i++) {
                  ProtoSentListener x = 
                     (ProtoSentListener)listeners.elementAt(i);
                  x.fireSentEvent(this);
               }
            }
         }
      } catch(IndexOutOfBoundsException& e) {
      }
   }
  */   
  
   void      addMaskToFlags(int v)      { flags |= v;          }
   void      removeMaskFromFlags(int v) { flags &= ~v;         }
   int       bitsSetInFlags(int v)      { return (flags&v)==v; }
   
   void growToFit(int l) {
      if (buf == null) {
         buf_len = l + 32;
         buf = new byte[buf_len];
         bufofs = 0;
      } else if (buf_len - len - bufofs < l) {
         buf_len = len + l + 32;
         byte *newbuf = new byte[buf_len];
         memcpy(newbuf, buf + bufofs, len);
         delete buf;
         buf = newbuf;
         bufofs = 0;
      }
   }
   void appendData(byte* inbuf, int ofs, int l) {
      growToFit(l);
      memcpy(buf+bufofs+len, inbuf+ofs, l);
      len += l;
   }
   
   void appendByte(byte b) {
      growToFit(1);
      buf[bufofs+len] = b;
      len++;
   }
   
   void appendShort(int v) {
      growToFit(2);
      int ofs = bufofs+len;
      len += 2;
      buf[ofs++] = (byte)((v >> 8) & 0xff);
      buf[ofs]   = (byte)((v )     & 0xff);
   }
   
   void append3ByteInteger(int v) {
      growToFit(3);
      int ofs = bufofs+len;
      len += 3;
      buf[ofs++] = (byte)((v >> 16) & 0xff);
      buf[ofs++] = (byte)((v >> 8)  & 0xff);
      buf[ofs]   = (byte)((v )      & 0xff);
   }
   void appendInteger(int v) {
      growToFit(4);
      int ofs = bufofs+len;
      len += 4;
      buf[ofs++] = (byte)((v >> 24) & 0xff);
      buf[ofs++] = (byte)((v >> 16) & 0xff);
      buf[ofs++] = (byte)((v >> 8)  & 0xff);
      buf[ofs]   = (byte)((v )      & 0xff);
   }
   void appendLong(long long v) {
      growToFit(8);
      int ofs = bufofs+len;
      len += 8;
      buf[ofs++] = (byte)((v >> 56) & 0xff);
      buf[ofs++] = (byte)((v >> 48) & 0xff);
      buf[ofs++] = (byte)((v >> 40) & 0xff);
      buf[ofs++] = (byte)((v >> 32) & 0xff);
      buf[ofs++] = (byte)((v >> 24) & 0xff);
      buf[ofs++] = (byte)((v >> 16) & 0xff);
      buf[ofs++] = (byte)((v >> 8)  & 0xff);
      buf[ofs]   = (byte)((v )      & 0xff);
   }
   
   void appendString8(char* s) {
      int arr_length = strlen(s);
      growToFit(arr_length + 1);
      appendByte((byte)arr_length);
      memcpy(buf + bufofs+len, s, arr_length);
      len += arr_length;
   }
   void appendString16(char* s) {
      int arr_length = strlen(s);
      growToFit(arr_length + 2);
      appendShort((short)arr_length);
      memcpy(buf + bufofs+len, s, arr_length);
      len += arr_length;
   }
   
   int cursorBytesLeft() {
      int ret = 0;
      if (cursor < len) ret = len - cursor;
      return ret;
   }
   
   byte getByte() throw(InvalidProtocolException) {
      byte ret = 0;
      if (buf == null || bufofs + cursor + 1 > buf_len) {
         throw InvalidProtocolException("Array exception");
      } else {
         ret = buf[bufofs+cursor];
         cursor += 1;
      }
      return ret;
   }
   
   int getUnsignedByte() throw (InvalidProtocolException) {
      int ret = 0;
      if (buf == null || bufofs + cursor + 1 > buf_len) {
         throw InvalidProtocolException("Array exception");
      } else {
         ret = ((int)buf[bufofs+cursor]) & 0xff;
         cursor += 1;
      } 
      return ret;
   }
   
   int getUnsignedShort() throw (InvalidProtocolException) {
      int ret = 0;
      if (buf == null || bufofs + cursor + 2 > buf_len) {
         throw InvalidProtocolException("Array exception");
      } else {
         ret = ((((int)buf[bufofs+cursor])   & 0xff) << 8) | 
               ((((int)buf[bufofs+cursor+1]) & 0xff));
         cursor += 2;
      }
      return ret;
   }
   
   short getShort() throw(InvalidProtocolException) {
      short ret = 0;
      if (buf == null || bufofs + cursor + 2 > buf_len) {
         throw InvalidProtocolException("Array exception");
      } else {
         ret = (short)(((((int)buf[bufofs+cursor])   & 0xff) << 8) | 
                       ((((int)buf[bufofs+cursor+1]) & 0xff)));
         cursor += 2;
      }
      return ret;
   }
   
   int get3ByteInteger() throw (InvalidProtocolException) {
      int ret = 0;
      if (buf == null || bufofs + cursor + 3 > buf_len) {
         throw InvalidProtocolException("Array exception");
      } else {
         ret = ((((int)buf[bufofs+cursor])   & 0xff) << 16) | 
               ((((int)buf[bufofs+cursor+1]) & 0xff) << 8)  | 
               ((((int)buf[bufofs+cursor+2]) & 0xff));
         cursor += 3;
      }
      return ret;
   }
   
   int getInteger() throw (InvalidProtocolException) {
      int ret = 0;
      if (buf == null || bufofs + cursor + 4 > buf_len) {
         throw InvalidProtocolException("Array exception");
      } else {
         ret = ((((int)buf[bufofs+cursor])   & 0xff) << 24) | 
               ((((int)buf[bufofs+cursor+1]) & 0xff) << 16) | 
               ((((int)buf[bufofs+cursor+2]) & 0xff) << 8)  | 
               ((((int)buf[bufofs+cursor+3]) & 0xff));
         cursor += 4;
      }
      return ret;
   }
   
   long long getLong() throw (InvalidProtocolException) {
      long long ret = 0;
      if (buf == null || bufofs + cursor + 8 > buf_len) {
         throw InvalidProtocolException("Array exception");
      } else {
         ret = ((((long long)buf[bufofs+cursor])   & 0xff) << 56) | 
               ((((long long)buf[bufofs+cursor+1]) & 0xff) << 48) | 
               ((((long long)buf[bufofs+cursor+2]) & 0xff) << 40) | 
               ((((long long)buf[bufofs+cursor+3]) & 0xff) << 32) | 
               ((((long long)buf[bufofs+cursor+4]) & 0xff) << 24) | 
               ((((long long)buf[bufofs+cursor+5]) & 0xff) << 16) | 
               ((((long long)buf[bufofs+cursor+6]) & 0xff) << 8)  | 
               ((((long long)buf[bufofs+cursor+7]) & 0xff));
         cursor += 8;
      }
      return ret;
   }
   
   char* getString8() throw (InvalidProtocolException) {
      char* ret = null;
      int l = getUnsignedByte();
      if (buf == null || bufofs + cursor + l > buf_len) {
         throw InvalidProtocolException("Array exception");
      } else {
         ret = new char[l+1];
         memcpy(ret, buf+bufofs+cursor, l);
         ret[l] = 0;
         cursor += l;
      }
      return ret;
   }
   char* getString16() throw (InvalidProtocolException) {
      char* ret = null;
      int l = getShort();
      if (buf == null || bufofs + cursor + l > buf_len) {
         throw InvalidProtocolException("Array exception");
      } else {
         ret = new char[l+1];
         memcpy(ret, buf+bufofs+cursor, l);
         ret[l] = 0;
         cursor += l;
      }
      return ret;
   }
   
    CompressInfo *getDataAtCursor(int l) throw (InvalidProtocolException) {
      CompressInfo *ret = null;
      if (buf == null || bufofs + cursor + l > buf_len) {
         throw InvalidProtocolException("Array exception");
      } else {
         ret = new CompressInfo(buf, bufofs+cursor, l);
         cursor += l;
      }
      return ret;
   }
   
   CompressInfo *getDataAtCursor() throw (InvalidProtocolException) {
      CompressInfo *ret = null;
      int l = len-cursor;
      if (l <= 0) {
         throw InvalidProtocolException(": Array exception");
      }
      ret = new CompressInfo(buf, bufofs+cursor, l);
      cursor += l;
      return ret;
   }
   
   void verifyCursorDone() throw (InvalidProtocolException) {
      int leftover = cursorBytesLeft();
      if (leftover != 0) {
         throw InvalidProtocolException("Leftover Bytes");
      }
   }
   
   void setData(byte *inbuf, int ofs, int l) {
       bufofs  = ofs;
       len     = l;
       buf_len = l + ofs;
       
       if (buf) delete buf;
       buf     = inbuf;
   }
   
   int getDataLength() {
      return len;
   }
   
   CompressInfo *getData() {
      CompressInfo* ret = new CompressInfo(buf, bufofs, len);
      return ret;
   }
   
   boolean getInited() {
      return inited;
   }
   
   void setInited(boolean v) {
      inited = v;
   }
   
   byte getOpcode() {
      return opcode;
   }
   void setOpcode(byte o) {
      opcode = o;
   }
   byte getHandle() {
      return handle;
   }
   void setHandle(byte h) {
      handle = h;
   }
   byte getFlags() {
      return flags;
   }
   void setFlags(byte f) {
      flags = f;
   }
      
   void write(OutputStream* out) throw (IOException) {
     /*
     **                                            DATA portion
     **                                       .____________________. 
     **        1Byte   1Byte  3Bytes  1Byte  /                      \
     **      +-------+-------+-------+------+-------+-------+-------+
     **      |OPCODE | FLAGS | LENP  | HAND | B1    |  ...  | BLENP |  
     **      +-------+-------+-------+------+-------+-------+-------+
     **
     **
     **   If the flag bit FLAGS_XTRAINT is set (0x80) then an integer value
     **    is stuffed between HAND and B1  (effectively a 10 byte header)
     */
      if (inited) {
         boolean xtra = bitsSetInFlags(FLAGS_XTRAINT);
         int sz = HEADER_SIZE + (xtra?4:0);
         byte *h = new byte[sz];
         h[0] = opcode;
         h[1] = flags;
         h[2] = (byte)((len >>  16) & 0xff);
         h[3] = (byte)((len >>  8)  & 0xff);
         h[4] = (byte)((len      )  & 0xff);
         h[5] = handle;
         if (xtra) {
            h[6] = (byte)((xtraInt >>  24) & 0xff);
            h[7] = (byte)((xtraInt >>  16) & 0xff);
            h[8] = (byte)((xtraInt >>  8)  & 0xff);
            h[9] = (byte)((xtraInt      )  & 0xff);
         }
         out->write(h, 0, sz);
         
         if (len > 0 && buf != null) {
            out->write(buf, bufofs, len);
         }
        //fireProtocolSent();
      }
   }
        
        
  // Read protocol from an array ... all return updated ofs
   int readAll(byte *arr, int ofs, int l) {
      ofs=readHeader(arr, ofs, l);
      if (ofs >= 0) {
         ofs = readBody(arr, ofs, l);
      }
      return ofs;
   }
   
   int readHeader(byte *arr, int ofs, int l) {
      reset();
      return setHeader(arr, ofs, l);
   }
   
   int readBody(byte *arr, int ofs, int l) {
      int totlen = 0;
      if (!buf || buf_len < len) {
         if (buf) delete buf;
         buf     = new byte[len];
         buf_len = len;
      }
      memcpy(buf, arr+ofs, len);
      bufofs  = 0;
      
     // Guess this returns new ofs into arr?
      return ofs + len;
   }
   
   
        
  // Read protocol from an InputStream ... all return updated true if worked,
  //  exception otherwise
   boolean readAll(InputStream* tin) throw(IOException) {
      if (readHeader(tin)) {
         readBody(tin);
      }
      return inited;
   }
   boolean readBody(InputStream* tin) throw(IOException) {
      int totlen = 0;
      
      if (!buf || buf_len < len) {
         if (buf) delete buf;
         buf = new byte[len];
         buf_len = len;
      }
      bufofs  = 0;
	
      try {
         while (totlen != len) {
            int l = tin->read(buf, totlen, len - totlen);
            if (l == -1) {
               inited = false;
               throw IOException("DSMPProto: readBody: EOF");
            }
            totlen += l;
         }
      } catch (IOException& e) {
         inited = false;
         throw;
      }
      
      return inited;
   }
   
   boolean readHeader(InputStream* tin) throw(IOException) {
      int totlen = 0;
      reset();
      byte *head = new byte[HEADER_SIZE+4];
      try {
         int totreadsz = HEADER_SIZE;
         while (totlen != totreadsz) {
            
//            System.out.println("ReadHead: Tot = " + totreadsz + " cur = " + totlen);
            int l = tin->read(head, totlen, totreadsz - totlen);
//            System.out.println("        : Read = " + l);
            if (l == -1) {
               throw IOException("DSMPProto: readHeader: EOF");
            }
            
            totlen += l;
            
           // If the extraint flag is set, get the extra int
            if (totlen == HEADER_SIZE && (head[1] & FLAGS_XTRAINT) != 0) {
               totreadsz = HEADER_SIZE+4;
            }
         }
         setHeader(head, 0, totreadsz);
      } catch (IOException& e) {
         inited = false;
         throw;
      }
      
      return inited;
   }
   
   int setHeader(byte *head, int ofs, int l) {
      inited = true;
      
      opcode  = head[ofs+0];
      flags   = head[ofs+1];
      len = ((((int)head[ofs+2]) << 16) & 0xff0000) | 
            ((((int)head[ofs+3]) <<  8) & 0xff00)   | 
            ((((int)head[ofs+4]))       & 0xff); 
      handle  = head[ofs+5];
      if ((flags & FLAGS_XTRAINT) != 0) {
         xtraInt = ((((int)head[ofs+6]) << 24) & 0xff000000) | 
                   ((((int)head[ofs+7]) << 16) & 0xff0000)   | 
                   ((((int)head[ofs+8]) <<  8) & 0xff00)     | 
                   ((((int)head[ofs+9]))       & 0xff); 
         ofs+=4;
      }
      ofs += HEADER_SIZE;
      return ofs;
   }
};

#ifdef NOPE
int getInteger(unsigned char* buf, int ofs) {
   int ret = (buf[ofs+0] << 24) |
             (buf[ofs+1] << 16) |
             (buf[ofs+2] <<  8) |
             (buf[ofs+3]);
   return ret;
}

int putInteger(unsigned char* buf, int ofs, int i) {
   buf[ofs+0] = (i >> 24) & 0xff;
   buf[ofs+1] = (i >> 16) & 0xff;
   buf[ofs+2] = (i >>  8) & 0xff;
   buf[ofs+3] = (i)       & 0xff;
   return ofs+4;
}
int putString8(unsigned char* buf, int ofs, int i) {
   buf[ofs+0] = (i >> 24) & 0xff;
   buf[ofs+1] = (i >> 16) & 0xff;
   buf[ofs+2] = (i >>  8) & 0xff;
   buf[ofs+3] = (i)       & 0xff;
   return ofs+4;
}

char* getString8(unsigned char* buf, int ofs) {
   int len = buf[ofs];
   char *ret = new char[len+1];
   
   strncpy(ret, (char*)(buf+ofs+1), len);
   ret[len] = 0;
   return ret;
}
char* getString16(unsigned char* buf, int ofs) {
   int len = (((int)buf[ofs]) << 8) | buf[ofs+1];
   char *ret = new char[len+1];
   
   strncpy(ret, (char*)(buf+ofs+2), len);
   ret[len] = 0;
   return ret;
}

int readbytes(unsigned char *buf, int ofs, int len) {
   int tot = 0;
   while(tot < len) {
      int r = read(infd, buf+ofs+tot, len-tot);
      if (r == -1 && errno != EINTR) {
         printf("Got fatal read error %d", errno);
         break;
      } else if (r == 0) {
         printf("Got EOF on read");
         break;
      } else {
         tot += r;
        /*
          printf(" 0x%02.2x", b);
          fflush(stdout);
        */
      }
   }
   return tot;
}

int writebytes(unsigned char *buf, int ofs, int len) {
   int tot = 0;
   while(tot < len) {
      int r = write(outfd, buf+ofs+tot, len-tot);
      if (r == -1 && errno != EINTR) {
         printf("Got fatal write error %d", errno);
         break;
      } else if (r == 0) {
         ;
      } else {
         tot += r;
        /*
          printf(" 0x%02.2x", b);
          fflush(stdout);
        */
      }
   }
   return tot;
}


void fillInProto(unsigned char *buf, int ofs, 
                 unsigned char op, 
                 unsigned char flags, 
                 unsigned char handle) {
   memset(buf+ofs, 0, 6);
   buf[0] = op;
   buf[1] = flags;
   buf[5] = handle;
}
#endif


class ConditionLock {
  public:
   ConditionLock() {}
   void get()      {}
   void release()  {}
   void notifyAll(){}
};

class Vector {
   int len;
   int arrsz;
   void** arr;
  public:
   Vector()  { arrsz=5; arr = (void**)malloc(arrsz*sizeof(void**)); len=0; }
   ~Vector() { free(arr); }
   void addElement(void* p) {
      if (len+1 >= arrsz) {
         arr=(void**)realloc(arr, (arrsz + 16)*sizeof(void**));
         arrsz += 16;
      }
      arr[len++] = p;
   }
   void removeAll() {
      len = 0;
   }
   void* firstElement() {
      return len?arr[0]:0;
   }
   void* removeElementAt(int idx) {
      void* ret = 0;
      if (idx < len && idx >= 0) {
         ret = arr[idx];
         if (idx+1 < len) {
            memmove(arr+idx, arr+idx+1, (len-idx-1)*sizeof(void**));
         }
         len--;
      }
      return ret;
   }
   void* elementAt(int idx) {
      void* ret = 0;
      if (idx < len && idx >= 0) {
         ret = arr[idx];
      }
      return ret;
   }
   int size()   { return len; }
};

class DSMPBaseHandler;
class DSMPDispatchBase {

  public:

   DSMPDispatchBase() {}
   
  /* -------------------------------------------------------*\
  ** Shutdown
  \* -------------------------------------------------------*/
   void fireShutdownEvent(DSMPBaseHandler *h) {
   }
   
   void uncaughtProtocol(DSMPBaseHandler *h, byte opcode) {
   }

  /* -------------------------------------------------------*\
  ** Commands
  \* -------------------------------------------------------*/
   
  /* -------------------------------------------------------*\
  ** Replies
  \* -------------------------------------------------------*/
   
  /* -------------------------------------------------------*\
  ** Reply Errors
  \* -------------------------------------------------------*/
   
  /* -------------------------------------------------------*\
  ** Events
  \* -------------------------------------------------------*/
   
  /* -------------------------------------------------------*\
  ** Errors
  \* -------------------------------------------------------*/
   
  /* -------------------------------------------------------*\
  ** Checking and Dispatching
  \* -------------------------------------------------------*/
  
   void checkProtocol(DSMPBaseProto *proto) throw(InvalidProtocolException) {
      dispatchProtocolI(proto, null, false);
   }
   
   void dispatchProtocol(DSMPBaseProto *proto, DSMPBaseHandler *h) 
                                            throw(InvalidProtocolException) {
      dispatchProtocolI(proto, h, true);
   }
   
   virtual void dispatchProtocolI(DSMPBaseProto *proto, 
                                  DSMPBaseHandler *handler, 
                                  boolean doDispatch) 
                  throw(InvalidProtocolException) {
   }
};

class DSMPBaseHandler {

  protected:
  
   boolean          verbose;
  
   InputStream      *istream;
   OutputStream     *ostream;
   
  // Debug
   OutputStream     *inboundSave, *outboundSave;
   
   DSMPDispatchBase *dispatch;
   
   Vector           tosend;
   ConditionLock    addLock;
   
   boolean          done;

   int              handlerid;
   
   int              flags;
   
  public:
   
   DSMPBaseHandler(DSMPDispatchBase *disp) {
      verbose   = false;
      istream   = null;
      ostream   = null;
      done      = false;
      handlerid = 2;
      flags     = 0;
      dispatch = disp;
      inboundSave = outboundSave = 0;
      
     // DEBUG!! 
     /*
      fprintf(stderr, "Saving in/out proto to /tmp\n");
      verbose = true;
      FILE* insave  = fopen("/tmp/insave.out", "wb");
      FILE* outsave = fopen("/tmp/outsave.out", "wb");
      inboundSave   = new OutputStream(fileno(insave));
      outboundSave  = new OutputStream(fileno(outsave));
     */
   }
   
   
   void             addMaskToFlags(int v)      { flags |= v;          }
   void             removeMaskFromFlags(int v) { flags &= ~v;         }
   boolean          bitsSetInFlags(int v)      { return (flags&v)==v; }
   int              getFlags()                 { return flags;        }
   DSMPDispatchBase *getDispatch()             { return dispatch;     }
   int              getHandlerId()             { return handlerid;    }
   
   
  /*
  ** Set a new source/dest for protocol
  */
   void setInputOutput(InputStream *is, OutputStream *os) {
      closeStreams();
      istream = is;
      ostream = os;
      done=false;
   }
   
   boolean eof() { return done; }
   
   void shutdown() {
      addLock.get();
      if (!done) {
         done = true;
         dispatch->fireShutdownEvent(this);
         addLock.notifyAll();
         closeStreams();
      }
      addLock.release();
   }
   
  /*
  ** Clean up our resources
  */
   void closeStreams() {
   
      if (istream != null) {
         try {
            istream->close();
         } catch(...) {}
         delete istream;
         istream = null;
      }
      if (ostream != null) {
         try {
            ostream->close();
         } catch(...) {}
         delete ostream;
         ostream = null;
      }
   }
   
   DSMPBaseProto* instanceProtocol(){
      return new DSMPBaseProto();
   }
   
  /*
  ** Get next packet of protocol
  */
   DSMPBaseProto *readProtocolPacket() throw(IOException) {
   
      DSMPBaseProto *ret = instanceProtocol();
      try {
         ret->readAll(istream);
      } catch(IOException& ex) {
         shutdown();
         throw ex;
      }
      return ret;
   }
   
  /*
  ** Get next packet of protocol
  */
   void sendProtocolPacket(DSMPBaseProto* p) {
      addLock.get();
      tosend.addElement(p);
//      p->setCurrentTime();
      addLock.notifyAll();
      addLock.release();
   }
   
  /*
  ** getNextProtoPacket - Used only by writer thread. 'tosend' should NOT be 
  ** touched by others.
  **
  **  Consumes packets from addInfos Vector array (only one of the 2 vectors 
  **  is current at any one time ... curAddInfo is the index of the current 
  **  one). These are processed by adding them to the 'tosend' vector, which 
  **  is where we pull things off to actually send. 
  **
  */ 
   DSMPBaseProto* getNextProtoPacket() {
   
      DSMPBaseProto *ret = null;
      
     // If we have proto in tosend, get it
      int sz = tosend.size();
      
      if (sz > 0) {
         ret = (DSMPBaseProto*)tosend.firstElement();
         tosend.removeElementAt(0);
         
//         long tt = ret.getDeltaTime();
//         if (tt > 500) {
//            fprintf(stderr, "TimeOnQ = %d QSize = %d\n", tt, sz);
//         }
      }
      return ret;
   }

  
  /*
  ** The thread associated with this object is charged with handling outgoing
  ** protocol packets (sending them to the other side)
  */
   void run() {
   
      long ptime      = 0;
      long totproto   = 0;
      
      try {
         while(!done) {
         
            fd_set readset, writeset;
            int ifd, ofd = -1;
            FD_ZERO(&readset);
            FD_ZERO(&writeset);
            FD_SET(ifd = istream->getFD(), &readset); 
            
            if (tosend.size()) {
               FD_SET(ofd = ostream->getFD(), &writeset); 
            }
            FPRINTF(stderr, "About to select\n");
            int ans=select(((ifd>ofd)?ifd:ofd)+1, &readset, &writeset, 0, 0);
            
            if (done) break;
            
            if (ans > 0) {
               FPRINTF(stderr, "Got something from select\n");
               if (FD_ISSET(ifd, &readset)) {
                  try {
                     FPRINTF(stderr, "Reading Proto\n");
                     DSMPBaseProto *proto = readProtocolPacket();
                     
                    // Debug
                     if (inboundSave) { 
                        inboundSave->write((byte*)"STARTPACKET", 0, 11);
                        proto->write(inboundSave);
                     }
                     FPRINTF(stderr, "Got Proto ... dispatching\n");
                     getDispatch()->dispatchProtocol(proto, this);
                     FPRINTF(stderr, "Back from dispatch\n");
                  } catch(InvalidProtocolException& ex) {
                     fprintf(stderr, "Error reading/processing proto\n");
                     throw;
                  }
               } 
               if (ofd >= 0 && FD_ISSET(ofd, &writeset)) {
                  FPRINTF(stderr, "Getting packet to write\n");
                  DSMPBaseProto *proto = getNextProtoPacket();
                  if (proto) {
                  
                     FPRINTF(stderr, "Writing packet\n");
                    // Debug
                     if (outboundSave) {
                        outboundSave->write((byte*)"STARTPACKET", 0, 11);
                        proto->write(outboundSave);
                     }
                     
                     proto->write(ostream);
                     FPRINTF(stderr, "packet written\n");
                     delete proto;
                  }
               }
            } else if (ans == -1 && errno != EINTR && errno != EAGAIN) {
               fprintf(stderr, "Got error = %d\n", errno);
               throw IOException("Error selecting");
            } 
         }
      } catch(IOException& ioe) {
         shutdown();
      } catch(...) {
         shutdown();
      }
      if (verbose) fprintf(stderr, "DSMPHandler Done");
   }
};


class MyDispatcher : public DSMPDispatchBase {

   DScraperData *dsdata;
   
  public:
  
   MyDispatcher() { 
      dsdata = new DScraperData();
      memset(dsdata, 0, sizeof dsdata); 
   }
   ~MyDispatcher() { delete dsdata; }
   
   void fireShutdownEvent(DSMPBaseHandler* h) {
      fprintf(stderr, "Scraping process FireShutdown ... exit\n");
      exit(99);
   }
   
   void dispatchProtocolI(DSMPBaseProto *p, 
                          DSMPBaseHandler *handler, 
                          boolean doDispatch) 
      throw(InvalidProtocolException) {
      
      byte handle = p->getHandle();
      byte opcode = p->getOpcode();
      byte flags  = p->getFlags();
      
      int i;
      
      FPRINTF(stderr, "Dispatching op=%d flgs=%d handle=%d\n", opcode, 
              flags, handle);
      DSMPBaseProto* retp = null;
      switch(opcode) {
         case OP_CONNECT: {
            FPRINTF(stderr, "In connect\n");
            char* host = p->getString8();
            p->verifyCursorDone();
            i = Java_oem_edge_ed_odc_meeting_client_DScraper_connect(0, 
                                                                     dsdata,
                                                                     host, 
                                                                     flags & 1, 
                                                                     (flags & 2) != 0);
            char* ans = 0;
            switch(i) {
               case FAILURE_TO_CONNECT_TO_DISPLAY:
                  ans = "Error connecting to specified display";
                  break;
               case CONNECT_SUCCESSFUL:
                  ans = "Connect was successful";
                  break;
               case APAR_NOT_INSTALLED:
                  ans = CANNOTCONNECT;
                  break;
               case CANT_CHECK_IF_APAR_INSTALLED:
               case INCONCLUSIVE_APAR_CHECK: 
               default:
                  ans = POTENTIALCONNECTERROR;
                  break;
            }
            
            if (!i) {
               dsdata->handler = handler;
            }
            PRINTF("Connect to host %s yielded %d [%s]\n", host, i, ans);
            
            delete host;
            
            retp = new DSMPBaseProto(OP_CONNECT_REPLY, (byte)!i, handle);
            retp->appendInteger(i);
            retp->appendString16(ans);
            break;
         }
         case OP_DISCONNECT: {
           // Just disconnect ...
           // p->verifyCursorDone();
           //Java_oem_edge_ed_odc_meeting_client_DScraper_disconnect(0, 
           //                                                         dsdata);
            exit(55);
            
            break;
         }
         case OP_SETSCRAPE_DELAY: {
            int delay = p->getInteger();
            p->verifyCursorDone();
            Java_oem_edge_ed_odc_meeting_client_DScraper_scrapingDelayI(0, 
                                                                      dsdata,
                                                                      delay);
            break;
         }
         case OP_PAUSE: 
            p->verifyCursorDone();
            Java_oem_edge_ed_odc_meeting_client_DScraper_pause(0, dsdata);
            break;
         case OP_RESUME: 
            p->verifyCursorDone();
            Java_oem_edge_ed_odc_meeting_client_DScraper_resume(0, dsdata);
            break;
         case OP_GET_DESKTOP_WINDOW: {
            p->verifyCursorDone();
            i = Java_oem_edge_ed_odc_meeting_client_DScraper_getDesktopWindow(
                                                                  0, dsdata);
                                                                      
            retp = new DSMPBaseProto(OP_GET_DESKTOP_WINDOW_REPLY, 
                                     i!=0 && i != -1, handle);
            if (retp->getFlags()) {
               retp->appendInteger(i);
            }
            break;
         }
         case OP_IS_MODE_STILL_VALID: {
            p->verifyCursorDone();
            i=Java_oem_edge_ed_odc_meeting_client_DScraper_isModeStillValid (0,
                                                                       dsdata);
            
            retp = new DSMPBaseProto(OP_IS_MODE_STILL_VALID_REPLY, 
                                     (byte)!!i, handle);
            break;
         }
         case OP_GET_TOPLEVEL_WINDOWS: {
            
            p->verifyCursorDone();
            retp = new DSMPBaseProto(OP_GET_TOPLEVEL_WINDOWS_REPLY, 
                                     0, handle);
            if (dsdata->xscraper) {
               retp->setFlags(1);
               LinkList* ll = dsdata->xscraper->enumerateWindows();
      
               if (ll) {
                  Link* link;
                  retp->appendShort(ll->get_numLinks());
                  while(link = ll->get_head()) {
                     ll->unchain(link);
                     int window = *(int*)link->data;
                     free((int*)link->data);
                     delete link;
                     link = 0;
                     retp->appendInteger(window);
                  }
                  delete ll;
                  ll = 0;
               }
            }
            break;
         }
         case OP_CONFIGURE_TO_DESKTOP: 
         
            p->verifyCursorDone();
            i=Java_oem_edge_ed_odc_meeting_client_DScraper_configureToDesktop(
                                       0, dsdata);
            
            retp = new DSMPBaseProto(OP_CONFIGURE_TO_DESKTOP_REPLY, 
                                     !i, handle);
            
            break;
         case OP_CONFIGURE_TO_WINDOW: {
            int win = p->getInteger();
            p->verifyCursorDone();
            i=Java_oem_edge_ed_odc_meeting_client_DScraper_configureToWindow(
                                       0, dsdata, win);
            
            retp = new DSMPBaseProto(OP_CONFIGURE_TO_WINDOW_REPLY, 
                                     !i, handle);
            break;
         }
         case OP_CONFIGURE: {
            int x = p->getInteger();
            int y = p->getInteger();
            int w = p->getInteger();
            int h = p->getInteger();
            p->verifyCursorDone();
            i=Java_oem_edge_ed_odc_meeting_client_DScraper_configure(
                                       0, dsdata, x, y, w, h);
            
            retp = new DSMPBaseProto(OP_CONFIGURE_REPLY, !i, handle);
            break;
         }
         case OP_GET_WINDOW_TITLE: {
            int win = p->getInteger();
            char* title;
            p->verifyCursorDone();
            title=Java_oem_edge_ed_odc_meeting_client_DScraper_getWindowTitle(
                                       0, dsdata, win);
            retp = new DSMPBaseProto(OP_GET_WINDOW_TITLE_REPLY, 
                                     title != 0, handle);
            
            if (title) {
               retp->appendString16(title);
               delete title;
            }
            break;
         }
         case OP_GET_CURSOR_POSITION: {
            p->verifyCursorDone();
            XPoint* xpoint = (XPoint*)
               Java_oem_edge_ed_odc_meeting_client_DScraper_getCursorPosition
                 (0, dsdata);
            
            retp = new DSMPBaseProto(OP_GET_CURSOR_POSITION_REPLY, xpoint!=0,
                                     handle);
            if (xpoint) {
               retp->appendInteger(xpoint->x);
               retp->appendInteger(xpoint->y);
               delete xpoint;
            }
            break;
         }
         case OP_GET_CURRENT_FRAME: {
            p->verifyCursorDone();
            XRectangle* rec = (XRectangle*)
               Java_oem_edge_ed_odc_meeting_client_DScraper_getCurrentFrame
                 (0, dsdata);
            
            retp = new DSMPBaseProto(OP_GET_CURRENT_FRAME_REPLY, 
                                     rec!=0, handle);
            if (rec) {
               retp->appendInteger(rec->x);
               retp->appendInteger(rec->y);
               retp->appendInteger(rec->width);
               retp->appendInteger(rec->height);
               delete rec;
            }
            break;
         }
         case OP_GET_NEW_FRAME: {
            p->verifyCursorDone();
            XRectangle* rec = (XRectangle*)
               Java_oem_edge_ed_odc_meeting_client_DScraper_getNewFrame 
                 (0, dsdata, flags&1);
            
            retp = new DSMPBaseProto(OP_GET_NEW_FRAME_REPLY, rec!=0, handle);
            if (rec) {
               retp->appendInteger(rec->x);
               retp->appendInteger(rec->y);
               retp->appendInteger(rec->width);
               retp->appendInteger(rec->height);
               delete rec;
            }
            break;
         }
         case OP_REPLAY_LAST_FRAME: {
            p->verifyCursorDone();
            XRectangle* rec = (XRectangle*)
               Java_oem_edge_ed_odc_meeting_client_DScraper_replayLastFrame 
                 (0, dsdata);
            
            retp = new DSMPBaseProto(OP_REPLAY_LAST_FRAME_REPLY, 
                                     rec!=0, handle);
            if (rec) {
               retp->appendInteger(rec->x);
               retp->appendInteger(rec->y);
               retp->appendInteger(rec->width);
               retp->appendInteger(rec->height);
               delete rec;
            }
            break;
         }
         case OP_GET_UPDATED_PELS: {
            p->verifyCursorDone();
            jbyteArray b;
            
            byte lbuf[(BLOCK_WIDTH*BLOCK_HEIGHT*4) + 20];
            
            dsdata->timer->timer_printdelta("Top GetUpdatedPels");
            dsdata->timer->timer_start();
            
            b=Java_oem_edge_ed_odc_meeting_client_DScraper_getUpdatedPixelsInBytes2(0, dsdata, lbuf);
            
            retp = new DSMPBaseProto(OP_GET_UPDATED_PELS_REPLY, b!=0, handle);
            
            int cnt=0;
            while(b && cnt < 100) {
               memcpy(&i, b+16, 4);
               i = ntohl(i);
               retp->appendData(b, 0, i+20);
               if (++cnt < 100) {
                  b=Java_oem_edge_ed_odc_meeting_client_DScraper_getUpdatedPixelsInBytes2(0, dsdata, lbuf);
               }
            }
            
            dsdata->timer->timer_printdelta("Returning");
            break;
         }
         case OP_INJECT_KEY: {
            XPoint xpoint;
            xpoint.x   = p->getInteger();
            xpoint.y   = p->getInteger();
            int keysym = p->getInteger();
            p->verifyCursorDone();
            Java_oem_edge_ed_odc_meeting_client_DScraper_injectKey(
                                   0, dsdata,
                                   &xpoint,
                                   (flags & 1) != 0,
                                   (flags & 2) != 0,
                                   keysym);
            
            break;
         }
         case OP_INJECT_MOUSE: {
            XPoint xpoint;
            xpoint.x   = p->getInteger();
            xpoint.y   = p->getInteger();
            int butnum = p->getInteger();
            p->verifyCursorDone();
            Java_oem_edge_ed_odc_meeting_client_DScraper_injectMouse(
                                   0, dsdata,
                                   &xpoint,
                                   (flags & 1) != 0,
                                   butnum);
            
            break;
         }
         case OP_SELECT_WINDOW: {
            p->verifyCursorDone();
            i = Java_oem_edge_ed_odc_meeting_client_DScraper_selectWindow(
                                                                  0, dsdata);
                                                                      
            retp = new DSMPBaseProto(OP_SELECT_WINDOW_REPLY, 
                                     i!=0 && i != -1, handle);
            if (retp->getFlags()) {
               retp->appendInteger(i);
            }
            break;
         }
         default:
            printf("Got Unknown opcode %d", opcode);
            exit(55);
            break;
      }

      if (retp) {
         handler->sendProtocolPacket(retp);
      }
      
      delete p;
   }
};


int main(int argc, char *argv[]) {
   char* outfile = 0;
   
  /* No incoming protocol should be greater than this */
   unsigned char inbuf[1024];
   
   int infd  = dup(0);
   int outfd = dup(1);
   
   if (argc > 2 && !strcmp(argv[1], "-outfile") && argc) {
      outfile = argv[2];
   }
   
  /* Get stderr and stdout hooked to some valid location. Just ditch stdin */
  // If outfile not specified, stays as stdout/err both go to orig stderr
   if (outfile) {
      freopen(outfile, "wb", stderr);
   }
   close(0);
   close(1);
   dup2(2, 1);
   
  // No buffering for stdout/err
   setbuf(stdout, 0);
   setbuf(stderr, 0);
   
   InputStream  *is = new InputStream(infd);
   OutputStream *os = new OutputStream(outfd);
   
   MyDispatcher disp;
   DSMPBaseHandler handler(&disp);
   handler.setInputOutput(is, os);
   handler.run();
   
   PRINTF("Bot of Out\n");
   exit(66);
}

void generateMouseEvent(DScraperData* dsdata) {

   if (dsdata && dsdata->xscraper && dsdata->handler) {
      XPoint* xpoint = (XPoint*)
         Java_oem_edge_ed_odc_meeting_client_DScraper_getCursorPosition
         (0, dsdata);
      
      
      if (xpoint) {
         DSMPBaseProto *retp = new DSMPBaseProto(OP_CURSOR_UPDATE_EVENT, 
                                                 0, 0);
         retp->appendInteger(xpoint->x);
         retp->appendInteger(xpoint->y);
         delete xpoint;
         ((DSMPBaseHandler*)dsdata->handler)->sendProtocolPacket(retp);
      }
   }
}
      

#ifdef NOPE
int main(int argc, char *argv[]) {
//   char* outfile = "/dev/null";
   char* outfile = "outfile";
   
   
  /* No incoming protocol should be greater than this */
   unsigned char inbuf[1024];
   
   infd  = dup(0);
   outfd = dup(1);
   
   if (argc > 2 && !strcmp(argv[1], "-outfile") && argc) {
      outfile = argv[2];
   }
   
  /* Get stderr and stdout hooked to some valid location. Just ditch stdin */
   freopen(outfile, "wb", stderr);
   close(0);
   close(1);
   dup2(2, 1);
   
   int tot, r, len;
   while(1) {
   
      tot = 0;
      
      r = readbytes(inbuf, 0, 6);
      if (r != 6) {
         printf("Got r = %d when wanted 6. Exit\n", r);
         exit(22);
      }
      tot += r;
      
     // If extraInt flag
      if (inbuf[1] & 0x80) {
         r = readbytes(inbuf, tot, 4);
         if (r != 4) {
            printf("Got r = %d when wanted 4. Exit\n", r);
            exit(22);
         }
         tot += r;
      }
      
      len = (inbuf[2] << 16) | (inbuf[3] << 8)  | inbuf[4];
      
      if (len < 0 || len > sizeof(inbuf) || len + tot > sizeof(inbuf)) {
         printf("Len asked for is %d, way too far out for me\n", len);
         exit(22);
      }
      
     // If we need more data ...
      if (len) {
         r = readbytes(inbuf, tot, len);
         if (r != len) {
            printf("Got r = %d when wanted %d. Exit\n", r, len);
            exit(22);
         }
         tot += r;
      }
      
      handleProto(inbuf, tot, len);
   }
   PRINTF("Bot of Out\n");
}
#endif

#endif
