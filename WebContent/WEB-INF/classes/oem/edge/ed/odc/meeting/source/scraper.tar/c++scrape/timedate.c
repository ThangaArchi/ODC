#ifdef __DATE__
char *link_date =	__DATE__  "  "  __TIME__;
#else
char *link_date =	"Unknown Time Date!";
#endif
