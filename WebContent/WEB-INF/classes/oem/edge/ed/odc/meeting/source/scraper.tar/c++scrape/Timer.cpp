
#include <stdio.h>
#include "Timer.h"

unsigned long Timer::gettime() {
   struct timeval tv;
   gettimeofday(&tv, 0);
   return tv.tv_sec * 1000 + tv.tv_usec / 1000; 
}

void Timer::timer_startForce() {
   starttime = lasttime = gettime();
}

void Timer::timer_start() {
   if (dbug) {
      timer_startForce();
   }
}

void Timer::timer_printdeltaForce(const char* s) {
   Timer* t = this;
   unsigned long tdelt, ttot, tlast;
   tlast = t->lasttime;
   t->lasttime = gettime();
   tdelt = t->lasttime - tlast;
   ttot  = t->lasttime - t->starttime;
   fprintf(stderr, "[%d] [%d]: %s\n", tdelt, ttot, s);
}

void Timer::timer_printdelta(const char* s) {
   if (dbug) {
      timer_printdeltaForce(s);
   }
}
