#ifndef _CMAP_H
#define _CMAP_H

#include <X11/Xlib.h>


void cmap_init();


/*--------- class Cmap ---------*/
class Cmap {

private:
   unsigned int  id;
   Visual*       vis;
   XColor*       colors;
   int           tickupdated;
   int           numXcolors;
   unsigned char needsInit;
   unsigned char isstatic;
   unsigned char mappingNeeded;
   unsigned char lastlookup_valid;
   unsigned long lastlookup_Pel;
   unsigned long lastlookup_MapPel;
   
  /* Used for Direct and True Color visuals */
   unsigned long rednorm,  greennorm,  bluenorm;
   unsigned long redshift, greenshift, blueshift;

public:
              Cmap(unsigned int cmapid, Visual* vis);
void          destroy();
void          update(Display* d, int tick);
unsigned long normalize_pixel  (unsigned long pel);
unsigned long unnormalize_pixel(unsigned long pel);

unsigned int  get_id()          { return id;          }
int           get_tickupdated() { return tickupdated; }

};

#endif
