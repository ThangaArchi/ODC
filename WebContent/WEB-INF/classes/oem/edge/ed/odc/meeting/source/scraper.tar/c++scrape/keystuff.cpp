#include "XScraper.h"
#include <X11/Xlibint.h>
#include <X11/extensions/XTest.h>

#define XK_CURRENCY
#define XK_MISCELLANY
#define XK_XKB_KEYS
#define XK_LATIN1
#include <X11/keysymdef.h>

#include <ctype.h>

static int localdebug = 0;

/*   Ancient lore regarding Keysyms and Keycodes

  A KeyCode represents a physical (or logical) key. KeyCodes lie in the
  inclusive range [8,255]. A KeyCode value carries no intrinsic information,
  although server implementors may attempt to encode geometry (for example,
  matrix) information in some fashion so that it can be interpreted
  in a server-dependent fashion. The mapping between keys and KeyCodes
  cannot be changed. 
  
  A KeySym is an encoding of a symbol on the cap of a key. The set of
  defined KeySyms includes the ISO Latin character sets (1-4), Katakana,
  Arabic, Cyrillic, Greek, Technical, Special, Publishing, APL, Hebrew,
  Thai, Korean and a miscellany of keys found on keyboards (Return, Help,
  Tab, and so on). To the extent possible, these sets are derived from
  international standards. In areas where no standards exist, some of
  these sets are derived from Digital Equipment Corporation standards.
  The list of defined symbols can be found in X11/keysymdef.h. Unfortunately,
  some C preprocessors have limits on the number of defined symbols.
  If you must use KeySyms not in the Latin 1-4, Greek, and miscellaneous
  classes, you may have to define a symbol for those sets. Most applications
  usually only include X11/keysym.h, which defines symbols for ISO Latin
  1-4, Greek, and miscellaneous. 

  A list of KeySyms is associated with each KeyCode. The list is intended
  to convey the set of symbols on the corresponding key. If the list (ignoring
  trailing NoSymbol entries) is a single KeySym ``K'', then the list is
  treated as if it were the list ``K NoSymbol K NoSymbol''. If the list
  (ignoring trailing NoSymbol entries) is a pair of KeySyms ``K1 K2'', then
  the list is treated as if it were the list ``K1 K2 K1 K2''. If the list
  (ignoring trailing NoSymbol entries) is a triple of KeySyms ``K1 K2 K3'', 
  then the list is treated as if it were the list ``K1 K2 K3 NoSymbol
  
  When an explicit ``void'' element is desired in the list, the value
  VoidSymbol can be used. 

  The first four elements of the list are split into two groups of KeySyms.
  Group 1 contains the first and second KeySyms; Group 2 contains the
  third and fourth KeySyms. Within each group, if the second element of
  the group is NoSymbol , then the group should be treated as if the second
  element were the same as the first element, except when the first element
  is an alphabetic KeySym ``K'' for which both lowercase and uppercase
  forms are defined. In that case, the group should be treated as if the
  first element were the lowercase form of ``K'' and the second element
  were the uppercase form of ``K.'' 

  The standard rules for obtaining a KeySym from a KeyPress event make
  use of only the Group 1 and Group 2 KeySyms; no interpretation of other
  KeySyms in the list is given. Which
  group to use is determined by the modifier state. Switching between
  groups is controlled by the KeySym named MODE SWITCH, by attaching that
  KeySym to some KeyCode and attaching that KeyCode to any one of the
  modifiers Mod1 through Mod5. This modifier is called the group modifier.
  For any KeyCode, Group 1 is used when the group modifier is off, and
  Group 2 is used when the group modifier is on. 
  
  The Lock modifier is interpreted as CapsLock when the KeySym named 
  XK_Caps_Lock is attached to some KeyCode and that KeyCode is attached
  to the Lock modifier. The Lock modifier is interpreted as ShiftLock
  when the KeySym named XK_Shift_Lock is attached to some KeyCode and
  that KeyCode is attached to the Lock modifier. If the Lock modifier
  could be interpreted as both CapsLock and ShiftLock, the CapsLock 
  interpretation is used. 
  
  The operation of keypad keys is controlled by the KeySym named XK_Num_Lock,
  by attaching that KeySym to some KeyCode and attaching that KeyCode
  to any one of the modifiers Mod1 through Mod5 . This modifier is called
  the numlock modifier. The standard KeySyms with the prefix ``XK_KP_'' in
  their name are called keypad KeySyms; these are KeySyms with numeric
  value in the hexadecimal range 0xFF80 to 0xFFBD inclusive. In addition,
  vendor-specific KeySyms in the hexadecimal range 0x11000000 to 0x1100FFFF
  are also keypad KeySyms. 

  Within a group, the choice of KeySym is determined by applying the first 
  rule that is satisfied from the following list: 

    - The numlock modifier is on and the second KeySym is a keypad KeySym. In 
      this case, if the Shift modifier is on, or if the Lock modifier is on 
      and is interpreted as ShiftLock, then the first KeySym is used, 
      otherwise the second KeySym is used. 

    - The Shift and Lock modifiers are both off. In this case, the first 
      KeySym is used. 

    - The Shift modifier is off, and the Lock modifier is on and is 
      interpreted as CapsLock. In this case, the first KeySym is used, but if 
      that KeySym is lowercase alphabetic, then the corresponding uppercase 
      KeySym is used instead. 

    - The Shift modifier is on, and the Lock modifier is on and is interpreted 
      as CapsLock. In this case, the second KeySym is used, but if that KeySym 
      is lowercase alphabetic, then the corresponding uppercase KeySym is used 
      instead. 

    - The Shift modifier is on, or the Lock modifier is on and is interpreted
      as ShiftLock, or both. In this case, the second KeySym is used. 
*/

void XScraper::freeKeyInjectionResources() {
   if (modifierKeyCodes) {
      XFreeModifiermap(modifierKeyCodes);
      modifierKeyCodes=(XModifierKeymap*)0;
   }
   if (keycodeToKeySymTable) {
      XFree(keycodeToKeySymTable);
      keycodeToKeySymTable=(KeySym*)0;
   }
   memset(forcedKeys, 0, sizeof(forcedKeys));
}

void setForcedKey(unsigned char keys[], KeyCode key, int onOff) {
   if (onOff) keys[(key/8)] |=   1 << (key % 8);
   else       keys[(key/8)] &= ~(1 << (key % 8));
}

int isKeypadKey(KeySym key) {
   switch(key) {
      case XK_KP_Space: 
      case XK_KP_Tab: 
      case XK_KP_Enter: 
      case XK_KP_F1: 
      case XK_KP_F2: 
      case XK_KP_F3: 
      case XK_KP_F4: 
      case XK_KP_Home: 
      case XK_KP_Left: 
      case XK_KP_Up: 
      case XK_KP_Right: 
      case XK_KP_Down: 
      case XK_KP_Prior: 
      case XK_KP_Next: 
      case XK_KP_End: 
      case XK_KP_Begin: 
      case XK_KP_Insert: 
      case XK_KP_Delete: 
      case XK_KP_Equal: 
      case XK_KP_Multiply: 
      case XK_KP_Add: 
      case XK_KP_Separator: 
      case XK_KP_Subtract: 
      case XK_KP_Decimal: 
      case XK_KP_Divide: 
      case XK_KP_0: 
      case XK_KP_1: 
      case XK_KP_2: 
      case XK_KP_3: 
      case XK_KP_4: 
      case XK_KP_5: 
      case XK_KP_6: 
      case XK_KP_7: 
      case XK_KP_8: 
      case XK_KP_9: 
         return 1;
   }
   return 0;
}


/*
** Note, this routine must on;y be called from scrapers thread (if threaded)
*/
void XScraper::reallyInjectKey(int x, int y, int trustXY, 
                               KeySym key, int pressOrRelease) {


  /*
  ** If our keycode to keysym mapping table is out of date, get a new one
  */
   if (!keycodeToKeySymTable || keymapOutOfDate) {
   
      keymapOutOfDate = 0;
      freeKeyInjectionResources();
      
      int mincode, maxcode;
      XDisplayKeycodes(srcDisplay, &mincode, &maxcode);
      minkeycode = mincode;
      maxkeycode = maxcode;
      
      
      int numcodes = (maxcode-mincode)+1;
      
     // We ONLY support 4 members. So, fill things out accordingly
      int keySymsPerKeyCode=0;
      KeySym *ksymtab = XGetKeyboardMapping(srcDisplay, mincode,
                                            numcodes, &keySymsPerKeyCode);
                                            
      KeySym *tptr = ksymtab;
      keycodeToKeySymTable = (KeySym*)XtMalloc(sizeof(KeySym)*4*numcodes);
      int i;
      for(i = 0; i < numcodes; i++) {
         int idx = i*4;
         switch(keySymsPerKeyCode) {
            default:
               memcpy(keycodeToKeySymTable+(idx), tptr, sizeof(KeySym)*4);
               break;
            case 3:
               memcpy(keycodeToKeySymTable+(idx), tptr, sizeof(KeySym)*3);
               keycodeToKeySymTable[(idx)+3] = NoSymbol;
               break;
            case 2:
               memcpy(keycodeToKeySymTable+(idx), tptr, sizeof(KeySym)*2);
               memcpy(keycodeToKeySymTable+(idx)+2, tptr,sizeof(KeySym)*2);
               break;
            case 1:
               keycodeToKeySymTable[(idx)]   = *tptr;
               keycodeToKeySymTable[(idx)+1] = NoSymbol;
               keycodeToKeySymTable[(idx)+2] = *tptr;
               keycodeToKeySymTable[(idx)+3] = NoSymbol;
               break;
         }
         
         if (isascii(keycodeToKeySymTable[idx]) && 
             isalpha(keycodeToKeySymTable[idx]) &&
             keycodeToKeySymTable[idx+1] == NoSymbol) {
            keycodeToKeySymTable[idx]   = tolower(keycodeToKeySymTable[idx]);
            keycodeToKeySymTable[idx+1] = toupper(keycodeToKeySymTable[idx]);
         }
         if (isascii(keycodeToKeySymTable[idx+2]) && 
             isalpha(keycodeToKeySymTable[idx+2]) &&
             keycodeToKeySymTable[idx+3] == NoSymbol) {
            keycodeToKeySymTable[idx+2] = tolower(keycodeToKeySymTable[idx+2]);
            keycodeToKeySymTable[idx+3] = toupper(keycodeToKeySymTable[idx+2]);
         }
         tptr += keySymsPerKeyCode;
      }
      
      if (debug || localdebug) {
         fprintf(stderr, "Keymapping table:\n");
         for(i = 0; i < numcodes; i++) {
            int idx = i*4;
            fprintf(stderr, 
                    "   [%3.3d]   [%4x] %c [%4x] %c [%4x] %c [%4x] %c\n",
                    i+minkeycode,
                    
                    keycodeToKeySymTable[idx],
                    ((isascii(keycodeToKeySymTable[idx]) && 
                      isprint(keycodeToKeySymTable[idx])) ? 
                     keycodeToKeySymTable[idx] : ' '),
                    
                    keycodeToKeySymTable[idx+1],
                    ((isascii(keycodeToKeySymTable[idx+1]) && 
                      isprint(keycodeToKeySymTable[idx+1])) ? 
                     keycodeToKeySymTable[idx+1] : ' '),
                    
                    keycodeToKeySymTable[idx+2],
                    ((isascii(keycodeToKeySymTable[idx+2]) && 
                      isprint(keycodeToKeySymTable[idx+2])) ? 
                     keycodeToKeySymTable[idx+2] : ' '),
                    
                    keycodeToKeySymTable[idx+3],
                    ((isascii(keycodeToKeySymTable[idx+3]) && 
                      isprint(keycodeToKeySymTable[idx+3])) ? 
                     keycodeToKeySymTable[idx+3] : ' '));
         }
      }
         
      
      XtFree((char*)ksymtab);
                                                 
      modifierKeyCodes = XGetModifierMapping(srcDisplay);
      
      lockKeyCode = 0;
      numLockKeyCode = 0;
      modeSwitchKeyCode = 0;
      rightShiftKeyCode = 0;
      leftShiftKeyCode = 0;
      lockIsCapsLock = 0;
      lockIsShiftLock = 0;
      modeSwitchModMask = 0;
      numLockModMask = 0;
      
      if (modifierKeyCodes) {
         int kpm = modifierKeyCodes->max_keypermod;
         KeyCode *modifiermap = modifierKeyCodes->modifiermap;
         
        // Note, I SHOULD check the all keysyms, not just the 1st ... but 
        //  there it is
         for(i=0; i < 8; i++) {
            for(int j=0; j < kpm; j++) {
               KeyCode code = *modifiermap++;
               if (code != 0) {
                  KeySym *tabp = &keycodeToKeySymTable[(code-minkeycode)* 4];
                  if (i == 0) {
                     if (*tabp == XK_Shift_L) {
                        leftShiftKeyCode  = code;
                     } else {
                        rightShiftKeyCode = code;
                     }
                  } else if (i == 1) {
                     if (*tabp == XK_Caps_Lock) {
                        lockIsCapsLock  = 1;
                        lockIsShiftLock = 0;
                        lockKeyCode     = code;
                     } else if (!lockIsCapsLock && *tabp == XK_Shift_Lock) {
                        lockIsShiftLock = 1;
                        lockKeyCode     = code;
                     }
                  } else if (i == 2) {
                    // controlKeyCode = *tabp;  We don't care about control
                    // Treat it as a normal key
                     ;
                  } else {
                     if (*tabp == XK_Mode_switch) {
                        modeSwitchKeyCode = code;
                        modeSwitchModMask = 1 << i;
                     } else if (*tabp == XK_Num_Lock) {
                        numLockKeyCode = code;
                        numLockModMask = 1 << i;
                     }
                  }
               }
            }
         }
      }
   }

   KeyCode newkc;
   newkc = XKeysymToKeycode(srcDisplay, key);
   
   if (debug || localdebug) {
      fprintf(stderr, 
              "------- Key%s [%x] %c    code = %x\n", 
              pressOrRelease?"Press":"Release",
              key, (isascii(key) && isprint(key))?key:' ', newkc);
   }
   
  /* If this is a release, release all forced keys */
   if (!pressOrRelease) {
      for(int i=0; i < 32; i++) {
         if (forcedKeys[i]) {
            for(int j=0; j < 8; j++) {
               if (forcedKeys[i] & (1 << j)) {
                  int lkey = (i*8) + j;
                  XTestFakeKeyEvent(srcDisplay, lkey, 0, 1);
                  if (debug || localdebug) 
                     fprintf(stderr, "Flush forced key 0x%x\n", lkey);
                  forcedKeys[i] &= ~(1 << j);
               }
            }
         }
      }
   }
   
  /*
  ** So, the premise here is we have the desired end keysym which we wish to 
  **  have reflected in an actual 'press' or 'release'.  We do a blocking
  **  query for the currently pressed keys to see what X thinks is held down
  **  (frozen keyboard could be a prob here), and then inject the required
  **  presses/releases of modifiers so the actual keycode inject will be 
  **  correctly interpreted ... Brute force and awkwardness strikes again!
  */
   char keymap[32];
   XQueryKeymap(srcDisplay, keymap);
   
  /*
  ** Calculate what modifiers + keycode need to be held/released to 
  **  accomplish the specified keysym press/release.
  **
  **  For keypress, if the required modifiers are not on, or we have a 
  **  conflict (somethings pressed that should not be pressed to make the
  **  keystoke happen), then we need to mark the offending keycode, 
  **  release it, send all modifiers we required (marking them as added), then
  **  finally, sending the non-modifier keycode.
  **
  **  For release, put things back the way they were.
  */
  
  /* Modifiers, in order:
  **
  **     Shift
  **     Lock
  **     Control
  **     Mod1
  **     Mod2
  **     Mod3
  **     Mod4
  **     Mod5
  */
   int modifiersOn = 0;
   static char *modnames[] = { 
      "Shift", "Lock", "Control", "Mod1", "Mod2", "Mod3", "Mod4", "Mod5" 
   };
   
   
   if (newkc) {
   
     // Calculate which modifiers are on
      if (modifierKeyCodes) {
         int kpm = modifierKeyCodes->max_keypermod;
         KeyCode *modifiermap = modifierKeyCodes->modifiermap;
         
         for(int i=0; i < 8; i++) {
            for(int j=0; j < kpm; j++) {
               KeyCode code = *modifiermap++;
               if (code != 0) {
                  int on  = keymap[code/8]  & (1<<(code % 8));
                  if (on) {
                     modifiersOn |= 1 << i;
                     if (debug || localdebug) {
                        printf("Modifier %s held\n", modnames[i]);
                     }
                  }
               }
            }
         }
      }
      
      
   
      KeySym *tabp = &keycodeToKeySymTable[(newkc-minkeycode)*4];
                                          
     // We know it mapped to this keycode, we now just have to find it
     // If it matches  directly OR, it is a convertable case char
     
      int forceShiftOff      = 0;
      int forceShiftOn       = 0;
      int forceModeSwitchOff = 0;
      int forceModeSwitchOn  = 0;
      int forceNumLockOff    = 0;
      int forceCapsLockOff   = 0;
      int forceShiftLockOff  = 0;
     
      if (pressOrRelease) {
        // If its a keypad key, && numlock is on && its in the 2nd spot
         int iskeypadKey = isKeypadKey(key);
         if ((numLockModMask & modifiersOn) && iskeypadKey &&
             (tabp[1] == key || tabp[3] == key)) {
            
           // If Shift or ShiftLock is on, no biggy, BUT, if modeswitch is not
           //  aligned with our boy, make it be so
            
            if        (tabp[3] != key) {
               
               forceModeSwitchOff = 1;
               
            } else if (tabp[1] != key) {
               
               if (modeSwitchKeyCode) {
                  forceModeSwitchOn  = 1;
               } else {
                  fprintf(stderr, 
                          "Zoinks! Need to force modeswitchON, not def'd %x\n",
                          key);
               }
            }
            
         } else if (iskeypadKey) {
            
            
           // Well, numlock IS on, and if 2nd key pos IS a keypad, 
           //  (but not OUR keypad ... as we now know), then force numlock off
            if ((numLockModMask & modifiersOn) && 
                (isKeypadKey(tabp[1]) || isKeypadKey(tabp[3]))) {
               forceNumLockOff = 1;
            }
            
            if (tabp[0] == key) {
               
              // Since its in pos 1, force shifting off
               forceShiftOff     = 1;
               forceShiftLockOff = 1;
               
            } else if (tabp[2] == key && modeSwitchKeyCode) {
              // Since its in pos 1, force shifting off 
              // Since its 2nd group, force modeswitch on
               forceShiftOff     = 1;
               forceShiftLockOff = 1;
               forceModeSwitchOn = 1;
            } else if (tabp[1] == key) {
              // Since no numlock, a SHIFT will do
               forceShiftOn = 1;
            } else if (tabp[3] == key && modeSwitchKeyCode) {
              // Since no numlock, a SHIFT will do ... if modeswitch is allowed
               forceShiftOn = 1;
               forceModeSwitchOn  = 1;
            } else {
               fprintf(stderr, 
                       "Good Gravy. No valid combo for keypad select[%x]\n",
                       key);
            }
            
         } else {
         
            int alpha = (isascii(key) && isalpha(key));
            
           // For now, don't deal with capslocking logic ... TODO!
            if (alpha) forceCapsLockOff = 1;
            
           // If we are using the 2nd pos
            if ((modifiersOn & 1) || 
                ((modifiersOn & 2) && lockIsShiftLock)) {
               
              // If modeswitch is on
               if (modifiersOn & modeSwitchModMask) {
                  
                 // If its NOT the shifted pos ...
                  if (key != tabp[3]) {
                     
                    // If it IS the non shifted, turn off shifting
                     if        (key == tabp[2]) {
                        forceShiftOff = 1;
                        forceShiftLockOff = 1;
                        
                     } else {
                        
                       // Not 2nd group, force modeswitch off
                        forceModeSwitchOff = 1;
                        
                       // If its NOT the shifted pos
                        if (key != tabp[1]) {
                           
                          // If it IS the non shifted, turn off shifting
                           if (key == tabp[0]) {
                              forceShiftOff = 1;
                              forceShiftLockOff = 1;
                           } else {
                              forceModeSwitchOff = 0;
                              fprintf(stderr, 
                                      "Zoinks! Keynotfound ks[%x] kc[%x]\n",
                                      key, newkc);
                           }
                        }
                     }
                  }
               } else {
                  
                 // If its NOT the shifted pos ...
                  if (key != tabp[1]) {
                     
                    // If it IS the non shifted, turn off shifting
                     if        (key == tabp[0]) {
                        forceShiftOff = 1;
                        forceShiftLockOff = 1;
                        
                     } else {
                        
                       // Not ist group, force modeswitch ON
                        forceModeSwitchOn = 1;
                        
                       // If its NOT the shifted pos
                        if (key != tabp[3]) {
                           
                          // If it IS the non shifted, turn off shifting
                           if (key == tabp[2]) {
                              forceShiftOff = 1;
                              forceShiftLockOff = 1;
                           } else {
                              forceModeSwitchOn = 0;
                              fprintf(stderr, 
                                      "Zoinks! Keynotfound ks[%x] kc[%x]\n",
                                      key, newkc);
                           }
                        }
                     }
                  }
               }
               
            } else {
            
              // First pos is the desired pos Be ugly and just duplicate code
            
              // If modeswitch is on
               if (modifiersOn & modeSwitchModMask) {
                  
                 // If its NOT the unshifted pos ...
                  if (key != tabp[2]) {
                     
                    // If it IS the shifted, turn On shifting
                     if  (key == tabp[3]) {
                        forceShiftOn = 1;
                        
                     } else {
                        
                       // Not 2nd group, force modeswitch off
                        forceModeSwitchOff = 1;
                        
                       // If its NOT the nonshifted pos
                        if (key != tabp[0]) {
                           
                          // If it IS the shifted, turn off shifting
                           if (key == tabp[1]) {
                              forceShiftOn = 1;
                           } else {
                              forceModeSwitchOff = 0;
                              fprintf(stderr, 
                                      "Zoinks! Keynotfound ks[%x] kc[%x]\n",
                                      key, newkc);
                           }
                        }
                     }
                  }
               } else {
                  
                 // If its NOT the non shifted pos ...
                  if (key != tabp[0]) {
                     
                    // If it IS the shifted, turn off shifting
                     if  (key == tabp[1]) {
                     
                        forceShiftOn = 1;
                        
                     } else {
                        
                       // Not ist group, force modeswitch ON
                        forceModeSwitchOn = 1;
                        
                       // If its NOT the non shifted pos
                        if (key != tabp[2]) {
                           
                          // If it IS the shifted, turn On shifting
                           if (key == tabp[3]) {
                              forceShiftOn = 1;
                           } else {
                              forceModeSwitchOn = 0;
                              fprintf(stderr, 
                                      "Zoinks! Keynotfound ks[%x] kc[%x]\n",
                                      key, newkc);
                           }
                        }
                     }
                  }
               }
            }
         }
         
         
         if (trustXY) {
            setXYPosition(x, y);
         }
         
        // For force modeswitch On/Off as needed
         if (forceModeSwitchOff && (modifiersOn & modeSwitchModMask)) {
            XTestFakeKeyEvent(srcDisplay, modeSwitchKeyCode, 0, 1);
            if (debug || localdebug) 
               fprintf(stderr, "Forcing modeSwitch Off\n");
            setForcedKey(forcedKeys, modeSwitchKeyCode, 0);
         } else if (forceModeSwitchOn && !(modifiersOn & modeSwitchModMask)) {
            XTestFakeKeyEvent(srcDisplay, modeSwitchKeyCode, 1, 1);
            setForcedKey(forcedKeys, modeSwitchKeyCode, 1);
            if (debug || localdebug) 
               fprintf(stderr, "Forcing modeswitch On\n");
         }
         
        // For force SHIFT On/Off as needed
         if (forceShiftOff && (modifiersOn & 1)) {
            if (leftShiftKeyCode) {
               XTestFakeKeyEvent(srcDisplay, leftShiftKeyCode, 0, 1);
               if (debug || localdebug) 
                  fprintf(stderr, "Forcing Left shift off %x\n", 
                          leftShiftKeyCode);
               setForcedKey(forcedKeys, leftShiftKeyCode, 0);
            }
            if (rightShiftKeyCode) {
               XTestFakeKeyEvent(srcDisplay, rightShiftKeyCode, 0, 1);
               if (debug || localdebug) 
                  fprintf(stderr, "Forcing Right shift off %x\n", 
                          rightShiftKeyCode);
               setForcedKey(forcedKeys, rightShiftKeyCode, 0);
            }
         } else if (forceShiftOn && !(modifiersOn & 1)) {
            if (leftShiftKeyCode) {
               XTestFakeKeyEvent(srcDisplay, leftShiftKeyCode, 1, 1);
               if (debug || localdebug) 
                  fprintf(stderr, "Forcing Left shift On\n");
               setForcedKey(forcedKeys, leftShiftKeyCode, 1);
            } else if (rightShiftKeyCode) {
               XTestFakeKeyEvent(srcDisplay, rightShiftKeyCode, 1, 1);
               if (debug || localdebug) 
                  fprintf(stderr, "Forcing Right shift On\n");
               setForcedKey(forcedKeys, rightShiftKeyCode, 1);
            } else {
               fprintf(stderr, "Bummer, no SHFT (left or right) for force!\n");
            }
         }
         
        // Force shiftlock modifier off as needed
         if (forceShiftLockOff && (modifiersOn & 0x2) && lockIsShiftLock) {
            XTestFakeKeyEvent(srcDisplay, lockKeyCode, 0, 1);
            if (debug || localdebug) 
               fprintf(stderr, "Forcing Shiftlock off\n");
         } else {
            forceShiftLockOff = 0;
         }
         
        // Force capslock modifier off as needed
         if (forceCapsLockOff && (modifiersOn & 0x2) && lockIsCapsLock) {
            XTestFakeKeyEvent(srcDisplay, lockKeyCode, 0, 1);
            if (debug || localdebug) 
               fprintf(stderr, "Forcing Capslock off\n");
         } else {
            forceCapsLockOff = 0;
         }
         
        // Force numlock modifier off as needed
         if (forceNumLockOff && (modifiersOn & numLockModMask)) {
            XTestFakeKeyEvent(srcDisplay, numLockKeyCode, 0, 1);
            if (debug || localdebug) 
               fprintf(stderr, "Forcing Numlock off\n");
         } else {
            forceNumLockOff = 0;
         }
      }
      
      XTestFakeKeyEvent(srcDisplay, newkc, pressOrRelease != 0, 1);
      
     // Force capslock modifier back ON as needed
      if (forceCapsLockOff) {
         XTestFakeKeyEvent(srcDisplay, lockKeyCode, 1, 1);
         if (debug || localdebug) 
            fprintf(stderr, "Forcing Capslock ON\n");
      }
      
     // Force numlock modifier back ON as needed
      if (forceNumLockOff) {
         XTestFakeKeyEvent(srcDisplay, numLockKeyCode, 1, 1);
         if (debug || localdebug) 
            fprintf(stderr, "Forcing Numlock ON\n");
      }
      
     // Force shiftlock modifier back ON as needed
      if (forceShiftLockOff) {
         XTestFakeKeyEvent(srcDisplay, lockKeyCode, 1, 1);
         if (debug || localdebug) 
            fprintf(stderr, "Forcing Shiftlock ON\n");
      }
   }
}
