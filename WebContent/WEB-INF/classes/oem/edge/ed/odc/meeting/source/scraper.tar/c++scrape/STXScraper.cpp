
#include "XScraper.h"
#include "STXScraper.h"
#include "javatokeysym.h"
#include <stdlib.h>
#include <stdio.h>
#include <wchar.h>


#define SRCP ((XScraper*)src)

/*
 * dummy constructor
 */
STXScraper::STXScraper() {
   src       = 0;
   debug     = 0;
   lastimage = 0;
   scrapeDelay = 250;
}

STXScraper::~STXScraper() {
   if (debug > 0) {
      fprintf(stderr, "STXScraper deconstructor\n");
   }
   if (src) {
      if (lastimage) {
         SRCP->freeImageBuffer((ImageBuffer*)lastimage);
         lastimage = 0;
      }
      delete SRCP;
      src = 0;
   }
}

void  STXScraper::scrapingDelay(int v) { 
   scrapeDelay = v;    
   if (src) {
      SRCP->setScrapeDelay(v);
   }
}
int   STXScraper::scrapingDelay()      { 
   return scrapeDelay; 
}

void  STXScraper::pauseScrape() {
   if (src) {
      SRCP->pauseScrape();
   }
}
void  STXScraper::resumeScrape() {
   if (src) {
      SRCP->resumeScrape();
   }
}

   
int  STXScraper::connect(char* disp, int viewonly) {
   if (debug > 0) {
      fprintf(stderr, 
              "STXScraper::connect to %s, viewonly = %d\n", disp, viewonly);
   }
   
   if (src && SRCP->isConnected()) {
      SRCP->disconnect();
   }
   if (!src) src = new XScraper();
   
   SRCP->setScrapeDelay(scrapeDelay);
   int ret = SRCP->connect(disp, viewonly);
   SetDebugLevel(debug);
   
   if (!ret) {
      // connected successfully, change default scraping size to size of desktop
      if (src && SRCP->isConnected()) {
         XRectangle r;
         if (!SRCP->getWindowExtents((Window)GetDesktopWindow(), &r)) {
            reconfigure(r.x, r.y, r.width, r.height);
         } else {
            fprintf(stderr, "STXScraper::connect: reconfiguring to desktop size failed!  Manually setting scraping area to be (0, 0, 1024, 768)!\n");
            reconfigure(0, 0, 1024, 768);
         }
      }
   }
   
   if (debug > 1) {
      if (ret) {
         fprintf(stderr, "STXScraper::connect unsuccessful!\n");
      } else {
         fprintf(stderr, "STXScraper::connect successful\n");
      }
   }
   return ret;
}
                         
int  STXScraper::disconnect() {
   if (debug > 0) {
      fprintf(stderr, "STXScraper::disconnect\n");
   }
   
   int ret = 0;
   if (src) {
      ret = SRCP->disconnect();
   }
   
   if (debug > 1) {
      if (ret) {
         fprintf(stderr, "STXScraper::disconnect unsuccessful!\n");
      } else {
         fprintf(stderr, "STXScraper::disconnect successful\n");
      }
   }
   return ret;
}

int  STXScraper::isConnected() {
   if (debug > 0) {
      fprintf(stderr, "STXScraper::isConnected\n");
   }
   
   int ret = 0;
   if (src) ret = SRCP->isConnected();
   
   if (debug > 1) {
      fprintf(stderr, "STXScraper::IsConnected returning %d\n", ret);
   }
   return ret;
}

int  STXScraper::reconfigure(HWND win) {
   if (debug > 0) {
      fprintf(stderr, "STXScraper::reconfigure to window 0x%x\n", win);
   }
   
   int ret = 0;
   if (src) ret = SRCP->reconfigure((Window)win);
   
   if (debug > 1) {
      if (ret) {
         fprintf(stderr, "STXScraper::reconfigure unsuccessful!\n");
      } else {
         fprintf(stderr, "STXScraper::reconfigure successful\n");
      }
   }
   return ret;
}

int STXScraper::reconfigure(int sx, int sy, int tw, int th) {
   if (debug > 0) {
      fprintf(stderr, 
              "STXScraper::reconfigure(%d, %d, %d, %d)\n", sx, sy, tw, th);
   }
   
   int ret = 0;
   if (src) ret = SRCP->reconfigure(sx, sy, tw, th);
   
   if (debug > 1) {
      if (ret) {
         fprintf(stderr, "STXScraper::reconfigure unsuccessful!\n");
      } else {
         fprintf(stderr, "STXScraper::reconfigure successful\n");
      }
   }
   return ret;
}

HWND STXScraper::GetDesktopWindow() {
   if (debug > 0) {
      fprintf(stderr, "STXScraper::GetDesktopWindow\n");
   }
   
   HWND ret = 0;
   if (src) ret = (HWND)(SRCP->getDesktopWindow());
   
   if (debug > 1) {
      fprintf(stderr, 
              "STXScraper::GetDesktopWindow returning window %d\n", ret);
   }
   return ret;
}

int STXScraper::IsWindowIconic(HWND hwnd) {
   if (debug > 0) {
      fprintf(stderr, "STXScraper::IsWindowIconic called on window 0x%x\n", hwnd);
   }
   
   int ret = 0;
   if (src) ret = (HWND)(SRCP->isWindowIconic((Window)hwnd));
   
   if (debug > 1) {
      fprintf(stderr, "STXScraper::IsWindowIconic returning %d\n", ret);
   }
   return ret;
}
int STXScraper::IsWindow(HWND hwnd) {
   if (debug > 0) {
      fprintf(stderr, "STXScraper::IsWindow called on window 0x%x\n", hwnd);
   }
   
   int ret = 0;
   if (src) ret = (HWND)(SRCP->isWindow((Window)hwnd));
   
   if (debug > 1) {
      fprintf(stderr, "STXScraper::IsWindow returning %d\n", ret);
   }
   return ret;
}
int STXScraper::IsWindowVisible(HWND hwnd) {
   if (debug > 0) {
      fprintf(stderr, 
              "STXScraper::IsWindowVisible called on window 0x%x\n", hwnd);
   }
   
   int ret = 0;
   if (src) ret = (HWND)(SRCP->isWindowVisible((Window)hwnd));
   
   if (debug > 1) {
      fprintf(stderr, "STXScraper::IsWindowVisible returning %d\n", ret);
   }
   return ret;
}

HWND STXScraper::GetParent( HWND hwnd ) {
   if (debug > 0) {
      fprintf(stderr, "STXScraper::GetParent of window 0x%x\n", hwnd);
   }
   
   HWND ret = 0;
   if (src) ret = (HWND)(SRCP->getParent((Window)hwnd));
   
   if (debug > 1) {
      fprintf(stderr, "STXScraper::GetParent returning window %d\n", ret);
   }
   return ret;
}

int STXScraper::GetWindowText(HWND hwnd, char* s, int l) {
   if (debug > 0) {
      fprintf(stderr, "STXScraper::GetWindowText of window 0x%x\n", hwnd);
   }
   
   int ret = 0;
   if (src) {
      ret = SRCP->getWindowText((Window)hwnd, (char*)s, l);
   }
   if (debug > 1) {
      fprintf(stderr, "\t%d bytes read, title = %s\n", ret, s);
   }
   return ret;
}

int STXScraper::GetWindowTextUnicode(HWND hwnd, char* s, int l) {
   if (debug > 0) {
      fprintf(stderr, 
              "STXScraper::GetWindowTextUnicode of window 0x%x\n", hwnd);
   }
   
   int ret = 0;
   if (src) {
      ret = SRCP->getWindowTextUnicode((Window)hwnd, (wchar_t*)s, l);
   }
   if (debug > 1) {
      fprintf(stderr, "\t%d bytes read\n", ret);
     //wprintf((wchar_t*)s);
     //fprintf(stderr, "\n");
   }
   return ret;
}

int STXScraper::EnumWindows( WNDENUMPROC proc, LPARAM lparam) {
   if (debug > 0) {
      fprintf(stderr, "STXScraper::EnumWindows\n");
   }
   
   int ret = 1;
   if (src && SRCP->isConnected()) {
      LinkList* ll = SRCP->enumerateWindows();
      
      if (debug > 1) {
         fprintf(stderr, 
                 "STXScraper::EnumWindows processing list of windows:\n");
         if (ll) {
            Link* link = ll->get_head();
            while (link) {
               fprintf(stderr, "\t0x%x\n", *(int*)link->data);
               link = link->right;
            }
         }
      }
   
      if (ll) {
         Link* link;
         ret = 0;
         while(link = ll->get_head()) {
            ll->unchain(link);
            proc(*(int*)link->data, lparam);
            free((int*)link->data);
            delete link;
            link = 0;
         }
         delete ll;
         ll = 0;
      }
   }
   
   return ret;
}

int STXScraper::GetWindowTextLength(HWND hwnd) {
   if (debug > 0) {
      fprintf(stderr, "STXScraper::GetWindowTextLength of window 0x%x\n", hwnd);
   }
   
   char str[4096];
   int ret = GetWindowText(hwnd, str, sizeof(str));
   if (debug > 1) {
      fprintf(stderr, "STXScraper::GetWindowTextLength returning %d\n", ret);
   }
   return ret;
}

int STXScraper::GetWindowRect(HWND w, RECT *window_rect) {
   if (debug > 0) {
      fprintf(stderr, "STXScraper::GetWindowRect\n");
   }
   
   int ret = 1;
   if (src && SRCP->isConnected()) {
      XRectangle r;
      
      Window aw = SRCP->find_directRootAncestor((Window)w);
      if (aw && !SRCP->getWindowExtents(aw, &r)) {
         ret = 0;
         window_rect->left   = r.x;
         window_rect->top    = r.y;
         window_rect->right  = r.x + r.width  - 1;
         window_rect->bottom = r.y + r.height - 1;
         if (debug > 1) {
            fprintf(stderr, 
            "STXScraper::GetWindowRect returning rect (%d, %d, %d, %d)\n", 
            r.x, r.y, window_rect->right, window_rect->bottom);
         }
      }
   }
   return ret;
}

HWND STXScraper::windowUnderPoint(POINT p) {
   if (debug > 0) {
      fprintf(stderr, "STXScraper::GetWindowRect\n");
   }
   
   HWND ret = 0;
   if (src && SRCP->isConnected()) {
      
      ret = SRCP->windowUnderPoint(p.x + SRCP->get_STARTX(), 
                                   p.y + SRCP->get_STARTY());
   }
   return ret;
}


int STXScraper::GetCursorPos( POINT *cp ) {
   if (debug > 0) {
      fprintf(stderr, "STXScraper::GetCursorPos\n");
   }
   
   int ret = 1;
   if (src && SRCP->isConnected()) {
      XPoint p;
      if (!SRCP->getCursorPosition(&p)) {
         ret = 0;
         /* we want to return a relative coordinate.  getCursorPosition returns 
            an ABSOLUTE coordinate, so we need to subtract the starting x and y 
            of the image to get a point RELATIVE to the image.  
            NOTE: coords may be NEGATIVE. */
         if (lastimage) {
            cp->x = p.x - ((ImageBuffer*)lastimage)->get_rootx();
            cp->y = p.y - ((ImageBuffer*)lastimage)->get_rooty();
         } else {
            cp->x = p.x - SRCP->get_STARTX();
            cp->y = p.y - SRCP->get_STARTY();
         }
         
         if (debug > 1) {
            fprintf(stderr, 
            "STXScraper::GetCursorPos returning point ABS(%d, %d) REL(%d, %D)\n", 
                    p.x, p.y, cp->x, cp->y);
         }
      }
   }
   return ret;
}

int STXScraper::InjectKey(int x, int y, int type, 
                          int keyCodeOrChar, KeySym ksym) {
   if (debug > 0) {
      fprintf(stderr, "STXScraper::InjectKey, (%d, %d), type=%d, ksym=%d\n",
              x, y, type, ksym);
   }
   
   int ret = 1;
   if (src && SRCP->isConnected()) {
      /* Relative coordinates are being passed in, and XScraper takes in 
         absolute coords, so we need to add the starting x and y of the image. */
      int modifierx = lastimage ? ((ImageBuffer*)lastimage)->get_rootx()
                                : SRCP->get_STARTX();
      int modifiery = lastimage ? ((ImageBuffer*)lastimage)->get_rooty()
                                : SRCP->get_STARTY();
      x += modifierx;
      y += modifiery;
      
      int newks=0;
      int doit = 1;
      if (keyCodeOrChar == 2) {
         newks = lookup_java_to_keysym(ksym);
      } else if (keyCodeOrChar == 1) {
         newks = lookup_unicode16_to_keysym(ksym);
      } else {
         doit = 0;
      }
      
     /*
     ** int ks=0;
     ** if (!(ks = lookup_java_to_keysym(ksym))) {
     **    ks = lookup_unicode16_to_keysym(ksym);
     ** }
     */
      
      if (doit) {
         if (!SRCP->injectKey(x, y, (inputType)type, newks)) {
            ret = 0;
         }
      }
   }
   if (debug > 1) {
      fprintf(stderr, "STXScraper::InjectKey returning %d\n", ret);
   }
   return ret;
} 

int STXScraper::InjectMouse(int x, int y, int type, int buttonNumber) {
   if (debug > 0) {
      fprintf(stderr, "STXScraper::InjectMouse, (%d, %d), type=%d, button=%d\n",
              x, y, type, buttonNumber);
   }
   
   int ret = 1;
   if (src && SRCP->isConnected()) {
      /* Relative coordinates are being passed in, and XScraper takes in 
         absolute coords, so we need to add the starting x and y of the image. */
      int modifierx = lastimage ? ((ImageBuffer*)lastimage)->get_rootx()
                                : SRCP->get_STARTX();
      int modifiery = lastimage ? ((ImageBuffer*)lastimage)->get_rooty()
                                : SRCP->get_STARTY();
      x += modifierx;
      y += modifiery;
      if (!SRCP->injectMouse(x, y, (inputType)type, buttonNumber)) {
         ret = 0;
      }
   }
   if (debug > 1) {
      fprintf(stderr, "STXScraper::InjectMouse returning %d\n", ret);
   }
   return ret;
}

int STXScraper::GetWindowPixels(int sx, int sy, int tw, int th, 
                                unsigned char* outbuf, int len, int newframe) {
   if (debug > 0) {
      fprintf(stderr, "STXScraper::GetWindowPixels with args:\n\tarea = (%d, %d, %d, %d)\n\tlen = %d\n\tnewframe = %d\n", sx, sy, tw, th, len, newframe);
   }
   
   int ret = 1;
   if (len < tw*th*4) {
      fprintf(stderr, "STXScraper::GetWindowPixels: Error - Not enough memory allocated(%d bytes) to get frame of width %d and height %d.\n", len, tw, th);
      return 1;
   }
   
   int x, y;
   int count = 0;
   ImageBuffer* image = 0;
   
   if (newframe || !lastimage) {
      if (src && SRCP->isConnected()) {
         SRCP->freeImageBuffer((ImageBuffer*)lastimage);
         lastimage = 0;
         image = SRCP->getImageFromStack();
         lastimage = (ImageBuffer*)image;
      }
   } else {
      image = (ImageBuffer*)lastimage;
   }
   
   if (!image) {
      fprintf(stderr, "XScraper::GetWindowPixels: image is null! abort\n");
      return 1;
   }
   
  // Calculate absolute bounds
   int SX, SY, EX, EY, ENDX, ENDY;
   SX = 0;
   SY = 0;
   EX = SX + image->get_width()  - 1;
   EY = SY + image->get_height() - 1;
   ENDX = EX;
   ENDY = EY;
   
  // Calculate desired bounds
   int ex = sx + tw - 1;
   int ey = sy + th - 1;
   
   if (!outbuf || !image) {
      fprintf(stderr, "XScraper::GetWindowPixels: Error - outbuf=0x%x, image=0x%x, abort.\n", outbuf, image);
      return 1;
   }
   
   unsigned long* i = (unsigned long*)(image->img);
   unsigned long* tp = (unsigned long*)outbuf;
   unsigned long a, b, c, d;
   
   if (debug > 0) {
      fprintf(stderr, "\tImage boundary (%d, %d, %d, %d)\n\tGrabbing boundary (%d, %d, %d, %d)\n", SX, SY, EX, EY, sx, sy, ex, ey);
   }
   
  // Get valid starting x/y values
   int tsx, tsy;
   tsx = (sx < SX)?SX:sx;
   tsy = (sy < SY)?SY:sy;
   
  // last_line will be pointer to first valid byte in the last line processed
   unsigned int pels_per_line = image->get_width();
   unsigned long* last_line   = i + (tsy * pels_per_line) + tsx;
   
  // 'i' is the current line traversal pointer
   i = last_line;
   
  // Foreach y asked for
   for (y = sy; y <= ey; y++) {
     // Foreach x asked for
      for (x = sx; x <= ex; x++) {
         
        // If this X and Y result in a valid pixel in the image ... add it
         if (y >= SY && y <= EY && x >= SX && x <= EX) {
            if (!SRCP->isBigEndian()) {
               *tp = *i; // lit endian, store as zRGB
            } else {     // big endian, store as BGRz
               a = ((*i) & 0xFF000000);
               b = ((*i) & 0x00FF0000);
               c = ((*i) & 0x0000FF00);
               d = ((*i) & 0x000000FF);
               d = ((d << 24) & 0xFF000000);
               c = ((c << 8)  & 0x00FF0000);
               b = ((b >> 8)  & 0x0000FF00);
               a = ((a >> 24) & 0x000000FF);
               *tp = a | b | c | d;
            }
            
           // get ready for next input pixel
            i++;
         } else {
         
           // Not a valid point in the image, just add a gray pixel
           
            if (!SRCP->isBigEndian()) {
               *tp = 0x00777777; // gray pixel
            } else {
               *tp = 0x77777700;
            }
         }
         
        // increment to next output pixel position and count
         tp++;
         count++;
      }
      
     // Get ready to process next line
      last_line += pels_per_line;
      i          = last_line;
   }
   
   if (count) ret = 0;
   if (debug > 1) {
      fprintf(stderr, "STXScraper::GetWindowPixels ");
      if (!ret) {
         fprintf(stderr, "successful.  ");
      } else {
         fprintf(stderr, "unsuccessful!!  ");
      }
      fprintf(stderr, "%d bytes read into buffer\n.", count*4);
   }
   return ret;
}

extern char *link_date;
void STXScraper::SetDebugLevel(int dlevel) {
   if (dlevel >= 0 && dlevel <= 6) {
      debug = dlevel;
      if (SRCP && (debug == 0 || debug >= 3)) {
         SRCP->set_debug(debug);
      }
      fprintf(stderr, "Debug level = %d\n", debug);
      fprintf(stderr, "STXScraper build time = %s\n", link_date);
      
   } else {
      fprintf(stderr, "Please set debug level between 0 and 6\n");
   }
}

   


/*
** We probably won't ever need these functions below.
*/
int STXScraper::OpenIcon( HWND ) {
   fprintf(stderr, "STXScraper::OpenIcon - Stubbed ... FIX!\n");
   return 0;  // always false
}
int STXScraper::SetForegroundWindow( HWND ) {
   fprintf(stderr, "STXScraper::SetForegroundWindow - Stubbed ... FIX!\n");
   return 0;  // always false
}

HRGN STXScraper::CreateRectRgn( int a, int b, int c, int d ) {
   fprintf(stderr, "STXScraper::CreateRectRgn - Stubbed ... FIX!\n");
   return 0;
}
int  STXScraper::GetRgnBox( HRGN hrgn, RECT *rect) {
   fprintf(stderr, "STXScraper::GetRgnBox - Stubbed ... FIX!\n");
   return 0;
}
int  STXScraper::PtInRegion(HRGN hrgn , int a, int b ) {
   fprintf(stderr, "STXScraper::PtInRegion - Stubbed ... FIX!\n");
   return 0;
}
int  STXScraper::DeleteObject( HRGN ) {
   fprintf(stderr, "STXScraper::DeleteObject - Stubbed ... FIX!\n");
   return 0;
}

int  STXScraper::GetSystemMetrics( int ) {
   fprintf(stderr, "STXScraper::GetSystemMetrics - Stubbed ... FIX!\n");
   return -1;
}

int  STXScraper::OffsetRgn( HRGN hrgn, int x, int y) {
   fprintf(stderr, "STXScraper::OffsetRgn - Stubbed ... FIX!\n");
   return 0;
}
HWND STXScraper::GetNextWindow(HWND hwnd, int t) {
   fprintf(stderr, "STXScraper::GetNextWindow - Stubbed ... FIX!\n");
   return hwnd+1;
}
int  STXScraper::IsRectEmpty( RECT *rect ) {
   fprintf(stderr, "STXScraper::IsRectEmpty - Stubbed ... FIX!\n");
   return 0;
}
int  STXScraper::GetWindowThreadProcessId( HWND hwnd, DWORD *pdw) {
   fprintf(stderr, "STXScraper::GetWindowThreadProcessId - Stubbed ... FIX!\n");
   return 0;
}
int  STXScraper::CombineRgn(HRGN h1, HRGN h2, HRGN h3, int val) {
   fprintf(stderr, "STXScraper::CombineRgn - Stubbed ... FIX!\n");
   return 0;
}
int  STXScraper::GetWindowRgn( HWND hwnd, HRGN hrgn) {
   fprintf(stderr, "STXScraper::GetWindowRgn - Stubbed ... FIX!\n");
   return 1;
}
