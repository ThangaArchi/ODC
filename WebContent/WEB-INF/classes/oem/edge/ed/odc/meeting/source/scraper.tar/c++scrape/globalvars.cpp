
#include "globalvars.h"


char* shortname  = 0;
SDMap* sdmap = 0;

