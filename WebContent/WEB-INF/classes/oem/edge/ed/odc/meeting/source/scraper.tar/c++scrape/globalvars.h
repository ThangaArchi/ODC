
/* global variables file, they are defined in globalvars.cpp */

#ifndef _GLOBALVARS_H
#define _GLOBALVARS_H

#include "SDMap.h"


extern char* shortname;// this is here because both xscraper and xsviewer use it

extern SDMap* sdmap;  // this is here because sdmap and xscraper cannot 
                      // include each other, is there another way?

#endif
