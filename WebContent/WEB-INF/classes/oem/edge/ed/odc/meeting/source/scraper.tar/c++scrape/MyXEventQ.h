#ifndef _MYXEVENTQ_H
#define _MYXEVENTQ_H

#include "MyXEvent.h"
#include "globals.h"


class MyXEventQ {

private:
   MyXEvent* head;
   MyXEvent* tail;
   int       numentries;

public:

#ifdef DOTHREADS
   pthread_mutex_t eventQMutex;
#endif

          MyXEventQ() { Init(); }  // constructor
void      queue_event(XEvent* xev, int otherinfo);
void      prepend_events(MyXEvent* mev);
   
/*------- inline functions -------*/
void      Init() { head = tail = 0; numentries = 0; }
MyXEvent* get_head() { return head; }
   
};

#endif
