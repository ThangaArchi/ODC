/* XScraper class
   Joe Crichton, Justin Su
   May-July 2002 */

/* Basic Overview

   The public function connect takes two parameters - a display to connect to,
   and whether you want to allow input or not.  connect will call start(), which
   gets everything going - a secondary thread is created which listens for events
   and queues them up... while the main thread endlessly does the doTimeout 
   function.  The doTimeout function does all the internal work - 
   it processes all incoming events and it scrapes the screen repeatedly, as fast 
   as it can.  Whatever program that wishes to use these scraped images can
   get them at any time now.
   
   For description of the XScraper and its algorithms, refer to the written
   document by Joe Crichton.
*/
 
#ifndef _XSCRAPER_H
#define _XSCRAPER_H

#include "Node.h"
#include "Hash.h"
#include "LinkList.h"
#include "ImageStack.h"
#include "globals.h"
#include "MyXEvent.h"
#include "MyXEventQ.h"
#include "Timer.h"
#include "ImageObserver.h"

#include <wchar.h>  // for unicode

#include <X11/Xlib.h>
#include <X11/Intrinsic.h>
#include <X11/StringDefs.h>
#include <X11/Xatom.h>
#include <X11/cursorfont.h>
#include <unistd.h>

enum inputType {
   SCRAPE_BUTTONPRESS   = LASTEvent + 10,
   SCRAPE_BUTTONRELEASE = LASTEvent + 11,
   SCRAPE_KEYPRESS      = LASTEvent + 12,
   SCRAPE_KEYRELEASE    = LASTEvent + 13,
   SCRAPE_MOUSEMOTION   = LASTEvent + 14,
   SCRAPE_FORCEUPDATE   = LASTEvent + 15,
   SCRAPE_SELECTWINDOW  = LASTEvent + 16
};


/*--------------------------------*/
/*------- global functions -------*/
/*--------------------------------*/

void  myerrorhandler(Display* d, XErrorEvent* ev);

void  scraperTimeout(XtPointer clientdata, XtIntervalId* timerid);

extern "C" void* scraperMain(void* userarg);


class MouseListener :  public Link {
public:
   MouseListener(void *d) : Link(d) {}
   MouseListener(void) : Link() {}
   virtual void locationUpdate(int x, int y) {}
};
 


/**
 * --------------------------------------------------
 * ----------------- XScraper class -----------------
 * --------------------------------------------------
 *
 * This is the source class for the scraping utility.  This class connects to
 * the source display to be scraped, grabs normalized images, and stores them
 * on a stack to be given to some destination.
 */
 
class XScraper {

private:

// scraping modes - scrape a fixed area, or scrape a paticular window family
#define FIXED_AREA   0
#define FAMILY_SHARE 1

// window states - top-level windows are either normal or iconic
#define NORMAL       1
#define ICONIC       2
#define WITHDRAWN    0

   GC   gc;
   Bool viewonly; // if true, user cannot interact with scraped display
   Bool xtestSupported;
   Bool tryXShm;
   
   XtIntervalId timerId;
   XtInputId    inputId;
   
   friend void* scraperMain(void* userarg);
   friend void scraperWakeupInputCB(XtPointer clientdata, int* fd, 
                                    XtInputId* inputid);
   
   int scrapetime;
   int doScrape;
   
   int scraper_please_die;
   int getScraperPleaseDie() { return scraper_please_die; }
   
#ifdef DOSHM
   Bool            xshmSupported;
   XShmSegmentInfo seginfo;
   XImage*         sharedXImage;
#endif

   int erroroccured;
   unsigned int tick;
   int bytes_per_line;
   int xtestMajor, xtestMinor, xtestEvent, xtestError;
   int xpointer, ypointer;
   int relx, rely;
   int dwidth, dheight;
   int STARTX, STARTY, TESTW, TESTH, ENDX, ENDY;
   
   Cursor crosshair;
   Window window_selection;
   
   int    doconfig, configx, configy, configw, configh;
   Window configwin;
   
   int    doforce, forcex, forcey, forcew, forceh;
   
   int       mode;  // either FIXED_AREA or FAMILY_SHARE
   Window    family_base;
   LinkList *familyTopLevels;
   
   LinkList *imageObservers;

   int            srcargc;
   char         **srcargv;
   Display       *srcDisplay;
   char          *srcdisplay;

   LinkList    ***quantlists;
   int            numqlistsW;
   int            numqlistsH;
   Node          *rootnode;
   Hash          *roothash;
   Node           bogusnode;
   
   ImageStack    *imagestack; // stack of scraped images to be given to something
   MyXEventQ      eventQ;     // queued source events to be processed
   
   LinkList      *mouseListeners;
   
  // Do justice to keymapping
   KeySym           *keycodeToKeySymTable;
   XModifierKeymap  *modifierKeyCodes;
   unsigned char    forcedKeys[32];
   unsigned char    keymapOutOfDate;
   KeyCode          lockKeyCode;
   KeyCode          numLockKeyCode;
   KeyCode          modeSwitchKeyCode;
   KeyCode          rightShiftKeyCode;
   KeyCode          leftShiftKeyCode;
   
   unsigned char    lockIsCapsLock;
   unsigned char    lockIsShiftLock;
   unsigned char    modeSwitchModMask;
   unsigned char    numLockModMask;
   
   KeyCode          minkeycode;
   KeyCode          maxkeycode;
   
   unsigned char    avail[32];  // Nexttime I won't have to recompile world
   
#ifdef DOTHREADS
   int wakeupPipe[2];
#endif

#ifndef DOTHREADS
   int queueXProto;
#endif
   
#ifdef DOTHREADS
   pthread_rwlock_t modelRWLock;
   pthread_t        thread;
   pthread_mutex_t  scraperMutex;
   pthread_cond_t   scraperCond;
#endif


/*------- private member functions -------*/

/** post: initialize members. */
void    init();

/** post: frees all memory. */
void    freeAll();

/** helper function for reconfiguring. */
void    help_config();

/** called by the main XScraper thread to do the actual reconfiguring. */
void    do_reconfigure(int sx, int sy, int tw, int th);

/** called by the main XScraper thread to do the actual reconfiguring. */
void    do_reconfigure(Window win);

/** called by the main XScraper thread: Do the actual force update operation*/
void    do_forceupdate(int sx, int sy, int tw, int th);
 
/** helper function for enumerateWindows. */
void      findClientWindow(Node* node, LinkList* toplevels);

/** post: return Display's resource mask. */
Window    getResourceMask();

/** post: Return the window masked with the Display's resource_mask. */
Window    getFamilyBase(Window win);

/** private version of enumerateWindows. no thread-locking. */
LinkList* _enumerateWindows();  

/** post: update the window's state (either NORMAL, ICONIC, or WITHDRAWN), 
          which is stored in the node. */
void    updateWindowState(Node* n);

/** post: update the window's title, which is stored in the node. */
void    updateWindowText(Node* n);

/** not used */
void    Deallocate_SharedInfo();

/** post: initialize quadrant lists. */
void    quant_initialize(int w, int h);

/** post: checks to see if any part of the window (represented by node)
 *        is in the quadrant [quadx, quadxy].  returns 1 if in quadrant. */
int     isInQuadrant(Node *node, int quadx, int quady);

/** post: return image for the window (Node* n). If qx and qy >= 0, then
 **       return image data for the specified quadrant only
 */
XImage* updateImageForNode(Node* n, int tick, int qx = -1, int qy = -1);

/** post: return the highest ancestor that has the same color depth as the
 *        node in question to be used for scraping action. 
 *        avoid_rootnode is 1 only if in FAMILY_SHARE mode */
Node*   getNodeForAncestorDepth(Node* n, int avoid_rootnode);

/** post: get and store data about all the windows in the particular
          quadrant (widx, hidx) */
void    processQuadrantLinks(LinkList* ll, int widx, int hidx);

/** post: free all quadrant data. This needs to be followed by a
 *        requadrantize(rootnode) */
void    free_QuadrantInfo();

/** post: frees the memory allocated for the quadrant lists. */
void    free_Quadrants();
   
/** post: finds a window's upper-most ancestor, that is, the ancestor
 *        which is a direct child of the root window. */
Window  _find_directRootAncestor(Window win);

/**
 * post: in FAMILY_SHARE mode, this method returns 1 only if this window 
 *       is part of the window family that we wish to keep in the 
 *       quadrant lists.
 *       in FIXED_AREA mode, this method always returns 1. */
int     isValidForFamilyShare(Window win);

/** post: free familyTopLevels. */
void    free_familyTopLevels();

/**
 * post: in FAMILY_SHARE mode, refresh the linked list of top level windows
 *       that are in the window family we are sharing. */
void    refreshFamilyShareTopLevels();

/** post: update the quadrants that the window is in
 *        @param node is the window to be requadrantized */
void    requadrantizeR(Node* node, int d);

/** post: requadrantize window by simply calling requadrantizeR(node, 0) */
void    requadrantize(Node* node);

/** post: number each node in the tree. */
int     numberNodeTree(Node* node, int num);

/** post: update xpointer and ypointer. */
int     setXYPosition (int x, int y);

/** post: warp mouse to (xpointer, ypointer). */
void    warpPointer(int x, int y);

/** post: returns the window that owns pixel at location x, y. */
Node*   findNodeContaining(int x, int y, int findExact=0);

/** post: sets the node's clip values. */
void    SetClipValues(Node* n);

/** post: builds an incore window model of all the windows on the screen. */
Node*   buildNodeTree(Node* parentnode, Window win);

/** post: sets the map state for self, all siblings and children based on the
 *        newstate value. */
void    setMapstate(Node* n, int newstate);

/** post: get specified image from source area, normalize it, then return it.*/
ImageBuffer* getNormalizedImage(int sx, int sy, int tw, int th);

/**
 * post: adjusts the rootx and rooty values of the node, and sets the
 *       clip values. */
void    adjust_rootxy(Node* n, int xdelt, int ydelt);

/** post: process mouse/keyboard input */
int     processInputEvent(MyXEvent* mev);

/** post: process one event from the queue */
int     processEvent(MyXEvent* mev);

/** post: XQueryPointer and add Motion event to Q */
void    queuePointerUpdate();

/** post: empties the event queue */
void    free_queuedEvents();

/** post: process each queued source event, requadrantize node tree if necessary.
 *        This should be called ONLY by src thread (when threaded). */
void    process_queuedEvents(int motionOnly = 0);

void    notifyImageObservers();

/** post: starts running the scraperTimeout function repeatedly.
 *        also a new thread is created that runs scraperMain. */
void    start();

/* Mouse motion observed */
void fireMouseMoved();
void removeAllMouseListeners();

void         queue_eventInternal(XEvent* newevent, int v) { 
   eventQ.queue_event(newevent, v); 
}
void queueXProtocol(int processLevel=0);

void freeKeyInjectionResources();

/*
** Takes a keysym and press/release info, and makes it happen
*/
void reallyInjectKey(int x, int y, KeySym key, int pressOrRelease) {
   reallyInjectKey(x, y, 1, key, pressOrRelease);
}
void reallyInjectKey(KeySym key, int pressOrRelease) {
   reallyInjectKey(0, 0, 0, key, pressOrRelease);
}

void reallyInjectKey(int x, int y, int trustXY, 
                     KeySym key, int pressOrRelease);

public:


   XtAppContext app;
   
   /* these are public now because XSViewer uses them for debugging */
   Timer timer;
   int   debug;

/*------- public member functions -------*/

        /** constructor */
        XScraper();

        
        
/*
** Allow external entity to be told when mouse moves
*/
void addMouseListener(MouseListener* listener);
void removeMouseListener(MouseListener* listener);
   
/** connects to the source display and builds the node tree that represents
    all of the windows. */
int     connect(char* disp, int view_only);

/** disconnects from display. */
int     disconnect();

/** returns 1 if connected to display, else 0. */
int     isConnected();

/** configure the scraping window's location and size to be that of a 
    particular window family. */
int     reconfigure(Window win);

/** configure the scraping area by passing in a starting x and y, and a width
    and height. */
int     reconfigure(int sx, int sy, int tw, int th);

/** returns parent of window. */
Window  getParent(Window win);

/** returns the window's starting location and its width and height. */
int     getWindowExtents(Window win, XRectangle* rec, int ignoremode);
int     getWindowExtents(Window win, XRectangle* rec);

/** returns cursor position */
int     getCursorPosition(XPoint* p);

/** injects inputted key information into xscraper, it does this by
    creating an XEvent and putting it on the queue to be processed */
int     injectKey(int x, int y, inputType type, KeySym k);

/** injects inputted mouse information into xscraper, it does this by
    creating an XEvent and putting it on the queue to be processed */
int     injectMouse(int x, int y, inputType type, int buttonNumber);

int     windowUnderPoint(int x, int y) {
   int ret = 0;
   if (x > STARTX && y > STARTY && x < ENDX && y < ENDY) {
      thread_lock_read(&modelRWLock);
      Node *n = findNodeContaining(x, y, 1);
      if (n) {
         ret = n->window;
      }
      thread_unlock_read(&modelRWLock);
   }
   return ret;
}

/** returns 1 if window is viewable, else returns 0 */
int     isWindowVisible(Window win);

/** returns 1 if window is iconic, else returns 0 */
int     isWindowIconic(Window win);

/** returns 1 if win is a valid window, else returns 0 */
int     isWindow(Window win);

/**
 *  post: returns a list of top-level windows.
 *  calls: getWindowManagerBase, search_for_TopLevel */
LinkList* enumerateWindows();

/** returns the desktop window, which is the root */
Window  getDesktopWindow();


/** returns ImageBuffer for specified area */
ImageBuffer* getUpdate(int x, int y, int w, int h);

/** stores the title of the Window win in buf, returns number of chars read */
int     getWindowText(Window win, char* buf, int size);

/** stores the title of the Window win in buf, in unicode
    returns number of chars read */
int     getWindowTextUnicode(Window win, wchar_t* buf, int size);

void processXProto();

/*------- other public functions ---------------*/

void    removeImageObserver(ImageObserver* obs);

/** This function is used by XSViewer to register itself as an image observer. */
void    addImageObserver(ImageObserver* obs);
   
/** used by STXScraper in GetWindowExtents */
Window  find_directRootAncestor(Window win);

/** used by XSViewer to test rebuilding of incore model */
void    rebuildRequad(int funct);

/** Called by viewer to check if current scraping mode is still valid. This is
    really used to check if the family_base is still of when configed to a win
*/
int     isCurrentModeStillValid();

/**
 * post: called by the global scraperTimeout function (or workProc). This 
 *       function kicks off the entire scraping process.
 * calls: processAll */
void    doTimeout();

/**
 * post:  Handles a frame scrape. Called by whoever and also doTimeout
 *       
 * calls: process_queuedEvents, getNormalizedImage */
ImageBuffer* processAll(int queueImage=1);

/**
 * post:  Called by viewer if it wants the XScraper to automatically drive
 *        scrape via a timeout. When runsThreaded is TRUE, this has no effect.
 *                                                 */
void runTimeout(int trueOrFalse);

/**
 * post:  When runsThreaded is TRUE, this is ignored, otherwise, XScraper will
 *        look at this value to determine how it gets events from its DISPLAY. 
 *        TRUE means it calls XtAppPending and XtAppNextEvent, otherwise
 *        it does nothing (expects they magically appear on its Q) */
void xscraperQueuesXProto(int trueOrFalse);

/*------- inline functions -------*/

void         queue_event(XEvent* newevent, int v) { 
   if (isConnected()) {
      eventQ.queue_event(newevent, v); 
      
#ifdef DOTHREADS
     // If doing threads, write to pipe to wakeup Scraper thread
      char ch = 1;
      write(wakeupPipe[1], &ch, 1);
#endif
   }
}

int runsThreaded() {
#ifdef DOTHREADS
   return 1;
#else
   return 0;
#endif
}

void         set_debug(int dlevel) { debug = dlevel;    }
int          get_debug()           { return debug;      }
int          get_timerdbug()       { return timer.dbug; }
void         set_timerdbug(int l)  { timer.dbug = l;    }
Display*     get_srcDisplay()      { return srcDisplay; }
char*        get_srcdisplay()      { return srcdisplay; }
void         set_erroroccured()    { erroroccured = 1;  }
Bool         get_viewonly()        { return viewonly;   }
int          get_TESTW()           { return TESTW;      }
int          get_TESTH()           { return TESTH;      }
int          get_STARTX()          { return STARTX;     }
int          get_STARTY()          { return STARTY;     }
int          get_dwidth()          { return dwidth;     }
int          get_dheight()         { return dheight;    }
void         setImageBuffering(int stk, int fre) { 
   imagestack->setBuffering(stk, fre);
}
void         setScrapeDelay(int tms)   { scrapetime = tms > 0 ? tms : 333; }
void         pauseScrape()             { doScrape   = 0; }
void         resumeScrape()            { doScrape   = 1; }
ImageBuffer* getImageFromStack()   { 
   ImageBuffer *ret = 0;
#ifndef DOTHREADS
   if (queueXProto) { 
      processAll(1);
   } 
   ret = imagestack->pop(); 
#else
   ret=imagestack->popOrWait(); 
#endif
   return ret;
}
ImageBuffer* getImageFromStackNB() { 
#ifndef DOTHREADS
   if (queueXProto) { 
      processAll(1);
   } 
#endif
   return imagestack->pop();  
}
ImageBuffer* popImageXYWH(ImageBuffer* b) {return imagestack->popImageXYWH(b);}
void         clearImageStack()     { imagestack->free_allStackedImages(); }
void         freeImageBuffer(ImageBuffer* img) {
   imagestack->freeImageBuffer(img); 
}
int          isBigEndian()         { return imagestack->isBigEndian(); }

Window       selectWindow();

/*------- XSViewer only uses these -------*/
void         free_imagestack()     { imagestack->freeImageBuffers(); }
ImageBuffer* get_freeimage(int SX, int SY, int TW, int TH) { return imagestack->getFreeImageBuffer(SX, SY, TW, TH); }
Node*        getNode(Window win) { return (Node*)roothash->find(win, HASHTYPE_NODE); }


};  // end class XScraper


//
// Error returns from connect 
//

#define FAILURE_TO_CONNECT_TO_DISPLAY   1
#define CANT_CHECK_IF_APAR_INSTALLED   33
#define INCONCLUSIVE_APAR_CHECK        44
#define APAR_NOT_INSTALLED             66
#define APAR_IS_INSTALLED             100
#define CONNECT_SUCCESSFUL              0

#endif
