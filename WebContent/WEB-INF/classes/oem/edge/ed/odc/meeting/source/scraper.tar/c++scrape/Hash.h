#ifndef _HASH_H
#define _HASH_H


#define HASHTYPE_NODE  1
#define HASHTYPE_CMAP  2
#define HASHTYPE_ANY   0xffffffff


/*--------- class Hash_t ---------*/
class Hash {

private:

   typedef struct _hash_entry_t {
     int                   val;
     void*                 data;
     int                   type;
     struct _hash_entry_t* next;
   } HashEntry_t;

   int           size;
   HashEntry_t** tab;

#define HASH1(v, sz) (((unsigned int)(v)) % (sz))
#define HASH2(v, sz) (HASH1(hashit((unsigned int)(v)), sz))
#define HASH3(v, sz)  (((unsigned int)v) & ((sz)-1))
#define HASH4(v, sz)  ( (((v) >> 24) ^ ((v) >> 16) ^ ((v) >> 8) ^ v) & ((sz)-1))
#define HASH(lv, lsz) (HASH4((unsigned int)lv, lsz))

   unsigned int hashit(unsigned int key);


public:
      Hash(int sz);
void  add(unsigned int val, void* data, int type);
void* remove(unsigned int val, int type);
void* find(unsigned int val, int type);
void  hash_free();

};

#endif
