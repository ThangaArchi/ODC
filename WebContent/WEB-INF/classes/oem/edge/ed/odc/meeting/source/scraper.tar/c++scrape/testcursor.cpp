#include "STXScraper.h"
#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>

/* Build with 
**
    /usr/ibmcxx/bin/xlC_r -o testcursor-AIX testcursor.cpp \
                     libXScrape-AIX.a  -lXm -lXt -lX11 -lXtst -lXext \
                    -lpthread -lm 
*/

main() {
   STXScraper *xs = new STXScraper();
   xs->connect(":0", 1);
//   xs->SetDebugLevel(2);
   xs->reconfigure(xs->GetDesktopWindow());
   
  // This is needed with OLD STXScraper ... fixed now
   unsigned char buf[1024];
   xs->GetWindowPixels(0, 0, 1, 1, buf, sizeof(buf), 0);
   
   while(1) {
      POINT p;
      xs->GetCursorPos(&p);
      fprintf(stderr, "==> (%d, %d)\n", p.x, p.y);
      sleep(1);
   }
}
