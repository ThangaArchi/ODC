
#include <string.h>
#include "Link.h"


Link::Link(void* d) {
   left = right = 0;
   data = d;
}
Link::Link() {
   left = right = 0;
   data = 0;
}
