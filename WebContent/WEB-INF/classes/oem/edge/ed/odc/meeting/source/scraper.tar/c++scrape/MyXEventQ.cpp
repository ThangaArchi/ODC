
#include "MyXEventQ.h"


void MyXEventQ::prepend_events(MyXEvent* mev) {
   if (mev) {
      thread_lock(&eventQMutex);
      MyXEvent* newtail = mev;
      int cnt = 1;
      while(newtail->next) { newtail = newtail->next; cnt++; }
      newtail->next = head;
      head          = mev;
      if (!tail) {
         tail = newtail;
      }
      numentries += cnt;
      thread_unlock(&eventQMutex);
   }
}

void MyXEventQ::queue_event(XEvent* xev, int otherinfo) {
   thread_lock(&eventQMutex);
   MyXEvent  *mev    = new MyXEvent();
   mev->ev           = *xev;
   mev->otherinfo    = otherinfo;
   if (tail) {
      tail->next = mev;
      tail = mev;
   } else {
      head = tail = mev;
   }
   numentries++;
   thread_unlock(&eventQMutex);
}
