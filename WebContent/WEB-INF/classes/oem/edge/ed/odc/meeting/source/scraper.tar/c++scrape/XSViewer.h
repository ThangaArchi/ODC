/* XSViewer class - Testing utility for XScraper
   Joe Crichton, Justin Su
   May-July 2002 */

#ifndef _XSVIEWER_H
#define _XSVIEWER_H

#include "XScraper.h"
#include "Cmap.h"
#include "MyXEventQ.h"
#include "Timer.h"
#include "ExposeList.h"
#include "ImageObserver.h"
#include <Xm/XmAll.h>


/* callback functions */
void exit_cb(Widget w, XtPointer client, XtPointer call);
void disconnect_cb(Widget w, XtPointer client, XtPointer call);
void timer_cb(Widget w, XtPointer client, XtPointer call);
void debug_cb(Widget w, XtPointer client, XtPointer call);
void config_cb(Widget w, XtPointer client, XtPointer call);
void rebuildRequad_cb(Widget w, XtPointer client, XtPointer call);
void configtowindow_cb(Widget w, XtPointer client, XtPointer call);
void enumwin_cb(Widget w, XtPointer client, XtPointer call);
void expose_cb(Widget w, XtPointer client, XtPointer call);
void InputbyMouse(Widget w, XtPointer client_data, XEvent *ev, Boolean *ctod);
void dstProcessImage(XtPointer clientdata, int* lsrc, XtInputId* inputId);


/*--------- class XSViewer ---------*/
class XSViewer : public Expose_cb, public ImageObserver {

private:

   XScraper *xscraper;
   
   Widget  menuBar, parent, fileButton, optionsButton, helpButton, 
           filePulldown, fileDisconnectButton, fileExitButton, 
           scrolledraw, drawarea,
           optionsPulldown, optionsTimerSrcToggle, optionsTimerDstToggle;
   GC      gc;
   Pixmap  pix;
   Cmap   *cmap;
   XImage *image;
   XtAppContext app;
   XtIntervalId timerId;
   
   int myPipe[2];

   int noOutput;
   int debug;
   
   MyXEventQ eventQ;
   Timer     timer;
   ExposeList   expose;

   Widget       dsttop;
   int          dstargc;
   char       **dstargv;
   Display     *dstDisplay;
   char        *dstdisplay;

   ImageBuffer *lastimage;
   
void connectToDestination();
void buildDestinationGUI();
int  check_and_change_pixmap(ImageBuffer* img);
void help_config();


public:

   XtAppContext getAppContext() { return app; }

     XSViewer(XScraper* s, int dst_noOutput, int dst_timerdbug, int dst_debug, char* ddisplay);
void start();
void do_disconnect_cb();
void do_configtowindow_cb();
void do_enumwin_cb();
void do_config_cb(int cfg);
void do_rebuildRequad_cb(int funct);
void do_InputbyMouse(XEvent* ev);
void do_dstProcessImage();
void do_dstProcessImage_TRYWAY();
virtual void image_ready();
virtual void handle_expose(int x, int y, int w, int h);
             // handle_expose inherited from expose_cb

};

#endif
