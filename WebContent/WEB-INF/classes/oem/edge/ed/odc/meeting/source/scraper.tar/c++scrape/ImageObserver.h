#ifndef _IMAGEOBSERVER_H
#define _IMAGEOBSERVER_H


class ImageObserver {
public:
   virtual void image_ready() = 0;
};


#endif
