
#include <stdio.h>
#include "SDMap.h"
#include "Link.h"


SDMap::SDMap() { 
   map = new LinkList(); 
}

void SDMap::add_SDPair(XScraper* s, Display* d) {
   map->chainLast(new Link(new SDPair(s, d)));
}

void SDMap::remove_SDPair(XScraper* s) {
   Link* l = map->get_head();
   while (l) {
      SDPair* sdp = (SDPair*)l->data;
      if (sdp && sdp->xscraper == s) {
	 map->unchain(l);
         delete sdp;
         delete l;
         return;
      } else {
         fprintf(stderr, "SDMap::remove_SDPair: error!\n");
      }
      l = l->right;
   }
   fprintf(stderr, "SDMap::remove_SDPair failed!\n");
}

XScraper* SDMap::get_XScraper(Display* d) {
   Link* l = map->get_head();
   while (l) {
      if (((SDPair*)l->data)->display == d) {
	 return ((SDPair*)l->data)->xscraper;
      }
      l = l->right;
   }
   return 0;
}
