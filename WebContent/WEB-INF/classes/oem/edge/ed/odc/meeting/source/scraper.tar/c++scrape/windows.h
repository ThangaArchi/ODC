/*
 * Pseudo windows.h to ensure that the compile will happen
 */ 
#if !defined(_INC_WINDOWS)
#define _INC_WINDOWS


#ifdef __cplusplus
extern "C" {
#endif //__cplusplus



/* include X11 defines for Unix environment */
#include "X11/X.h"
#include "X11/Xlib.h"

#ifdef DOTHREADS
#include <pthread.h>
#endif

#define  HWND      long
#define  HINSTANCE long
#define  HRGN      long

#define  NULLHWND   0L
#define  NULLREGION 0L

#define WINAPI    
#define CALLBACK  

typedef int                 BOOL;
#define FALSE               0
#define TRUE                1

typedef unsigned char       BYTE;
typedef unsigned short      WORD;
typedef unsigned long       DWORD;
typedef unsigned long       HDC;

typedef unsigned int        UINT;
typedef BYTE *             PBYTE;
typedef int                  INT;
  typedef int *            HBITMAP;

typedef unsigned long ULONG;

#ifdef STRICT
typedef signed long         LONG;
#else
#define LONG long
#endif

typedef UINT WPARAM;
typedef LONG LPARAM;
typedef LONG LRESULT;

typedef char *           NPSTR;
typedef char *           LPSTR;
typedef const char *     LPCSTR;
typedef BYTE *           LPBYTE;
typedef int *            LPINT;
typedef WORD *           LPWORD;
typedef long *           LPLONG;
typedef DWORD *          LPDWORD;
typedef void *           LPVOID;
typedef int              ATOM;

typedef UINT                    HANDLE;
typedef HANDLE                 HCURSOR;

#ifdef STRICT
typedef void (CALLBACK*     FARPROC)(void);
#else
typedef int (CALLBACK*      FARPROC)();
#endif

/* JMC Changed to char* for now */
#define  wstring        char*
#define  TCHAR          char
#define  WCHAR          char

typedef UINT HBRUSH;
typedef UINT HPALETTE;

typedef LRESULT (CALLBACK* WNDPROC)(HWND, UINT, WPARAM, LPARAM);
typedef LRESULT (CALLBACK* WNDENUMPROC)(HWND,  LPARAM);


typedef struct tagRECT
{
    int left;
    int top;
    int right;
    int bottom;
} RECT;
typedef RECT*      PRECT;

typedef struct tagPOINT
{
    int x;
    int y;
} POINT;
typedef POINT*       PPOINT;

typedef struct CREATESTRUCT_ 
{
void *  lpCreateParams;
} CREATESTRUCT;
typedef CREATESTRUCT* LPCREATESTRUCT;

typedef struct WNDCLASSEX_ 
{
	int                 cbSize;
	void               *style;
	WNDPROC             lpfnWndProc;
	unsigned long       hInstance;
	char               *lpszClassName;
} WNDCLASSEX;
typedef WNDCLASSEX* LPWNDCLASSEX;

/* Queued message structure */
typedef struct tagMSG
{
    HWND	hwnd;
    UINT        message;
    WPARAM	wParam;
    LPARAM	lParam;
    DWORD       time;
    POINT	pt;
} MSG;
/* JMC Changed to PMSGG for now */
typedef MSG* PMSGG;

typedef struct tagBITMAPINFOHEADER
{
    DWORD   biSize;
    LONG    biWidth;
    LONG    biHeight;
    WORD    biPlanes;
    WORD    biBitCount;
    DWORD   biCompression;
    DWORD   biSizeImage;
    LONG    biXPelsPerMeter;
    LONG    biYPelsPerMeter;
    DWORD   biClrUsed;
    DWORD   biClrImportant;
} BITMAPINFOHEADER;
typedef BITMAPINFOHEADER *  PBITMAPINFOHEADER;
typedef BITMAPINFOHEADER * LPBITMAPINFOHEADER;

typedef struct tagRGBQUAD
{
    BYTE    rgbBlue;
    BYTE    rgbGreen;
    BYTE    rgbRed;
    BYTE    rgbReserved;
} RGBQUAD;
typedef RGBQUAD * LPRGBQUAD;


typedef struct tagBITMAPINFO
{
    BITMAPINFOHEADER bmiHeader;
    RGBQUAD          bmiColors[1];
} BITMAPINFO;
typedef BITMAPINFO *  PBITMAPINFO;
typedef BITMAPINFO * LPBITMAPINFO;


#define CW_USEDEFAULT  0
#define WS_POPUP       1
#define WS_OVERLAPPEDWINDOW   0x0001
#define WS_EX_APPWINDOW       0x0002
#define WS_EX_TOPMOST         0x0004

/* Message numbers */
#define WM_QUIT        0x000C
#define WM_NCCREATE    0x0200
#define WM_CREATE      0x0201
#define WM_DESTROY     0x0202
#define WM_USER        0x8000

#define SM_CXSCREEN    -1
#define SM_CYSCREEN    -2

#define ERROR           1

#define RGN_AND         2
#define GW_HWNDPREV     4
#define RGN_XOR         8

/*  defined to make unicode functions use ascii functions */
#define lstrlen strlen
#define lstrcpy strcpy

#ifdef __cplusplus
}
#endif //__cplusplus

#endif /* _INC_WINDOWS */
