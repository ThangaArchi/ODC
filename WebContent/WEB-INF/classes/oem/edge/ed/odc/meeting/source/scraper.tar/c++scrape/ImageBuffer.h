#ifndef _IMAGEBUFFER_H
#define _IMAGEBUFFER_H


class ImageBuffer {

public:
   int            refs;
   unsigned char* img;
   int            rootx;
   int            rooty;
   int            width;
   int            height;
   int            big_endian;

int            get_refs()      { return refs; }
unsigned char* get_img()       { return img; }
int            get_rootx()     { return rootx; }
int            get_rooty()     { return rooty; }
int            get_width()     { return width; }
int            get_height()    { return height; }
int            isBigEndian()   { return big_endian; }
   
};

#endif
