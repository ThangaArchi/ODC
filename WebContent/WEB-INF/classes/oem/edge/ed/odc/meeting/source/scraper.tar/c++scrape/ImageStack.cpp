
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include "ImageStack.h"
#include "globals.h"

#ifdef SunOS
#define BROKENCOND
#endif

ImageStack::ImageStack() {
   numfreeimg       = 0;
   numstackedimg    = 0;
   
   maxstackedimages = MAX_STACKED_IMAGES;
   maxfreeimages    = MAX_FREE_IMAGES;
   
#ifdef DOTHREADS
   pthread_cond_init(&imageStackCond, 0);
#endif

   int test   = 0xff000000;
   if (*((unsigned char*)&test)) {
      big_endian = 1;
   } else {
      big_endian = 0;
   }
}

ImageBuffer* ImageStack::getFreeImageBuffer(int SX, int SY, int TW, int TH) {
   ImageBuffer* ret = 0;
   
   thread_lock(&imageFreeBufferMutex);
   
   // JMC 7/16/02 - Only take it if it matches my needs
   while(!ret && numfreeimg) {
      ret = free_imgbuf[--numfreeimg];
      if (ret->rootx != SX || ret->rooty  != SY || 
          ret->width != TW || ret->height != TH) {
         free(ret->img);
         free(ret);
         ret = 0;
      }
   }
   
   if (!ret) {
      ret = (ImageBuffer*)malloc(sizeof(ImageBuffer));
      memset(ret, 0, sizeof(ImageBuffer));
      ret->img    = (unsigned char*)malloc(TW*TH * 4);
      ret->rootx  = SX;
      ret->rooty  = SY;
      ret->width  = TW;
      ret->height = TH;
      ret->big_endian = big_endian;
   }
   
   thread_unlock(&imageFreeBufferMutex);
   
   IMAGEBUFFER_INCREMENT_REF_COUNT(ret);

   return ret;
}

void ImageStack::freeImageBuffer(ImageBuffer* image) {

   if (image) {
      if (IMAGEBUFFER_DECREMENT_REF_COUNT(image) <= 0) {
         image->refs = 0;
         thread_lock(&imageFreeBufferMutex);
         if (numfreeimg >= maxfreeimages) {
            free(image->img);
            free(image);
            image = 0;
         } else {
            free_imgbuf[numfreeimg++] = image;
         }
         thread_unlock(&imageFreeBufferMutex);
      }
   }
}

void ImageStack::freeImageBuffers() {
   
   int i;
   thread_lock(&imageFreeBufferMutex);

   for(i = 0; i < numfreeimg; i++) {
      ImageBuffer* image = free_imgbuf[i];
      image->refs = 0;
      free(image->img);
      free(image);
      image = 0;
   }
   numfreeimg = 0;
   thread_unlock(&imageFreeBufferMutex);
}


void ImageStack::push(ImageBuffer* image) {
   
   thread_lock(&imageStackMutex);

   if (numstackedimg >= maxstackedimages) {
      freeImageBuffer(imgstack[0]);
      memmove(imgstack, 
              &imgstack[1], 
              sizeof(ImageBuffer*) * (maxstackedimages-1));
      imgstack[numstackedimg-1] = image;
   } else {
      imgstack[numstackedimg++] = image;
   }
   
   thread_unlock(&imageStackMutex);
   
#ifdef DOTHREADS
   pthread_cond_signal(&imageStackCond);
#endif
}

ImageBuffer* ImageStack::popImageXYWH(ImageBuffer* b) {
   ImageBuffer* ret = 0;
   thread_lock(&imageStackMutex);
   if (numstackedimg) {
      ret = imgstack[--numstackedimg];
      if (ret->rootx  != b->rootx ||
          ret->rooty  != b->rooty ||
          ret->width  != b->width ||
          ret->height != b->height) {
         numstackedimg++;;
         ret = 0;
      }
   }
   thread_unlock(&imageStackMutex);
   return ret;
}

ImageBuffer* ImageStack::pop() {
   ImageBuffer* ret = 0;
   thread_lock(&imageStackMutex);
   
   if (numstackedimg) {
      ret = imgstack[--numstackedimg];
   }
   thread_unlock(&imageStackMutex);
   return ret;
}

ImageBuffer* ImageStack::popOrWait() {
   ImageBuffer* ret = 0;
   
#if defined(BROKENCOND) || !defined(DOTHREADS)

  // BrokenCond on SUN leaves us to play icky games
   while(ret == 0) {
      while (numstackedimg <= 0) {
#ifdef DOTHREADS
         usleep(50000);
#endif
      }
      
      if (numstackedimg) {
         thread_lock(&imageStackMutex);
         if (numstackedimg) {
            ret = imgstack[--numstackedimg];
         }
         thread_unlock(&imageStackMutex);
      }
   }
   
#else
   thread_lock(&imageStackMutex);
   while (numstackedimg <= 0) {
      pthread_cond_wait(&imageStackCond, &imageStackMutex);
   }
   if (numstackedimg) {
      ret = imgstack[--numstackedimg];
   }
   thread_unlock(&imageStackMutex);
#endif
   return ret;
}

void ImageStack::free_allStackedImages() {
   thread_lock(&imageStackMutex);

   while(numstackedimg > 0) {
      freeImageBuffer(imgstack[--numstackedimg]);
   }   
   thread_unlock(&imageStackMutex);
}

void ImageStack::setBuffering(int s, int f) {
   thread_lock(&imageStackMutex);
   
   maxstackedimages = (s>0 && s<=MAX_STACKED_IMAGES)?s:MAX_STACKED_IMAGES;
   maxfreeimages    = (f>0 && f<=MAX_FREE_IMAGES)   ?f:MAX_FREE_IMAGES;
   while(numstackedimg > maxstackedimages) {
      freeImageBuffer(imgstack[--numstackedimg]);
   }   
   while(numfreeimg > maxfreeimages) {
      ImageBuffer* fre = free_imgbuf[--numfreeimg];
      free(fre->img);
      free(fre);
   }   
   thread_unlock(&imageStackMutex);
}
