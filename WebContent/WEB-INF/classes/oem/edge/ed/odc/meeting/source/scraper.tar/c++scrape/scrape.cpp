/* Scrape C++ Version
   Refactored by Justin Su
   May, June 2002 */

/*
** Note: Have to deal with windows/cmaps, etc being destroyed. Have to know 
**        when a cmap is no longer valid ... we could see the ID again in the
**        future, and it will have new meaning!!
**
**     : Need to trap Proto errors WRT GetImage failing, (or queries) for 
**       components which have been deleted.
*/

#include <stdlib.h>
#include <stdio.h>
#include <ctype.h>
#include <signal.h>
#include "XScraper.h"
#include "XSViewer.h"
#include "LinkList.h"
#include "globalvars.h"
#include "SDMap.h"


int  origargc;
char **origargv;

char* args_string(char* argname, char* s) {
   if (!s) {
      fprintf(stderr, "%s: Error: Argument %s requires a parameter!\n",
               shortname, argname);
      exit(3);
   }
   return strcpy((char*)malloc(strlen(s)+1), s);
}

int args_int(char* argname, char* s) {
   int ret = 0;
   if (!s || !isascii(*s) || sscanf(s, "%d", &ret) != 1) {
      fprintf(stderr, "%s: Error: Argument %s requires a number parameter!\n",
               shortname, argname);
      exit(3);
   }
   return ret;
}

void show_help() {
   fprintf(stderr, "Usage: %s <options>\n\n\tWhere <options> are:\n\n" 
           "\t\t-xshm                  Try using XShm (could be faster)\n"
           "\t\t-viewonly              View mode only. No control\n"
           "\t\t-srcdisplay DISPLAY    DISPLAY to be scraped\n"
           "\t\t-dstdisplay DISPLAY    DISPLAY to show scrapings\n"
           "\t\t-srcgeometry geom      Geometry to share on src"
           "\t\t-dstgeometry geom      TBD Geometry to map to on dst\n"
           "\t\t-srcdebug lev          Set SRC debug level\n"
           "\t\t-dstdebug lev          Set DST debug level\n"
           "\t\t-srctimer              Show SRC timer vals\n"
           "\t\t-dsttimer              Show DST timer vals\n"
           "\t\t-?                     This help message\n",
           shortname);
   exit(1);
}

void args_adjust(int sidx, int num) {
   memmove(origargv+sidx, origargv+sidx+num, 4*(origargc-sidx-num));
   origargc -= num;
}


/* store args to be passed into the src and dst clases */
char* srcdisplay = 0;
Bool  src_tryXShm = 0;
int   dst_noOutput = 0;
int   src_timerdbug=0, dst_timerdbug=0, src_debug=0, dst_debug=0;
Bool  src_viewonly = 0;
char* dstdisplay = 0;
int   TESTW=600, TESTH=600, STARTX=0, STARTY=0;

void doParseArgs(int argc, char** argv) {
   int i;
   origargv = argv;
   origargc = argc;

   if ((shortname = strrchr(argv[0], '/'))) {
      shortname++;
   } else {
      shortname = argv[0];
   }
   
   if (argc <= 1) {
      show_help();
   } else
   for(i=1; i < origargc; i++) {
      if (*origargv[i] == '-') {
         if        (!strcmp(origargv[i], "-srcdisplay")) {
            srcdisplay = args_string(origargv[i], origargv[i+1]);
            args_adjust(i, 2); i--;
         } else if (!strcmp(origargv[i], "-xshm")) {
            src_tryXShm = 1;
         } else if (!strcmp(origargv[i], "-nooutput")) {
            dst_noOutput = 1;
         } else if (!strcmp(origargv[i], "-srctimer")) {
            src_timerdbug = 1;
         } else if (!strcmp(origargv[i], "-dsttimer")) {
            dst_timerdbug = 1;
         } else if (!strcmp(origargv[i], "-srcdebug")) {
            src_debug = args_int(origargv[i], origargv[i+1]);
            args_adjust(i, 2); i--;
         } else if (!strcmp(origargv[i], "-dstdebug")) {
            dst_debug = args_int(origargv[i], origargv[i+1]);
            args_adjust(i, 2); i--;
         } else if (!strcmp(origargv[i], "-viewonly")) {
            args_adjust(i, 1); i--;
            src_viewonly = 1;
         } else if (!strcmp(origargv[i], "-dstdisplay")) {
            dstdisplay = args_string(origargv[i], origargv[i+1]); 
            args_adjust(i, 2); i--;
         } else if (!strncmp(origargv[i], "-srcgeom", 8)) {
            if (sscanf(origargv[i+1], "%dx%d+%d+%d", 
                       &TESTW, &TESTH, &STARTX, &STARTY) != 4) {
               fprintf(stderr, "%s: -srcgeometry must take WxH+x+y\n", 
                       shortname);
               exit(1);
            }
            args_adjust(i, 2); i--;
         } if (!strcmp(origargv[i], "-?")) {
            show_help();
         }
      } else if (!strcmp(origargv[i], "?")) {
         show_help();
      }
   }
}

/*----- exit functions -----*/

extern "C" void myatexit() {
#ifdef DOSHM
   Deallocate_SharedInfo();
#endif

#ifdef DOTHREADS
   fprintf(stderr, "Cancelling XScraper thread ... ");
   /*   pthread_cancel(src->thread);
   fprintf(stderr, "Exiting ... Joining src thread");
   pthread_join(src->thread, 0);*/
#endif
   fprintf(stderr, "Exiting\n");
}

extern "C" void doexit(int ip) {
  /*myatexit();*/
   exit(44);
}
/*--------------------------*/


void* start_viewer(void* userarg) {
   ((XSViewer*)userarg)->start();
   return 0;
}

void doInit() {
   XtToolkitInitialize();

#ifndef OLDWAY
   {
      struct sigaction act;
      
      act.sa_handler = doexit;
      sigemptyset(&act.sa_mask);
      act.sa_flags = 0;
      sigaction(SIGINT,  &act, 0);
      sigaction(SIGQUIT, &act, 0);
      sigaction(SIGHUP,  &act, 0);
      sigaction(SIGTERM, &act, 0);
      sigaction(SIGABRT, &act, 0);
   }
#else
   signal(SIGINT, doexit);
   signal(SIGQUIT, doexit);
   signal(SIGHUP, doexit);
   signal(SIGTERM, doexit);
   signal(SIGABRT, doexit);
#endif
   atexit(myatexit);
}


/* main function for scrape */
int main(int argc, char* argv[]) {

   XScraper* src;
   XSViewer* dst;
   XScraper* src2;
   XSViewer* dst2;
   
   doInit();
   doParseArgs(argc, argv);

   src = new XScraper();
   if (!src->connect(srcdisplay, 0x80 | src_viewonly)) {
      dst = new XSViewer(src, dst_noOutput, dst_timerdbug, dst_debug, dstdisplay);
      src->addImageObserver(dst);
   
      dst->start();
   } else {
      fprintf(stderr, "Error completing connect");
   }
}
