#ifndef _MYXEVENT_H
#define _MYXEVENT_H

#include <X11/Xlib.h>

class MyXEvent {

public:
   XEvent ev;
   int    otherinfo;
   MyXEvent* next;

     MyXEvent() { next = 0; }
void free_MyXEvent() { delete(this); }

};

#endif
