#ifndef _IMAGESTACK_H
#define _IMAGESTACK_H

#include "ImageBuffer.h"
#include "globals.h"


#define IMAGEBUFFER_IMAGE(i)       ((i)->img)
#define IMAGEBUFFER_IMAGE_ULONG(i) ((unsigned long*)((i)->img))


/**
 * The ImageStack class is a stack of ImageBuffers.
 */
class ImageStack {

private:

#define IMAGEBUFFER_INCREMENT_REF_COUNT(i) (++((i)->refs))
#define IMAGEBUFFER_DECREMENT_REF_COUNT(i) (--((i)->refs))
#define MAX_FREE_IMAGES 3     // 4
#define MAX_STACKED_IMAGES 3  // 5

   ImageBuffer* free_imgbuf[MAX_FREE_IMAGES];
   int numfreeimg;
   ImageBuffer* imgstack[MAX_STACKED_IMAGES];
   int numstackedimg;
   int maxstackedimages;
   int maxfreeimages;
   int big_endian;

public:

#ifdef DOTHREADS
   pthread_mutex_t imageFreeBufferMutex;
   pthread_mutex_t imageStackMutex;
   pthread_cond_t  imageStackCond;
#endif
             ImageStack();
ImageBuffer* getFreeImageBuffer(int SX, int SY, int TW, int TH);
void         freeImageBuffer(ImageBuffer* image);
void         freeImageBuffers();
void         push(ImageBuffer* image);
ImageBuffer* pop();
ImageBuffer* popOrWait();
void         free_allStackedImages();
void         setBuffering(int s, int f);
int          isBigEndian() { return big_endian; }
ImageBuffer* popImageXYWH(ImageBuffer* b);
};

#endif
