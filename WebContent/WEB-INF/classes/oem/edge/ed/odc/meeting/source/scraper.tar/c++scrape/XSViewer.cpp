/* XSViewer class - Testing utility for XScraper
   Joe Crichton, Justin Su
   May-July 2002 */

#include <stdlib.h>
#include <unistd.h>
#include <math.h>
#include <fcntl.h>
#include "XSViewer.h"
#include "globalvars.h"

//#define TRYWAY

#ifdef hpux
#define XDevice int
#define _XINPUT_H_
#endif

#include <X11/extensions/XTest.h>


void dstProcessImageTO(XtPointer clientdata, XtIntervalId *id);

XSViewer::XSViewer(XScraper* s, int dst_noOutput, int dst_timerdbug, int dst_debug, char* ddisplay) {
   // memset(this, 0, sizeof(*this));

   /* memset not used because it destroys the virtual function table */
   xscraper = s;

   menuBar = parent = fileButton = optionsButton = helpButton = 
          filePulldown = fileDisconnectButton = fileExitButton = 
          scrolledraw = drawarea =
          optionsPulldown = optionsTimerSrcToggle = optionsTimerDstToggle = 0;
   pix      = 0;
   gc       = 0;
   cmap     = 0;
   image    = 0;
   app      = 0;
   timerId  = 0;
   
   myPipe[0]  = 0;
   myPipe[1]  = 0;
   debug    = 0;
   noOutput = 0;
   
   dsttop   = 0;
   dstargc  = 0;
   dstargv  = 0;
   dstDisplay = 0;
   dstdisplay = 0;
   
   lastimage  = 0;

   timer.dbug = 0;

   /*----- done setting everything to 0 -----*/

   /* ParseArgs in scrape.cpp sets defaults for these variables.
      If you wish to change the defaults, change them there. */
   noOutput = dst_noOutput;
   timer.dbug = dst_timerdbug;
   debug = dst_debug;
   dstdisplay = ddisplay;

   if (!dstdisplay) {
     dstdisplay = getenv("DISPLAY");
   }

   if (!dstdisplay || !xscraper->get_srcdisplay()) {
      fprintf(stderr, "%s: Either the src or dst displays is NULL!\n", 
              shortname);
      exit(5);
   }

   if (xscraper->runsThreaded()) {
      app = XtCreateApplicationContext();
   } else {
      app = xscraper->app;
   }
   
#ifdef DOTHREADS

   pthread_mutexattr_t mutexattr;
   pthread_mutexattr_init(&mutexattr);
   pthread_mutexattr_settype(&mutexattr, PTHREAD_MUTEX_RECURSIVE);
   pthread_mutex_init(&eventQ.eventQMutex, &mutexattr);   
   pthread_mutexattr_destroy(&mutexattr);
#endif

   pipe(myPipe);
   connectToDestination();
   buildDestinationGUI();
}

void XSViewer::connectToDestination() {
  /*XtAppAddActions(app, actions_table, XtNumber(actions_table));
   XtAppSetFallbackResources(app, fallbacks);
  */
   if (!app) fprintf(stderr, "dst: app is null!\n"); else {
     //printf("dstdisplay=%s shortname=%s\n", dstdisplay, shortname);
   }
   
   /* malloc problem occurs here sometimes??  TODO! */
   dstDisplay = XtOpenDisplay(app, dstdisplay, shortname, "SScrape", 
                              0, 0, &dstargc, dstargv);
   if (!dstDisplay) {
      fprintf(stderr, 
              "sscrape: Error connecting to dstdisplay [%s]. Abort\n",
              dstdisplay);
      exit(2);
   }
  //fprintf(stderr,
  //        "Update dst to pick visual and make a TC out of whatever!\n");
   
   dsttop = XtAppCreateShell(shortname,
                             "SScrape",
                             applicationShellWidgetClass,
                             dstDisplay,
                             (ArgList)NULL, 0);
}   

void XSViewer::start() {

   if (!xscraper->runsThreaded()) {
      xscraper->runTimeout(1);
      xscraper->xscraperQueuesXProto(0);
   }

   for (;;) {
      XEvent newevent;
      XtAppNextEvent(app, &newevent);

      if (newevent.xany.display == XtDisplay(dsttop)) {
         XtDispatchEvent(&newevent);
      } else {
         if (!xscraper->runsThreaded()) {
            xscraper->queue_event(&newevent, 0);
         }
      }
   }
}

void XSViewer::do_disconnect_cb() {
   xscraper->disconnect();
   xscraper->connect(":0", 0);
}

void disconnect_cb(Widget w, XtPointer client, XtPointer call) {
   XSViewer* xsv;
   XtVaGetValues(w, XmNuserData, &xsv, 0);
   xsv->do_disconnect_cb();
}

void exit_cb(Widget w, XtPointer client, XtPointer call) {
  exit(3);  /* want to change so only closes window */
}

void timer_cb(Widget w, XtPointer client, XtPointer call) {
   XmToggleButtonCallbackStruct *cbs = (XmToggleButtonCallbackStruct*)call;
   int* dbugp = (int*)client;
   *dbugp = cbs->set?1:0;
}

void debug_cb(Widget w, XtPointer client, XtPointer call) {
   int* dbugp = (int*)client;
   char* n = XtName(w);
   char* vp = strrchr(n, ' ');
   int v = atoi(vp+1);
   *dbugp = v;
   fprintf(stderr, "New debug value = %d\n", *dbugp);
}

/* called by do_config_cb and do_configtowindow_cb */
void XSViewer::help_config() {
   Dimension width = 0, height = 0;
   Dimension tw, th;
   
   XtVaGetValues(dsttop, XmNwidth, &width, XmNheight, &height, 0);   
   tw = width  - xscraper->get_TESTW();
   th = height - xscraper->get_TESTH();
   
   XFreePixmap(dstDisplay, pix);
   pix = XCreatePixmap(dstDisplay, DefaultRootWindow(dstDisplay), 
                       xscraper->get_TESTW(), xscraper->get_TESTH(),
                       DefaultDepth(dstDisplay, 0));
   XtVaSetValues(drawarea, XmNwidth,  xscraper->get_TESTW(),
                 XmNheight, xscraper->get_TESTH(), 0);
   
   width  = xscraper->get_TESTW() + tw;
   height = xscraper->get_TESTH() + th;
   if (width < xscraper->get_dwidth() && height < xscraper->get_dheight()) {
      XtVaSetValues(dsttop, XmNwidth, width, XmNheight, height, 0);
   }
}

/* called by the global config_cb function */
void XSViewer::do_config_cb(int cfg) {

   int STARTX, STARTY, TESTW, TESTH;   
   fprintf(stderr, "New Config = %d\n", cfg);

   switch(cfg) {
      case 2: 
         STARTX = 400;
         STARTY = 400;
         TESTW  = 600;
         TESTH  = 600;
         break;
      case 3:  // config to desktop size
         STARTX = 0;
         STARTY = 0;
         TESTW  = xscraper->get_dwidth();
         TESTH  = xscraper->get_dheight();
/*       STARTX = 1000;
         STARTY = 500;
         TESTW  = 200;
         TESTH  = 500;*/
         break;
      case 1:
      default: // default initial scraping size
         STARTX = 0;
         STARTY = 0;
         TESTW  = 600;
         TESTH  = 600;
         break;
   }
   
   xscraper->reconfigure(STARTX, STARTY, TESTW, TESTH);
   help_config();
}

void config_cb(Widget w, XtPointer client, XtPointer call) {
   XSViewer* xsv;
   XtVaGetValues(w, XmNuserData, &xsv, 0);
   int cfg = (int)client;
   xsv->do_config_cb(cfg);
}

void XSViewer::do_configtowindow_cb() {
   Window win = 0;
   int count = 0;
   Link* link;
   Node* n;
   LinkList* toplevels = xscraper->enumerateWindows();
   sleep(3);
   printf("Select a window to reconfigure to:\n");
   
#ifdef SELECTIT
   win = xscraper->selectWindow();
   if (win) {
      xscraper->reconfigure(win);
      help_config();
      return;
   } 
#endif
   
   if (toplevels) {
      printf("Select a window to reconfigure to:\n");
      link = toplevels->get_head();
      while (link) {
         count++;
         n = xscraper->getNode(*((int*)link->data));
         if (n) {
            printf("\t%d\t0x%x\t%s", count, n->window, n->text);
            if (n->wm_state == NORMAL) {
               printf("\n");
            } else {
               printf("\t[Iconicized]\n");
            }
         }
         link = link->right;
      }
   }
   int num;
   scanf("%d", &num);
   if (num >= 1 && num <= count) {
      count = 1;
      link = toplevels->get_head();
      while (count < num) {
         count++;
         link = link->right;
      }
      win = *((int*)link->data);
      n = xscraper->getNode(*((int*)link->data));
      if (n) {
         if (n->wm_state == NORMAL) {
            printf("Reconfiguring to 0x%x\t%s\n", n->window, n->text);
         } else {
            printf("Hey, there's a reason it says [Iconicized], bozo!\n");
           //      win = 0;
         }
      }
   } else {
      printf("Invalid choice!  C'mon now, this ain't so hard!\n");
   }
   
   while (link = toplevels->get_head()) {
      toplevels->unchain(link);
      free((int*)link->data);
      delete link;
      link = 0;
   }
   delete toplevels;
   toplevels = 0;
   
   if (win) {
      xscraper->reconfigure(win);
      help_config();
   }
}

void configtowindow_cb(Widget w, XtPointer client, XtPointer call) {
   XSViewer* xsv;
   XtVaGetValues(w, XmNuserData, &xsv, 0);
   xsv->do_configtowindow_cb();
}

/* called by the global rebuildRequad_cb function */
void XSViewer::do_rebuildRequad_cb(int funct) {
   timer.timer_startForce();
   if (funct) {
      timer.timer_printdeltaForce("Rebuilding incore Model");
   } else {
      timer.timer_printdeltaForce("Requadrantize");
   }
   xscraper->rebuildRequad(funct);
   timer.timer_printdeltaForce("Done");
}

void rebuildRequad_cb(Widget w, XtPointer client, XtPointer call) {
   XSViewer* xsv;
   XtVaGetValues(w, XmNuserData, &xsv, 0);
   int funct = (int)client;
   xsv->do_rebuildRequad_cb(funct);
}

void XSViewer::do_enumwin_cb() {
   LinkList* toplevels = xscraper->enumerateWindows();
   if (toplevels) {
      Link* link;
      Node* n;
      while (link = toplevels->get_head()) {
         n = xscraper->getNode(*((int*)link->data));
         if (n) {
            printf("0x%x\t%s\n", n->window, n->text);
         }
         toplevels->unchain(link);
         free((int*)link->data);
         delete link;
         link = 0;
      }
   }
   delete toplevels;
   toplevels = 0;
}

void enumwin_cb(Widget w, XtPointer client, XtPointer call) {
   XSViewer* xsv;
   XtVaGetValues(w, XmNuserData, &xsv, 0);
   xsv->do_enumwin_cb();
}

void XSViewer::handle_expose(int x, int y, int w, int h) {
   XCopyArea(dstDisplay, pix, XtWindow(drawarea), gc, 
             x, y, w, h, x, y);
}

void expose_cb(Widget w, XtPointer client, XtPointer call) {
   XSViewer* xsv;
   XtVaGetValues(w, XmNuserData, &xsv, 0);

   XmDrawingAreaCallbackStruct *ev = (XmDrawingAreaCallbackStruct*)call;
   XExposeEvent* xev = (XExposeEvent*)&ev->event->xexpose;
   /*   add_expose(xev->x, xev->y, xev->width, xev->height);*/
   xsv->handle_expose(xev->x, xev->y, xev->width, xev->height);
}

/* called by the global InputbyMouse function */
void XSViewer::do_InputbyMouse(XEvent* ev) {
   if (xscraper->get_viewonly()) {
      return;
   }   
   if (debug >= 6) {
      fprintf(stderr, "DST: Ev %d\n", ev->type);
   }
   
   if (lastimage) {
      if (ev->type == EnterNotify || ev->type == LeaveNotify) {
        ev->xcrossing.x += lastimage->get_rootx();
        ev->xcrossing.y += lastimage->get_rooty();
         
      } else {
        ev->xbutton.x += lastimage->get_rootx();
        ev->xbutton.y += lastimage->get_rooty();
      }
   } else {
      fprintf(stderr, "DST:do_Input: no lastimage, throwing out input\n");
      return;
   }
   
   switch(ev->type) {
      case KeyPress: {
         KeySym ksym;
         char lbuf[10];
         
         XLookupString(&ev->xkey, lbuf, sizeof lbuf, &ksym, 0);
    
         xscraper->injectKey(ev->xbutton.x, ev->xbutton.y, 
                             SCRAPE_KEYPRESS, ksym);
         break;
      }
      case KeyRelease: {
         KeySym ksym;
         char lbuf[10];
         
         XLookupString(&ev->xkey, lbuf, sizeof lbuf, &ksym, 0);
         
         xscraper->injectKey(ev->xbutton.x, ev->xbutton.y, 
                             SCRAPE_KEYRELEASE, ksym);
         break;
      }
      case EnterNotify:
      case LeaveNotify: {
         xscraper->injectMouse(ev->xcrossing.x, ev->xcrossing.y, 
                               SCRAPE_MOUSEMOTION, 0);
         break;
      }
      case MotionNotify: {
         if (debug >= 6)
            fprintf(stderr, "   x=%d, y=%d\n", ev->xbutton.x, ev->xbutton.y);
         xscraper->injectMouse(ev->xbutton.x, ev->xbutton.y, 
                               SCRAPE_MOUSEMOTION, 0);
         break;
      }
      case ButtonPress: {
         xscraper->injectMouse(ev->xbutton.x, ev->xbutton.y, 
                               SCRAPE_BUTTONPRESS, ev->xbutton.button);
         break;
      }
      case ButtonRelease: {
         xscraper->injectMouse(ev->xbutton.x, ev->xbutton.y, 
                               SCRAPE_BUTTONRELEASE, ev->xbutton.button);
         break;
      }
      default: {
         fprintf(stderr, "XSViewer: What input is this?\n");
      }
   };
}

void InputbyMouse(Widget w, XtPointer client_data, XEvent *ev, Boolean *ctod) {
   XSViewer* dst;
   XtVaGetValues(w, XmNuserData, &dst, 0);
   dst->do_InputbyMouse(ev);
}

void XSViewer::buildDestinationGUI() {

   Widget rebuildModelButton, requadButton, tbut;
   XGCValues gcv;
   Visual* vis = DefaultVisual(dstDisplay, 0);
   XPixmapFormatValues* fmts;
   int numfmts=0;
   int i, depth, modval, totbits, sdw, sdh;
   Colormap lcmap;
   Arg args[5];
   Widget clipwindow=0;
   
   static int color_masks[] = { 0, 
                                0x001, 0x003, 0x007, 0x00f, 
                                0x01f, 0x03f, 0x07f, 0x0ff, 
                                0x1ff, 0x3ff, 0x7ff, 0xfff
   };
   
   lcmap = DefaultColormap(dstDisplay, 0);
   
   depth = 8;
   if (vis->c_class == PseudoColor) {
      int r, g, b;
      int rv, gv, bv;
      int num, i;
      XColor *cols;
      Visual* nvis       = (Visual*)malloc(sizeof(Visual));
      
      memset(nvis, 0, sizeof(Visual));
      
      depth = vis->bits_per_rgb;
      r = g = b = depth/3;
      if (r + g + b < depth) r++;
      if (r + g + b < depth) g++;
      
      nvis->visualid     = vis->visualid;
      nvis->c_class        = TrueColor;
      nvis->bits_per_rgb = r;
      nvis->map_entries  = (int)pow(2, (float)r);
      nvis->blue_mask    = color_masks[b];
      nvis->green_mask   = color_masks[g] << b;
      nvis->red_mask     = color_masks[r] << g+b;
      
      rv = (int)(65536/(pow(2, (float)r)-1));
      gv = (int)(65536/(pow(2, (float)g)-1));
      bv = (int)(65536/(pow(2, (float)b)-1));
      
      vis = nvis;
      lcmap = XCreateColormap(dstDisplay, DefaultRootWindow(dstDisplay), 
                              vis, 1);
      
      fprintf(stderr, "DST: Using PseudoColor cmap = %d\n", lcmap);
      num = (int)pow(2, (float)depth);
      cols = (XColor*)malloc(sizeof(XColor)*num);
      for(i=0; i < num; i++) {
         cols[i].pixel = i;
         cols[i].flags = 7;
         cols[i].red   = ((i & nvis->red_mask)>>(g+b))    * rv;
         cols[i].green = ((i & nvis->green_mask)>>(b))    * gv;
         cols[i].blue  =  (i & nvis->blue_mask)           * bv;
      }

      XStoreColors(dstDisplay, lcmap, cols, num);
      free(cols);
      cols = 0;
      
   } else if (vis->c_class == TrueColor) {
      depth = vis->bits_per_rgb == 3?8:vis->bits_per_rgb*3;
      
     /* Grr ... Citrix lies ... just count them */
      int msk = vis->red_mask | vis->green_mask | vis->blue_mask;
      for(i=1, depth=0; i ; i<<=1) {
         if (i & msk) depth++;
      }
   } else {
      fprintf(stderr, 
              "Hey, I only work with TrueColor or PseudoColor ROOT!\n");
      exit(3);
   }
   
   cmap = new Cmap(lcmap, vis);
      
   fmts = XListPixmapFormats(dstDisplay, &numfmts);
   for(i=0; i < numfmts; i++) {
      if (fmts[i].depth == 16 && depth == 15) {
         depth = 16;
      }
      if (fmts[i].depth == depth) {
         break;
      }
   }
   
   if (i >= numfmts) {
      fprintf(stderr, "Could not find PixmapFormat of correct depth! %d\n",
              depth);
      exit(3);
   }
   
   image = XCreateImage(dstDisplay, vis, depth, ZPixmap, 
                            0, 0, BLOCK_WIDTH, BLOCK_HEIGHT, 
                            fmts[i].scanline_pad, 0);
   image->bits_per_pixel = fmts[i].bits_per_pixel;
   
   totbits = (BLOCK_WIDTH*fmts[i].bits_per_pixel);
   
   modval = totbits%fmts[i].scanline_pad;
   if (modval) totbits += fmts[i].scanline_pad-modval;
   image->bytes_per_line = totbits/8;
   image->data = (char*)malloc(image->bytes_per_line * BLOCK_HEIGHT);
   
   XtFree((char*)(XtPointer)fmts);
 
  //fprintf(stderr, "About to create widget depth=%d\n", depth);
   
   parent = 
      XtCreateManagedWidget("parent", xmFormWidgetClass, dsttop, 0, 0);
   XtVaSetValues(parent, XmNhorizontalSpacing, 0,
                             XmNverticalSpacing, 0,
                             0);

  /*
  ** Menubar 
  */
   menuBar = XmCreateMenuBar(parent, (char*)"menuBar", 0, 0);
   XtVaSetValues(menuBar, XmNleftAttachment, XmATTACH_FORM,
                              XmNrightAttachment, XmATTACH_FORM,
                              XmNtopAttachment, XmATTACH_FORM,
                              0);
   XtManageChild(menuBar);
   fileButton = XmCreateCascadeButton(menuBar, (char*)"File", 0, 0);
   XtManageChild(fileButton);
   optionsButton = XmCreateCascadeButton(menuBar, (char*)"Options", 0, 0);
   XtManageChild(optionsButton);
   helpButton = XmCreateCascadeButton(menuBar, (char*)"Help", 0, 0);
   XtManageChild(helpButton);
   XtVaSetValues(menuBar, XmNmenuHelpWidget, helpButton, 0);
   
  /*
  ** Create pulldown menu from file button
  */
   
   filePulldown = XmCreatePulldownMenu(menuBar, (char*)"filePulldown", 0, 0);
   XtVaSetValues(fileButton, XmNsubMenuId, filePulldown, 0);

   fileDisconnectButton = XmCreatePushButton(filePulldown, (char*)"Disconnect", 0, 0);
   XtManageChild(fileDisconnectButton);
   XtVaSetValues(fileDisconnectButton, XmNuserData, this, 0);
//   XtAddCallback(fileDisconnectButton, XmNactivateCallback, disconnect_cb, 0);
   
   fileExitButton = XmCreatePushButton(filePulldown, (char*)"Exit", 0, 0);
   XtManageChild(fileExitButton);
   XtAddCallback(fileExitButton, XmNactivateCallback, exit_cb, 0);
   
  /*
  ** Create pulldown menu from Option button
  */
   
   optionsPulldown = XmCreatePulldownMenu(menuBar, (char*)"optPulldown",0,0);
   XtVaSetValues(optionsButton, XmNsubMenuId, optionsPulldown, 0);

   optionsTimerSrcToggle = XmCreateToggleButton(optionsPulldown, 
                                                   (char*)"Src Timer", 0, 0);
   XtVaSetValues(optionsTimerSrcToggle, XmNset, xscraper->get_timerdbug() != 0, 0);
   XtManageChild(optionsTimerSrcToggle);
   XtAddCallback(optionsTimerSrcToggle, XmNvalueChangedCallback, timer_cb, 
                 &xscraper->timer.dbug);
                 
   optionsTimerDstToggle = XmCreateToggleButton(optionsPulldown, 
                                                   (char*)"Dst Timer", 0, 0);
   XtVaSetValues(optionsTimerDstToggle, XmNset, timer.dbug != 0, 0);
   XtManageChild(optionsTimerDstToggle);
   XtAddCallback(optionsTimerDstToggle, XmNvalueChangedCallback, timer_cb, 
                 &timer.dbug);
   
   XtManageChild(XmCreateSeparator(optionsPulldown, (char*)"Sep1", 0, 0));
   
   requadButton = XmCreatePushButton(optionsPulldown, 
                                                 (char*)"Requadrantize", 0, 0);
   XtManageChild(requadButton);
   XtVaSetValues(requadButton, XmNuserData, this, 0);
   XtAddCallback(requadButton, XmNactivateCallback, 
                 rebuildRequad_cb, (XtPointer)0);
                 
   rebuildModelButton = XmCreatePushButton(optionsPulldown, 
                                                 (char*)"Rebuild Model", 0, 0);
   XtManageChild(rebuildModelButton);
   XtVaSetValues(rebuildModelButton, XmNuserData, this, 0);
   XtAddCallback(rebuildModelButton, XmNactivateCallback, 
                 rebuildRequad_cb, (XtPointer)1);
   
   XtManageChild(XmCreateSeparator(optionsPulldown, (char*)"Sep2", 0, 0));
   
   tbut = XmCreatePushButton(optionsPulldown, (char*)"Src Debug 0", 0, 0);
   XtManageChild(tbut);
   XtAddCallback(tbut, XmNactivateCallback, debug_cb, &xscraper->debug);
   
   tbut = XmCreatePushButton(optionsPulldown, (char*)"Src Debug 1", 0, 0);
   XtManageChild(tbut);
   XtAddCallback(tbut, XmNactivateCallback, debug_cb, &xscraper->debug);
   
   tbut = XmCreatePushButton(optionsPulldown, (char*)"Src Debug 2", 0, 0);
   XtManageChild(tbut);
   XtAddCallback(tbut, XmNactivateCallback, debug_cb, &xscraper->debug);
   
   tbut = XmCreatePushButton(optionsPulldown, (char*)"Src Debug 3", 0, 0);
   XtManageChild(tbut);
   XtAddCallback(tbut, XmNactivateCallback, debug_cb, &xscraper->debug);
              
   tbut = XmCreatePushButton(optionsPulldown, (char*)"Src Debug 4", 0, 0);
   XtManageChild(tbut);
   XtAddCallback(tbut, XmNactivateCallback, debug_cb, &xscraper->debug);
   
   tbut = XmCreatePushButton(optionsPulldown, (char*)"Src Debug 5", 0, 0);
   XtManageChild(tbut);
   XtAddCallback(tbut, XmNactivateCallback, debug_cb, &xscraper->debug);
   
   tbut = XmCreatePushButton(optionsPulldown, (char*)"Src Debug 6", 0, 0);
   XtManageChild(tbut);
   XtAddCallback(tbut, XmNactivateCallback, debug_cb, &xscraper->debug);
              
   XtManageChild(XmCreateSeparator(optionsPulldown, (char*)"Sep3", 0, 0));
   
   tbut = XmCreatePushButton(optionsPulldown, (char*)"Dst Debug 0", 0, 0);
   XtManageChild(tbut);
   XtAddCallback(tbut, XmNactivateCallback, debug_cb, &debug);
   
   tbut = XmCreatePushButton(optionsPulldown, (char*)"Dst Debug 1", 0, 0);
   XtManageChild(tbut);
   XtAddCallback(tbut, XmNactivateCallback, debug_cb, &debug);
   
   tbut = XmCreatePushButton(optionsPulldown, (char*)"Dst Debug 2", 0, 0);
   XtManageChild(tbut);
   XtAddCallback(tbut, XmNactivateCallback, debug_cb, &debug);
   
   tbut = XmCreatePushButton(optionsPulldown, (char*)"Dst Debug 3", 0, 0);
   XtManageChild(tbut);
   XtAddCallback(tbut, XmNactivateCallback, debug_cb, &debug);
              
   tbut = XmCreatePushButton(optionsPulldown, (char*)"Dst Debug 4", 0, 0);
   XtManageChild(tbut);
   XtAddCallback(tbut, XmNactivateCallback, debug_cb, &debug);
   
   tbut = XmCreatePushButton(optionsPulldown, (char*)"Dst Debug 5", 0, 0);
   XtManageChild(tbut);
   XtAddCallback(tbut, XmNactivateCallback, debug_cb, &debug);
   
   tbut = XmCreatePushButton(optionsPulldown, (char*)"Dst Debug 6", 0, 0);
   XtManageChild(tbut);
   XtAddCallback(tbut, XmNactivateCallback, debug_cb, &debug);
   
   XtManageChild(XmCreateSeparator(optionsPulldown, (char*)"Sep4", 0, 0));
              
   tbut = XmCreatePushButton(optionsPulldown, (char*)"Orig Config", 0, 0);
   XtManageChild(tbut);
   XtVaSetValues(tbut, XmNuserData, this, 0);
   XtAddCallback(tbut, XmNactivateCallback, config_cb, (XtPointer)1);
   
   tbut = XmCreatePushButton(optionsPulldown, (char*)"Config 2", 0, 0);
   XtManageChild(tbut);
   XtVaSetValues(tbut, XmNuserData, this, 0);
   XtAddCallback(tbut, XmNactivateCallback, config_cb, (XtPointer)2);
   
   tbut = XmCreatePushButton(optionsPulldown, (char*)"Config 3", 0, 0);
   XtManageChild(tbut);
   XtVaSetValues(tbut, XmNuserData, this, 0);
   XtAddCallback(tbut, XmNactivateCallback, config_cb, (XtPointer)3);
   
   tbut = XmCreatePushButton(optionsPulldown, (char*)"Enumerate Windows", 0, 0);
   XtManageChild(tbut);
   XtVaSetValues(tbut, XmNuserData, this, 0);
   XtAddCallback(tbut, XmNactivateCallback, enumwin_cb, 0);
   
   tbut = XmCreatePushButton(optionsPulldown, (char*)"Config to Window", 0, 0);
   XtManageChild(tbut);
   XtVaSetValues(tbut, XmNuserData, this, 0);
   XtAddCallback(tbut, XmNactivateCallback, configtowindow_cb, 0);
       
   // Create scrolled display area
   sdw = (90*xscraper->get_dwidth()) / 100;
   sdh = (90*xscraper->get_dheight())/ 100;
   if (sdw > xscraper->get_TESTW()) sdw = xscraper->get_TESTW();
   if (sdh > xscraper->get_TESTH()) sdh = xscraper->get_TESTH();
   
   sdw += 10; sdh += 10;
  
   XtSetArg(args[0], XmNscrollingPolicy, XmAUTOMATIC);
   scrolledraw=XmCreateScrolledWindow(parent, (char*)"scrolleddraw", args, 1);
   XtVaSetValues(scrolledraw, XmNleftAttachment,   XmATTACH_FORM,
                                  XmNrightAttachment,  XmATTACH_FORM,
                                  XmNbottomAttachment, XmATTACH_FORM,
                                  XmNtopAttachment,    XmATTACH_WIDGET,
                                  XmNtopWidget,        menuBar,
                                  XmNwidth,            sdw,
                                  XmNheight,           sdh,
                 0);
   XtManageChild(scrolledraw);
   
   // Create drawing area
   pix = XCreatePixmap(dstDisplay, DefaultRootWindow(dstDisplay), 
                       xscraper->get_TESTW(), xscraper->get_TESTH(), 
                       DefaultDepth(dstDisplay, 0));
   
   XtSetArg(args[0], XmNcolormap,        lcmap);
   drawarea=XmCreateDrawingArea(scrolledraw, (char*)"draw", args, 1);
   XtVaSetValues(drawarea,    XmNwidth,            xscraper->get_TESTW(),
                              XmNheight,           xscraper->get_TESTH(), 0);
   XtVaSetValues(drawarea, XmNuserData, this, 0);
   XtAddCallback(drawarea, XmNexposeCallback, expose_cb, 0);
   XtManageChild(drawarea);
   
   XtVaSetValues(scrolledraw, XmNworkWindow, drawarea, 0);
   XtVaGetValues(scrolledraw, XmNclipWindow, &clipwindow,  0);
   
   gc = XCreateGC(dstDisplay, DefaultRootWindow(dstDisplay), 
                      0, &gcv);
                      
   if (!xscraper->get_viewonly()) {
      XtAddEventHandler(drawarea, ButtonPressMask | ButtonReleaseMask |
                        ButtonMotionMask | PointerMotionMask | KeyPressMask |
                        KeyReleaseMask | EnterWindowMask | LeaveWindowMask,
                        False, (XtEventHandler)InputbyMouse, 0);
   }
                      
                      
   XtRealizeWidget(dsttop);
   
   /* If my local cmap is != root cmap, put both windows on Colormap prop */
   if (lcmap != DefaultColormap(dstDisplay, 0)) {
      unsigned int winlist[3];
      winlist[0] = XtWindow(drawarea);
      winlist[1] = XtWindow(dsttop);
      winlist[2] = 0;
      XChangeProperty(dstDisplay, 
                      XtWindow(dsttop), 
                      XInternAtom(dstDisplay, "WM_COLORMAP_WINDOWS", 0),
                      XA_WINDOW,
                      32,
                      PropModeReplace,
                      (const unsigned char*)(XtPointer)winlist, 2);
   }
   
   fcntl(myPipe[0], F_SETFL, O_NONBLOCK);
   
#ifdef TRYWAY 
   xscraper->pauseScrape();
   xscraper->clearImageStack();
   XtAppAddTimeOut(app, 5000, dstProcessImageTO, this);
#else
   XtAppAddInput(app, myPipe[0], (XtPointer)XtInputReadMask, 
                 dstProcessImage, this);
#endif
}

#define DO_INLINE_EXPOSES
int XSViewer::check_and_change_pixmap(ImageBuffer* img) {
   int quads;
   int x, y, wi, hi, i, rem;
   int wblocks;
   int hblocks;
   int pelsperwblock;
   int lastpelsperwblock;
   int pelsperhblock;
   int lastpelsperhblock;
   int iterperline;
   int bytesperpel;
   int bytes_per_line;
   int ret = 0;
   
   bytesperpel = 4;
 
  /* LOTS of optimizations can be plied! */

  /* Calculate number of w and h blocks needed */
   wblocks = xscraper->get_TESTW() / BLOCK_WIDTH;
   rem     = xscraper->get_TESTW() % BLOCK_WIDTH;
   if (wblocks == 0) {
      wblocks = 1;
      pelsperwblock = lastpelsperwblock = xscraper->get_TESTW();
   } else if (rem) {
      wblocks++;
      pelsperwblock = BLOCK_WIDTH;
      lastpelsperwblock = rem;
   } else {
      pelsperwblock = lastpelsperwblock = BLOCK_WIDTH;
   }
   
   hblocks = xscraper->get_TESTH() / BLOCK_HEIGHT;
   rem     = xscraper->get_TESTH() % BLOCK_HEIGHT;
   if (hblocks == 0) {
      hblocks = 1;
      pelsperhblock = lastpelsperhblock = xscraper->get_TESTH();
   } else if (rem) {
      hblocks++;
      pelsperhblock = BLOCK_HEIGHT;
      lastpelsperhblock = rem;
   } else {
      pelsperhblock = lastpelsperhblock = BLOCK_HEIGHT;
   }
   
   bytes_per_line = bytesperpel*xscraper->get_TESTW();
   
   timer.timer_printdelta("DST: top ccp");
   
  /* 
  ** Process a row of blocks at a time, repeat hblocks times
  */
   y = 0;
   for (hi = hblocks; hi; hi--) {
   
      int th = ((hi == 1)?lastpelsperhblock:pelsperhblock);
      
      x = 0;
      
      for (wi = wblocks; wi; wi--) {
         int h, tw;
         unsigned char* od, *nd;
         int ofs;
         int doit = 0;
         
         tw=((wi == 1)?lastpelsperwblock:pelsperwblock);
         
        /*doit = check_expose(x, y, tw, th);*/
         
         if (!doit && lastimage) {
            ofs = (x*bytesperpel)+(bytes_per_line*y);
            od = IMAGEBUFFER_IMAGE(lastimage) + ofs;
            nd = IMAGEBUFFER_IMAGE(img)            + ofs;
            for (h = th; h && !doit; h--, od += bytes_per_line, 
                                       nd += bytes_per_line) {
               if (memcmp(od, nd, tw*bytesperpel)) {
                  doit = 1;
                  break;
               }
            }
         }
         
         if (doit || !lastimage) {
            int lx, ly;
            if (debug > 4) {
               fprintf(stderr, "DST: Copy x/y %d/%d w/h %d/%d\n", 
                       x, y, tw, th);
            }
            
            ofs = (x*bytesperpel) + (bytes_per_line*y);
            for (ly = 0; ly < th; ly++) {
               nd = IMAGEBUFFER_IMAGE(img) + ofs + (ly*bytes_per_line);
               for (lx = 0; lx < tw; lx++, nd += 4) {
                  unsigned long pel = *(unsigned long*)nd;
                  pel = cmap->unnormalize_pixel(pel);
                  XPutPixel(this->image, lx, ly, pel);
               }
            }
            
            timer.timer_printdelta("DST: Before putimg");
            XPutImage(dstDisplay, pix, gc, 
                      this->image, 0, 0, x, y, tw, th);
                      
            timer.timer_printdelta("DST: After putimg");
#ifdef DO_INLINE_EXPOSES
            handle_expose(x, y, tw, th);
#else
            expose.add_expose(x, y, tw, th);
#endif
            timer.timer_printdelta("DST: After addexpose");
                          
            ret++;
         }
         
         x += pelsperwblock;
      }
      y += pelsperhblock;
   }
   
#ifdef DO_INLINE_EXPOSES
   expose.clear_exposes();
#else
   timer_printdelta("DST: Start Expose Process");
   expose.handle_exposes(this);
   timer_printdelta("DST: Finished Expose Process");
#endif
   
   return ret;
}


/* called by the global dstProcessImage function */
void XSViewer::do_dstProcessImage() {
   char ch = 0;
   
#ifdef DOTHREADS
   pthread_testcancel();
#endif

   timer.timer_start();

   ImageBuffer* img = xscraper->getImageFromStack();

   while(read(myPipe[0], &ch, 1) == 1);

   xscraper->free_imagestack();
   timer.timer_printdelta("DST: dstProcImg: Popimage, read wakeup byte");

   if (img) {
      int changed;
      
      if (!noOutput) {
      
        // JMC 7/15/02 - If the image size changed, modify our drawing area
        //               AND ditch any old image (which does NOT match as well)
         Dimension w, h;
         XtVaGetValues(drawarea, XmNwidth, &w, XmNheight, &h, 0);
         if (img->width != w || img->height != h || 
            (lastimage && 
             (lastimage->width != img->width||lastimage->height != img->height))) {
            xscraper->freeImageBuffer(lastimage);
            lastimage = 0;
            XFreePixmap(dstDisplay, pix);
            pix = XCreatePixmap(dstDisplay, DefaultRootWindow(dstDisplay), 
                                img->width, img->height,
                                DefaultDepth(dstDisplay, 0));
            XtVaSetValues(drawarea, XmNwidth, img->width, 
                                    XmNheight, img->height, 0);
         }
         
         changed = check_and_change_pixmap(img);
         timer.timer_printdelta("DST: dstProcImg: Calculate Difference squares");
      }
      
      if (lastimage) {
         xscraper->freeImageBuffer(lastimage);
      }
      lastimage = img;
      
#ifdef NOEXPOSEMETHOD
      if (changed) {         
        /* Ensure Pixmap updates are installed  */
         XtVaSetValues(drawarea, XmNbackgroundPixmap, 0, 0);
         XtVaSetValues(drawarea, XmNbackgroundPixmap, pix, 0);
         XFlush(dstDisplay);
      }
#endif

      XFlush(dstDisplay);

   } else {
      fprintf(stderr, "dstProcessImage: No image waiting!\n");
   }
   
   timer.timer_printdelta("DST: dstProcImg: Done");
}


/* called by the global dstProcessImage function */
void XSViewer::do_dstProcessImage_TRYWAY() {
   char ch = 0;
   
#ifdef DOTHREADS
   pthread_testcancel();
#endif

   timer.timer_start();

   xscraper->clearImageStack();
   timer.timer_printdelta("DST: dstProcImg: Popimage, read wakeup byte");

   if (!noOutput) {
      Dimension myw, myh;
      int myx, myy;
      XtVaGetValues(drawarea, XmNwidth,  &myw, 
                    XmNheight, &myh, 0);
      if (myw != xscraper->get_TESTW() || myh != xscraper->get_TESTH()) {
         xscraper->freeImageBuffer(lastimage);
         XFreePixmap(dstDisplay, pix);
         pix = XCreatePixmap(dstDisplay, DefaultRootWindow(dstDisplay), 
                             myw, myh, DefaultDepth(dstDisplay, 0));
         XtVaSetValues(drawarea, XmNwidth,  myw, 
                       XmNheight, myh, 0);
         
      }
      
      myx = xscraper->get_STARTX();
      myy = xscraper->get_STARTY();
      
      
      {
         int quads;
         int x, y, wi, hi, i, rem;
         int wblocks;
         int hblocks;
         int pelsperwblock;
         int lastpelsperwblock;
         int pelsperhblock;
         int lastpelsperhblock;
         int iterperline;
         int bytesperpel;
         
         bytesperpel = 4;
         
        /* LOTS of optimizations can be plied! */
         
        /* Calculate number of w and h blocks needed */
         wblocks = xscraper->get_TESTW() / BLOCK_WIDTH;
         rem     = xscraper->get_TESTW() % BLOCK_WIDTH;
         if (wblocks == 0) {
            wblocks = 1;
            pelsperwblock = lastpelsperwblock = xscraper->get_TESTW();
         } else if (rem) {
            wblocks++;
            pelsperwblock = BLOCK_WIDTH;
            lastpelsperwblock = rem;
         } else {
            pelsperwblock = lastpelsperwblock = BLOCK_WIDTH;
         }
         
         hblocks = xscraper->get_TESTH() / BLOCK_HEIGHT;
         rem     = xscraper->get_TESTH() % BLOCK_HEIGHT;
         if (hblocks == 0) {
            hblocks = 1;
            pelsperhblock = lastpelsperhblock = xscraper->get_TESTH();
         } else if (rem) {
            hblocks++;
            pelsperhblock = BLOCK_HEIGHT;
            lastpelsperhblock = rem;
         } else {
            pelsperhblock = lastpelsperhblock = BLOCK_HEIGHT;
         }
         
         timer.timer_printdelta("DST: top ccp");
         
        /* 
        ** Process a row of blocks at a time, repeat hblocks times
        */
         y = 0;
         for (hi = hblocks; hi; hi--) {
            
            int th = ((hi == 1)?lastpelsperhblock:pelsperhblock);
            
            x = 0;
            
            for (wi = wblocks; wi; wi--) {
               int lx, ly;
               int h, tw;
               unsigned char* od, *nd;
               int ofs;
               int doit = 0;
               
               tw=((wi == 1)?lastpelsperwblock:pelsperwblock);
               
               ImageBuffer* img = xscraper->getUpdate(myx + x, myy + y, 
                                                      tw, th);
               if (img) {
                  if (debug > 4) {
                     fprintf(stderr, "DST: Copy x/y %d/%d w/h %d/%d\n", 
                             x, y, tw, th);
                  }
                  
                  if (doit) {
                  nd = IMAGEBUFFER_IMAGE(img);
                  for (ly = 0; ly < th; ly++) {
                     for (lx = 0; lx < tw; lx++, nd += 4) {
                        unsigned long pel = *(unsigned long*)nd;
                        pel = cmap->unnormalize_pixel(pel);
                        XPutPixel(image, lx, ly, pel);
                     }
                  }
                  
                  timer.timer_printdelta("DST: Before putimg");
                  XPutImage(dstDisplay, pix, gc, 
                            image, 0, 0, x, y, tw, th);
                  
                  timer.timer_printdelta("DST: After putimg");
#ifdef DO_INLINE_EXPOSES
                  handle_expose(x, y, tw, th);
#else
                  expose.add_expose(x, y, tw, th);
#endif
                  timer.timer_printdelta("DST: After addexpose");
                  }
                  xscraper->freeImageBuffer(img);
               }
               
               x += pelsperwblock;
            }
            y += pelsperhblock;
         }
         
#ifdef DO_INLINE_EXPOSES
         expose.clear_exposes();
#else
         timer_printdelta("DST: Start Expose Process");
         expose.handle_exposes(this);
         timer_printdelta("DST: Finished Expose Process");
#endif
      }            
      
      
#ifdef NOEXPOSEMETHOD
      if (changed) {         
        /* Ensure Pixmap updates are installed  */
         XtVaSetValues(drawarea, XmNbackgroundPixmap, 0, 0);
         XtVaSetValues(drawarea, XmNbackgroundPixmap, pix, 0);
         XFlush(dstDisplay);
      }
#endif
      
      XFlush(dstDisplay);
      
   } else {
      fprintf(stderr, "dstProcessImage: No image waiting!\n");
   }
   
   timer.timer_printdelta("DST: dstProcImg: Done");
}

/* Don't do this with a timeout ... instead, do it with a pipe XtAppAddInput */
void dstProcessImage(XtPointer clientdata, int* lsrc, XtInputId* inputId) {   
   XSViewer* xsv = (XSViewer*)clientdata;
   xsv->do_dstProcessImage();
}

// This is an experiment ... not used right now
void dstProcessImageTO(XtPointer clientdata, XtIntervalId *id) {
   XSViewer *xsviewer = (XSViewer*)clientdata;
   xsviewer->do_dstProcessImage_TRYWAY();
   XtAppAddTimeOut(xsviewer->getAppContext(), 5000, dstProcessImageTO, clientdata);
}

/**
 * post: called by XScraper::notifyImageObservers when an image is ready
 *       to be grabbed.  This function wakes the XSViewer up using the pipe.
 */
void XSViewer::image_ready() {
#ifdef TRYWAY
//   fprintf(stderr, ".");
#else
   char ch = 0;
   while(write(myPipe[1], &ch, 1) != 1);
#endif
}
