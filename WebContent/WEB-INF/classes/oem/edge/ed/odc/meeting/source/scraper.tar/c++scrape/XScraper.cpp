/* XScraper class
   Joe Crichton, Justin Su
   May-July 2002 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <fcntl.h>
#include "XScraper.h"
#include "Cmap.h"
#include "globalvars.h"
#include "SDMap.h"
#include <signal.h>

#include <X11/Xlibint.h>
#include <X11/extensions/XTest.h>

/* SHM not supported now. */
#undef DOSHM
#ifdef DOSHM
#include <sys/ipc.h>
#include <sys/shm.h>
#include <X11/extensions/XShm.h>
#endif

#ifdef SunOS
#define BROKENCOND
#endif


#define BLOCKIMAGES  /* Scrape the area in blocks at a time.  We found
                        that this increases the performance quite
                        drastically, especially when scraping larger areas. */

static int is_sdmap_init = 0;
static int is_cmap_init  = 0;

#ifdef DOTHREADS
// These are routines called if the thread is cancelled/exists. We push the
//  routine on a stack as we get locks, and pop them off as we release them
extern "C" void ptcup_ul (void* v) {
   fprintf(stderr, "Unlocking MUTEX in CLEANUP routine (%X)\n", v);
   pthread_mutex_unlock((pthread_mutex_t*)v);
}
extern "C" void ptcup_ulr(void* v) {
   fprintf(stderr, "Unlocking READLOCKED in CLEANUP routine (%X)\n", v);
   pthread_rwlock_unlock((pthread_rwlock_t*)v); 
}
extern "C" void ptcup_ulw(void* v) {
   fprintf(stderr, "Unlocking WRITELOCKED in CLEANUP routine (%X)\n", v);
   pthread_rwlock_unlock((pthread_rwlock_t*)v); 
}
#endif


/**
 * post: constructor function - manually set everything to 0,
 *       and initialize variables.
 */
XScraper::XScraper() {

   init();
   
#ifndef DOTHREADS
   queueXProto = 1;
#endif
   
   imagestack = new ImageStack();
   imageObservers = new LinkList();
   
   mouseListeners = new LinkList();
   
   if (!is_cmap_init) {
      cmap_init();
      is_cmap_init = 1;
   }
   if (!is_sdmap_init) {
      sdmap = new SDMap();
      is_sdmap_init = 1;
   }
   
   TESTW      = 600;  // default values for scraping size
   TESTH      = 600;
   STARTX     = 0;
   STARTY     = 0;
   ENDX       = (STARTX + TESTW) - 1;
   ENDY       = (STARTY + TESTH) - 1;
   
   app = XtCreateApplicationContext();

#ifdef DOTHREADS
   pthread_mutexattr_t mutexattr;
   pthread_mutexattr_init(&mutexattr);
   pthread_mutexattr_settype(&mutexattr, PTHREAD_MUTEX_RECURSIVE);
   pthread_rwlock_init(&modelRWLock, 0);
   pthread_mutex_init(&imagestack->imageFreeBufferMutex, &mutexattr);
   pthread_mutex_init(&imagestack->imageStackMutex,      &mutexattr);
   pthread_mutex_init(&eventQ.eventQMutex,               &mutexattr);
   pthread_mutex_init(&scraperMutex,                     &mutexattr);
   pthread_mutexattr_destroy(&mutexattr);
   pthread_cond_init(&scraperCond, 0);
#endif
}

/**
 * post: init members
 */
void XScraper::init() {
   // memset(this, 0, sizeof(*this));
   /* memset not used because it destroys the virtual function table */
   
   crosshair        = 0;
   window_selection = 0;
   scrapetime       = 333;
   doScrape         = 1;
   gc               = 0;
   timerId          = 0;
   viewonly         = 0;
   xtestSupported   = 0;
   tryXShm          = 0;
   
   erroroccured     = 0;
   debug            = 0;
   timer.dbug       = 0;
   bytes_per_line   = 0;
   
   xtestMajor = xtestMinor = xtestEvent = xtestError = 0;
   xpointer = ypointer = 0;
   relx = rely         = 0;
   
#ifdef DOTHREADS
   thread             = 0;
   scraper_please_die = 0;
#endif

   dwidth = dheight = 0;

   srcargc    = 0;
   srcargv    = 0;
   srcDisplay = 0;
   srcdisplay = 0;
   
   quantlists = 0;
   numqlistsW = 0;
   numqlistsH = 0;
   rootnode   = 0;
   roothash   = 0;
   
   familyTopLevels  = 0;
   imageObservers   = 0;
   
   keymapOutOfDate      = 1;
   modifierKeyCodes     = 0;
   keycodeToKeySymTable = 0;
   memset(forcedKeys, 0, sizeof(forcedKeys));
   
   doconfig = configx = configy = configw = configh = 0;
   doforce  = forcex  = forcey  = forcew  = forceh  = 0;
   configwin = 0;
   
   /*----- done setting everything to 0, now init variables -----*/

   tick        = 1;
   mode        = FIXED_AREA;
   family_base = 0;
}




/*-----------------------------------------------------------------*/
/*----------PUBLIC FUNCTIONS (AND THEIR HELPER FUNCTIONS)----------*/
/*-----------------------------------------------------------------*/


/**
 * post: handles warnings for the XScraper class 
 */
void mywarninghandler(String 		name,
                      String		type,
                      String		cls,
                      String		def,
                      String*		params,
                      Cardinal*		num_params ) {
                      
   fprintf(stderr, 
           "+--- Warning ------------------------------------------------\n");
   fprintf(stderr, 
           "+ Received Warning Name %s\n", name);
   fprintf(stderr, 
           "+                  type %s\n", type);
   fprintf(stderr, 
           "+                  cls  %s\n", cls);
   fprintf(stderr, 
           "+                  def  %s\n", def);
   fprintf(stderr, 
           "+------------------------------------------------------------\n");
}


/**
 * post: opens the source display and builds the node tree that represents
 *       the windows.
 * calls: start
 */
 
#ifdef AIXV4
#include <sys/wait.h>
static char *checkapar_script = 
"#!/bin/ksh\n"
"X11RTE=$(/bin/lslpp -q -c -L X11.base.rte | cut -d: -f3)\n"
"echo \"$X11RTE\" | \\\n"
"   grep '^[0-9][0-9]*\\.[0-9][0-9]*\\.[0-9][0-9]*\\.[0-9][0-9]*' > /dev/null 2>&1\n"
"\n"
"if [ $? = 0 ] ; then\n"
"  v1=$(echo \"$X11RTE\" | cut -d. -f1)\n"
"  v2=$(echo \"$X11RTE\" | cut -d. -f2)\n"
"  v3=$(echo \"$X11RTE\" | cut -d. -f3)\n"
"  v4=$(echo \"$X11RTE\" | cut -d. -f4)\n"
"  if [ $v1 = 4 ] ; then\n"
"     if [ $v2 != 3 -o $v3 != 3 -o $v4 -lt 80 ] ; then\n"
"        echo \"AIX Backing store fix NOT applied!\"\n"
"        return 66\n"
"     fi\n"
"  elif [ $v1 -lt 4 ] ; then\n"
"     echo \"AIX Backing store fix NOT applied!\"\n"
"     return 66\n"
"  elif [ $v1 -eq 5 ] ; then\n"
"     if [ $v2 = 1 -a $v3 = 0 -a $v4 -lt 50 ] ; then\n"
"        echo \"AIX Backing store fix NOT applied!\"\n"
"        return 66\n"
"     fi\n"
"  fi\n"
"else\n"
"   echo \"Inconclusive check for backingstore fix ... RTE version $X11RTE\"\n"
"   return 44\n"
"fi\n"
"echo \"AIX BackingStore Apar fix is installed\"\n"
"return 100\n";
#endif

int XScraper::connect(char* disp, int view_only) {
   if (srcdisplay != 0) delete srcdisplay;
   srcdisplay = new char[strlen(disp)+1];
   strcpy(srcdisplay, disp);
   viewonly   = view_only & 1;
   doScrape   = 1;
   
   fprintf(stderr, "\nConnecting to [%s], viewonly=%d ..... ",
           srcdisplay, viewonly);
   
  // XtToolkitInitialize();
   
   XtAppSetWarningMsgHandler(app, mywarninghandler);
   
   srcDisplay = XtOpenDisplay(app, srcdisplay, shortname, "SScrape", 
                              0, 0, &srcargc, srcargv);

   
   if (!srcDisplay) {
      fprintf(stderr, "failure!. Abort.\n");
      delete srcdisplay;
      srcdisplay = 0;
      viewonly = 0;
      return FAILURE_TO_CONNECT_TO_DISPLAY;
   }
   
   fprintf(stderr, "Success.\n");
   
  // On AIX, if backingstore is ON, fail if not at good APAR level
  // If any other bits other than 1 is on, that means don't check
   if (DoesBackingStore(ScreenOfDisplay(srcDisplay,DefaultScreen(srcDisplay))) && 
       !(view_only & ~1) && 
       strstr(XServerVendor(srcDisplay), "International Business Machines")) {
       
      int forceret = CANT_CHECK_IF_APAR_INSTALLED;
      
#ifdef AIXV4
      if (*disp == ':' || strstr(disp, "unix:")) { 
         char tmpfileS[L_tmpnam];
         char* tmpfile = tmpnam(tmpfileS);
         if (tmpfile) {
            FILE* f = fopen(tmpfile, "w");
            if (f) {
               fprintf(f, checkapar_script);
               fflush(f);
               fclose(f);
               chmod(tmpfile, 0777);         
               
              // Make sure we can get the RC
               struct sigaction thisaction, lastaction;
               memset(&thisaction, 0, sizeof(thisaction));
               thisaction.sa_handler = SIG_DFL;
               sigaction(SIGCHLD, &thisaction, &lastaction);
               
               int pid = fork();
               if (pid != -1) {
                  if (!pid) {
                     execl(tmpfile, tmpfile, 0);
                     exit(44);
                  } else {
                     int status;
                     int pidret;
                     do {
                        pidret = waitpid(pid, &status, 0);
                     } while((pidret != pid || !WIFEXITED(status)) &&
                             !(pid == -1 && errno == ECHILD));
                             
                     if (pidret != -1) {
                        forceret = WEXITSTATUS(status);
                     }
                     if (forceret == APAR_IS_INSTALLED) {
                        forceret = 0;
                     } else if (forceret == 0) {
                        forceret = CANT_CHECK_IF_APAR_INSTALLED;
                     }
                  }
               }
               sigaction(SIGCHLD, &lastaction, 0);
               
               unlink(tmpfile);
            } else {
               forceret = CANT_CHECK_IF_APAR_INSTALLED;
            }
         }
      }
#endif
      if (forceret != 0) {
         XtCloseDisplay(srcDisplay);
         delete srcdisplay;
         srcDisplay = 0;
         return forceret;
      }
   }
   
   /* add display to the XScraper-Display map - because myerrorhandler 
      needs to figure out whether the display passed in is from an 
      XScraper object or not. */
   sdmap->add_SDPair(this, srcDisplay);
   
   XSetErrorHandler((XErrorHandler)myerrorhandler);
   
   dwidth  = DisplayWidth (srcDisplay, 0);
   dheight = DisplayHeight(srcDisplay, 0);
   quant_initialize(dwidth, dheight);
   
/*#ifdef DOSHM
   
   if (tryXShm && (xshmSupported = XShmQueryExtension(srcDisplay))) {
      int dealloc = 0;
      fprintf(stderr, "Add check that server and I am on same machine!!!\n");
      
      sharedXImage = XShmCreateImage(srcDisplay, 
                                     DefaultVisual(srcDisplay, 0), 
                                     DefaultDepth(srcDisplay, 0),
                                     ZPixmap, 
                                     0, 
                                     &seginfo,
                                     TESTW, TESTH);
      if (sharedXImage) {
         seginfo.shmid = 
            shmget(IPC_PRIVATE, 
                   sharedXImage->bytes_per_line * 
                   sharedXImage->height, IPC_CREAT | 0777);
                   
         if (seginfo.shmid != -1) {
            void* addr = shmat(seginfo.shmid, 0, 0);
         
            if (addr != (void*)-1) {
            
               seginfo.shmaddr = sharedXImage->data = addr;
               
               seginfo.readOnly = False;
               if (!XShmAttach(srcDisplay, &seginfo)) {
                  dealloc = 1;
                  shmdt(seginfo.shmaddr);
                  fprintf(stderr,
                          "Error creating ShmAttaching to "
                          "Private segment for XShm!\n");
               }
               
            } else {
               dealloc = 1;
               fprintf(stderr,
                       "Error creating attaching to "
                       "Private segment for XShm!\n");
            }
               
            if (dealloc) {
               shmctl(seginfo.shmid, IPC_RMID, 0);
            }
               
         } else {
            dealloc = 1;
            fprintf(stderr, "Error creating Private segment for XShm!\n");
         }
         
         if (dealloc) {
            memset(&seginfo, 0, sizeof(seginfo));
            XDestroyImage(sharedXImage);
            sharedXImage = 0;
         }
      }
      
      if (sharedXImage) {
         fprintf(stderr, "Using XShm Extension!\n");
      }
   }
#endif*/
   
   xtestSupported = XTestQueryExtension(srcDisplay, 
                                        &xtestEvent, &xtestError,
                                        &xtestMajor, &xtestMinor);
                                            
   if (!viewonly) {
      if (!xtestSupported) {
         viewonly = 1;
         fprintf(stderr, "XTest extension is NOT supported! View only");
      } else {
         int grabcontrol = XTestGrabControl(srcDisplay, 1);
         if (debug > 2) {
            printf("DST: Grab Control = %d\n", grabcontrol);
         }
      }
   }

   /* Build node tree, store its root in rootnode. roothash also initialized. */
   fprintf(stderr, "Building node tree ...");
   XGrabServer(srcDisplay);
   roothash = new Hash(1024*64);
   rootnode = buildNodeTree(0, DefaultRootWindow(srcDisplay));
   numberNodeTree(rootnode, 1);
   requadrantize(rootnode);
   XUngrabServer(srcDisplay);
   XFlush(srcDisplay);
   fprintf(stderr, "... Completed\n");
   
   start();
   return 0;
}

/**
 * post: notify all ImageObservers when an image is ready by calling their
 *       image_ready() function (an abstract function that needs to be
 *       implemented by the ImageObserver).
 *
 * called by doTimeout
 */
void XScraper::notifyImageObservers() {
   thread_lock_read(&modelRWLock);
   Link* link = imageObservers->get_head();
   while (link) {
      ((ImageObserver*)link->data)->image_ready();
      link = link->right;
   }
   thread_unlock_read(&modelRWLock);
}

void XScraper::removeImageObserver(ImageObserver* obs) {
   thread_lock_write(&modelRWLock);
   imageObservers->deleteByData(obs);
   thread_unlock_write(&modelRWLock);
}

/* This function is used by XSViewer to register itself as an image observer. */
void XScraper::addImageObserver(ImageObserver* obs) {
   thread_lock_write(&modelRWLock);
   imageObservers->chainLast(new Link(obs));
   thread_unlock_write(&modelRWLock);
}

/**
 * post: frees all memory.
 *
 * called by disconnect
 * private function - assume to be write-locked already
 */
void XScraper::freeAll() {
   removeAllMouseListeners();
   imagestack->free_allStackedImages();
   imagestack->freeImageBuffers();
   free_queuedEvents();    // free eventQ
   free_Quadrants();       // free quantlists
   
   freeKeyInjectionResources();
   
   rootnode->destroy(1, roothash);  // free node tree
   rootnode = 0;

   // Note, there will still be cmaps floating around!
   roothash->hash_free();
   delete roothash;
   roothash = 0;
   
   free_familyTopLevels(); // deallocate family share list
   
   imageObservers->resetLL();
   delete imageObservers;
   imageObservers = 0;
   if (srcdisplay) delete srcdisplay;
   srcdisplay = 0;
}

/**
 * post: disconnects from display.
 */
int XScraper::disconnect() {
   if (!isConnected()) return 1;
   
#ifdef DOTHREADS
  //
  // Cancelling the thread is difficult. I put the push/pop code in for
  //  all my mutexes and locks ... BUT, X11 has multi-threaded support
  //  with locks/mutexes, and does NOT use the push/pop cleanup routines. So, 
  //  use the pthread_cancel as a last resort. First try setting a 'die' type
  //  flag that the scraper will check in a good place.
  //
   scraper_please_die = 1;
   int count = 1;
   while(pthread_kill(thread, 0) == 0 && count < 5) {
      sleep(1);
      count++;
   }
   if (count >= 5) {
      fprintf(stderr, "Force thread to terminated. Calling thread cancel\n");
      pthread_cancel(thread);   // when to cancel thread??  TODO!! 
   }
   fprintf(stderr, "Disconnecting ... Joining src thread\n");
   pthread_join(thread, 0);
   
   XtRemoveInput(inputId);
   close(wakeupPipe[0]);
   close(wakeupPipe[1]);
#endif
   
   thread_lock_write(&modelRWLock);

   fprintf(stderr, "Disconnected from [%s]\n", srcdisplay);
   freeAll();                   // free up all allocated structures and memory
   sdmap->remove_SDPair(this);  // remove xscraper from map
   XtCloseDisplay(srcDisplay);  // disconnect from display
   
   init();
   
   thread_unlock_write(&modelRWLock);  
   return 0;
}

/**
 * post: returns 1 if connected to display, else 0.
 */
int XScraper::isConnected() {
   if (srcDisplay) return 1;
   return 0;
}


int XScraper::isCurrentModeStillValid() {

   int ret = 1;
   
  // Only affects non-threaded env
   queueXProtocol(2);

   thread_lock_read(&modelRWLock);
   
   if (mode == FAMILY_SHARE && 
       (familyTopLevels == 0 || !familyTopLevels->get_head())) {
      ret = 0;
   }
   
   thread_unlock_read(&modelRWLock);
   return ret;
}

/**
 * post: adjust clipvalues and requadrantize
 *
 * called by do_reconfigure
 * private function - assume the model to be write-locked already from 
 *                    do_reconfigure
 */
void XScraper::help_config() {
   imagestack->free_allStackedImages();
   imagestack->freeImageBuffers();
   
  /* JMC 7/16/02 - For now, don't free Queued events ... this will 
                   make our incore model out of date. We DO want to free
                   input events from display half 
    free_queuedEvents();            // free eventQ
  */
  
   free_QuadrantInfo();            // free quantlists
   adjust_rootxy(rootnode, 0, 0);  // adjust clipvalues 
   requadrantize(rootnode);
}

void XScraper::do_reconfigure(Window win) {
  // Only affects non-threaded env
   queueXProtocol(2);

   thread_lock_write(&modelRWLock);
   
   if (win != rootnode->window) {
      mode        = FAMILY_SHARE;
      family_base = getFamilyBase(win); 
      refreshFamilyShareTopLevels();
      XMapWindow(srcDisplay, win);
      XRaiseWindow(srcDisplay, win);
   } else {
      mode        = FIXED_AREA;
      family_base = 0;
      STARTX = rootnode->rootx;
      STARTY = rootnode->rooty;
      TESTW  = rootnode->attrs.width;
      TESTH  = rootnode->attrs.height;
      ENDX   = STARTX + TESTW - 1;
      ENDY   = STARTY + TESTH - 1;
   }
   
   help_config();
   configwin = 0;
   doconfig  = 0;
   thread_unlock_write(&modelRWLock);
   
#ifdef DOTHREADS
   thread_lock(&scraperMutex);
   pthread_cond_signal(&scraperCond);
   thread_unlock(&scraperMutex);
#endif
}

/**
 * post: configure the scraping window's location and size to be that of a 
 *       particular window family
 */
int XScraper::reconfigure(Window win) {
   if (!isConnected()) return 1;
   
   thread_lock_write(&modelRWLock); 
   doconfig  = 1;
   configwin = win;
   thread_unlock_write(&modelRWLock);
   
#ifdef DOTHREADS

#ifndef BROKENCOND
   thread_lock(&scraperMutex);
#endif

   while (doconfig) {
      if (debug) {
         fprintf(stderr, "Going to sleep on reconfig\n");
      }
#ifdef BROKENCOND
      usleep(250000);
#else
      pthread_cond_wait(&scraperCond, &scraperMutex);
#endif
   }
#ifndef BROKENCOND
   thread_unlock(&scraperMutex);
#endif
#else
   do_reconfigure(win);
#endif
   return 0;
}

//
// Should be called only by main thread (when threaded). MUST not have
//  any RWLocks when calling
//
void XScraper::do_forceupdate(int x, int y, int w, int h) {
         
#ifdef DOTHREADS
   pthread_testcancel();
#endif
         
   if (!++tick) tick = 1;
         
   timer.timer_start();
         
   ImageBuffer* image = getNormalizedImage(x, y, w, h);
   timer.timer_printdelta("SRC: Finished Normalization");
   
  // put normalized image on stack and then notify viewer.
   imagestack->push(image);
   
  // tell viewer that scraped image is ready to be displayed.
   notifyImageObservers();
   doforce = 0;
}

void XScraper::do_reconfigure(int sx, int sy, int tw, int th) {
  // Only affects non-threaded env
   queueXProtocol(2);

   thread_lock_write(&modelRWLock);
   mode   = FIXED_AREA;
   family_base = 0;
   
   if (tw < 1) tw = 1;
   if (th < 1) th = 1;
   
   STARTX = sx;
   STARTY = sy;
   TESTW  = tw;
   TESTH  = th;
   ENDX   = sx + tw - 1;
   ENDY   = sy + th - 1;
   help_config();
   doconfig = 0;
   thread_unlock_write(&modelRWLock); 
   
#ifdef DOTHREADS
   thread_lock(&scraperMutex);
   pthread_cond_signal(&scraperCond);
   thread_unlock(&scraperMutex);
#endif
}

/**
 * post: configure the scraping area by passing in a starting x and y, and a 
 *       width and height.
 */
int XScraper::reconfigure(int sx, int sy, int tw, int th) {
   if (!isConnected()) return 1;
   
   thread_lock_write(&modelRWLock);
   doconfig  = 1;
   configwin = 0;
   configx   = sx;
   configy   = sy;
   configw   = tw;
   configh   = th;
   thread_unlock_write(&modelRWLock);
   
#ifdef DOTHREADS

#ifndef BROKENCOND
   thread_lock(&scraperMutex);
#endif

   while (doconfig) {
      if (debug) {
         fprintf(stderr, "Going to sleep on reconfig\n");
      }
#ifdef BROKENCOND
      usleep(250000);
#else
      pthread_cond_wait(&scraperCond, &scraperMutex);
#endif
   }
#ifndef BROKENCOND
   thread_unlock(&scraperMutex);
#endif

#else

   do_reconfigure(sx, sy, tw, th);

#endif
   return 0;
}

/**
 * post: returns parent of window.
 */
Window XScraper::getParent(Window win) {
   if (!isConnected()) return 1;
   
  // Only affects non-threaded env
   queueXProtocol(2);

   Window ret = 0;
   thread_lock_read(&modelRWLock);
   Node* n = (Node*)roothash->find(win, HASHTYPE_NODE);
   if (n && n->parentnode) {
      ret = n->parentnode->window;
   }
   thread_unlock_read(&modelRWLock);
   return ret;
}

/**
 * post: returns the window's starting location and its width and height.
 */
int XScraper::getWindowExtents(Window win, XRectangle* rec) {
   return getWindowExtents(win, rec, 1);
}
int XScraper::getWindowExtents(Window win, XRectangle* rec, int ignoremode) {
   if (!isConnected()) return 1;
   
  // Only affects non-threaded env
   queueXProtocol(2);

   int ret = 1;
   thread_lock_read(&modelRWLock);
   Node* n = (Node*)roothash->find(win, HASHTYPE_NODE);
   if (!ignoremode && mode == FAMILY_SHARE) {
      if (n) {
         rec->x      = STARTX;
         rec->y      = STARTY;
         rec->width  = TESTW;
         rec->height = TESTH;
         ret = 0;
      }
   } else {
      if (n) {
         rec->x      = n->rootx;
         rec->y      = n->rooty;
         rec->width  = n->attrs.width;
         rec->height = n->attrs.height;
         ret = 0;
      }
   }
   thread_unlock_read(&modelRWLock);
   return ret;
}


/** post: returns cursor position */
int XScraper::getCursorPosition(XPoint* p) {
   if (!isConnected()) return 1;
   
  // Only affects non-threaded env
   queueXProtocol(1);
   
   thread_lock_read(&modelRWLock);
   
   p->x = xpointer;
   p->y = ypointer;
   thread_unlock_read(&modelRWLock);
   return 0;
}

/**
 * post: injects inputted key information into xscraper, it does this by
 *       creating an XEvent and putting it on the queue to be processed
 *
 *       x any y are absolute coordinates!  They are relative to the 
 *       upper-left corner of the scraping area.
 */
int XScraper::injectKey(int x, int y, inputType type, KeySym ksym) {
   if (!isConnected()) return 1;
   
   if (x < 0 || x >= get_dwidth() ||
       y < 0 || y >= get_dheight()) {
      return 0;
   }
   
   XEvent ev;
   ev.type = type;
   ev.xbutton.x = x;
   ev.xbutton.y = y;
   queue_event(&ev, (int)ksym); 
   
  // Only affects non-threaded env
   queueXProtocol(1);
   
   return 0;
} 

/**
 * post: injects inputted mouse information into xscraper, it does this by
 *       creating an XEvent and putting it on the queue to be processed
 *
 *       x any y are absolute coordinates!  They are relative to the 
 *       upper-left corner of the scraping area.
 */
int XScraper::injectMouse(int x, int y, inputType type, int buttonNumber) {
   if (!isConnected()) return 1;
   
   if (x < 0 || x >= get_dwidth() ||
       y < 0 || y >= get_dheight()) {
      return 0;
   }
   
   XEvent ev;
   ev.type = type;
   ev.xbutton.x = x;
   ev.xbutton.y = y;
   ev.xbutton.button = buttonNumber;
//   fprintf(stderr, "IM: (%d, %d)\n", x, y);
   queue_event(&ev, 0); 
   return 0;
}

/**.
 * post: returns 1 if window is viewable, else returns 0
 */
int XScraper::isWindowVisible(Window win) {
   if (!isConnected()) return -1;

   Node*n = 0;   
   thread_lock_read(&modelRWLock);
   
  // Only affects non-threaded env
   queueXProtocol(2);
   
   n = (Node*)roothash->find(win, HASHTYPE_NODE);
   thread_unlock_read(&modelRWLock);
   
   if (n && n->attrs.map_state == IsViewable) {
      return 1;
   }
   return 0;
}

/**
 * post: returns 1 if window is iconic, else returns 0.
 */
int XScraper::isWindowIconic(Window win) {
   if (!isConnected()) return -1;
   
  // Only affects non-threaded env
   queueXProtocol(2);
   
   Node* n = 0; 
   thread_lock_read(&modelRWLock);
   n = (Node*)roothash->find(win, HASHTYPE_NODE);
   thread_unlock_read(&modelRWLock);
   
   if (n && n->wm_state && n->attrs.map_state == IsUnmapped) {
      return 1;
   }
   return 0;
}

/** 
 * post: returns 1 if w is a valid window, else returns 0.
 */
int XScraper::isWindow(Window win) {
   if (!isConnected()) return -1;
   
  // Only affects non-threaded env
   queueXProtocol(2);
   
   Node* n = 0;
   thread_lock_read(&modelRWLock);
   n = (Node*)roothash->find(win, HASHTYPE_NODE);
   thread_unlock_read(&modelRWLock);
   
   if (n) return 1;
   return 0;
}

           //printf("%s 0x%x\n", t->text, t->window);
            
           /*int bytes = (strlen(t->text)+1) * 2;
            wchar_t* unitext = (wchar_t*)malloc(bytes);
            
            int len = strlen(t->text) + 1;
            //mbsnrtowcs(unitext, (const char**)&(t->text), bytes, 3, (mbstate_t*)t->text);
            for (int j = 0; j < len; j++) {  // ?????????????????
              mbrtowc(&(unitext[j]), &((t->text)[j]), 1, (mbstate_t*)"");
            }
            //strtows(unitext, t->text);
            
            char* poop = (char*)malloc(len);
            for (j = 0; j < len; j++) {  // ?????????????????
               wcrtomb(&(poop[j]), unitext[j], (mbstate_t*)"");
            }
           //wcsnrtombs(poop, (const wchar_t**)&unitext, 2, 1, (mbstate_t*)"");
            printf("poop = %s\n", poop);
            free(poop);
            
            wchar_t* buf = (wchar_t*)malloc((strlen(t->text) + 1) * 2);
            for (int k = 0; k < len; k++) {
               buf[k] = unitext[k];
            }
            wprintf(buf);
            printf("\n");
            free(buf);
            free(unitext);*/
            
 
/* post: We want to know the Display's resource mask so that we can find
         windows that have the same base in FAMILY_SHARE mode. */
Window XScraper::getResourceMask() {
   return (~srcDisplay->resource_mask);
}

/* post: Return the window masked with the Display's resource_mask. */
Window XScraper::getFamilyBase(Window win) {
   return (win & getResourceMask());
}

void XScraper::findClientWindow(Node* node, LinkList* toplevels) {
   int found = 0;
   Node* t = node;
   while (t) {
      if (t->wm_state != 0) {
         if (t->attrs.c_class == InputOutput) {
            int* i = (int*)malloc(sizeof(int));
            *i = t->window;
            toplevels->chainLast(new Link(i));
         }
         found++;  /* we could return here instead of incrementing found,
                      but we're just making sure... */
      }
      t = t->right_sibling;
   }
   
   if (found == 1) return; // if found top-level window, then return
   if (found > 1) {        // this should never happen! 
      printf("XScraper::findClientWindow Hm? %s 0x%x\n",node->text,node->window);
      return;
   }
   
   /* if did not find top-level window, continue searching all children */
   t = node;
   while (t) {
      if (t->children) {
         findClientWindow(t->children, toplevels);
      }
      t = t->right_sibling;
   }
}
 
/**
 * post: returns a list of top-level windows.
 *       Assumption: enumerateWindows finds top level windows by assuming  
 *       that the WM_STATE for a window is set.  It is possible that not
 *       all window managers comply with this.
 *
 * public function
 */
LinkList* XScraper::enumerateWindows() {
   if (!isConnected()) return 0;
   LinkList* toplevels = 0;
      
   thread_lock_read(&modelRWLock);

  // Only affects non-threaded env
   queueXProtocol(2);
   
   toplevels = _enumerateWindows();
   
   thread_unlock_read(&modelRWLock);
   return toplevels;
}

/**
 * post: same as above function, but private function so it does NOT do a 
 *       thread_lock_read.  This is required because the scraper thread has
 *       already done a thread_lock_write, and it CANNOT do a
 *       thread_lock_read or else it will hang...
 */
LinkList* XScraper::_enumerateWindows() {
   if (!isConnected()) return 0;
   
   Node* n;
   if (rootnode) {
      n = rootnode->children;
   } else {
      return 0;
   }   
   /* For each window manager window, recursively search under the node
      until you reach a non-window manager top level window. */
   LinkList* toplevels = new LinkList();
   while (n) {     
      if (n->wm_state == 0) {
         if (n->children) {
            findClientWindow(n->children, toplevels);
         }
      } else {
         if (n->attrs.c_class == InputOutput) {
            //printf("%s\t0x%x\t0x%x\n", n->text, n->window, wak);
            int* i = (int*)malloc(sizeof(int));
            *i = n->window;
            toplevels->chainLast(new Link(i));
         }
      }
      n = n->right_sibling;
   }
   return toplevels;
}

/** 
 * post: returns the desktop window, which is the root.
 */
Window XScraper::getDesktopWindow() {
   if (!isConnected()) return 0;
   Window win = 0;
   thread_lock_read(&modelRWLock);
   if (rootnode) {
      win = rootnode->window;
   }
   thread_unlock_read(&modelRWLock);
   return win;
}

/**
 * post: stores the title of the window in buf.
 *       returns number of chars read
 */
int XScraper::getWindowText(Window win, char* buf, int size) {
   if (!isConnected()) return 0;
   
  // Only affects non-threaded env
   queueXProtocol(2);
   
   int i = 0;
   thread_lock_read(&modelRWLock);
   Node* n = (Node*)roothash->find(win, HASHTYPE_NODE);
   
   if (n && n->text) {
      int len = strlen(n->text) + 1;
      for (i = 0; i < size && i < len; i++) {
         buf[i] = n->text[i];
      }
   }
   thread_unlock_read(&modelRWLock);
   if (i <= 1) return 0;
   return i;
}

/**
 * post : stores the title of the window in buf, in unicode.
 *        returns number of chars read
 *
 * Assumption: This function simply converts from ascii to unicode.  We used
 *             XFetchName to grab the window title (which we store in the 
 *             respective node in ascii).  How XFetchName works when the 
 *             machine is in unicode to begin with remains to be seen.
 */
int XScraper::getWindowTextUnicode(Window win, wchar_t* buf, int size) {
   if (!isConnected()) return 0;

   // Only affects non-threaded env
   queueXProtocol(2);

   int len = 0;
   wchar_t* unitext = 0;   
   
   thread_lock_read(&modelRWLock);
   Node* n = (Node*)roothash->find(win, HASHTYPE_NODE);   
   
   unitext = (wchar_t*)malloc((strlen(n->text)+1) * 2);
   //strtows(unitext, n->text);  // convert ascii string to unicode
   
   /* This method of conversion should work on all platforms. */
   int ln = strlen(n->text) + 1;
   for (int j = 0; j < ln; j++) {
   
#if defined(hpux) || (defined(sun) && ! defined(DOTHREADS))
     // probs on HP and 5.5.1 sun
      char* tcp = (char*)&unitext[j];
      tcp[0] = 0;
      tcp[1] = n->text[j];
#else
      mbrtowc(&(unitext[j]), &((n->text)[j]), 1, ((mbstate_t*)n->text));
#endif
   }
     
   len = strlen(n->text) + 1;
   thread_unlock_read(&modelRWLock);
   
   int s = size / 2;
   int i = 0;
   for (i = 0; i < s && i < len; i++) {
      buf[i] = unitext[i];
   }
   free(unitext);
   if (i <= 1) return 0;
   return i * 2;
}




/*-----------------------------------------------------------------*/
/*---------------------PRIVATE FUNCTIONS---------------------------*/
/*-----------------------------------------------------------------*/



#ifdef DOSHM
void XScraper::Deallocate_SharedInfo() {
   if (sharedXImage) {
      fprintf(stderr, "Deallocating xshm info\n");
      XShmDetach(srcDisplay, &seginfo);
      shmdt(seginfo.shmaddr);
      shmctl(seginfo.shmid, IPC_RMID, 0);
      XDestroyImage(sharedXImage);
      sharedXImage = 0;
   }
}   
#endif

/**
 * post: update the window's wm_state, which is stored in the node.
 *       Assumption: enumerateWindows finds top level windows by assuming  
 *       that the WM_STATE for a window is set.  It is possible that not
 *       all window managers comply with this.
 *
 * called by buildNodeTree, processEvent
 */
void XScraper::updateWindowState(Node* n) {
   if (n) {
      n->wm_state = 0;
   }
   Atom xa_WM_STATE = XInternAtom(srcDisplay, "WM_STATE", False);
   int WM_STATE_ELEMENTS = 1;
   Atom actual_type;
   int  actual_format;
   unsigned long  nitems;
   unsigned long  bytes_after;
   unsigned long *prop = 0;
   int status = XGetWindowProperty(srcDisplay,
                                   n->window,
                                   xa_WM_STATE,
                                   0, WM_STATE_ELEMENTS, False,
                                   xa_WM_STATE,
                                   &actual_type, &actual_format, &nitems, 
                                   &bytes_after, (unsigned char**)&prop);
   if ((status == Success) && (actual_type == xa_WM_STATE) && 
       (nitems == WM_STATE_ELEMENTS)) {
      if (prop) {
         if (*prop == NormalState) {
            n->wm_state = NORMAL;
           //printf("WM_STATE for 0x%x\t%s\t is Normal\n", n->window, n->text);
         } else if (*prop == IconicState) {
            n->wm_state = ICONIC;
           //printf("WM_STATE for 0x%x\t%s\t is Iconic\n", n->window, n->text);
         } else if (*prop == WithdrawnState) {
            // WITHDRAWN is currently defined as 0, we don't want these windows
            n->wm_state = WITHDRAWN;
           //printf("WM_STATE for 0x%x\t%s\t is Withdrawn\n", n->window, n->text);
         }
         XFree((char*)prop);
         prop = 0;
      }
      
   }
}

/**
 * post: update the window's title, which is stored in the node.
 *
 * called by buildNodeTree, processEvent
 */
void XScraper::updateWindowText(Node* n) {
   char* data;
   if (n && n->text) {
      free(n->text);
      n->text = 0;
   }
   
  // XFetchName does not support COMPOUND_TEXT ... 
  // XFetchName(srcDisplay, n->window, &data);
   
   char** list_ret = 0;
   int    count_ret;
   XTextProperty textprop;
   if (XGetTextProperty(srcDisplay, n->window, &textprop, XA_WM_NAME)) {
      XmbTextPropertyToTextList(srcDisplay, &textprop, &list_ret, &count_ret);
      if (list_ret) {
         if (count_ret > 0) {
            n->text = (char*)malloc(strlen(list_ret[0]) + 1);
            strcpy(n->text, list_ret[0]);
         }
         XFreeStringList(list_ret);
      }
      if (textprop.value) {
         XtFree((char*)textprop.value);
      }
   }
}

/**
 * post: initialize quadrant lists.
 *
 * called by connect
 */
void XScraper::quant_initialize(int w, int h) {
   int i, j;
   numqlistsW = DIV_BLOCK_WIDTH(w);
   if (MOD_BLOCK_WIDTH(w)) {
      numqlistsW++;
   }
   numqlistsH = DIV_BLOCK_HEIGHT(h);
   if (MOD_BLOCK_HEIGHT(h)) {
      numqlistsH++;
   }
   
   quantlists = (LinkList***)malloc( sizeof(LinkList**) * numqlistsH );
   
   for (i = 0; i < numqlistsH; i++) {
      quantlists[i] = (LinkList**)malloc( sizeof(LinkList*) * numqlistsW );
      for (j = 0; j < numqlistsW; j++) {
	 quantlists[i][j] = new LinkList();
         quantlists[i][j]->malloc_voidata();
	 quantlists[i][j]->memset_voidata();
      }
   }
}

/**
 * post: checks to see if any part of the window (represented by node)
 *       is in the quadrant [quadx, quadxy].  returns 1 if in quadrant.
 *
 * called by processQuadrantLinks
 * private function - assume the model to be write-locked already from
 *                    processQuadrantLinks
 */
int XScraper::isInQuadrant(Node *node, int quadx, int quady) {
   int widx, hidx, hstart, hend, wstart, wend;
   int ret = node->quadret;
   if (node->quadtick != tick || 
       (node->quadx != quadx  || node->quady != quady)) {
      hstart = DIV_BLOCK_HEIGHT(node->Bclipy);
      hend   = DIV_BLOCK_HEIGHT(node->Bclipy2);
      wstart = DIV_BLOCK_WIDTH(node->Bclipx);
      wend   = DIV_BLOCK_WIDTH(node->Bclipx2);
      ret = quadx >= wstart && quadx <= wend &&
            quady >= hstart && quady <= hend &&
            node->Bclipx <= node->Bclipx2      &&
            node->Bclipy <= node->Bclipy2;
      node->quadtick = tick;
      node->quadx    = quadx;
      node->quady    = quady;
      node->quadret  = ret;
   }
   return ret;
}

/**
 * post: return image for the window (represented by node).
 *
 * called by getNormalizedImage
 * private function - assume the model to be read-locked already from
 *                    getNormalizedImage
 */
XImage* XScraper::updateImageForNode(Node* n, int tic, int qx, int qy) {

   if (n->imagetick != tic || qx != n->imageqx || qy != n->imageqy) {
   
      int x, y, w, h;
      int sx = STARTX, sy = STARTY, ex = ENDX, ey = ENDY;      
      
      // Doing quadrant-wise image collection
      if (qx >= 0) {
         int bx = MULT_BLOCK_WIDTH (qx);
         int by = MULT_BLOCK_HEIGHT(qy);
         int bx2 = bx + BLOCK_WIDTH  - 1; 
         int by2 = by + BLOCK_HEIGHT - 1; 
         if (bx > sx)  sx = bx;
         if (by > sy)  sy = by;
         if (bx2 < ex) ex = bx2;
         if (by2 < ey) ey = by2;
      }
      
      n->imageqx = qx;
      n->imageqy = qy;
      n->imagetick = tic;
      
      if (n->image) {
         XDestroyImage(n->image);
         n->image = 0;
      }
      
      x = n->Bclipx  - n->rootx;  // Relative offset with border
      y = n->Bclipy  - n->rooty;  // same as -attrs.border_width if clip is ok
      w = n->Bclip_width;
      h = n->Bclip_height;
      
      n->imgrootx = n->Bclipx;
      n->imgrooty = n->Bclipy;
      
      if (n->Bclipx < sx) {
         int d = sx - n->Bclipx;
         x += d;
         w -= d;
         n->imgrootx += d;
      }
      
      if (n->Bclipy < sy) {
         int d = sy - n->Bclipy;
         y += d;
         h -= d;
         n->imgrooty += d;
      }
      
      if (n->Bclipx2 > ex) {
         int d = n->Bclipx2-ex;
         w -= d;
      }
      
      if (n->Bclipy2 > ey) {
         int d = n->Bclipy2-ey;
         h -= d;
      }
      if (timer.dbug && debug >= 1) {
         char out[1024];
         sprintf(out, "SRC: Start getimage (0x%x, xy(%d, %d) wh(%d, %d)",
                 n->window, x, y, w, h);
         timer.timer_printdelta(out);
      } 
      erroroccured = 0;
      if (w <= 0 || h <= 0) {
         erroroccured = 1;
      } else {
         n->image = 
            XGetImage(srcDisplay, n->window, x,y,w,h, 0xffffffff, ZPixmap);
         if (n->image == 0) erroroccured = 1;
      }
                           
      if (erroroccured) {
         erroroccured = 0;
         if (debug > 0) {
            fprintf(stderr, "XScraper::XGetImage erroroccured (0x%x, xy(%d, %d) wh(%d, %d)\n", n->window, x, y, w, h);
         }
         n->image = 0;
      }
      if (timer.dbug && debug >= 1) {
         timer.timer_printdelta("SRC: Finish getimage");
      }
   }
   return n->image;
}

/**
 * post: return the highest ancestor that has the same color depth as the
 *       node in question to be used for scraping action.
 *
 * called by processQuadrantLinks
 * private function - assume the model to be write-locked from
 *                    processQuadrantLinks
 */
Node* XScraper::getNodeForAncestorDepth(Node* n, int avoid_rootnode) {
   Node* ret = n;
   if (n->ancestDepthTick != tick) {

      while(ret->parentnode && 
            ret->parentnode->attrs.depth == n->attrs.depth) {
            
         /* avoid_rootnode is 1 if we are in FAMILY_SHARE mode. 
            In this case, this function never returns the rootnode. 
            This ensures that we will not catch glimpses of windows we are
            not supposed to see, being in FAMILY_SHARE mode. */
         if (avoid_rootnode && ret->parentnode == rootnode) {
            break;
         }
         ret = ret->parentnode;
      }

      n->ancestDepthNode = ret;
      n->ancestDepthTick = tick;

      if (ret != n) {
         ret->ancestDepthNode = ret;
         ret->ancestDepthTick = tick;

      }
   } else {
      ret = n->ancestDepthNode;
   }
   return ret;
}

/**
 * post: get and store data about all the windows in the particular
         quadrant (widx, hidx)
 * calls: isInQuadrant, getNodeForAncestorDepth
 *
 * called by requadrantizeR
 * private function - assume the model to be write-locked already from
 *                    requadrantizeR
 */
void XScraper::processQuadrantLinks(LinkList* ll, int widx, int hidx) {

   int v              = 1;
   Node* fn           = 0;
   int pels           = 0;
   /* TODO: for blocks which are not complete, this may be less */
   int totpels        = BLOCK_WIDTH * BLOCK_HEIGHT;
   Node* commonancest = 0;
   
   Link* link;
   Link* next;
   Node** nodelist;
   
   ll->sort((int)&((Node*)0)->orderval, -1);
   
   link  = ll->get_head();
   nodelist = (Node**)ll->get_voidata();
   
   memset(nodelist, 0, sizeof(Node*) * totpels);
   
   while (link && pels < totpels) {
      Node* ln = (Node*)(link->data);
      
      next = link->right;
      
      if (!isInQuadrant(ln, widx, hidx)     ||
          ln->destroyed                     || 
          ln->attrs.map_state != IsViewable ||
          ln->attrs.c_class     == InputOnly) {              
          
         ll->unchain(link);
         delete link;
         link = 0;
         ln->refcnt--;
         if (ln->destroyed) {
            ln->destroy(0, 0);
         }
      } else {
         int hstart, hend, wstart, wend, x, y, x2, y2, w, h, idx, sidx, hi, wi;
         
         Node* ancestnode = getNodeForAncestorDepth(ln, (mode == FAMILY_SHARE));
         
        /* if all pixels of a region have same colormap and visual,         
           store their common ancestor node */
         if (!fn) { 
            fn = ln;
            commonancest = ancestnode;
         } else if (v                                         &&
                    (ln->attrs.visual   != fn->attrs.visual   ||
                     ln->attrs.colormap != fn->attrs.colormap ||
                     commonancest       != ancestnode)) {
            v=0;
         }
         
         hstart = DIV_BLOCK_HEIGHT(ln->Bclipy);
         hend   = DIV_BLOCK_HEIGHT(ln->Bclipy2);
         wstart = DIV_BLOCK_WIDTH(ln->Bclipx);
         wend   = DIV_BLOCK_WIDTH(ln->Bclipx2);
         
         x=0; x2=BLOCK_WIDTH-1;
         y=0; y2=BLOCK_HEIGHT-1;
         
         if (wstart == widx) {
            x = MOD_BLOCK_WIDTH(ln->Bclipx);
         }
         if (wend == widx) {
            x2 = MOD_BLOCK_WIDTH(ln->Bclipx2);
         }
         if (hstart == hidx) {
            y = MOD_BLOCK_HEIGHT(ln->Bclipy);
         }
         if (hend == hidx) {
            y2 = MOD_BLOCK_HEIGHT(ln->Bclipy2);
         }
            
         w = (x2-x)+1;
         h = (y2-y)+1;
         
         if (w > 0 && h > 0) {
            sidx = MULT_BLOCK_WIDTH(y) + x;
            
            for (hi = h; hi; hi--, sidx += BLOCK_WIDTH) {
               
               idx = sidx;
               for (wi = w; wi; wi--, idx++) {
                  
                  if (!nodelist[idx]) {                   
                     if (isValidForFamilyShare(ln->window)) {
                        nodelist[idx] = ln;
                     } else {
                       /* if we are in FAMILY_SHARE mode, and this node is not
                          part of the family we are sharing, then do not add
                          node to the quadrant lists. */
                        nodelist[idx] = &bogusnode;
                        v = 0;  /* needed so that common ancestor node is not 
                                   used in place of bogusnode. */
                     }
                     pels++;
                  }
               }
            }
         }  
      }
      link = next;
   }
   ll->set_intdata(v);
}

/**
 * post: free all quadrant data. This needs to be followed by a
 *       requadrantize(rootnode)
 *
 * called by rebuildRequad, help_config
 * private function - assume the model to be write-locked already
 */
void XScraper::free_QuadrantInfo() {
   int i, j;
   for (i = 0; i < numqlistsH; i++) {
      for (j = 0; j < numqlistsW; j++) {
         LinkList* ll = quantlists[i][j];
         Link *link;
         while ((link=ll->get_head()) != 0) {
            Node* node;
            ll->unchain(link);
            node = (Node*)link->data;
            node->refcnt--;
            delete link;
         }
         ll->memset_voidata();
      }
   }
}

/**
 * post: frees the memory allocated for the quadrant lists.
 *
 * called by freeAll
 * private function - assume the model to be write-locked already from freeAll
 */
void XScraper::free_Quadrants() {
   int i, j;
   for (i = 0; i < numqlistsH; i++) {
      for (j = 0; j < numqlistsW; j++) {
         LinkList* ll = quantlists[i][j];
         Link *link;
         while ((link=ll->get_head()) != 0) {
            Node* node;
            ll->unchain(link);
            node = (Node*)link->data;
            node->refcnt--;
            delete link;
         }
         ll->free_voidata();
      }
      free(quantlists[i]);
   }
   free(quantlists);
}

/**
 * post: finds the upper-most ancestor of Window win, that is, the ancestor
 *       which is a direct child of the root window.
 *
 * called by isValidForFamilyShare, refreshFamilyShareTopLevels
 */
Window XScraper::find_directRootAncestor(Window win) {
   if (!isConnected()) return 0;
   Window ret = 0;
   thread_lock_read(&modelRWLock);
   
   ret = _find_directRootAncestor(win);
   
   thread_unlock_read(&modelRWLock);
   return ret;
}

/**
 * post: same as above function, but private, so it does NOT do a 
 *       thread_lock_read.  This is required because the scraper thread has
 *       already done a thread_lock_write, and it CANNOT do a
 *       thread_lock_read or else it will hang...
 */
Window XScraper::_find_directRootAncestor(Window win) {
   Node* n = (Node*)roothash->find(win, HASHTYPE_NODE);
   if (n == rootnode) { 
      return n->window;   // JMC 7/15/02 - Changed this from HUH message
   }
   
   int found = 0;
   while (n && n->parentnode && !found) {
      if (n->parentnode == rootnode) {
         found = 1;
      } else {
         n = n->parentnode;
      }
   }

   if (found) {
      return n->window;
   } else {
      return 0;
   }
}

/**
 * post: in FAMILY_SHARE mode, this method returns 1 only if this window 
 *       is part of the window family that we wish to keep in the quadrant
 *       list.
 *       in FIXED_AREA mode, this method always returns 1.
 *
 * called by processQuadrantLinks, processEvent
 * private function - assume the model to be write-locked already from
 *                    processQuadrantLinks
 */
int XScraper::isValidForFamilyShare(Window win) {
   int ret = 0;
   
   if (mode == FAMILY_SHARE) {
      
      /* Find node's direct root ancestor and check if it's on 
         the familyTopLevels list */
      Window w = _find_directRootAncestor(win);
      
      if (w && familyTopLevels) {
      
         Window root_mask = getResourceMask();
         
         /* Assumption: If the window has the same base as the family_base,
            then we ALWAYS want to share it, regardless.
            We did this because we can't always find all the top level
            windows, so this theoretically catches the windows which 
            SHOULD be shared, but are NOT found as top level windows. 
            An example of this is the pulldown menus of Netscape. */
         if ((w & root_mask) == family_base) {
            return 1;
         }
         
         Link* link = familyTopLevels->get_head();
         while (link) {
            if (w == *((int*)link->data)) {
               ret = 1;
               break;
            }
            link = link->right;
         }
      } else if (0) {
        // No error msg here ... we MAY have familyTopLevels empty if watched
        //  application is terminated
         fprintf(stderr, "iVFFS: Could not find root ancestor!\n");
      }
   } else {
      ret = 1;
   } 
   return ret;
}

/**
 * post: free familyTopLevels linked list.
 *
 * called by refreshFamilyShareTopLevels, freeAll
 * private function - assume the model to be write-locked already
 */
void XScraper::free_familyTopLevels() {
   if (familyTopLevels) {
      Link* link;
      while(link = familyTopLevels->get_head()) {
         familyTopLevels->unchain(link);
         free((int*)link->data);
         delete link;
         link = 0;
      }
      familyTopLevels->resetLL();
      delete familyTopLevels;
      familyTopLevels = 0;
   }
}

/**
 * post: in FAMILY_SHARE mode, refresh the linked list of top level windows
 *       that are in the window family we are sharing.
 *
 * called by requandrantize, do_reconfigure(Window)
 * private function - assume the model to be write-locked already
 */
void XScraper::refreshFamilyShareTopLevels() {
   free_familyTopLevels();
   
   // Call private version of function, no thread-locking.
   familyTopLevels = _enumerateWindows();
   
   if (!familyTopLevels || !family_base) {
      fprintf(stderr, "invalid familytoplevels or invalid family base!\n");
      free_familyTopLevels();
      
      return;
   }
   Window root_mask = getResourceMask();
   Link* link = familyTopLevels->get_head();
   int f;
   // We keep all windows that have the same family base.
   while (link) {
      f = 0;
      if ((*((int*)link->data) & root_mask) != family_base) {
         Link* temp = link;
         link = link->right;
         familyTopLevels->unchain(temp);
         free((int*)temp->data);
         delete temp;
         temp = 0;
         f = 1;
      }
      if (!f) {
         link = link->right;
      }
   }
   
   // Replace all family top levels with their direct root ancestors.
   link = familyTopLevels->get_head();
   if (!link) {
      free_familyTopLevels();
   }
   while (link) {
      Window w = _find_directRootAncestor(*((int*)link->data));
      if (w) {
         *((int*)link->data) = w;
      } else {
         fprintf(stderr, "rFSTLevels: Could not find root ancestor!\n");
      }
      link = link->right;
   }
   
  /*
   if (!familyTopLevels || !familyTopLevels->get_head()) {
     // No family top levels left ... app must have been terminated
      fprintf(stderr, "No Familytoplevels LEFT!\n");
   }
  */
   
   /* Iterate through familyTopLevels list, take the LOWEST start x and y
      values, and take the HIGHEST end x and y values. */
   int TW, TH, SX, SY, EX, EY;
   TW = TH = 0;
   SX = SY =  999999;
   EX = EY = -999999;
   link = familyTopLevels ? familyTopLevels->get_head() : 0;
   while (link) {
      Node* n = (Node*)roothash->find(*((int*)link->data), HASHTYPE_NODE);
      if (n->rootx < SX) {
         SX = n->rootx;
      }
      if (n->rooty < SY) {
         SY = n->rooty;
      }
      if (n->rootx2 > EX) {
         EX = n->rootx2;
      }
      if (n->rooty2 > EY) {
         EY = n->rooty2;
      }
      link = link->right;
   }
   
   if (SX == 999999) { SX = 0; EX = 0; }
   if (SY == 999999) { SY = 0; EY = 0; }
   
   /* If any of the values are outside the boundaries of the desktop, adjust
      them so they are within the desktop. */
   int dw = get_dwidth();
   int dh = get_dheight();
   if (SX < 0) {
      SX = 0;
   } else if (SX >= dw) {
      SX = dw-1;
   }
   if (SY < 0) {
      SY = 0;
   } else if (SY >= dh) {
      SY = dh-1;
   }
   if (EX < 0) {
      EX = 0;
   } else if (EX >= dw) {
      EX = dw-1;
   }
   if (EY < 0) {
      EY = 0;
   } else if (EY >= dh) {
      EY = dh-1;
   }
   
   TW   = (EX - SX) + 1;
   TH   = (EY - SY) + 1;
   
   if (TW < 1) TW = 1;
   if (TH < 1) TH = 1;
   
   /* if any dimensions have changed, we need to call adjust_rootxy and
      set new clip values. */
   if (TW != TESTW || TH != TESTH || SX != STARTX || SY != STARTY) {
      TESTW  = TW;
      TESTH  = TH;
      STARTX = SX;
      STARTY = SY;
      ENDX   = EX;
      ENDY   = EY;
      imagestack->free_allStackedImages();
      imagestack->freeImageBuffers();
      adjust_rootxy(rootnode, 0, 0);
   }
}

/**
 * post: update the quadrants that the window is in
 *       @param node is the window to be requadrantized
 * calls: processQuadrantLinks
 *
 * called by requadrantize
 * private function - assume the model to be write-locked already from
 *                    requadrantize
 */
void XScraper::requadrantizeR(Node* node, int d) {
   int widx, hidx, hstart, hend, wstart, wend;
   
   if (node->destroyed                      ||
       node->attrs.map_state != IsViewable  ||
       node->attrs.c_class     == InputOnly) { 
      return;
   }
   
   hstart = DIV_BLOCK_HEIGHT(node->Bclipy);
   hend   = DIV_BLOCK_HEIGHT(node->Bclipy2);
   wstart = DIV_BLOCK_WIDTH(node->Bclipx);
   wend   = DIV_BLOCK_WIDTH(node->Bclipx2);
   
   if (hstart <  0)          hstart = 0;
   if (hstart >= numqlistsH) return;
   if (hend   <  0)          return;
   if (hend   >= numqlistsH) hend   = numqlistsH-1;
   
   if (wstart <  0)          wstart = 0;
   if (wstart >= numqlistsW) return;
   if (wend   <  0)          return;
   if (wend   >= numqlistsW) wend   = numqlistsW-1;
   
   if (hstart > hend || wstart > wend) return;
   
   {
      Node* c = node->children;
      while(c) {
         requadrantizeR(c, d+1);
         c = c->right_sibling;
      }
   }
   
   for (hidx = hstart; hidx <= hend; hidx++) {
      LinkList** llp = quantlists[hidx];
      for (widx = wstart; widx <= wend; widx++) {
         LinkList* ll = llp[widx];

         if (ll->deleteByData(node)) {
            node->refcnt--;
         }
         ll->sortAdd(new Link(node), 
                     (int)&((Node*)0)->orderval, 
                     -1);
         node->refcnt++;
         
         /* mark intdata as appropriate */
         if (d == 0) {
            processQuadrantLinks(ll, widx, hidx);
         }
      }
   }
}

/**
 * post: requadrantize window by simply calling requadrantizeR(node, 0)
 *
 * called by help_config, rebuildRequad, processEvent, process_queuedEvents
 * private function - assume the model to be write-locked already
 */
void XScraper::requadrantize(Node* node) {

   if (mode == FAMILY_SHARE) {
      refreshFamilyShareTopLevels();
   }
   requadrantizeR(node, 0);
}

/**
 * post: number each node in the tree.
 */
int XScraper::numberNodeTree(Node* node, int num) {
   node->orderval = num;
   node = node->children;
   while(node && node->right_sibling) {
      node = node->right_sibling;
   }
   
   while(node) {
      num = numberNodeTree(node, num+1);
      node = node->left_sibling;
   }
   return num;
}


/*
** Model should be write-locked LOCKED when this is called
*/
void XScraper::fireMouseMoved() {
   Link* listener = mouseListeners->get_head();
   while(listener) {
      ((MouseListener*)listener)->locationUpdate(xpointer, ypointer);
      listener = listener->right;
   }
}
void XScraper::removeAllMouseListeners() {
   Link *l;
   while(l=mouseListeners->get_head()) {
      mouseListeners->unchain(l);
   }
}

/*
** Model is locked by these mouse listener calls
*/
void XScraper::addMouseListener(MouseListener* listener) {
   thread_lock_write(&modelRWLock);   
   mouseListeners->chainLast(listener);
   thread_unlock_write(&modelRWLock);   
}
void XScraper::removeMouseListener(MouseListener* listener) {
   thread_lock_write(&modelRWLock);   
   mouseListeners->unchain(listener);
   thread_unlock_write(&modelRWLock);   
}

/* X & Y are in ABSOLUTE XScraper address space.
   private function - assume to be write-locked already */
int XScraper::setXYPosition (int x, int y) {
   int moved = 0;
   
   if (debug >= 6) {
      fprintf(stderr, 
              "setXYPos(%d, %d) - (sx,sy) = (%d, %d) (ex, ey) = (%d, %d)\n",
              x, y, STARTX, STARTY, ENDX, ENDY);
   }
   
   if (x < STARTX)  x = STARTX;
   if (x > ENDX)    x = ENDX;
   if (y < STARTY)  y = STARTY;
   if (y > ENDY)    y = ENDY;
   
  /*
   relx = rely = 0;
   
   if (x != xpointer || y != ypointer) {
      relx = x-xpointer;
      rely = y-ypointer;
      xpointer = x;
      ypointer = y;
      moved = 1;
   }
  */
  
   warpPointer(x, y);
//   fprintf(stderr, "WP: = (%d, %d)\n", x, y);
               
   return moved;
}

void XScraper::warpPointer(int x, int y) {
   if (debug > 3) {
      fprintf(stderr, "warpPointer: (%d, %d)\n", xpointer, ypointer);
   }
   if (!viewonly) {
      XWarpPointer(srcDisplay, None, DefaultRootWindow(srcDisplay), 0, 0, 0, 0,
                   x, y);
   }
}


/**
 * post: returns the window that owns pixel at location (x, y).
 *
 * called by getNormalizedImage
 * private function - assume the model to be read-locked already from 
 *                    getNormalizedImage
 */
Node* XScraper::findNodeContaining(int x, int y, int exactNode) {
   int widx, hidx, qx, qy, idx;
   Node* ret;
   LinkList** llp;
   LinkList*  ll;
      
   widx = DIV_BLOCK_WIDTH(x);
   hidx = DIV_BLOCK_HEIGHT(y);
   
   llp  = quantlists[hidx];
   ll   = llp[widx];
    
   /* If the intdata is set, then all nodes have same depth, vis, and cmap,
      and any node will do. */
   if (!exactNode && ll->get_intdata()) {
      return (Node*)(ll->get_head())->data;
   }
   
   qx   = MOD_BLOCK_WIDTH(x);
   qy   = MOD_BLOCK_HEIGHT(y);
   idx  = MULT_BLOCK_WIDTH(qy)+qx;
   
   ret = ((Node**)ll->get_voidata())[idx];
   
   return ret;
}


/**
 * post: sets the node's clip values.
 */
void XScraper::SetClipValues(Node* n) {
      if (n->parentnode) {
         n->clipx   = (n->parentnode->clipx  > n->rootx)  ?
                         n->parentnode->clipx             :
                         n->rootx;
         n->clipx2  = (n->parentnode->clipx2 < n->rootx2) ?
                         n->parentnode->clipx2            :
                         n->rootx2;
         n->clipy   = (n->parentnode->clipy  > n->rooty)  ?
                         n->parentnode->clipy             :
                         n->rooty;
         n->clipy2  = (n->parentnode->clipy2 < n->rooty2) ?
                         n->parentnode->clipy2            :
                         n->rooty2;

         n->Bclipx  = n->rootx  - n->attrs.border_width;
         n->Bclipx2 = n->rootx2 + n->attrs.border_width;
         n->Bclipy  = n->rooty  - n->attrs.border_width;
         n->Bclipy2 = n->rooty2 + n->attrs.border_width;

         n->Bclipx  = (n->parentnode->clipx  > n->Bclipx) ?
                         n->parentnode->clipx             :
                         n->Bclipx;
         n->Bclipx2 = (n->parentnode->clipx2 < n->Bclipx2)?
                         n->parentnode->clipx2            :
                         n->Bclipx2;
         n->Bclipy  = (n->parentnode->clipy  > n->Bclipy) ?
                         n->parentnode->clipy             :
                         n->Bclipy;
         n->Bclipy2 = (n->parentnode->clipy2 < n->Bclipy2)?
                         n->parentnode->clipy2            :
                         n->Bclipy2;
                         
         n->Bclip_width  = n->Bclipx2 - n->Bclipx + 1;
         n->Bclip_height = n->Bclipy2 - n->Bclipy + 1;
         
      } else {
         n->Bclipx  = n->clipx  = STARTX;
         n->Bclipx2 = n->clipx2 = ENDX;
         n->Bclipy  = n->clipy  = STARTY;
         n->Bclipy2 = n->clipy2 = ENDY;
         n->Bclip_width  = n->Bclipx2 - n->Bclipx + 1;
         n->Bclip_height = n->Bclipy2 - n->Bclipy + 1;
      }
}

/**
 * post: builds an incore window model of all the windows on the screen.
 *       The root window node is on the top of the tree and it
 *       contains a pointer to its leftmost child.
 *       All children are siblings.  The tree is ordered so that the
 *       leftmost sibling is the topmost window in the stacking order.
 *       Therefore traversing the tree in a prefix order when
 *       searching for the owner window of a particular pixel will
 *       ensure that the first visible node found that contains the
 *       x/y coordinate, is the correct window.
 *  
 * In the end ALL nodes should have a valid Colormap value, except for those
** having a valid of None.
**
** Got to be very careful, the tree will easily get out of wack. Events come
** in, which we will process to update this tree, but the state of the server
** may already have changed. Not sure how to fix yet TODO!!!
 *
 * calls: SetClipValues, recursive call
 *
 * called by connect, rebuildRequad, processEvent
 */
Node* XScraper::buildNodeTree(Node *parentnode, Window win) {
   Window rootwin, parent, *children=0, cwin;
   unsigned int numchildren;
   int x1, y1;
   Node * mynode = 0;
   int i;
   
   XWindowAttributes    attrs;
   XSetWindowAttributes setattrs;
   
   if (roothash->find(win, HASHTYPE_NODE)) {
      if (debug > 1) {
         fprintf(stderr, "Gulp ... 0x%x Window already created!!\n", win);
      }
      return 0;
   }
   
   if (debug >= 10) {
     fprintf(stderr, "XScraper::buildNodeTree for window 0x%x parent 0x%x\n", win, 
	     parentnode ? parentnode->window : 0);
   }
   erroroccured = 0;
   int status = XGetWindowAttributes(srcDisplay, win, &attrs);
   erroroccured |= !status;
   if (!erroroccured) {
   
     // Update event mask BEFORE calling QueryTree, otherwise we have a
     //  window of vulnerability (might miss a new child window)
     
     // Note: We have problems getting ButtonMotion, as we are usually in a
     //        GRAB when that occurs. Current fix is that we poll cursor
     //        position each scrape. At least we have tracking to some degree
      setattrs.event_mask = VisibilityChangeMask   | StructureNotifyMask |
                            SubstructureNotifyMask | PropertyChangeMask  |
                            PointerMotionMask      | EnterWindowMask     | 
                            ButtonMotionMask       | LeaveWindowMask;
                            
        /* Only 1 client can select for ButtonPressMask ... stay away! 
                            ButtonPressMask        | ButtonReleaseMask   |
        */
                            
      status=XChangeWindowAttributes(srcDisplay, win, CWEventMask, &setattrs);
      erroroccured |= !status;
      
      if (!erroroccured) {
         status = XQueryTree(srcDisplay, win, &rootwin, &parent, &children, 
                             &numchildren);
         erroroccured |= !status;
         if (!status) children = 0;  // Make sure children is correct
      }
                    
      if (!erroroccured) {
         if (parent == None) {
            x1 = attrs.x; y1 = attrs.y;
         } else {
            XTranslateCoordinates(srcDisplay, win, rootwin, 
                                  0, 0, &x1, &y1, &cwin);
         }
         
         if (!erroroccured) {
           /* Add XSetWindowAttributes for EVENTMASK! */
            mynode         = new Node();
            mynode->attrs  = attrs;
            mynode->window = win;
            mynode->parent = parent;
            mynode->rootx  = x1;
            mynode->rooty  = y1;
            mynode->rootx2 = (x1 + attrs.width)  - 1;
            mynode->rooty2 = (y1 + attrs.height) - 1;
            updateWindowText(mynode);   // store window's title
            updateWindowState(mynode);  // store window's WM_STATE
            
            roothash->add(win, mynode, HASHTYPE_NODE);
            mynode->refcnt++;
            
            if (parentnode) {
               mynode->chainFirst(parentnode);
            }
            
           // Parentnode must be valid before calling this.
            SetClipValues(mynode);
            
            if        (attrs.colormap == None) {
               ;
            } else if (attrs.colormap != CopyFromParent) {
               Cmap* cmap = (Cmap*)roothash->find(attrs.colormap, 
                                                  HASHTYPE_CMAP);
               if (!cmap) {
                  cmap = new Cmap(attrs.colormap, attrs.visual);
                  roothash->add(attrs.colormap, cmap, HASHTYPE_CMAP);
               }
            } else if (parentnode) {
               attrs.colormap = parentnode->attrs.colormap;
            }
            
            for(i=0; i < numchildren; i++) {
               buildNodeTree(mynode, children[i]);
            }
         }
      }
   }
   
   if (children) {
      XtFree((char*)(XtPointer)children);
   }
   
   if (erroroccured) {
      if (debug) {
         fprintf(stderr, "XSCRAPER:ERR:buildNodeTree 0x%x, \n", win);
      }
      if (mynode) {
         if (parentnode) {
            mynode->unchain();
         }
         delete mynode;
      }
      mynode = 0;
      erroroccured = 0;
   }
   
   return mynode;
}
   
/**
 * post: sets the map state for self, all siblings and children based on the
 *       newstate value.
 *
 * called by processEvent
 * private function - assume the model to be write-locked already from 
 *                    processEvent
 */
void XScraper::setMapstate(Node* n, int newstate) {
   int dochildren = 1;
   if (!n) return;
   
   if (n->attrs.map_state == IsUnmapped) {
      dochildren = 0;
   } else if (newstate == IsViewable) {
   
      /* If an ancestor is now viewable, and I'm already viewable, then
         my children and siblings should already be correct. Just return. */
      if (n->attrs.map_state == IsViewable) {
         return;
      } else {
         n->attrs.map_state = IsViewable;
      }
   } else if (n->attrs.map_state == IsUnviewable) {
      /* If an ancestor is now not viewable, and I'm already not viewable, then
         my children and siblings should already be correct. Just return. */
      return;
   } else {
      n->attrs.map_state = IsUnviewable;
   }
   
   if (dochildren && n->children) {
      setMapstate(n->children, newstate);
   }
   
   if (n->right_sibling) {
      setMapstate(n->right_sibling, newstate);
   }
}

/**
 * post: handles errors for the XScraper class 
 */
void myerrorhandler(Display* d, XErrorEvent* ev) {
   /* get XScraper object from XScraper-Display map */
   XScraper* xscraper = sdmap->get_XScraper(d);
   if (!xscraper) {
      if (xscraper->get_debug()) {
         fprintf(stderr, "XScraper::myerrorhandler: display not found in XScraper_Display mapping! %X %X\n", d, ev);
      }
      
     //exit(7);
   }

   char errtxt[512];
   XGetErrorText(d, ev->error_code, errtxt, 512);
   if (errtxt == 0) strcpy(errtxt, "Unknown");
   if ( /*!xscraper || d != xscraper->get_srcDisplay() || */
      xscraper->get_debug()) {
      
      fprintf(stderr, 
            "+--- Error --------------------------------------------------\n");
      fprintf(stderr, 
              "+ Received Error from Display %s:\n", DisplayString(d));
      fprintf(stderr, 
              "+       Error: %s,\n"
              "+       Serial %d, Errorcode = %u, Resid = 0x%x,\n"
              "+       reqcode %u, minorcode %u\n", errtxt,
              ev->serial, ev->error_code, ev->resourceid, ev->request_code, 
              ev->minor_code);
      fprintf(stderr, 
            "+------------------------------------------------------------\n");
   }
   
   if (xscraper && d == xscraper->get_srcDisplay()) {
      xscraper->set_erroroccured();
   }
}

/**
 * post: get specified image from source, normalize it, then return it.
 *
 *       Note: rectangular area in question send it. Must be within screen
 *             boundry
 *
 * calls: updateImageForNode
 *
 * called by doTimeout
 */
ImageBuffer* XScraper::getNormalizedImage(int startx, int starty, 
                                          int testw,  int testh) {
   int x, y, usex, usey;
   
   XImage *img    = 0;
   XImage *altimg = 0;
   XImage *useimg = 0;
   
   Node          *altnode = 0;
   Cmap          *cmap    = 0;
   unsigned long *tp;
   ImageBuffer   *outbuf  = 0;
   
   thread_lock_read(&modelRWLock);   
   
/*#ifdef DOSHM
   if (xshmSupported) {
      Status status = 0;
      status=XShmGetImage(srcDisplay, DefaultRootWindow(srcDisplay), 
                          sharedXImage, 0, 0, 0xffffffff);
      if (!status) {
         fprintf(stderr, "Error doing XShmGetImage! ... Switching\n");
         Deallocate_SharedInfo();
      } else {
         img = sharedXImage;
      }
   }  
   if (!img)
#endif*/
   
   outbuf = imagestack->getFreeImageBuffer(startx, starty, testw, testh);
   tp = IMAGEBUFFER_IMAGE_ULONG(outbuf);
   
   int SX  = startx;
   int SY  = starty;
   int EX  = (startx + testw) - 1;
   int EY  = (starty + testh) - 1;
   int xquad = -1;
   int yquad = -1;
   int yspan = outbuf->get_width();
   
   
#ifdef BLOCKIMAGES

   int qx, qy, idx;
   
   int sxq  = DIV_BLOCK_WIDTH (SX);
   int sxdq = MOD_BLOCK_WIDTH (SX);
   int syq  = DIV_BLOCK_HEIGHT(SY);
   int sydq = MOD_BLOCK_HEIGHT(SY);
   
   int exq  = DIV_BLOCK_WIDTH (EX);
   int exdq = MOD_BLOCK_WIDTH (EX);
   int eyq  = DIV_BLOCK_HEIGHT(EY);
   int eydq = MOD_BLOCK_HEIGHT(EY);
   
   unsigned long *yqtp = tp;
   for (yquad = syq; yquad <= eyq; yquad++) {
      SY = yquad==syq ? sydq : 0;
      EY = yquad==eyq ? eydq : (BLOCK_HEIGHT-1);
      int tt = MULT_BLOCK_HEIGHT(yquad);
      SY += tt;
      EY += tt;
      
      unsigned long *xqtp = yqtp;
      for (xquad = sxq; xquad <= exq; xquad++) {
         SX = xquad==sxq ? sxdq: 0;
         EX = xquad==exq ? exdq : (BLOCK_WIDTH-1);
         
         tt = MULT_BLOCK_WIDTH(xquad);
         SX += tt;
         EX += tt;
         
         tp = xqtp;
         
         LinkList* ll = (quantlists[yquad])[xquad];
         qx   = MOD_BLOCK_WIDTH(SX);
         qy   = MOD_BLOCK_HEIGHT(SY);
         idx  = MULT_BLOCK_WIDTH(qy) + qx;
         
         Node** np = ((Node**)ll->get_voidata());
         np = (np)?np+idx:0;
         
         Node** orignp = np;
#endif
         
         unsigned long *lasttp = tp;   
         for (y = SY; y <= EY; y++, tp = lasttp + yspan, lasttp = tp) {
            
            for (x = SX; x <= EX; x++) {
               
#ifdef BLOCKIMAGES
               Node* n = np?*np++:0;
#else
#ifdef NO_MAPPING
               Node* n = rootnode;
#else
               Node* n = findNodeContaining(x, y);
#endif
#endif
               if (n == &bogusnode) {
                  n = 0;  // set n to null if bogusnode... gray pixel
               }
               
               if (n && (!cmap || n->attrs.colormap != cmap->get_id())) {
                  cmap = (Cmap*)roothash->find(n->attrs.colormap, 
                                               HASHTYPE_CMAP);
               }
               
               if (!n) {
                  usex = usey = 0;
                  useimg = 0;
               } else {
                  
#ifdef MAKELAMEFUNCTIONCALLSINNORMALIZE
                  altnode = getNodeForAncestorDepth(n, (mode == FAMILY_SHARE));
                  altimg  = updateImageForNode(altnode, tick, xquad, yquad);
#else
                  // This gets set from requadrantizing.
                  altnode = n->ancestDepthNode; 

                  if (altnode->imagetick != tick || 
                      xquad != altnode->imageqx  ||
                      yquad != altnode->imageqy) {
                     altimg  = updateImageForNode(altnode, tick, xquad, yquad);
                  } else {
                     altimg = altnode->image;
                  }
#endif
                  
                  useimg = altimg;
                  usex = x - altnode->imgrootx;
                  usey = y - altnode->imgrooty;
               }
               
               if (useimg && !cmap) {
                  if (debug > 0) {
                     fprintf(stderr, "Gak, Win 0x%x has None colormap\n", 
                             n->window);
                  }
                  *tp++ = 0x00777777; // gray pixel
               } else {
                  
                  unsigned long pel;
                  if (useimg) {
                     pel = XGetPixel(useimg, usex, usey);
                     
                     erroroccured = 0;
                     if (cmap->get_tickupdated() != tick) {  // for speed
                        cmap->update(srcDisplay, tick);
                     }
                     if (erroroccured) {
                        erroroccured = 0;
                        if (debug > 0) {
                           fprintf(stderr, 
                                   "XScraper::getNormalizedImage erroroccured cmap 0x%x, \n", 
                                   cmap->get_id());
                        }
                     }
                     *tp++ = cmap->normalize_pixel(pel);
                  } else {
                     *tp++ = 0x00777777; // gray pixel
                  }
               }
            }
#ifdef BLOCKIMAGES
            np = orignp + BLOCK_WIDTH;
            orignp = np;
#endif
         }
         
#ifdef BLOCKIMAGES
         xqtp += (EX-SX) + 1;
      }
      yqtp += yspan*((EY-SY) + 1);
   }
#endif

   
   thread_unlock_read(&modelRWLock);   
   
   /* if (!sharedXImage) {
      XDestroyImage(img);
   } */
   
   return outbuf;
}

/**
 * post: adjusts the rootx and rooty values of the node, and sets the
 *       clip values.
 *
 * called by config, refreshFamilyShareTopLevels, processEvent
 * private function - assume the model to be write-locked already
 */
void XScraper::adjust_rootxy(Node* n, int xdelt, int ydelt) {
   for(; n; n = n->right_sibling) {
      if (debug) {
         fprintf(stderr, "XScraper::adjust_rootxy 0x%x Oxy(%d,%d) Nxy(%d,%d)\n",
                 n->window, n->rootx, n->rooty, n->rootx+xdelt, n->rooty+ydelt);
      }
      n->rootx += xdelt;
      n->rooty += ydelt;
      n->rootx2 = (n->rootx + n->attrs.width)  - 1;
      n->rooty2 = (n->rooty + n->attrs.height) - 1;
      SetClipValues(n);
      adjust_rootxy(n->children, xdelt, ydelt);
   }
}

/**
 * This function is only used by XSViewer.
 *
 * This causes a "Xlib:unexpected async reply" sometimes, especially if running 
 * with more than one scrape and destination... it could easily be fixed by
 * having this function signal the main thread to do the rebuild... but
 * we don't care.
 */
void XScraper::rebuildRequad(int funct) {
   thread_lock_write(&modelRWLock);
   if (funct) {
      XGrabServer(srcDisplay);      
      
      free_queuedEvents();
      free_QuadrantInfo();
      rootnode->destroy(1, roothash);
      
      roothash->hash_free();
      
      roothash = new Hash(1024*64);
      rootnode = buildNodeTree(0, DefaultRootWindow(srcDisplay));
      numberNodeTree(rootnode, 1);
      requadrantize(rootnode);
      XUngrabServer(srcDisplay);
      XFlush(srcDisplay);
   } else {
      adjust_rootxy(rootnode, 0, 0);
      numberNodeTree(rootnode, 1);
      requadrantize(rootnode);
   }
   thread_unlock_write(&modelRWLock);
}

/**
 * post: Outside client is asking for a specific rectangular area
 *
 *       Note: rectangular area in question must be within screen boundry
 */
ImageBuffer* XScraper::getUpdate(int x, int y, int w, int h) {
   if (!isConnected()) return 0;
   int ex = x + w - 1;
   int ey = y + h - 1;
   if (x < 0 || x >= get_dwidth()  || ex < 0 || ex > get_dwidth() ||
       y < 0 || y >= get_dheight() || ey < 0 || ey > get_dheight()) {
      return 0;
   }
   
   XEvent ev;
   ev.type = SCRAPE_FORCEUPDATE;
   ev.xbutton.x      = x;
   ev.xbutton.y      = y;
   ev.xbutton.x_root = w;
   ev.xbutton.y_root = h;
   queue_event(&ev, 0); 
   
  // Only affects non-threaded env
   queueXProtocol(2);
   
   return getImageFromStack();
}

/**
 * post: Outside client is asking for window selection. Return the toplevel
 *       window (from enumerateWindows) which coincides with the selection.
 *       We WILL return root.
 */
Window XScraper::selectWindow() {
   if (!isConnected()) return 0;
   
   XEvent ev;
   ev.type = SCRAPE_SELECTWINDOW;
   window_selection = -1;
   queue_event(&ev, 0); 

  // Only affects non-threaded env
   queueXProtocol(2);
   
   while(window_selection == -1) {
      sleep(1);
   }
   
   if (window_selection) {
      if (window_selection != rootnode->window) {
         LinkList *toplevels = enumerateWindows();
         
        // This code should REALLY be model locked ... consider it
         if (toplevels) {
            Link* link;
            int gotit = 0;
            while (link = toplevels->get_head()) {
               if (!gotit) {
                  Node* n = getNode(*((int*)link->data));
                  
                  Window lwin = n?n->window:0;
                  
                  while(n && n->parentnode) {
                     if (n->window == window_selection) {
                        gotit=1;
                        window_selection = lwin;
                        break;
                     }
                     n = n->parentnode;
                  }
               }
               
               toplevels->unchain(link);
               free((int*)link->data);
               delete link;
               link = 0;
            }
            delete toplevels;
         }               
      }
   }
   
   return window_selection;
}

/**
 * post: 
** Process Interesting Events 
**
** S   CirculateNotify    - Sent when CirculateWindow is used (usually by the
**                          the winmgr) to raise bottom, or lower top window.
** C   ColormapNotify     - Sent when Colormap is installed/uninstalled for a
**                          window, or the Cmap attribute is changes for a win.
** S   ConfigureNotify    - Sent when ConfigureWindow is used to change stack
**                          order, location, and/or size of window.
** S   DestroyNotify      - Sent when a window is being destroyed. We SHOULD
**                          be able to ignore this, as if the window is MAPPED,
**                          an UnmapNotify SHOULD preceed the DestroyNotify. We
**                          will act on the UnmapNotify. May have to use this
**                          event to surmise when RIDs are turned in (TODO!!)
** S   GravityNotify      - Indicates a window was resized, and that resulted
**                          in a change of position for a child based on the
**                          childs gravity setting.
** S   MapNotify          - Sent when a window is mapped.
** S   MappingNotify      - Sent when the Key, Pointer, or Modifier mappings
**                          are changed.  Always sent, no special setup req.
** S   ReparentNotify     - Sent when a window is reparented.
** S   UnmapNotify        - Sent when a window is unmapped
** V   VisibilityNotify   - Sent when a windows visibility changes (change
**                          between Unobscured, PartiallyObscured, and 
**                          FullyObscured.
**     
**     
** Note - The 'S' prefix indicates that the event is selected via the
**        StructureNotify and/or SubstructureNotify event mask.
**      - The 'C' prefix indicates that the event is selected via the
**        ColormapChange even mask.
**      - The 'V' prefix indicates that the event is selected via the
**        VisibilityChange even mask.
**
**
** Note2: Add a q'ing mechanism to q incoming events while processing a
**        frame. 
**
** Note3: Added NOPE blocks to ensure we ALWAYS process events. This stinks, 
**        there is a window of vulnerability where we can miss events when 
**        they occur right at creation. We probably need to resynch our
**        model every so often to ensure it stays correct
**
** Note4: Note3 may be wrong now ... reordered things in buildNodeTree so
**        eventmask is updated prior to QueryTree. So, we SHOULD be ok
*
*  called by process_queuedEvents
*  private function - assume the model to be write-locked already from
*                     process_queuesEvents
*/
int XScraper::processEvent(MyXEvent* mev) {

   int requad = 0;
   int change = 0;
   
   
   XEvent *ev = &mev->ev;
//   fprintf(stderr,  "%u: processEvent ev = %d\n", timer.gettime(), ev->type);
   if (debug > 5) {
      fprintf(stderr, "XScraper: event = %d\n", ev->type);
   }
   
   switch(ev->type) {
      
      case ButtonPress: 
      case ButtonRelease: 
      case MotionNotify: {
         if (ev->xbutton.x_root != xpointer ||
             ev->xbutton.y_root != ypointer) {
            xpointer = ev->xbutton.x_root;
            ypointer = ev->xbutton.y_root;
            fireMouseMoved();
//         fprintf(stderr, "RealM:  = (%d, %d)\n", xpointer, ypointer);
         }
         break;
      }
      
      case EnterNotify:
      case LeaveNotify: {
         if (ev->xcrossing.x_root != xpointer ||
             ev->xcrossing.y_root != ypointer) {
            xpointer = ev->xcrossing.x_root;
            ypointer = ev->xcrossing.y_root;
            fireMouseMoved();
//            fprintf(stderr, "RealEL: = (%d, %d)\n", xpointer, ypointer);
//         } else {
//            fprintf(stderr, "RealEL: = SKIP!!!!\n");
         }
         break;
      }
      
      
     //
     // SELECTWINDOW Does a grab and waits for the user to select a window
     //
      case SCRAPE_SELECTWINDOW: {
         
#ifdef DOTHREADS
         pthread_testcancel();
#endif
         
         Window win = None;
         
         XBell(srcDisplay, 100);
         
         if (crosshair == 0) {
            crosshair = XCreateFontCursor(srcDisplay, XC_crosshair);
//            fprintf(stderr, "SELECTWINDOW: CURSOR = %x\n", crosshair);
         }
         
         int status = XGrabPointer(srcDisplay, rootnode->window, False,
                                   ButtonPressMask, GrabModeSync,
                                   GrabModeAsync, rootnode->window, 
                                   crosshair, CurrentTime);
         if (status != GrabSuccess) {
            window_selection = 0;
//            fprintf(stderr, "SELECTWINDOW: GRAB FAILED\n");
            
         } else {
//            fprintf(stderr, "SELECTWINDOW: GRAB WORKED\n");
         
            while (win == None) {
               XEvent event;
               XAllowEvents(srcDisplay, SyncPointer, CurrentTime);
               XWindowEvent(srcDisplay, rootnode->window, ButtonPressMask, 
                            &event);
               switch (event.type) {
                  case ButtonPress:
                     if (win == None) {
                        win = event.xbutton.subwindow; 
                        if (win == None) win = rootnode->window;
                     }
                     break;
                  default:
//                     fprintf(stderr, "SELECTWINDOW: Got ev = %d\n", 
//                             event.type);
                     break;
               }
            } 
            
//            fprintf(stderr, "SELECTWINDOW: DONE win=%x\n", win); 
            XUngrabPointer(srcDisplay, CurrentTime);
            if (win == -1) win = 0;
            window_selection = win;
            XBell(srcDisplay, 100);
//            fprintf(stderr, "SELECTWINDOW: REALLYDONE\n");
         }
         
         break;
      }
      
      
     // FORCEUPDATE is a contrived event for the scraping thread to scrape
     //             the specified area. This was added as an experiment. 
     //             If you pause the scraper, forceupdate is a way to get 
     //             a one shot frame update
      case SCRAPE_FORCEUPDATE: {
         doforce = 1; // Show that we want it done. Used to do it here, but
        //
         forcex = ev->xbutton.x;
         forcey = ev->xbutton.y;
         forcew = ev->xbutton.x_root;
         forceh = ev->xbutton.y_root;         
         break;
      }
      
      // These SCRAPE_ input events are from the viewer side.
      case SCRAPE_MOUSEMOTION: {
         int x = ev->xbutton.x;
         int y = ev->xbutton.y;
         if (mode == FAMILY_SHARE) {
            Node* n = findNodeContaining(x, y, 1);
            if (n != &bogusnode) {
               setXYPosition(x, y);
//               fprintf(stderr, "FME:   = (%d, %d)\n", x, y);
//               warpPointer();
            }
         } else {
            setXYPosition(x, y);
//               fprintf(stderr, "FME:   = (%d, %d)\n", xpointer, ypointer);
//            warpPointer();
         }
         break;
      }
      
      case SCRAPE_KEYPRESS:
      case SCRAPE_KEYRELEASE: {
         int x = ev->xbutton.x;
         int y = ev->xbutton.y;
         
         /* If we are in family share mode, make sure we have a valid window
            focus... we do not want to send input to a window that we are
            not sharing. */
         if (mode == FAMILY_SHARE) {
            Window focus;
            int revert_to;
            XGetInputFocus(srcDisplay, &focus, &revert_to);
            
            if (isValidForFamilyShare(focus)) {
               Node* n = findNodeContaining(x, y, 1);
               if (n && n != &bogusnode) {
                  reallyInjectKey(x, y, (KeySym)mev->otherinfo, 
                                  ev->type==SCRAPE_KEYPRESS);
               } else {
                  reallyInjectKey((KeySym)mev->otherinfo, 
                                  ev->type==SCRAPE_KEYPRESS);
               }
            } else {
               if (ev->type == SCRAPE_KEYPRESS) {
                  fprintf(stderr, "Key press/release - invalid focus window\n");
               }
            }
         } else {

            reallyInjectKey(x, y, (KeySym)mev->otherinfo, 
                            ev->type==SCRAPE_KEYPRESS);
         }
         break;
      }
      
      case SCRAPE_BUTTONPRESS:
      case SCRAPE_BUTTONRELEASE: {
         int x = ev->xbutton.x;
         int y = ev->xbutton.y;
         
         Node* n = findNodeContaining(x, y, 1); 
         if (mode == FAMILY_SHARE) {
            
            if (n && n != &bogusnode) {
               setXYPosition(x, y);
//               warpPointer();
               XTestFakeButtonEvent(srcDisplay, ev->xbutton.button, 
                                    ev->type == SCRAPE_BUTTONPRESS, 1);
            } /*else {
               if (ev->type == SCRAPE_BUTTONPRESS) {
                  fprintf(stderr, "Button press/release - bogusnode\n");
               }
            }*/
         } else {
            setXYPosition(x, y);
//            warpPointer(); 
            XTestFakeButtonEvent(srcDisplay, ev->xbutton.button, 
                                 ev->type == SCRAPE_BUTTONPRESS, 1);
         }
         break;
      }
      
      case ColormapNotify: {
         XColormapEvent *lev = &ev->xcolormap;
         if (lev->c_new) {
            if (debug) {
               fprintf(stderr, "New Colormap for window %d%s\n", lev->window,
                       lev->send_event?" Synth":"");
            }
         }
         
         // We don't trust window managers!
         if (lev->send_event) {
            break;
         }
         break;
      }
      case ConfigureNotify: {
         XConfigureEvent *lev = &ev->xconfigure;
         if (debug > 3) {
            fprintf(stderr, 
                    "ConfigNotify 0x%x[0x%x] xy (%d,%d) wh(%d,%d) abv[0x%x] bw[%d]%s\n",
                    lev->window, lev->event,
                    lev->x,      lev->y,
                    lev->width,  lev->height, lev->above, 
                    lev->border_width, lev->send_event?" Synth":"");
         }
         
         // We don't trust window managers!
         if (lev->send_event) {
            break;
         }

         /* Always process events!  The window may have been created
            just a moment ago, and we may not have been able to place our
            watch mask on it yet. */
         Node* n = (Node*)roothash->find(lev->window, HASHTYPE_NODE);
         if (debug > 3) {
            fprintf(stderr, 
                    "   BC  w/p 0x%x/0x%x xy(%d,%d) wh(%d,%d) rx/ry(%d,%d) abv[0x%x] bw[%d]\n",
                    n->window, n->parentnode?n->parentnode->window:0,
                    n->attrs.x, n->attrs.y,
                    n->attrs.width,  n->attrs.height,
                    n->rootx, n->rooty,
                    n->right_sibling?n->right_sibling->window:0, 
                    n->attrs.border_width);
         }
         
         if (!n) {
            if (debug) {
               fprintf(stderr, "Gak! no hashentry for 0x%x\n", lev->window);
            }
            return -1;
         } 
         
         if (!lev->above && n->right_sibling) {
            
            n->unchain();
            n->chainLast(n->parentnode);
            change |= 0x1000;
            
         } else if (lev->above && 
                    (!n->right_sibling || 
                     n->right_sibling->window != lev->above)) {
            
            Node* rsib = (Node*)roothash->find(lev->above, HASHTYPE_NODE);
            if (!rsib) {
               if (debug) {
                  fprintf(stderr, "Gak! Above: no hashentry for 0x%x\n", 
                          lev->above);
               }
               break;
            } else if (rsib->parentnode != n->parentnode) {
               if (debug) {
                  fprintf(stderr, 
                          "Gak! Got Above for non sibling! 0x%x/0x%x\n", 
                          lev->window, lev->above);
               }
               break;
            } else {
               n->unchain();
               n->chainBefore(rsib);
               change |= 0x1000;
            }
         }
         
         if (lev->x            != n->attrs.x            ||
             lev->y            != n->attrs.y            ||
             lev->width        != n->attrs.width        ||
             lev->height       != n->attrs.height       || 
             lev->border_width != n->attrs.border_width) {
            
            int xdelta, ydelta, wdelta, hdelta;     
            xdelta                = lev->x      - n->attrs.x;
            ydelta                = lev->y      - n->attrs.y;
            wdelta                = lev->width  - n->attrs.width;
            hdelta                = lev->height - n->attrs.height;
            
            n->attrs.x            = lev->x;
            n->attrs.y            = lev->y;
            n->attrs.width        = lev->width;
            n->attrs.height       = lev->height;
            n->attrs.border_width = lev->border_width;
            
            n->rootx             += xdelta;
            n->rooty             += ydelta;
            
            n->rootx2             = (n->rootx + n->attrs.width)  - 1;
            n->rooty2             = (n->rooty + n->attrs.height) - 1;
            
            SetClipValues(n);
            
            if (xdelta || ydelta || wdelta || hdelta) {
               adjust_rootxy(n->children, xdelta, ydelta);
            }
            
            change++;
         }
         
         if (change) {
            if (debug > 3) {
               fprintf(stderr, 
                       "   AD  w/p 0x%x/0x%x xy(%d,%d) wh(%d,%d) rx/rx(%d,%d) abv[0x%x] bw[%d]\n",
                       n->window, n->parentnode?n->parentnode->window:0,
                       n->attrs.x, n->attrs.y,
                       n->attrs.width,  n->attrs.height,
                       n->rootx, n->rooty,
                       n->right_sibling?n->right_sibling->window:0,
                       n->attrs.border_width);
            }
            if (change >= 0x1000) {
               numberNodeTree(rootnode, 1);
            }
#ifdef DOINDIVREQUAD
            requadrantize(n);
#endif
         }
         break;
      }
      case CirculateNotify: {
         XCirculateEvent *lev = &ev->xcirculate;
         
         if (debug > 3) {
            fprintf(stderr, 
                    "CirculateNotify 0x%x[0x%x] %s%s\n", 
                    lev->window,
                    lev->event,
                    (lev->place == PlaceOnTop?"Top":"Bottom"),
                    lev->send_event?" Synth":"");
         }
         
         if (lev->send_event) {
            break;
         }
         
         Node* n = (Node*)roothash->find(lev->window, HASHTYPE_NODE);
            if (!n) {
               if (debug) {
                  fprintf(stderr, "Gak! no hashentry for 0x%x\n", lev->window);
               }
               
               return -1;
            } 
            
            if (lev->place == PlaceOnTop && n->left_sibling) {
               n->unchain();
               n->chainFirst(n->parentnode);
               change++;
            } else if (lev->place != PlaceOnTop && n->right_sibling) {
               n->unchain();
               n->chainLast(n->parentnode);
               change++;
            }
            
            if (change) {
               numberNodeTree(rootnode, 1);
#ifdef DOINDIVREQUAD
               requadrantize(n);
#endif
            }
         break;
      }
      
      case CreateNotify: {
         XCreateWindowEvent *lev = &ev->xcreatewindow;
         
         if (debug > 3) {
            fprintf(stderr, 
                    "CreateWindowNotify w/p 0x%x/0x%x x/y %d/%d w/h %d/%d%s\n",
                    lev->window,
                    lev->parent,
                    lev->x, lev->y,
                    lev->width, lev->height, 
                    lev->send_event?" Synth":"");
         }
         
         if (lev->send_event) {
            break;
         }
         
         {
            Node* n = (Node*)roothash->find(lev->window, HASHTYPE_NODE);
            if (n) {
               if (debug) {
                  fprintf(stderr, "Window for Create already created! 0x%x\n", 
                          lev->window);
               }
            } else {
               n = (Node*)roothash->find(lev->parent, HASHTYPE_NODE);
               if (!n) {
                  if (debug) {
                     fprintf(stderr, "Gak! no hashentry for 0x%x\n", 
                             lev->window);
                  }
                  return -1;
               } else {
                  n = buildNodeTree(n, lev->window);
                  numberNodeTree(rootnode, 1);
               }
            } 
         }
         break;
      }
      
      case DestroyNotify: {
         XDestroyWindowEvent *lev = &ev->xdestroywindow;
         if (debug > 3) {
            fprintf(stderr, 
                    "DestroyNotify 0x%x[0x%x]%s\n", 
                    lev->window,
                    lev->event, 
                    lev->send_event?" Synth":"");
         }
         
         if (lev->send_event) {
            break;
         }
         
         Node* pn;
         Node* n = (Node*)roothash->find(lev->window, HASHTYPE_NODE);
         if (!n) {
            if (debug > 4) {
               fprintf(stderr, "Gak! no hashentry for 0x%x\n", 
                          lev->window);
            }
            return -1;
         } 
         
         pn = n->parentnode;
         n->destroy(1, roothash);
         numberNodeTree(rootnode, 1);
#ifdef DOINDIVREQUAD
         requadrantize(pn);
#endif
         break;
      }
      case GravityNotify: {
         XGravityEvent *lev = &ev->xgravity;
         if (debug > 3) {
            fprintf(stderr, 
                    "GravityNotify 0x%x[0x%x] xy (%d,%d)%s\n", 
                    ev->xgravity.window,
                    ev->xgravity.event,
                    ev->xgravity.x,
                    ev->xgravity.y, 
                    lev->send_event?" Synth":"");
         }
         
         if (lev->send_event) {
            break;
         }
         
         Node* n = (Node*)roothash->find(lev->window, HASHTYPE_NODE);
         if (!n) {
            if (debug) {
               fprintf(stderr, "Gak! no hashentry for 0x%x\n", 
                       lev->window);
            }
            return -1;
         } 
            
         if (lev->x      != n->attrs.x     ||
             lev->y      != n->attrs.y) {
            
            int xdelta, ydelta;     
            xdelta          = lev->x - n->attrs.x;
            ydelta          = lev->y - n->attrs.y;
            
               n->rootx       += xdelta;
               n->rooty       += ydelta;
               
               n->rootx2       = (n->rootx + n->attrs.width)  - 1;
               n->rooty2       = (n->rooty + n->attrs.height) - 1;
               
               n->attrs.x      = lev->x;
               n->attrs.y      = lev->y;
               
               SetClipValues(n);
               
               adjust_rootxy(n->children, xdelta, ydelta);
               
#ifdef DOINDIVREQUAD
               requadrantize(n);
#endif
         }
         break;
      }
      case MapNotify: {
         XMapEvent *lev = &ev->xmap;
         if (debug > 3) {
            fprintf(stderr, 
                    "MapNotify 0x%x[0x%x]%s\n",
                    lev->window,
                    lev->event,
                    lev->send_event?" Synth":"");
         }
         
         if (lev->send_event) {
            break;
         }

         Node* n = (Node*)roothash->find(lev->window, HASHTYPE_NODE);
         if (!n) {
            if (debug) {
               fprintf(stderr, "Gak! Map for unknown window 0x%x.\n", 
                       lev->window);
            }
         } else if (n->attrs.map_state == IsUnmapped) {
            n->attrs.map_state = IsViewable;
               if (n->parentnode && 
                   n->parentnode->attrs.map_state != IsViewable) {
                  n->attrs.map_state = IsUnviewable;
               } else {
                  if (n->children) {
                     setMapstate(n->children, IsViewable);
                  }
               }
               change++;
         } else if (debug > 4) {
            fprintf(stderr, 
                    "Gak! Got MapNotify for 0x%x ans is ALREADY mapped\n", 
                    lev->window);
         }
            
#ifdef DOINDIVREQUAD
            if (change) {
               requadrantize(n);
            }
#endif
         break;
      }
      case MappingNotify: {
         if (debug > 3) {
            fprintf(stderr, "MappingNotify!!!\n");
         }
         keymapOutOfDate = 1;
         break;
      }
      case ReparentNotify: {
         XReparentEvent *lev = &ev->xreparent;
         if (debug > 3) {
            fprintf(stderr, 
                    "ReparentNotify w/p 0x%x/0x%x[0x%x] xy (%d,%d)%s\n", 
                    lev->window,
                    lev->parent,
                    lev->event,
                    lev->x,
                    lev->y, 
                    lev->send_event?" Synth":"");
         }
         
         if (lev->send_event) {
            break;
         }
         
        /*
        ** Process this event everytime
        **
        **  This is needed as it is possible for:
        **
        **     window created
        **     CreateNotify sent
        **     windowmgr finds it, reparents window
        **     Scrape sees CreateNotify, and places watch list for events
        **     ReparentNotify for parent shows up
        **
        **  Other scenarios are also possible. Just check them all
        */
         if (1) { 
            int xdelta, ydelta;
            
            Node* n  = (Node*)roothash->find(lev->window, HASHTYPE_NODE);
            Node* pn = (Node*)roothash->find(lev->parent, HASHTYPE_NODE);
            Node* opn;
            
            if (!n || !pn) {
               if (debug) {
                  fprintf(stderr, "Gak! no hashentry for 0x%x or 0x%x\n", 
                          lev->window, lev->parent);
               }
               return -1;
            }       
            if (n->parentnode == pn) {
               if (debug > 4) {
                  fprintf(stderr, 
                          "Reparenting to same parent! 0x%x/0x%x\n", 
                          lev->window, lev->parent);
               }
               return 0;
            }
            n->attrs.x      = lev->x;
            n->attrs.y      = lev->y;
               
            xdelta          = (pn->rootx + lev->x) - n->rootx;
            ydelta          = (pn->rooty + lev->y) - n->rooty;
            
            opn = n->parentnode;  
            n->unchain();
            /* Don't know where to chain. Put at end. TODO! */
            n->chainFirst(pn); 
            
            n->rootx       += xdelta;
            n->rooty       += ydelta;
            n->rootx2       = (n->rootx + n->attrs.width)  - 1;
            n->rooty2       = (n->rooty + n->attrs.height) - 1;
            
            SetClipValues(n);
            adjust_rootxy(n->children, xdelta, ydelta);
            change++;
            numberNodeTree(rootnode, 1);
            
#ifdef DOINDIVREQUAD
            requadrantize(n->parentnode);
            requadrantize(opn);
#endif
         }         
         break;
      }
      case UnmapNotify: {
         XUnmapEvent *lev = &ev->xunmap;         
         if (debug > 3) {
            fprintf(stderr, 
                    "UnmapNotify 0x%x[0x%x]%s\n",
                    lev->window,
                    lev->event,
                    lev->send_event?" Synth":"");
         }
         
         if (lev->send_event) {
            break;
         }
         
         Node* n = (Node*)roothash->find(lev->window, HASHTYPE_NODE);
         if (!n) {
            if (debug) {
               fprintf(stderr, "Gak! no hashentry for 0x%x\n", lev->window);
            }
            return -1;
         } 
         
         if (n->attrs.map_state == IsUnmapped) {
            if (debug > 4) {
               fprintf(stderr, 
                       "Gak! Got UnmapNotify and already unmapped! 0x%x\n", 
                       lev->window);
            }
         } else {
            if (n->attrs.map_state == IsViewable && n->children) {
               setMapstate(n->children, IsUnviewable);
            }
            n->attrs.map_state = IsUnmapped;
            change++;
#ifdef DOINDIVREQUAD
            requadrantize(n->parentnode);
#endif
         }
         break;
      }
      
      case VisibilityNotify: {
         XVisibilityEvent *lev = &ev->xvisibility;
         if (debug > 3) {
            fprintf(stderr, 
                    "VisibilityNotify 0x%x state=%d%s\n",
                    lev->window,
                    lev->state, 
                    lev->send_event?" Synth":"");
         }
         
         if (lev->send_event) {
            break;
         }
         
         {
            Node* n = (Node*)roothash->find(lev->window, HASHTYPE_NODE);
            if (!n) {
               if (debug) {
                  fprintf(stderr, "Gak! no hashentry for 0x%x\n", lev->window);
               }
               return -1;
            } 
         }
         
         break;
      }
      
      case PropertyNotify: {
         /* Window title has changed, or window state has changed (i.e. from
            normal to iconic. */
         XPropertyEvent *lev = &ev->xproperty;
         Node* n = (Node*)roothash->find(lev->window, HASHTYPE_NODE);
         if (lev->atom == XA_WM_NAME) {
            if (lev->state == PropertyDelete) {
               if (n && n->text) {
                  free(n->text);
                  n->text = 0;
               }
            } else if (lev->state == PropertyNewValue) {
               updateWindowText(n);
            }
         } else {
            updateWindowState(n);
         }
         
         break;
      }
      case ClientMessage: {
         ; // Ignore client messages
      }      
      default: 
         fprintf(stderr, "Unknown event type %d!!!\n", ev->type);
         break;
   }
   return change;
}

/**
 * post: process each q'd source event, requadrantize node tree if necessary.
 *       This should be called ONLY by src thread (when threaded).
 *
 * calls: processEvent, requadrantize, do_reconfigure
 * called by doTimeout
 */
void XScraper::process_queuedEvents(int motionOnly) {
   MyXEvent* mev;
   int changed = 0;
   
//   fprintf(stderr,  "%u: process_queuedEvents\n", timer.gettime());
   
   thread_lock(&eventQ.eventQMutex);
   mev = eventQ.get_head();
   eventQ.Init();
   thread_unlock(&eventQ.eventQMutex);
   
   thread_lock_write(&modelRWLock);
   
  // Do motion/Key events LAST after model update (two passes)
   
   MyXEvent* savehead=0;
   MyXEvent* savetail=0;
   while(mev) {
      int saveItem = 0;
      MyXEvent* lev = mev;
      switch(mev->ev.type) {
         case ButtonPress: 
         case ButtonRelease: 
         case MotionNotify: 
         case EnterNotify:
         case LeaveNotify: 
         case SCRAPE_MOUSEMOTION:
         case SCRAPE_KEYPRESS:
         case SCRAPE_KEYRELEASE: 
         case SCRAPE_BUTTONPRESS:
         case SCRAPE_BUTTONRELEASE: 
         case SCRAPE_FORCEUPDATE:    // This is NOT motion, but makes sense
         
           // If a motion/button/key event, wait till model is up to date
            if (motionOnly) {
               changed += processEvent(mev);
            } else {
               saveItem = 1;
            }
            
            break;
            
         default:
         
            if (motionOnly) {
               saveItem = 1;
            } else {
              // Model Modifier protocol
               changed += processEvent(mev);
            }
            break;
      }
      
      if (saveItem) {
         if (savetail) {
            savetail->next=mev;
            savetail = mev;
         } else {
            savehead=savetail=mev;
         }
         mev = mev->next;
         lev->next = 0;
      } else {
         mev = mev->next;
         lev->free_MyXEvent();
      }
   }
 
   if (changed) {
      requadrantize(rootnode);
   }
   
   if (motionOnly) {
      if (savehead) {
         eventQ.prepend_events(savehead);
      }
   } else {
      mev = savehead;
      changed = 0;
      while(mev) {
         MyXEvent* lev = mev;
//         fprintf(stderr, "MEVA h=%x hn=%x t=%x mev=%x mn=%x\n",
//                 savehead, savehead->next, savetail, mev, mev->next);
         changed += processEvent(mev);
//         fprintf(stderr, "MEVB h=%x hn=%x t=%x mev=%x mn=%x\n",
//                 savehead, savehead->next, savetail, mev, mev->next);
         mev = mev->next;
         lev->free_MyXEvent();
      }
      
      if (changed) {
         requadrantize(rootnode);
         fprintf(stderr, "Zoinks ... model changed on pointer/key events!");
      }
   }
   
   thread_unlock_write(&modelRWLock);
   
   if (doconfig) {
      if (configwin) {
         do_reconfigure(configwin);
      } else {
         do_reconfigure(configx, configy, configw, configh);
      }
   }
   
   if (doforce) {
      do_forceupdate(forcex, forcey, forcew, forceh);
   }
}

/**
 * post: empties the event queue
 *
 * called by freeAll, help_config, rebuildRequad
 * private function - assume the model to be write-locked already
 */
void XScraper::free_queuedEvents() {
   MyXEvent* mev;
   int changed = 0;
   
   thread_lock(&eventQ.eventQMutex);
   mev = eventQ.get_head();
   eventQ.Init();
   thread_unlock(&eventQ.eventQMutex);
   
   while(mev) {
      MyXEvent* lev = mev;
      mev = mev->next;
      lev->free_MyXEvent();
   }
}

void XScraper::queuePointerUpdate() {
   XEvent xev;
   Window rw, cw;
   int rx, ry, wx, wy;
   unsigned int msk;
   XQueryPointer(srcDisplay, rootnode->window, 
                 &rw, &cw, &rx, &ry, &wx, &wy, &msk);
   
   xev.type = MotionNotify;
   xev.xmotion.x_root = rx;
   xev.xmotion.y_root = ry;
   queue_eventInternal(&xev, 0); 
}

ImageBuffer* XScraper::processAll(int queueImage) {
   ImageBuffer *image = 0;
   
  // Only affects non-threaded env
   queueXProtocol(0);
   
//   fprintf(stderr,  "%u: doTimeout TOP\n", timer.gettime());
   if (debug) {
      fprintf(stderr, "Scraper - processAll\n");
   }
   
#ifdef DOTHREADS
   pthread_testcancel();
#endif 

   if (!++tick) tick = 1;

   // process source events then notify viewer to start processing its events.
   timer.timer_start();
   
  // Get current cursor pos ... do update of pointer
   queuePointerUpdate();
   
  // Process ALL events
   process_queuedEvents(0);

   if (doScrape) {
     // get normalized image.
      timer.timer_printdelta("SRC: Process Q'd src events");
      image = getNormalizedImage(STARTX, STARTY, TESTW, TESTH);
      
     // put normalized image on stack and then notify viewer.
      timer.timer_printdelta("SRC: Normalization");
      
      if (image && queueImage) {
        // tell viewer that scraped image is ready to be displayed.
         imagestack->push(image);
         notifyImageObservers();
      }
   }

   timer.timer_printdelta("SRC: Scrape complete ... Query Pointer");
  // Get current cursor pos ... do update of pointer
   queuePointerUpdate();
   process_queuedEvents(1);
   timer.timer_printdelta("SRC: Query Pointer Done");
      
//   fprintf(stderr,  "%u: processAll BOT\n", timer.gettime());
   return image;
}


/**
 * post: called by the global scraperTimeout function, this function does the 
 *       entire scraping process.
 * calls: process_queuedEvents, getNormalizedImage
 */ 
void XScraper::doTimeout() {
   
//   fprintf(stderr,  "%u: doTimeout TOP\n", timer.gettime());
   if (debug) {
      fprintf(stderr, "Scraper - doTimeout\n");
   }
   
   ImageBuffer *image = processAll(1);
   
   // have timeout run scraperTimeout every scrapetime ms or so.
   timerId = XtAppAddTimeOut(app, scrapetime, scraperTimeout, this);
}

void XScraper::runTimeout(int v) {
#ifndef DOTHREADS
   if (!v && timerId) {
      XtRemoveTimeOut(timerId);
      timerId = 0;
   } else if (v && timerId == 0) {
      timerId = XtAppAddTimeOut(app, scrapetime, scraperTimeout, this);
   }
#endif
}

void XScraper::xscraperQueuesXProto(int v) {
#ifndef DOTHREADS
   queueXProto = v?1:0; 
#endif
}

Boolean workProc(XtPointer clientdata) {
   ((XScraper*)clientdata)->doTimeout();
   
  // Returning TRUE causes the workproc to be deregistered.
   return True;
}

/**
 * post: calls XScraper::doTimeout */
void scraperTimeout(XtPointer clientdata, XtIntervalId* timerid) {
  // Do our work in a workproc, so we know there is nothing else going on
   XtAppAddWorkProc(((XScraper*)clientdata)->app, workProc, clientdata);
}

#ifdef DOTHREADS
void scraperWakeupInputCB(XtPointer clientdata, int* fd, 
                          XtInputId* inputid) {
   XScraper* xscraper = (XScraper*)clientdata;
   
   int ch=0;
   while(read(xscraper->wakeupPipe[0], &ch, 1)>0);
   
//   fprintf(stderr, "WakeupInput: TOP\n");
   xscraper->process_queuedEvents(1);
//   fprintf(stderr, "WakeupInput: BOT\n");
}
#endif

void hexdump(void* buf, int len) {
   char s1[80];
   int k;
   char* sep=0;
   for(k=0; k < len; k++) {
      if (k % 16 == 0) {
         if (k) {
            fprintf(stderr, "%s", s1);
         }
         sprintf(s1, "\n%4.4x: ", k);
      }
      sep = (char*)((!(k % 8))?"  ":" ");
      sprintf(s1+strlen(s1), "%s%02.2x", sep, ((unsigned char*)buf)[k]);
   }
   fprintf(stderr, "%s\n", s1);
}

/*
** For non threaded (or green threaded) environments, provide a way to drain 
**  the events from the DISPLAY and enqueue them. If processLevel is 0, no
**  processing is done. If 1, mouseonly, otherwise ALL
*/
void XScraper::queueXProtocol(int processLevel) {
#ifndef DOTHREADS
   XtInputMask mask;
   if (queueXProto == 1 && isConnected()) {
      queueXProto++;
      while( mask = XtAppPending(app) ) {
         if (mask & XtIMXEvent) {
            XEvent newevent;
            XtAppNextEvent(app, &newevent);
            queue_eventInternal(&newevent, 0); 
         } else {
            XtAppProcessEvent(app, mask);
         }
      }
      if (processLevel == 1) {
         process_queuedEvents(1);
      } else if (processLevel > 1) {
         process_queuedEvents(0);
      }
      queueXProto--;
   }
      
#endif
}


/**
 * post: gets events and queues them up.
 */
#ifdef DOTHREADS
void* scraperMain(void* userarg) {
   XScraper* xscraper = (XScraper*)userarg;
   int mask = XtInputReadMask;
   
   if (xscraper->debug) {
      fprintf(stderr, "ScraperMain - Starting\n");
   }
   
   XtAppAddTimeOut(xscraper->app, 1, scraperTimeout, xscraper);
   
   xscraper->inputId = 
       XtAppAddInput(xscraper->app, xscraper->wakeupPipe[0], 
                     (XtPointer)mask, scraperWakeupInputCB, 
                     xscraper);
      
   for (; !xscraper->getScraperPleaseDie(); ) {
      XEvent newevent;
      XtAppNextEvent(xscraper->app, &newevent);
      xscraper->queue_eventInternal(&newevent, 0); 
      xscraper->process_queuedEvents(1);
   }
   
   fprintf(stderr, "main thread exitting\n");
   return 0;
}
#endif

/**
 * post: starts running the scraperTimeout function repeatedly.
 *       also a new thread is created that runs scraperMain.
 */
void XScraper::start() {
#ifdef DOTHREADS

   if (pipe(wakeupPipe) != 0) {
      perror("PIPE");
   }
   fcntl(wakeupPipe[0],F_SETFL,O_NDELAY);
   fcntl(wakeupPipe[1],F_SETFL,O_NDELAY);
   
   int err = pthread_create(&thread, 0, scraperMain, this);
   if (err != 0) {
      perror("pthread_create");
      fprintf(stderr, "Error starting background thread %d!!\n", err);
   }   
#endif
}
