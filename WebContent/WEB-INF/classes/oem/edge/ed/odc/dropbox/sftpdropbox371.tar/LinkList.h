#ifndef _LINKLIST_H
#define _LINKLIST_H

#include "Link.h"


class LinkList {
   
private:
   
#define INTVALUE(l, o) (*(int*)(((unsigned char*)(l)->data)+(o)))
   
   int            num;
   int            intdata;
   void*          voidata;
   int            voidsz;
   Link           *head, *tail;
   
public:
           LinkList();
           ~LinkList();
   void    malloc_voidata(int sz);
   void    memset_voidata();
   void    free_voidata();
   void    sort(int ofs, int dir);
   void    sortAdd(Link* link, int ofs, int dir);
   void*   deleteByData(void* data);
   Link*   findByData(void* data);
   Link*   unchain(Link* link);
   void    resetLL();
   void    chainLast(Link* link);
   void    chainFirst(Link* link);
   void    chainBefore(Link* link, Link* otherlink);
   void    chainAfter(Link* link, Link* otherlink);
   
/*------- inline functions -------*/
   int     get_intdata()      { return intdata;  }
   void    set_intdata(int v) { intdata = v;     }
   Link*   get_head()         { return head;     }
   Link*   get_tail()         { return tail;     }
   void*   get_voidata()      { return voidata;  }
   int     get_voidataSize()  { return voidsz; }
   int     get_numLinks()     { return num;      }
   
  // No checking to see if link is actually IN this list!! Be careful
   void    make_linkHead(Link *l) { 
   
     // If there is no left, then we are already head
      if (l->left) {
         tail->right    = head;
         head->left     = tail;
         tail           = l->left;
         head           = l;
         l->left        = 0;
         tail->right    = 0;
      }
   }
};

#endif
