/* $OpenBSD: version.h,v 1.39 2003/09/16 21:02:40 markus Exp $ */

#define SSH_VERSION	"OpenSSH_3.7.1p1"
