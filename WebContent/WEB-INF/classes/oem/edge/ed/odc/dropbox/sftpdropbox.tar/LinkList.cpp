
#include <stdlib.h>
#include <string.h>
#include "LinkList.h"


LinkList::LinkList() {
   num     = 0;
   intdata = 0;
   voidata = 0;
   voidsz  = -1;
   head = tail = 0;
}
LinkList::~LinkList() {
   resetLL();
}

void LinkList::malloc_voidata(int sz) {
   voidata = malloc(voidsz=sz);
}

void LinkList::memset_voidata() {
   memset(voidata, 0, voidsz);
}

void LinkList::free_voidata() {
   if (voidata && voidsz > 0) {
      free(voidata);
      voidata = 0;
      voidsz = -1;
   }
}

/* I hope not to use this ... Buble sort. Jzzzeeesh */
void LinkList::sort(int ofs, int dir) {
   LinkList* ll = this;
   int i, j, sw=1;
   int n = ll->num-1;
   Link* w;
   Link* tmp;
   
   if (dir < 0) {
      for(i=0; sw && i < n; i++, n--) {
         w = ll->head;
         sw = 0;
         for(j=0; j < n; j++) {
            tmp = w->right;
            if (INTVALUE(w, ofs) < INTVALUE(tmp, ofs)) {
               ll->unchain(w);
               ll->chainAfter(w, tmp);
               sw=1;
            } else {
               w = tmp;
            }
         }
      }
   } else {
      for(i=0; sw && i < n; i++, n--) {
         w = ll->head;
         sw = 0;
         for(j=0; j < n; j++) {
            tmp = w->right;
            if (INTVALUE(w, ofs) > INTVALUE(tmp, ofs)) {
               ll->unchain(w);
               ll->chainAfter(w, tmp);
               sw=1;
            } else {
               w = tmp;
            }
         }
      }
   }
}

void LinkList::sortAdd(Link* link, int ofs, int dir) {
   LinkList* ll = this;
   Link* tl = ll->head;
   if (dir < 0) {
      while(tl && INTVALUE(tl, ofs) > INTVALUE(link, ofs)) {
         tl = tl->right;
      }
   } else {
      while(tl && INTVALUE(tl, ofs) < INTVALUE(link, ofs)) {
         tl = tl->right;
      }
   }
   
   if (tl) {
      ll->chainBefore(link, tl);
   } else {
      ll->chainLast(link);
   }
}

void LinkList::resetLL() {
   LinkList* ll = this;
   Link* link = ll->head;
   while(link) {
      Link* tmp = link;
      link = link->right;
      tmp->left = tmp->right = 0;
      delete tmp;
      tmp = 0;
   }
   num     = 0;
   intdata = 0;
   
   if (voidata && voidsz > -1) free(voidata);
   voidata = 0;
   voidsz = -1;
   head = tail = 0;
}

void* LinkList::deleteByData(void* data) {
   LinkList* ll = this;
   Link* link = ll->head;
   void* didit=0;
   while(link && link->data != data) {
      link = link->right;
   }
   if (link) {
      didit=link->data;
      ll->unchain(link);
      delete link;
      link = 0;
   }
   return didit;
}

Link* LinkList::findByData(void* data) {
   LinkList* ll = this;
   Link* link = ll->head;
   while(link && link->data != data) {
      link = link->right;
   }
   return link;
}

/*void LinkList::destroyLL() {
   resetLL();
   delete(this);
}*/

Link* LinkList::unchain(Link* link) {
   LinkList* ll = this;
   Link* ret = link;
   
   if (!link->left) {
      ll->head = link->right;
   } else {
      link->left->right = link->right;
   }
   
   if (link->right) {
      link->right->left = link->left;
   } else {
      ll->tail = link->left;
   }
   
   link->right = link->left = 0;
   ll->num--;
   
   return ret;
}

void LinkList::chainLast(Link* link) {
   LinkList* ll = this;
   link->right = 0;
   if (ll->tail) {
      ll->tail->right = link;
      link->left = ll->tail;
      ll->tail = link;
   } else {
      ll->head = ll->tail = link;
      link->left = 0;
   }
   ll->num++;
}

void LinkList::chainFirst(Link* link) {
   LinkList* ll = this;
   link->left = 0;
   if (ll->head) {
      ll->head->left = link;
      link->right    = ll->head;
      ll->head       = link;
   } else {
      ll->head = ll->tail = link;
      link->right = 0;
   }
   ll->num++;
}

void LinkList::chainBefore(Link* link, Link* otherlink) {
   LinkList* ll = this;
   link->left  = otherlink->left;
   link->right = otherlink;
   if (link->left) {
      link->left->right = link;
   } else {
      ll->head = link;
   }
   otherlink->left = link;
   ll->num++;
}

void LinkList::chainAfter(Link* link, Link* otherlink) {
   LinkList* ll = this;
   link->right = otherlink->right;
   link->left  = otherlink;
   if (link->right) {
      link->right->left = link;
   } else {
      ll->tail = link;
   }
   otherlink->right = link;
   ll->num++;
}
