extern "C" {
#include "includes.h"

#include "buffer.h"
#include "bufaux.h"
#include "getput.h"
#include "log.h"
#include "xmalloc.h"

#include "sftp.h"
#include "sftp-common.h"

#include <sys/timeb.h>
}

#include "LinkList.h"

#include "joe.h"

#include <jni.h>

#include "sftpDropbox.h"

// JMC
void logbytes(char* ptr, int len) {
   log("Message[%d]:", len);
   char outline[80]; 
   sprintf(outline, "0000: %70s", "");
   int j=0;
   for (int i=0; i < len; i++) {
      sprintf(outline+6+(j*3), "%2.2x", ptr[i]);
      outline[8+(j*3)] = ' ';
      char toprint = ptr[i];
      if (toprint < ' ' || toprint > 127) {
         toprint='.';
      }
      outline[6+48+2+j] = toprint;
      j++;
      if (!(j % 16)) {
         log(outline);
         sprintf(outline, "%4.4X: %70s", i, "");
         j=0;
      }
   }
   if ((j % 16)) {
      log(outline);
   }
}


//#define DODEBUG
#ifdef DODEBUG
#define debug log
jboolean dodebug = JNI_TRUE;
#else
#undef debug
jboolean dodebug = JNI_FALSE;
#endif

Dropbox *Dropbox::dropbox = NULL;

#define attrib_clear(a) memset((a), 0, sizeof(*a))

#define INBOX     "inbox"
#define OUTBOX    "sent"
#define SANDBOX   "drafts"
#define ACCESSDIR "#ACCESS#"
#define DONEVALUE "#DONE#"

#define FULLINBOX      "/inbox"
#define FULLOUTBOX     "/sent"
#define FULLSANDBOX    "/drafts"

#define userName() getenv("LOGNAME")

char* dropboxToken = 0;
char* dropboxUrl   = 0;
char* dropboxHost  = 0;
int   dropboxPort  = -1;

#ifdef DOTESTING
static char testlogin_token[] = "37201022938028e53dcb4c2b3a37a055d6e4db104421435a8619ac4da632653ff9de8c0810058e82ec8657500f37f1f23c9378a9241035568caefb89b09c08de3d9988882dd7";
static char testhost[] = "iceland.fishkill.ibm.com";
static int  testport   = 5060;
#endif


/*-------------------------------------------------------------------------*\
**             Java Init Function/Statics 
\*-------------------------------------------------------------------------*/
      
JNIEnv* javaenv = 0;
JavaVM* jvm     = 0;
int     gotjvm  = 0;

#ifdef TUNNELCLIENTJAR
char* myclasspath = TUNNELCLIENTJAR;
#else
char* myclasspath = "";
#endif



// sftpDropbox
jclass                    jdropboxClass                   = 0;
jobject                   jdropbox                        = 0;
jmethodID                 threadMaker_methid              = 0;
static jmethodID          connect_methid                  = 0;
static jmethodID          listInOutSandBox_methid         = 0;
static jmethodID          listPackageContents_methid      = 0;
static jmethodID          queryAcls_methid                = 0;
static jmethodID          deletePackage_methid            = 0;
static jmethodID          createPackage_methid            = 0;
static jmethodID          removeAcl_methid                = 0;
static jmethodID          addAcl_methid                   = 0; 
static jmethodID          commitPackage_methid            = 0; 
static jmethodID          deleteFileFromPackage_methid    = 0;
static jmethodID          uploadFile_methid               = 0;
static jmethodID          downloadFile_methid             = 0;
static jmethodID          readFileData_methid             = 0;
static jmethodID          writeFileData_methid            = 0;
static jmethodID          closeOperation_methid           = 0;
static jmethodID          login_methid                    = 0;

// Vector
static jclass             vectorClass                     = 0;

// Enumeration
static jclass             enumerationClass                = 0;
static jmethodID          Enum_hasMoreElements_methid     = 0;
static jmethodID          Enum_nextElement_methid         = 0;

// PackageInfo
static jclass             packageInfoClass                = 0;
static jmethodID          PI_getPackageId_methid          = 0;
static jmethodID          PI_getPackageExpiration_methid  = 0;
static jmethodID          PI_getPackageSize_methid        = 0;
static jmethodID          PI_getPackageName_methid        = 0;
static jmethodID          PI_getPackageOwner_methid       = 0;
static jmethodID          PI_getPackageCompany_methid     = 0;

// FileInfo
static jclass             fileInfoClass                   = 0;
static jmethodID          FI_getFileId_methid             = 0;
static jmethodID          FI_getFileExpiration_methid     = 0;
static jmethodID          FI_getFileSize_methid           = 0;
static jmethodID          FI_getFileName_methid           = 0;
static jmethodID          FI_getFileStatus_methid         = 0;

// Misc
static jclass             miscClass                       = 0;
static jmethodID          MISC_getConnectInfoG_methid     = 0;

// DebugPrint
static jclass             debugPrintClass                 = 0;
static jmethodID          DebugPrint_setLevel_methid      = 0;

// System
static jclass             systemClass                     = 0;
static jmethodID          System_setOut_methid            = 0;
static jobject            System_stdErr_Obj               = 0;

#define findclassVoid(cv, cn)               \
   (cv) = javaenv->FindClass((cn));         \
   if (!(cv)) {                             \
      error("Could not find %s class",      \
            (cn));                          \
      return;                               \
   }
   
#define findclass(cv, cn)                   \
   (cv) = javaenv->FindClass((cn));         \
   if (!(cv)) {                             \
      error("Could not find %s class",      \
            (cn));                          \
      return -1;                            \
   }
   
#define getstaticmethid(cv, mv, mn, ms)     \
   (mv) = javaenv->GetStaticMethodID((cv), (mn), (ms)); \
   if (!(mv)) {                             \
      error("Could not find %s(%s) static method", \
            (mn), (ms));                    \
      return -1;                            \
   }
   
#define getstaticobject(cv, ov, on, os)     { \
   jfieldID _lfid = javaenv->GetStaticFieldID((cv), (on), (os)); \
   (ov) = javaenv->GetStaticObjectField((cv), _lfid);            \
   if (!(ov)) {                             \
      error("Could not find %s(%s) static object", \
            (on), (os));                    \
      return -1;                            \
   }}
   
   
#define getmethid(cv, mv, mn, ms)           \
   (mv) = javaenv->GetMethodID((cv), (mn), (ms)); \
   if (!(mv)) {                             \
      error("Could not find %s(%s) method", \
            (mn), (ms));                    \
      return -1;                            \
   }

int javamethinit() {

  // sftpDropbox
   findclass(jdropboxClass, "oem/edge/ed/odc/dropbox/client/sftpDropbox");
   getmethid(jdropboxClass, connect_methid, 
             "connect", "(Ljava/lang/String;I)Z");
   getmethid(jdropboxClass, login_methid, 
             "login", "(Ljava/lang/String;)Z");
   getmethid(jdropboxClass, listInOutSandBox_methid, 
             "listInOutSandBox", "(I)Ljava/util/Enumeration;");
   getmethid(jdropboxClass, listPackageContents_methid, 
             "listPackageContents", "(J)Ljava/util/Enumeration;");
   getmethid(jdropboxClass, queryAcls_methid, 
             "queryAcls", "(J)Ljava/util/Enumeration;");
   getmethid(jdropboxClass, deletePackage_methid,
             "deletePackage", "(J)Z");
   getmethid(jdropboxClass, createPackage_methid,
             "createPackage", "(Ljava/lang/String;)Z");
   getmethid(jdropboxClass, commitPackage_methid,
             "commitPackage", "(J)Z");
   getmethid(jdropboxClass, removeAcl_methid,
             "removeAcl",     "(JLjava/lang/String;)Z");
   getmethid(jdropboxClass, addAcl_methid,
             "addAcl",        "(JLjava/lang/String;)Z");
   getmethid(jdropboxClass, deleteFileFromPackage_methid,
             "deleteFileFromPackage",  "(JJ)Z");
   getmethid(jdropboxClass, downloadFile_methid,
             "downloadFile", "(JJ)Loem/edge/ed/odc/ftp/common/Operation;");
   getmethid(jdropboxClass, uploadFile_methid,
             "uploadFile",   "(JLjava/lang/String;)Loem/edge/ed/odc/ftp/common/Operation;");
             
   getmethid(jdropboxClass, readFileData_methid,
             "readFileData",   "(Loem/edge/ed/odc/dropbox/client/sftpDropbox$MyClientDownloadOperation;[BII)I");
   getmethid(jdropboxClass, writeFileData_methid,
             "writeFileData",  "(Loem/edge/ed/odc/dropbox/client/sftpDropbox$MyClientUploadOperation;[BII)V");
   getmethid(jdropboxClass, closeOperation_methid,
             "closeOperation", "(Loem/edge/ed/odc/ftp/common/Operation;)Z");
             
  // PackageInfo
   findclass(packageInfoClass,  "oem/edge/ed/odc/dropbox/common/PackageInfo");
   getmethid(packageInfoClass,  PI_getPackageName_methid, 
             "getPackageName", "()Ljava/lang/String;");
   getmethid(packageInfoClass,  PI_getPackageOwner_methid, 
             "getPackageOwner", "()Ljava/lang/String;");
   getmethid(packageInfoClass,  PI_getPackageCompany_methid, 
             "getPackageCompany", "()Ljava/lang/String;");
   getmethid(packageInfoClass,  PI_getPackageId_methid, 
             "getPackageId", "()J");
   getmethid(packageInfoClass,  PI_getPackageSize_methid, 
             "getPackageSize", "()J");
   getmethid(packageInfoClass,  PI_getPackageExpiration_methid, 
             "getPackageExpiration", "()J");
   
   
  // FileInfo
   findclass(fileInfoClass,     "oem/edge/ed/odc/dropbox/common/FileInfo");
   getmethid(fileInfoClass,  FI_getFileName_methid, 
             "getFileName", "()Ljava/lang/String;");
   getmethid(fileInfoClass,  FI_getFileId_methid, 
             "getFileId", "()J");
   getmethid(fileInfoClass,  FI_getFileSize_methid, 
             "getFileSize", "()J");
   getmethid(fileInfoClass,  FI_getFileStatus_methid, 
             "getFileStatus", "()B");
   getmethid(fileInfoClass,  FI_getFileExpiration_methid, 
             "getFileExpiration", "()J");
   
   
  // Misc
   findclass(miscClass,        "oem/edge/ed/odc/tunnel/common/Misc");
   getstaticmethid(miscClass,  MISC_getConnectInfoG_methid, 
             "getConnectInfoGeneric", "(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;");
   
  // Vector
   findclass(vectorClass,       "java/util/Vector");
   
   
  // Enumeration
   findclass(enumerationClass,  "java/util/Enumeration");
   getmethid(enumerationClass, Enum_hasMoreElements_methid, 
             "hasMoreElements", "()Z");
   getmethid(enumerationClass, Enum_nextElement_methid,
             "nextElement", "()Ljava/lang/Object;");
             
  // DebugPrint
   findclass(debugPrintClass, "oem/edge/ed/odc/tunnel/common/DebugPrint");
   getstaticmethid(debugPrintClass,  DebugPrint_setLevel_methid,
                   "setLevel", "(I)V");
             
  // System
   findclass(systemClass, "java/lang/System");
   getstaticmethid(systemClass,  System_setOut_methid,
                   "setOut", "(Ljava/io/PrintStream;)V");
   getstaticobject(systemClass,  System_stdErr_Obj,
                   "err", "Ljava/io/PrintStream;");
                   
   return 0;
};

/*-------------------------------------------------------------------------*\
**             Misc Routines 
\*-------------------------------------------------------------------------*/

char* cvt_realpath(const char * ret) {
   char b[1024];
   int i = 0;
   int bi = 0;
   if (*ret != '/') b[bi++] = '/';
   while(ret[i]) {
      if        ((i==0 || ret[i-1] == '/') && 
                 ret[i] == '.' && ret[i+1] == '\0') {
         
//         printf("Skip . i=%d\n", i);
         i++; // skip it
         
      } else if ((i==0 || ret[i-1] == '/') && 
                 ret[i] == '.' && ret[i+1] == '/') {
//         printf("Skip . i=%d\n", i);
         i += 2;  // skip . and /
         
      } else if ((i==0 || ret[i-1] == '/') &&
                 !strncmp(ret+i, "..", 2)  && 
                 (ret[i+2] == '\0' || ret[i+2] == '/')) {
         
        // back up one level
         i += 2;
         
         b[bi-1] = '\0';
         char * newb = strrchr(b, '/');
         
//         printf("b=[%s] %X bi=%d  ret=[%s] i=%d newb[%s] %X\n", 
//                b, b, bi, ret+i, i, (newb?newb:NULL), newb);
                
         if (newb) {
            b[bi=newb-b] = '\0';
//            printf(">>> bi = %d\n", bi);
            if (bi == 0) b[bi++]='/';
         } else {
            b[0] = '/'; bi = 1;
         }
         
      } else {
//         printf("ccc bi = %d i=%d\n", bi, i);
         if (!bi || ret[i] != '/' || b[bi-1] != '/') {
            b[bi++] = ret[i++];
         } else {
            i++;
         }
      }
   }
   b[bi] = '\0';
   debug("cvt from [%s] to [%s]\n", ret, b);
   return xstrdup(b);
}

char *
local_ls_file(MYDIRENTRY *dp) 
{
	int ulen, glen, sz = 0;
        struct stat stats = dp->getStats();
	struct tm *ltime = localtime(&stats.st_mtime);
	const char *user, *group;
	char buf[1024], mode[11+1], tbuf[12+1]; /* ubuf[11+1], gbuf[11+1];*/

        sprintf(mode, "%crw%c------ ", 
                (S_ISDIR(stats.st_mode)?'d':'-'), 
                (S_ISDIR(stats.st_mode)?'x':'-')); 
                
        user  = dp->getOwner();
        group = "unknown";
        
	if (ltime != NULL) {
		if (time(NULL) - stats.st_mtime < (365*24*60*60)/2)
			sz = strftime(tbuf, sizeof tbuf, "%b %e %H:%M", ltime);
		else
			sz = strftime(tbuf, sizeof tbuf, "%b %e  %Y", ltime);
	}
	if (sz == 0)
		tbuf[0] = '\0';
	ulen = MAX(strlen(user), 8);
	glen = MAX(strlen(group), 8);
	snprintf(buf, sizeof buf, "%s %3d %-*s %-*s %8llu %s %s", mode,
	    stats.st_nlink, ulen, user, glen, group,
	    (unsigned long long)stats.st_size, tbuf, dp->getName());
            
        debug(buf);
	return xstrdup(buf);
}

struct PathInfo {
   int topdirnum;

   char topdir[1024];
   char pack[1024];
   char file[1024];
   int  isAccess;
   char access[1024];
   char fullpath[1024];
   
  // If it does not start with /, assume it does
   void parse(const char* s) {
      topdir[0] = '\0';
      pack[0]   = '\0';
      file[0]   = '\0';
      access[0] = '\0';
      isAccess  = 0;
      
      strcpy(fullpath, s);
      
      if (*s != '\0' && *s == '/') s++;
      
      int i = 0;
      while(*s != '\0' && *s != '/' && i < (int)sizeof(topdir)-1) 
         topdir[i++] = *s++;
      topdir[i] = '\0';
      
      if (*s != '\0' && *s == '/') s++;
      
      i = 0;
      while(*s != '\0' && *s != '/' && i < (int)sizeof(pack)-1) 
         pack[i++] = *s++;
      pack[i] = '\0';
      
      if (*s != '\0' && *s == '/') s++;
      
      i = 0;
      while(*s != '\0' && i < (int)sizeof(file)-1) 
         file[i++] = *s++;
      file[i] = '\0';
      
      topdirnum = 3;
      if (strcmp(topdir, SANDBOX)) {
         topdirnum--;
         if (strcmp(topdir, OUTBOX)) {
            topdirnum--;
            if (strcmp(topdir, INBOX)) {
               topdirnum--;
            }
         }
      } 
      
     // Only outbox and sandbox have access
      if (topdirnum > 1) {
         int accesslen = strlen(ACCESSDIR);
         if (!strncmp(file, ACCESSDIR, accesslen)) {
            if ((int)strlen(file) == accesslen) {
               isAccess = 1;
            } else if (file[accesslen] == '/') {
               isAccess = 1;
               strcpy(access, file+accesslen+1);
               file[accesslen] = '\0';
            }
         }
      }
   }
};

/*-------------------------------------------------------------------------*\
**             Java Access functions
\*-------------------------------------------------------------------------*/

/*
** Query Inbox, Outbox, Sandbox
*/
MYDIR* myquerypackages(const char* dirowner, PathInfo *pinfo) {
   MYDIR *mydir = NULL;
    
   javaenv->ExceptionClear();
  
   jobject enumer = javaenv->CallObjectMethod(jdropbox, 
                                              listInOutSandBox_methid, 
                                              (jint)pinfo->topdirnum, 0);
   if (!javaenv->ExceptionOccurred() && enumer) {
      
      char path[1024];
      sprintf(path, "/%s", pinfo->topdir);
      mydir = new MYDIR(dirowner, path);
      mydir->setCompany("unknown");
      
      while(!javaenv->ExceptionOccurred() && 
            javaenv->CallBooleanMethod(enumer, 
                                      Enum_hasMoreElements_methid, 0)){
                                      
         jobject tobj = javaenv->CallObjectMethod(enumer, 
                                                  Enum_nextElement_methid, 
                                                  0);
         jstring nameJ  = (jstring)javaenv->CallObjectMethod(tobj,
                                                   PI_getPackageName_methid, 
                                                   0);
         jstring ownerJ = (jstring)javaenv->CallObjectMethod(tobj,
                                                   PI_getPackageOwner_methid, 
                                                   0);
         jstring companyJ = (jstring)javaenv->CallObjectMethod(tobj,
                                                 PI_getPackageCompany_methid, 
                                                    0);
         long long packid  = javaenv->CallLongMethod(tobj,
                                                     PI_getPackageId_methid, 
                                                     0);
         long long size  = javaenv->CallLongMethod(tobj, 
                                                 PI_getPackageSize_methid, 
                                                    0);
         long long expire= javaenv->CallLongMethod(tobj, 
                                              PI_getPackageExpiration_methid, 
                                                    0);
         
         jboolean z=false;
         const char* name    = javaenv->GetStringUTFChars(nameJ, &z);
         const char* owner   = javaenv->GetStringUTFChars(ownerJ, &z);
         const char* company = javaenv->GetStringUTFChars(companyJ, &z);
         
         struct stat stats;
         memset(&stats, 0, sizeof stats);
                   
         stats.st_size   = size;
                  
         stats.st_ctime  = expire/1000;
         
        // Can't do expire time on dir, otherwise it won't refresh
        //  for some sftp clients (they use the m/a time to determine they
        //  already have the latest info)
#ifdef DOEXPIRETIME
         stats.st_atime  = expire/1000;
         stats.st_mtime  = expire/1000;
#else
         struct timeb t;
         ftime(&t);
         stats.st_atime  = t.time;
         stats.st_mtime  = t.time;
#endif
         stats.st_uid    = 1;
         stats.st_gid    = 1;
         stats.st_mode   = 0755 | _S_IFDIR;

         
         MYDIRENTRY* mydirent = new MYDIRENTRY(owner, path, name, stats);
         
         mydirent->setId(packid);
         mydirent->setCompany(company);
         mydir->addEntry(mydirent);
         
         javaenv->ReleaseStringUTFChars(nameJ,    name);
         javaenv->ReleaseStringUTFChars(ownerJ,   owner);
         javaenv->ReleaseStringUTFChars(companyJ, company);
         
         javaenv->DeleteLocalRef(companyJ);
         javaenv->DeleteLocalRef(ownerJ);
         javaenv->DeleteLocalRef(nameJ);
         javaenv->DeleteLocalRef(tobj);
      }
      
      javaenv->DeleteLocalRef(enumer);
   }
      
   return mydir;
}

/*
** Query package contents
*/
MYDIRENTRY* myquerypackage(PathInfo *pinfo) {

   MYDIR *mydir = myquerypackages("dontcare", pinfo);
   
   if (javaenv->ExceptionOccurred() || !mydir) return NULL;
   
  // Search for our boy
   MYDIRENTRY *dp = NULL;
   while((dp = mydir->readDir())) {
      if (!strcmp(dp->getName(), pinfo->pack)) {
         break;
      }
      delete dp;
   }
   
   delete mydir;
   
   return dp;
}

/*
** Query package contents
*/
MYDIR* myquerypackagecontents(PathInfo *pinfo, int dohierarchy) {

   MYDIRENTRY *dp = myquerypackage(pinfo);
   
   if (javaenv->ExceptionOccurred() || !dp) return NULL;
   
   char tn[1024];
   if (dohierarchy && *pinfo->file) {
      sprintf(tn, "/%s/%s/%s", pinfo->topdir, pinfo->pack, pinfo->file);
   } else {
      sprintf(tn, "/%s/%s", pinfo->topdir, pinfo->pack);
   }
   MYDIR* mydir = new MYDIR(dp->getOwner(), tn);
   mydir->setCompany(dp->getCompany());
   
  /* Our answer is good ... if we are doing hier, then assume bad, unless
      we have no file portion specified, then since package exists, we are good
   */
   int isOK = 1;
   if (dohierarchy && *pinfo->file) isOK = 0;
   
   if (pinfo->topdirnum > 1 && (!dohierarchy || !*pinfo->file)) {
debug("mqpc: at top, adding ACCESS"); 
     // Add access directory
      struct stat stats = dp->getStats();
      stats.st_size = 0;
      MYDIRENTRY *accessEntry = new MYDIRENTRY(dp->getOwner(), tn,
                                               ACCESSDIR, stats);
      accessEntry->setCompany(dp->getCompany());
      accessEntry->setId(dp->getId());
      mydir->addEntry(accessEntry);
   }
   
  // Make sure Directory knows its package id
   mydir->setId(dp->getId());
   
   jobject enumer = javaenv->CallObjectMethod(jdropbox, 
                                              listPackageContents_methid, 
                                              (jlong)dp->getId(), 0);
                                              
   int slenfile = strlen(pinfo->file);
   
   if (!javaenv->ExceptionOccurred() && enumer) {
      
      while(!javaenv->ExceptionOccurred() && 
            javaenv->CallBooleanMethod(enumer, 
                                      Enum_hasMoreElements_methid, 0)){
                                      
         jobject tobj = javaenv->CallObjectMethod(enumer, 
                                                  Enum_nextElement_methid, 
                                                  0);
         jstring nameJ  = (jstring)javaenv->CallObjectMethod(tobj,
                                                   FI_getFileName_methid, 
                                                   0);
         jboolean z=false;
         const char* name    = javaenv->GetStringUTFChars(nameJ, &z);
         const char* fname   = name;
         
        /*
        ** If we are doing hierarchy, only keep those which start with 
        **  pinfo->file, and which then have a slash. Keep only that next 
        **  segment. If its not a terminating segment, then its a file, 
        **  otherwise its a dir.
        */
         int includeit = 1;
         if (dohierarchy) {
debug("mqpc: doing hierarchy, check for match"); 
            includeit = 0;
            const char* nptr = 0;
            
           /* If at the package level, */
            if (!*pinfo->file) {
               nptr = name;
debug("mqpc: package level %s", tn); 
            } else if (!strncmp(pinfo->file, name, slenfile) && 
                       name[slenfile] == '/') {
               nptr = name + slenfile + 1;
debug("mqpc: lower level %s: %s", tn, nptr); 
            }
            
           /* If we have a match ... */
            if (nptr) {
            
              // At this point, we have validated that pinfo->file is good
               isOK = 1;
               
               char* slashptr = strchr(nptr, '/');
               if (!slashptr) {
                 // Its a file, include it
                  includeit = 1;
                  fname = nptr;
               } else {
                 // Its an interm path, include it as a dir
                  struct stat stats = dp->getStats();
                  stats.st_size = 0;
                  
                  char subname[1024];
                  strncpy(subname, nptr, slashptr-nptr);
                  subname[slashptr-nptr] = '\0';
                  MYDIRENTRY* mydirent = new MYDIRENTRY(mydir->getOwner(), 
                                                        tn, subname, stats);
                  mydirent->setCompany(dp->getCompany());
                  mydir->addEntry(mydirent, 1);
debug("mqpc: Add dir %s: %s", tn, subname); 
               }
            }
         }
         
         if (includeit) {
            long long fileid  = javaenv->CallLongMethod(tobj,
                                                        FI_getFileId_methid, 
                                                        0);
            long long size  = javaenv->CallLongMethod(tobj, 
                                                      FI_getFileSize_methid, 
                                                      0);
            unsigned char status = 
               javaenv->CallByteMethod(tobj, FI_getFileStatus_methid, 0);
            
            struct stat stats;
            stats = dp->getStats();
            stats.st_size   = size;
            
            int ugid = 1;
            if (status != 10) ugid = 2;
            stats.st_uid    = ugid;
            stats.st_gid    = ugid;
            stats.st_mode   = 0644 | _S_IFREG;
            
           // The ctime is set to the Expiration time of package always
            stats.st_atime  = stats.st_ctime;
            stats.st_mtime  = stats.st_ctime;
            
            MYDIRENTRY* mydirent = new MYDIRENTRY(mydir->getOwner(), tn, 
                                                  fname, stats);
            mydirent->setId(fileid);
            mydirent->setCompany(dp->getCompany());
            mydir->addEntry(mydirent);
debug("mqpc: Add file %s: %s", tn, name); 
         }
            
         javaenv->ReleaseStringUTFChars(nameJ,    name);
            
         javaenv->DeleteLocalRef(nameJ);
         javaenv->DeleteLocalRef(tobj);
      }
      
      javaenv->DeleteLocalRef(enumer);
   }
      
      
  // Search for pretend directories which match this p->file ... add any
  //  pretend contents
   if (Dropbox::dropbox && dohierarchy) {
      
debug("mqpc: Add any MadeDirs %s", tn); 
      MadeDirectories *madeDirs = 
         Dropbox::dropbox->getDirectories(mydir->getId());
         
      Link *link = (Link*)((madeDirs)?madeDirs->ll.get_head():NULL);
      while(link) {
      
         MYDIRENTRY *dirent = (MYDIRENTRY*)link->data;
         
         char name[1024];
         *name = '\0';
         
        // It definitely has at least 2 slashes (/inbox/pack) ... skip them
         char* skipptr=strchr(strchr(dirent->getDirectory()+1, '/')+1, '/');
         if (skipptr) {
            strcpy(name, skipptr+1);
            strcat(name, "/");
         }
         strcat(name, dirent->getName());
         
        /*
        ** We are doing hierarchy, and looking for MadeDirectories which
        **  are appropriate for this query. Build the flat name for this 
        **  dirent, and compare to pinfo->file ... If its found, then we
        **  at least have a valid query. If its found, AND it has a child
        **  (ie. is followed by a slash), then collect that info for return.
        */
         const char* nptr = 0;
            
        /* If at the package level, */
         if (!*pinfo->file) {
            nptr = name;
         } else if (!strncmp(pinfo->file, name, slenfile)) {
            if (name[slenfile] == '/') {
               nptr = name + slenfile + 1;
            } else if (name[slenfile] == '\0') {
               isOK = 1;  // Its a match, but is a terminator
            }
         }
         
        /* If we have a match ... */
         if (nptr) {
            
           // At this point, we have validated that pinfo->file is good
            isOK = 1;
            
           // If no next slash, then its a terminating directory. 
           //  Has no children
            char* slashptr = strchr(nptr, '/');
           // Its an interm path, include it as a dir
            struct stat stats = dp->getStats();
            stats.st_size = 0;
            
            char subname[1024];
            if (slashptr) {
               strncpy(subname, nptr, slashptr-nptr);
               subname[slashptr-nptr] = '\0';
            } else {
               strcpy(subname, nptr);
            }
            MYDIRENTRY* mydirent = new MYDIRENTRY(mydir->getOwner(), 
                                                  tn, subname, stats);
            mydirent->setCompany(mydir->getCompany());
            mydir->addEntry(mydirent, 1);
debug("mqpc: Add MadeDir  %s: %s", tn, subname); 
         }
         
         link = link->right;
      }
   }
      
  // If path did not map to anything, no good.
   if (!isOK) {
      delete mydir;
      mydir = NULL;
   }
   
   delete dp;
   
   return mydir;
}

/*
** Query file in package
*/
MYDIRENTRY* myqueryfile(PathInfo *pinfo) {

   MYDIR *mydir = myquerypackagecontents(pinfo, 0);
   
   if (javaenv->ExceptionOccurred() || !mydir) return NULL;
   
  // Search for our boy
   MYDIRENTRY *dp = NULL;
   while((dp = mydir->readDir())) {
   
     /* If its a dead on name match, and its a file (not a made up direntry) */
      if (!strcmp(dp->getName(), pinfo->file) && 
          (dp->getStats().st_mode & _S_IFREG)) {
          
         break;
      }
      delete dp;
   }
   
  // Set the packageid in the file's dirent
   if (dp) dp->_setPId(mydir->getId());
   
   delete mydir;
   
   return dp;
}

/*
** Query Acls
*/
MYDIR* myqueryacls(PathInfo *pinfo, MYDIRENTRY* packageEnt) {

   MYDIR* ret = NULL;
   
   javaenv->ExceptionClear();
   
   jobject enumer = javaenv->CallObjectMethod(jdropbox, 
                                              queryAcls_methid, 
                                              (jlong)packageEnt->getId(), 
                                              0);
                                              
   char tn[1024];
   sprintf(tn, "/%s/%s/%s", pinfo->topdir, pinfo->pack, pinfo->file);
   
   if (!javaenv->ExceptionOccurred() && enumer) {
      
      ret = new MYDIR(packageEnt->getOwner(), tn);
      ret->setId(packageEnt->getId());
      ret->setCompany(packageEnt->getCompany());
      
      while(!javaenv->ExceptionOccurred() && 
            javaenv->CallBooleanMethod(enumer, 
                                      Enum_hasMoreElements_methid, 0)){
                                      
         jstring aclJ = (jstring)javaenv->CallObjectMethod(enumer, 
                                                  Enum_nextElement_methid, 
                                                  0);
         jboolean z=false;
         const char* acl    = javaenv->GetStringUTFChars(aclJ, &z);
         
         struct stat stats;
         struct timeb t;
         
         ftime(&t);
         stats.st_atime  = t.time;
         stats.st_mtime  = t.time;
         stats.st_size   = 555;
         stats.st_uid    = 1;
         stats.st_gid    = 1;
         stats.st_mode   = 0700 | _S_IFDIR;

         MYDIRENTRY* mydirent = new MYDIRENTRY(packageEnt->getOwner(), tn, 
                                               acl, stats);
         mydirent->setId(packageEnt->getId());
         mydirent->setCompany(packageEnt->getCompany());
         ret->addEntry(mydirent);
         
         javaenv->ReleaseStringUTFChars(aclJ,    acl);
         
         javaenv->DeleteLocalRef(aclJ);
      }
      
      javaenv->DeleteLocalRef(enumer);
   }
      
   return ret;
}

/*
** Delete file from Package
*/
int mydeletefilefrompackage(long long packid, long long fileid) {

   javaenv->ExceptionClear();
   
   jboolean ret = javaenv->CallBooleanMethod(jdropbox, 
                                             deleteFileFromPackage_methid, 
                                             (jlong)packid,
                                             (jlong)fileid,
                                             0);
                                              
   return (int)(ret && !javaenv->ExceptionOccurred())?0:-1;
}

/*
** Add ACL to Package
*/
int myaddacl(long long packid, const char* acl) {

   javaenv->ExceptionClear();
   
   jstring aclJ = javaenv->NewStringUTF(acl);
   
   jboolean ret = javaenv->CallBooleanMethod(jdropbox, 
                                             addAcl_methid, 
                                             (jlong)packid,
                                             aclJ,
                                             0);
   javaenv->DeleteLocalRef(aclJ);
                                              
   return (int)(ret && !javaenv->ExceptionOccurred())?0:-1;
}

/*
** Remove ACL from Package
*/
int myremoveacl(long long packid, const char* acl) {

   javaenv->ExceptionClear();
   
   jstring aclJ = javaenv->NewStringUTF(acl);
   
   jboolean ret = javaenv->CallBooleanMethod(jdropbox, 
                                             removeAcl_methid, 
                                             (jlong)packid,
                                             aclJ,
                                             0);
   javaenv->DeleteLocalRef(aclJ);
                                              
   return (int)(ret && !javaenv->ExceptionOccurred())?0:-1;
}

/*
** Create a new package
*/
int mycreatepackage(const char* pack) {

   javaenv->ExceptionClear();
   
   jstring packJ = javaenv->NewStringUTF(pack);
   
   jboolean ret = javaenv->CallBooleanMethod(jdropbox, 
                                             createPackage_methid, 
                                             packJ,
                                             0);
   javaenv->DeleteLocalRef(packJ);
                                              
   return (int)(ret && !javaenv->ExceptionOccurred())?0:-1;
}

/*
** Add ACL to Package
*/
int mycommitpackage(long long packid) {

   javaenv->ExceptionClear();
   
   jboolean ret = javaenv->CallBooleanMethod(jdropbox, 
                                             commitPackage_methid, 
                                             (jlong)packid,
                                             0);
   return (int)(ret && !javaenv->ExceptionOccurred())?0:-1;
}

/*
** Delete a package
*/
int mydeletepackage(long long packid) {

   javaenv->ExceptionClear();
   
   jboolean ret = javaenv->CallBooleanMethod(jdropbox, 
                                             deletePackage_methid, 
                                             (jlong)packid,
                                             0);
                                             
   return (int)(ret && !javaenv->ExceptionOccurred())?0:-1;
}

/*
** Start upload of a file
*/
jobject mystartuploadfile(long long packid, const char* file) {

   javaenv->ExceptionClear();
   
   jstring fileJ = javaenv->NewStringUTF(file);
   
   jobject ret = javaenv->CallObjectMethod(jdropbox, 
                                           uploadFile_methid, 
                                           (jlong)packid,
                                           fileJ,
                                           0);
   javaenv->DeleteLocalRef(fileJ);
                                              
   return (jobject)(ret && !javaenv->ExceptionOccurred())?ret:NULL;
}

/*
** Start download of a file
*/
jobject mystartdownloadfile(long long packid, long long fileid) {

   javaenv->ExceptionClear();
   
   jobject ret = javaenv->CallObjectMethod(jdropbox, 
                                           downloadFile_methid, 
                                           (jlong)packid,
                                           (jlong)fileid,
                                           0);
                                              
   return (jobject)(ret && !javaenv->ExceptionOccurred())?ret:NULL;
}


/*
** Download data from file
*/
int myfsread(jobject jobj, char* buf, int ofs, int len) {

   javaenv->ExceptionClear();
   
   if (len > 50000) len = 50000;
   
   jbyteArray arrJ = javaenv->NewByteArray(len);
   
   int ret = javaenv->CallIntMethod(jdropbox,
                                    readFileData_methid, 
                                    jobj,
                                    (jobject)arrJ,
                                    (jint)0,
                                    (jint)len,
                                    0);
                                           
   javaenv->GetByteArrayRegion(arrJ, 0, len, (jbyte*)(buf+ofs));
   
   javaenv->DeleteLocalRef(arrJ);
                                              
   return (ret >= 0 && !javaenv->ExceptionOccurred())?ret:-1;
}

/*
** Upload data to file
*/
int myfswrite(jobject jobj, char* buf, int ofs, int len) {

   javaenv->ExceptionClear();
   
   int inlen = len;
   
   int tlen = (len > 50000) ? 50000 : len;
   jbyteArray arrJ = javaenv->NewByteArray(tlen);
   
   while(len > 0) {
      tlen = (len > 50000) ? 50000 : len;
      debug("myfswrite: inlen=%d len=%d tlen=%d", inlen, len, tlen);
      javaenv->SetByteArrayRegion(arrJ, 0, tlen, (jbyte*)(buf+ofs));
      debug("myfswrite: calling Java");
      javaenv->CallVoidMethod(jdropbox,
                              writeFileData_methid, 
                              jobj,
                              (jobject)arrJ,
                              (jint)0,
                              (jint)tlen,
                              0);
      debug("myfswrite: back");
      if (javaenv->ExceptionOccurred()) break;
      len -= tlen;
      ofs += tlen;
   }
   
   int exceptionOccurred = javaenv->ExceptionOccurred() != NULL;
                                              
   javaenv->DeleteLocalRef(arrJ);
   
   return (!exceptionOccurred)?inlen:-1;
}

/*
** Download data from file
*/
int myfsclose(jobject jobj) {

   javaenv->ExceptionClear();
   
   jboolean ret = javaenv->CallBooleanMethod(jdropbox,
                                             closeOperation_methid, 
                                             jobj,
                                             0);
                                           
   javaenv->DeleteLocalRef(jobj);
                                              
   return (ret && !javaenv->ExceptionOccurred())?0:-1;
}


/*
** Login to dropbox
*/
int mylogin(char* token) {
   int ret = -1;
   
   javaenv->ExceptionClear();
      
   if (token) {
      jstring tokstrJ = javaenv->NewStringUTF(token);
      
      jboolean rc = javaenv->CallBooleanMethod(jdropbox, login_methid, 
                                               tokstrJ, 0);
      if (!javaenv->ExceptionOccurred() && rc) ret =  0;
      
      javaenv->DeleteLocalRef(tokstrJ);
   }
      
   return ret;
}


/*
** Load JVM and connect to Dropbox
*/
int myconnect(char* host, int port) {

   int ret = -1;
         
   if (!jdropbox) {
      error("myconnect, error instancing sftpDropbox");
      return -1;
   }
      
   jstring hoststr = javaenv->NewStringUTF(host);
   
   jboolean rc = javaenv->CallBooleanMethod(jdropbox, connect_methid, 
                                            hoststr, (jint)port, NULL);
   if (!javaenv->ExceptionOccurred() && rc) ret =  0;
   debug("myconnect, rc = %d", rc);

      
   javaenv->DeleteLocalRef(hoststr);
      
   return ret;
}

// We won't come back from here ... instead, we will get a new thread calling
//  into the giveMeAJavaThread method below. Apparent bug in Java 1.3.1 on AIX
//  4.3.3 where Monitors do not want to work correctly prevents me from using
//  a 'native' thread.
extern "C" void java_initialize();
void java_initialize() {
   if (!gotjvm) {
   
     /* Java 131 restrictions ... these MUST be set
      AIXTHREAD_SCOPE=S
      AIXTHREAD_MUTEX_DEBUG=OFF
      AIXTHREAD_RWLOCK_DEBUG=OFF
      AIXTHREAD_COND_DEBUG=OFF
     */
      putenv("AIXTHREAD_SCOPE=S");
      putenv("AIXTHREAD_MUTEX_DEBUG=OFF");
      putenv("AIXTHREAD_RWLOCK_DEBUG=OFF");
      putenv("AIXTHREAD_COND_DEBUG=OFF");
     
     /* This CAN be set to hel palleviate problems
      JITC_COMPILEOPT=NSCC_CACHE
     */
      putenv("JITC_COMPILEOPT=NSCC_CACHE");
     /*
       Pgm must be linked with -bM:UR 
      */
   
#ifndef JNI_VERSION_1_2
      JDK1_1InitArgs vm_args;
      
      vm_args.version = JNI_VERSION_1_1;
      
      JNI_GetDefaultJavaVMInitArgs(&vm_args);
      
      char* envclasspath=getenv("CLASSPATH");
      
      int cplen = 0;
      if (envclasspath) cplen = strlen(envclasspath)+1;
      
      char* newclasspath = (char*)malloc(strlen(vm_args.classpath) + 
                                         strlen(myclasspath) + cplen + 1);
      strcpy(newclasspath, myclasspath);
      strcat(newclasspath, vm_args.classpath);
      if (newclasspath) {
         strcat(newclasspath, ":");
         strcat(newclasspath, envclasspath);
      }
      
      vm_args.classpath = newclasspath;
      
      log("New classpath[%s]", newclasspath);
#else
      JavaVMInitArgs vm_args;
      vm_args.version = JNI_VERSION_1_2;
      vm_args.ignoreUnrecognized = JNI_FALSE;
      
      char* envclasspath=getenv("CLASSPATH");
      
      vm_args.nOptions = 0;
      vm_args.options  = (JavaVMOption*)malloc(sizeof(JavaVMOption)*10);
      
      
      if (envclasspath) {
         char* cp = (char*)malloc(strlen(envclasspath) + strlen(myclasspath) +
                                  1 + 1 + 20);
         strcpy(cp, "-Djava.class.path=");
         strcat(cp, envclasspath);
         if (myclasspath && *myclasspath) {
            strcat(cp, ":");
            strcat(cp, myclasspath);
         }
         vm_args.options[0].optionString  = cp;
         vm_args.nOptions++;
         
         log("Adding classpath arg[%s]", cp);
      }
      {
         char* libp=getenv("LIBPATH");
         if (libp) log("LIBPATH=[%s]", libp);
         libp=getenv("LD_LIBRARY_PATH");
         if (libp) log("LD_LIBRARY_PATH=[%s]", libp);
      }
#endif

      if (JNI_CreateJavaVM(&jvm, (void**)&javaenv, &vm_args) < 0) {
         error("Error creating JVM");
         return;
      }
      
      
      if (javamethinit()) return;
      
      javaenv->CallStaticVoidMethod(systemClass, System_setOut_methid,
                                    System_stdErr_Obj, NULL);
      
      gotjvm = 1;
      
      javaenv->ExceptionClear();
   }
}


extern "C" char* jmc_authpassword(const char* url, const char* user, 
                                  const char* password);
#ifndef DOITINLINE
char* jmc_authpassword(const char* url, const char* user, 
                       const char* password) {
   char* ret = NULL;
   java_initialize();
   
   javaenv->ExceptionClear();
//   javaenv->CallStaticVoidMethod(debugPrintClass, DebugPrint_setLevel_methid,
//                                 (jint)255, NULL);
   if (javaenv->ExceptionOccurred()) { 
      log("Exception");
      javaenv->ExceptionDescribe();
   }
   
   if (!url || !user || !password) return 0;
   
   jstring userJ  = javaenv->NewStringUTF(user);
   jstring pwJ    = javaenv->NewStringUTF(password);
   jstring opJ    = javaenv->NewStringUTF("XFR");
   jstring scopeJ = javaenv->NewStringUTF("");
   jstring urlJ   = javaenv->NewStringUTF(url);
   
   debug("Calling getConnInfo");
   jstring strJ = (jstring)
      javaenv->CallStaticObjectMethod(miscClass, MISC_getConnectInfoG_methid, 
                                      userJ, pwJ, opJ, scopeJ, urlJ, NULL);
   
   if (javaenv->ExceptionOccurred()) { 
      log("Exception");
      javaenv->ExceptionDescribe();
   }
   debug("back strJ=%x", strJ);
   if (!javaenv->ExceptionOccurred() && strJ) {
      jboolean iscopy = JNI_FALSE;
      const char* token = javaenv->GetStringUTFChars(strJ, &iscopy);
      if (token) {
         ret =  xstrdup(token);
         javaenv->ReleaseStringUTFChars(strJ, token);
         
      }
   }
   
   javaenv->DeleteLocalRef(userJ);
   javaenv->DeleteLocalRef(pwJ);
   javaenv->DeleteLocalRef(opJ);
   javaenv->DeleteLocalRef(scopeJ);
   javaenv->DeleteLocalRef(urlJ);
   if (strJ) {
      javaenv->DeleteLocalRef(strJ);
   }
   
   return ret;
}
#else
// Geeze, do it it its own JVM
char* jmc_authpassword(const char* url, const char* user,
                       const char* password) {
   char* ret = NULL;
   int p1[2];   // Send TO   new pgm
   int p2[2];   // Get  From new pgm
   log("Calling pipe");
   if (!pipe(p1) && !pipe(p2)) {
      int pid = fork();
      if (pid == 0) {
      
         log("Duping stdinout");
         dup2(p1[0], 0);
         dup2(p2[1], 1);
         
         close (p1[0]);
         close (p1[1]);
         close (p2[0]);
         close (p2[1]);
         
         execl("/afs/eda/u/crichton/projects/openssh-3.6.1p1/ccauthpasswd", "ccauthpasswd", (char *)0);
//         execl("/tmp/ccauthpasswd", "ccauthpasswd", (char *)0);
         exit(errno);
      } else if (pid != -1) {
      
         char buf[1024];
         
         close (p1[0]);
         close (p2[1]);
         
         sprintf(buf, "%s\n%s\n", user, password);
         log("writing BUF[%s]", buf);
         int totwrite = strlen(buf)+1;
         int written = 0;
         while(written < totwrite) {
            int w = write(p1[1], buf+written, totwrite-written);
            if (w < 0) {
               if (errno != EINTR && errno != EAGAIN) {
                  log("error write = %d", errno);
                  break;
               }
            } else {
               written += w;
            }
         }
         log("totwrite = %d written = %d", totwrite, written);
         if (written == totwrite) {
            int totread = 0;
            int sz = 0;
            while(1) {
               int r = read(p2[0], buf, sizeof(buf));
               if (r == 0) break;
               if (r < 0) {
                  if (errno != EINTR && errno != EAGAIN) {
                     log("error read = %d", errno);
                     break;
                  }
               } else {
                  ret = (char*)xrealloc(ret, totread+1+r);
                  memcpy(ret+totread, buf, r);
                  
                  totread += r;
                  
                  if (totread > 65*1024*1024) {
                     xfree(ret);
                     ret = 0;
                     break;
                  }
               }   
            }
         }
         
         
         int status;
         while(waitpid(pid, &status, 0) != pid && WIFEXITED(status));
         
         if (WEXITSTATUS(status) != 0) {
            log("exit status = %d", WEXITSTATUS(status));
            if (ret) xfree(ret);
            ret = 0;
         } else {
            if (ret) {
               int doit = 0;
               const char* toks=strstr(ret, "TOKEN[");
               if (toks) {
                  toks += 6;
                  char* toke = strstr(toks, "]\n");
                  if (toke) {
                     memmove(ret, toks, toke-toks);
                     ret[toke-toks] = '\0';
                     doit = 1;
                  }
               }
               
               log("Token is -%s-", ret);
               
               if (!doit) {
                  xfree(ret);
                  ret = 0;
               }
            }
         }
      }
      
      close (p2[0]);      
      close (p1[1]);
   }
   return ret;
}


#endif
// Wanted to reuse joe.cpp from sshd, so had to play some games with where
//  things lived. 
int java_sftp_init2() {

   findclass(jdropboxClass, "oem/edge/ed/odc/dropbox/client/sftpDropbox");
   jmethodID constructID = javaenv->GetMethodID(jdropboxClass, 
                                                "<init>", 
                                                "(Z)V");
   if (!constructID) {
      error("myconnect, methid for constructor == 0");
      return -1;
   }
   
   jdropbox = javaenv->NewObject(jdropboxClass, constructID, dodebug, 0);
   
   threadMaker_methid = javaenv->GetMethodID(jdropboxClass, 
                                             "getMeAJavaThread", 
                                             "()V");
                                                       
   if (!threadMaker_methid) {
      error("java_initialize, methid for threadMaker == 0");
      return -1;
   }
   return 0;
}


/*-------------------------------------------------------------------------*\
**             DROPBOX 
\*-------------------------------------------------------------------------*/
MYFILE* Dropbox::openUpload(const char* s) {
   debug("Dropbox:openUpload: %s\n", s);
   
   PathInfo p;
   p.parse(s);
   
   MYFILE* ret = NULL;
   
   if (p.topdirnum == 3 && !p.isAccess && *p.pack) {
      MYDIRENTRY *dp =  myquerypackage(&p);
      
      if (dp) {
         long long packid = dp->getId();
         
         jobject jobj = mystartuploadfile(packid, p.file);
         if (jobj) {
            char packpath[1024];
            sprintf(packpath, "/%s/%s", p.topdir, p.pack);
            ret = new MYFILE(dp->getOwner(), packpath, p.file, 
                             jobj, MYFILE_UPLOAD);
         }
         delete dp;
      }
   }
   
   return ret;
}
MYFILE* Dropbox::openDownload(const char* s) {
   debug("Dropbox:openDownload: %s\n", s);
   PathInfo p;
   p.parse(s);
   
   MYFILE* ret = NULL;
   
   if ((p.topdirnum > 0) && !p.isAccess && *p.pack) {
      MYDIRENTRY *dp =  myqueryfile(&p);
      
      if (dp) {
         long long packid = dp->_getPId();
         
         jobject jobj = mystartdownloadfile(packid, dp->getId());
         if (jobj) {
            ret = new MYFILE(dp->getOwner(), dp->getDirectory(), 
                             p.file, jobj, MYFILE_DOWNLOAD);
            ret->setSize(dp->getStats().st_size);
         }
         delete dp;
      }
   }
   
   return ret;
}
MYDIR* Dropbox::openDir(const char* s) {
   debug("Dropbox:openDir: %s\n", s);
   
   MYDIR* ret = NULL;
   
   PathInfo p;
   p.parse(s);
   
  // If it is one of our known address ...
   if (!*p.topdir) {
      struct stat stats;
      memset(&stats, 0, sizeof(stats));
      stats.st_size  = 555;
      stats.st_mode = 0755 | _S_IFDIR;
      stats.st_uid = 1;
      stats.st_gid = 1;
      
      struct timeb t;
      ftime(&t);
      
      stats.st_atime = t.time;
      stats.st_mtime = t.time;
      stats.st_ctime = t.time;
      
      ret = new MYDIR(userName(), "/");
      ret->setCompany("unknown");
      ret->addEntry(new MYDIRENTRY(ret->getOwner(), "/", INBOX,   stats));
      ret->addEntry(new MYDIRENTRY(ret->getOwner(), "/", OUTBOX,  stats));
      ret->addEntry(new MYDIRENTRY(ret->getOwner(), "/", SANDBOX, stats));
   } else if (!p.topdirnum) {
      ret = NULL;
   } else if (!*p.pack) {
      ret = myquerypackages(userName(), &p);
   } else if (p.isAccess) {
     // If the Access directory AND not an Access dir entry
      if (!*p.access) {
         MYDIRENTRY *dp =  myquerypackage(&p);
         
         if (dp) {
            ret = myqueryacls(&p, dp);
            delete dp;
         }
      }
   } else {
   
     /*
     ** Package contents may contain a mix of real things (files and ACCESS 
     **  dir) and ficticious things (mkdir's inside a package to create
     **  hierarchy which last only for that sftp session unless a file is
     **  created at that level)
     */
      ret = myquerypackagecontents(&p, 1);
      
     /*
     ** We need to return the right 'stuff' for the request level or hierarchy
     **
     ** For a package level query, return all items with NO hierarchy, and the
     **  first segment (uniqized). For all others, return the correct segment
     **  which matches to that level.
     **
     ** If there are collisions where there are DIR parts and FILE parts with 
     **  the same name at the same level, return the FILE part. This is NOT 
     **  great ... TODO, just make the DIR part uniq, and then manage that 
     **  everywhere that is needed.
     **
     ** myquerypackagecontents passing 1 takes care of this stuff
     */
   }
   return ret;
}

int Dropbox::connect() {
   debug("Dropbox:connect\n");
   
#ifdef DOTESTING
   if (!myconnect(testhost, testport) && !mylogin(testlogin_token)) {
      return 0;
   }
#else
   if (!myconnect(dropboxHost, dropboxPort) && !mylogin(dropboxToken)) {
      return 0;
   }
#endif
   return -1;
}

int     Dropbox::doStat(char* s, Attrib* a) {
   debug("Dropbox:doStat: %s\n", s);
   
  // If it is one of our known addresses ...
  
   PathInfo p;
   p.parse(s);
   
  // If this is NOT a good topdir, just return error
   if (*p.topdir && !p.topdirnum) {
      return -1;
   }
   
  // If no package
   if (!*p.pack) {
      
      attrib_clear(a);
      a->flags = 0;
      a->flags |= SSH2_FILEXFER_ATTR_SIZE;
      a->size = 555;
      a->flags |= SSH2_FILEXFER_ATTR_UIDGID;
      a->uid = 1;
      a->gid = 1;
      a->flags |= SSH2_FILEXFER_ATTR_PERMISSIONS;
      
      a->perm = _S_IFDIR | 0755;
      a->flags |= SSH2_FILEXFER_ATTR_ACMODTIME;
      
      struct timeb t;
      ftime(&t);
      
      a->atime = t.time;
      a->mtime = t.time;
      return 0;
   } else if (!*p.file) {
      
      MYDIRENTRY* mydirent = myquerypackage(&p);
      if (mydirent) {
         struct stat stats = mydirent->getStats();
            
         attrib_clear(a);
         a->flags = 0;
         a->flags |= SSH2_FILEXFER_ATTR_SIZE;
         a->size = stats.st_size;
         a->flags |= SSH2_FILEXFER_ATTR_UIDGID;
         a->uid = 1;
         a->gid = 1;
         a->flags |= SSH2_FILEXFER_ATTR_PERMISSIONS;
         a->perm = _S_IFDIR | 0755;
         a->flags |= SSH2_FILEXFER_ATTR_ACMODTIME;
         a->atime = stats.st_atime;
         a->mtime = stats.st_mtime;
         delete mydirent;
         return 0;
      }
   } else if (p.isAccess) {
      MYDIRENTRY * mydirent = myquerypackage(&p);
      if (mydirent) {
         if (!*p.access) {
           // If the Access directory
            attrib_clear(a);
            a->flags = 0;
            a->flags |= SSH2_FILEXFER_ATTR_SIZE;
            a->size = 555;
            a->flags |= SSH2_FILEXFER_ATTR_UIDGID;
            a->uid = 1;
            a->gid = 1;
            a->flags |= SSH2_FILEXFER_ATTR_PERMISSIONS;
            a->perm = _S_IFDIR | 0755;
            a->flags |= SSH2_FILEXFER_ATTR_ACMODTIME;
            
            struct stat stats = mydirent->getStats();
            
            a->atime = stats.st_atime;
            a->mtime = stats.st_mtime;
            delete mydirent;
            return 0;
         } else {
            MYDIR* mydir = myqueryacls(&p, mydirent);
            delete mydirent;
            if (mydir) {
               
               while((mydirent = mydir->readDir())) {
                  if (!strcmp(mydirent->getName(), p.access)) {
                     struct stat stats = mydirent->getStats();
                     
                     attrib_clear(a);
                     a->flags = 0;
                     a->flags |= SSH2_FILEXFER_ATTR_SIZE;
                     a->size = stats.st_size;
                     a->size = stats.st_size;
                     a->flags |= SSH2_FILEXFER_ATTR_UIDGID;
                     a->uid = 1;
                     a->gid = 1;
                     a->flags |= SSH2_FILEXFER_ATTR_PERMISSIONS;
                     a->perm = _S_IFDIR | 0755;
                     a->flags |= SSH2_FILEXFER_ATTR_ACMODTIME;
                     a->atime = stats.st_atime;
                     a->mtime = stats.st_mtime;
                     delete mydirent;
                     delete mydir;
                     return 0;
                  }
                  delete mydirent;
               }
               delete mydir;
            }
         }
      }
   } else {
   
      char news[1024];
      strcpy(news, s);
      
      char* fname = strrchr(news, '/');
      *fname++ = '\0';
      
      PathInfo ap;
      ap.parse(news);
      
      MYDIR * mydir = myquerypackagecontents(&ap, 1);
      if (mydir) {
         MYDIRENTRY *mydirent;
         while((mydirent = mydir->readDir())) {
            
            if (!strcmp(mydirent->getName(), fname)) {
               struct stat stats = mydirent->getStats();
               
               attrib_clear(a);
               a->flags = 0;
               a->flags |= SSH2_FILEXFER_ATTR_SIZE;
               a->size = stats.st_size;
               a->size = stats.st_size;
               a->flags |= SSH2_FILEXFER_ATTR_UIDGID;
               a->uid = 1;
               a->gid = 1;
               a->flags |= SSH2_FILEXFER_ATTR_PERMISSIONS;
               if (S_ISDIR(stats.st_mode)) {
                  a->perm = _S_IFDIR | 0755;
               } else {
                  a->perm = _S_IFREG | 0644;
               }
               a->flags |= SSH2_FILEXFER_ATTR_ACMODTIME;
               a->atime = stats.st_atime;
               a->mtime = stats.st_mtime;
               delete mydirent;
               delete mydir;
               return 0;
            }
            delete mydirent;
         }
         delete mydir;
      }
   }
   
   return -1;
}

int     Dropbox::unlink(char* s) {
   debug("Dropbox:unlink: %s\n", s);
   
   PathInfo p;
   p.parse(s);
   
  // If its a fixed thing that can't possible be deleted as a file
   if (p.topdirnum && *p.file && !p.isAccess) {
   
      MYDIR * mydir = myquerypackagecontents(&p, 0);
      if (mydir) {
         MYDIRENTRY *mydirent;
         
         while((mydirent = mydir->readDir())) {
            if (!strcmp(mydirent->getName(), p.file) && 
                (mydirent->getStats().st_mode & _S_IFREG)) {

               int ret = mydeletefilefrompackage(mydir->getId(), 
                                                 mydirent->getId());
               delete mydirent;
               delete mydir;
               return ret;
            }
            delete mydirent;
         }
         delete mydir;
      }
   }

   return -1;
}

int     Dropbox::mkdir(char* s) {
   debug("Dropbox:mkdir: %s\n", s);
   
   PathInfo p;
   p.parse(s);
   
   int ret = -1;
   
   if (p.isAccess && *p.access) {
      MYDIRENTRY *dp = myquerypackage(&p);
      if (dp) {
         long long packid = dp->getId();
         delete dp;
         ret = myaddacl(packid, p.access);
      }
   } else if (p.topdirnum == 3 && *p.pack && !*p.file) {
      ret = mycreatepackage(p.pack);
   } else if (p.topdirnum == 3 && *p.pack && !strcmp(p.file, DONEVALUE)) {
      MYDIRENTRY *dp = myquerypackage(&p);
      if (dp) {
         long long packid = dp->getId();
         delete dp;
         ret = mycommitpackage(packid);
      }
   } else if (p.topdirnum == 3 && *p.pack && *p.file) {
     // If someone is making some hierarchy
      
     // Make sure it doesn't already exist
     
     // remove final segment (query parent dir), make new PathInfo
      char news[1024];
      strcpy(news, s);
      char* fname = strrchr(news, '/');
      *fname++ = '\0';
      
      PathInfo ap;
      ap.parse(news);
      
      MYDIR * mydir = myquerypackagecontents(&ap, 1);
      if (mydir) {
      
         MYDIRENTRY *mydirent=NULL;
         while((mydirent = mydir->readDir())) {
            
            if (!strcmp(mydirent->getName(), fname)) {
               delete mydirent;
               break;
            }
            delete mydirent;
         }
         if (!mydirent) {
            MadeDirectories *madedirs = addDirectories(mydir->getId());
            if (madedirs) {
               struct stat stats;
               struct timeb t;
               
               ftime(&t);
               stats.st_atime  = t.time;
               stats.st_mtime  = t.time;
               stats.st_size   = 555;
               stats.st_uid    = 1;
               stats.st_gid    = 1;
               stats.st_mode   = 0700 | _S_IFDIR;
               
               mydirent = new MYDIRENTRY(mydir->getOwner(), 
                                         news, fname, stats);
               mydirent->setId(mydir->getId());
               mydirent->setCompany(mydir->getCompany());
               madedirs->addEntry(mydirent);
               ret = 0;
            }
         }
         delete mydir;
      }
   }
   return ret;
}
int     Dropbox::rmdir(char* s) {
   debug("Dropbox:rmdir: %s\n", s);
   
   PathInfo p;
   p.parse(s);
   
   int ret = -1;
   
   if (p.isAccess && *p.access) {
      MYDIRENTRY * dp = myquerypackage(&p);
      if (dp) {
         long long packid = dp->getId();
         delete dp;
         ret = myremoveacl(packid, p.access);
      }
   } else if (p.topdirnum > 1 && *p.pack && !*p.file) {
     // Can only delete from Outbox and Sandbox
      MYDIRENTRY* dp = myquerypackage(&p);
      if (dp) {
         long long packid = dp->getId();
         delete dp;
         ret = mydeletepackage(packid);
      }
   } else if (p.topdirnum == 3 && *p.pack && *p.file) {
     // If someone is making some hierarchy
      
     // Make sure it doesn't already exist
     
     // remove final segment (query parent dir), make new PathInfo
      char news[1024];
      strcpy(news, s);
      char* fname = strrchr(news, '/');
      *fname++ = '\0';
      
     // Query actual directory for children
      MYDIR * mydir = myquerypackagecontents(&p, 1);
      
     // If we have a directory
      if (mydir) {
      
        // If that dir is empty (then we know we know its in MadeDirectories
         MYDIRENTRY *mydirent=NULL;
         if (!(mydirent = mydir->readDir())) {
         
            LinkList *ll = &(getDirectories(mydir->getId())->ll);
            Link *link   = ll->get_head();
            while(link) {
               mydirent = (MYDIRENTRY*)link->data;
               if (!strcmp(mydirent->getName(), fname) && 
                   !strcmp(mydirent->getDirectory(), news)) {
                  ll->unchain(link);
                  debug("About to rmdir DIRENTRY");
                  delete mydirent;
                  delete link;
                  ret = 0;
                  break;
               }
               link = link->right;
            }
         } else {
            delete mydirent;
         }
         delete mydir;
      }
   }
   return ret;
}

int     Dropbox::objectExists(char* s) {
   debug("Dropbox:objectExists: %s\n", s);
   
   Attrib a;
   return !doStat(s, &a);
}

/*-------------------------------------------------------------------------*\
**             MYFILE
\*-------------------------------------------------------------------------*/
int     MYFILE::close() {
   debug("MYFILE:close: %s", name);
   
   int ret = -1;
   
   if (jobj) {
      ret = myfsclose((jobject)jobj);
      jobj = NULL;
   }
   
   return ret;
}
int     MYFILE::readData(long long off, char* buf, int len) {
   debug("MYFILE:readData: %s ofs=%lld off=%lld len=%d", name, ofs, off, len);
   int ret = -1;
   if (type == MYFILE_DOWNLOAD && jobj) {
      if (off == ofs) {
         while(len > 0) {
            int num = myfsread((jobject)jobj, buf+ret, 0, len);
        
            
            if (num == 0) {
               if (ret == -1) ret = 0;
               break;
            }
            if (num <= 0) break;
            if (ret == -1) ret = 0;
            
            ofs += num;
            ret += num;
            len -= num;
         }
      } else if (off > size) {
        // If we have reached EOF, don't complain in a bad way
         return 0;
      }
   }
   debug("MYFILE:readData: ret=%d ofs=%lld", ret, ofs);
   return ret;
}
int     MYFILE::writeData(long long off, char* buf, int len) {
   debug("MYFILE:writeData: %s off=%lld len=%d", name, off, len);
   int ret = -1;
   if (type == MYFILE_UPLOAD && off == ofs && jobj) {
      ret = myfswrite((jobject)jobj, buf, 0, len);
      if (ret > 0) {
         ofs += ret;
         size += ret;
      }
   }
   debug("MYFILE:writeData: return");
   return ret;
}
int     MYFILE::doStat(Attrib* a) {
   debug("MYFILE:doStat: %s\n", name);
   attrib_clear(a);
   a->flags = 0;
   a->flags |= SSH2_FILEXFER_ATTR_SIZE;
   a->size = size;
   a->flags |= SSH2_FILEXFER_ATTR_UIDGID;
   a->uid = 1;
   a->gid = 1;
   a->flags |= SSH2_FILEXFER_ATTR_PERMISSIONS;
   
   a->perm = _S_IFREG | 0644;
   a->flags |= SSH2_FILEXFER_ATTR_ACMODTIME;
   
   struct timeb t;
   ftime(&t);
   
   a->atime = t.time;
   a->mtime = t.time;
   return 0;
}

/*-------------------------------------------------------------------------*\
**             MYDIR
\*-------------------------------------------------------------------------*/

MYDIR::~MYDIR() {
   debug("In DIR destructor this=%X", this);
   Link *link;
   while((link=entries->get_head())) {
      entries->unchain(link);
   debug("About to delete DIRENTRY");
      delete (MYDIRENTRY*)link->data;
      delete link;
   }
   delete entries;
   debug("Done DIR destructor this=%X", this);
}

// Entry is owned by MYDIR now
MYDIRENTRY* MYDIR::addEntry(MYDIRENTRY* entry, int uniq) {
   debug("MYDIR:addEntry: %X\n", entry);
   
   Link *link = new Link(entry);
   
  // Make the names uniq ... If have same name, then name it with packid/fileid
  //  This could STILL be non-uniq, but much more remote ... and I'm tired
   Link *tl = entries->get_head();
   while(tl) {
      MYDIRENTRY *tle = (MYDIRENTRY*)tl->data;
      if (!strcmp(tle->getName(), entry->getName())) {
         if (uniq) {
            delete link;
            link = NULL;
            entry = NULL;
            break;
         } else {
            char newname[1024];
            sprintf(newname, "%s_id_%lld", entry->getName(), entry->getId());
            entry->setName(newname);
            break;
         }
      }
      tl = tl->right;
   }
   if (link) entries->chainLast(link);
   return entry;
}

// Entry is given to caller
MYDIRENTRY* MYDIR::readDir() {
   debug("MYDIR:readDir: %s\n", path);
   
   MYDIRENTRY* ret = NULL;
   
   Link* link = entries->get_head();
   if (link) {
      entries->unchain(link);
      ret = (MYDIRENTRY*)link->data;
      delete link;
   }
   return ret;
}

/*-------------------------------------------------------------------------*\
**             MYDIRENTRY
\*-------------------------------------------------------------------------*/
MYDIRENTRY::~MYDIRENTRY() {
   debug("In MYDIRENTRY destructor this=%X", this);
   if (name)    xfree(name);
}
char*       MYDIRENTRY::ls_file() {
   debug("MYDIRENTRY:ls_file: %s\n", name);
   return local_ls_file(this);
}

/*-------------------------------------------------------------------------*\
**             MYDIRBASE
\*-------------------------------------------------------------------------*/
MYDIRBASE::~MYDIRBASE() {
   debug("In MYDIRBASE destructor this=%X", this);
   debug("In MYDIRBASE owner=%X %s", owner, owner);
   if (owner)   xfree(owner);
   debug("In MYDIRBASE path=%X %s", path, path);
   if (path)    xfree(path);
   debug("In MYDIRBASE company=%X %s", company, company);
   if (company) xfree(company);
   debug("Done MYDIRBASE destructor this=%X", this);
}
