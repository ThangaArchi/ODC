extern "C" {
#include "includes.h"

#include "buffer.h"
#include "bufaux.h"
#include "getput.h"
#include "log.h"
#include "xmalloc.h"

#include "sftp.h"
#include "sftp-common.h"

#include <sys/timeb.h>
}



#include "LinkList.h"

#include "joe.h"

#include <jni.h>

#include "sftpDropbox.h"

extern JNIEnv* javaenv;
extern JavaVM* jvm;
extern jclass  jdropboxClass;
extern jobject jdropbox;
extern jmethodID threadMaker_methid;
extern int javamethinit();
extern "C" void java_initialize();
extern void sftpDropboxServerContinue();

/*
 * Class:     sftpDropbox
 * Method:    giveMeAJavaThread
 * Signature: (LsftpDropbox;)V
 */
extern "C" 
JNIEXPORT void JNICALL Java_sftpDropbox_giveMeAJavaThread(JNIEnv *env, 
                                                          jclass clazz, 
                                                          jobject sftpdrop) {
   log("In give me a thread!!!");
   
   javaenv = env;
   jdropbox = sftpdrop;
   
   if (javamethinit() != 0) {
      error("ZOINKS! Error initting javamethids ... exit");
      exit(33);
   }
   
   sftpDropboxServerContinue();
}

extern int java_sftp_init2();
void java_sftpstart() {
   java_initialize();
   
   if (java_sftp_init2()) return;
   
   JNINativeMethod * nativemeth = new JNINativeMethod();
   nativemeth->name = "giveMeAJavaThread";
   nativemeth->signature = "(Loem/edge/ed/odc/dropbox/client/sftpDropbox;)V";
   nativemeth->fnPtr = (void*)Java_sftpDropbox_giveMeAJavaThread;
   
   javaenv->RegisterNatives(jdropboxClass, nativemeth, 1);
   
   javaenv->CallVoidMethod(jdropbox, threadMaker_methid, 0);   
}

