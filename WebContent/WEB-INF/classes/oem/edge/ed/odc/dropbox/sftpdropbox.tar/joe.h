#ifndef JOE_SFTP_H
#define JOE_SFTP_H

struct Attrib;

/*
typedef enum {
   MYDIR_UNKNOWN,
   MYDIR_INBOX,
   MYDIR_OUTBOX,
   MYDIR_SANDBOX,
   MYDIR_PACKAGE,
} MYDIR_TYPES;

*/


// All int returns are -1 for failure, >= 0 for success

class MYDIRBASE {

  protected:
   char* path;
   char* owner;
   char* company;
   long long id;
   
  public:   

   MYDIRBASE(const char* o, const char* p) {
      owner   = xstrdup(o);
      path    = xstrdup(p);
      company = xstrdup("");
      id      = 0;
   }
   
   virtual ~MYDIRBASE();
   
   const char* getOwner()     { return owner;   }
   const char* getDirectory() { return path;    }
   const char* getCompany()   { return company; }
   
   void setCompany(const char *n){ 
      if (company) xfree(company); 
      company = xstrdup(n); 
   }
   
   long long getId()   { return id; }
   void setId(long long tid) { id=tid; }
};


class MYDIRENTRY : public MYDIRBASE {

  protected:
   char* name;
   long long pid;
   
   struct stat stats;
      
  public:
  
   MYDIRENTRY(const char* o, const char* p, 
              const char* n, struct stat s) : MYDIRBASE(o, p) {
      name    = xstrdup(n);
      stats   = s;
      pid     = 0;
   }
   
   virtual ~MYDIRENTRY();
  
   const char* getName()      { return name;    }
   void setName(const char *n)   { 
      if (name) xfree(name);
      name = xstrdup(n); 
   }
   
   struct stat getStats()     { 
      return stats; 
   }
      
  // Not always set ... 
   long long _getPId()   { return pid; }
   void _setPId(long long tid) { pid=tid; }
   
   char* ls_file();
};

class MYDIR : public MYDIRBASE {

  protected:
   LinkList *entries;
   
  public:
  
   MYDIR(const char* o, const char *p) : MYDIRBASE(o, p) {
      entries = new LinkList();
   }
   
   virtual ~MYDIR();
  
   int close() { return 0; }
   MYDIRENTRY* readDir();
   
   void addEntry(MYDIRENTRY* d) {
      addEntry(d, 0);
   }
   
   MYDIRENTRY* addEntry(MYDIRENTRY*, int uniqit);
   
   LinkList* getEntries() { return entries; }
};


#define MYFILE_UPLOAD   1
#define MYFILE_DOWNLOAD 2
class MYFILE {

   char* owner;
   char* name;
   char* path;
   int   type;
   
   void* jobj;
   long long ofs;
   long long size;
   
  public:
  
   MYFILE(const char* o, const char* p, const char* n, void* obj, int t) {
      owner = xstrdup(o);
      path  = xstrdup(p);
      name  = xstrdup(n);
      type  = t;
      jobj = obj;
      ofs  = 0;
      size = 0;
   }
   
   ~MYFILE() {
      if (owner) xfree(owner);
      if (path)  xfree(path);
      if (name)  xfree(name);
   }
   
   void setSize(long long sz) { size = sz;    }
   void setOfs (long long of) { ofs = of;     }
   
   const char* getOwner()     { return owner; }
   const char* getDirectory() { return path;  }
   const char* getName()      { return name;  }
   
   int close();
   int readData(long long off, char* buf, int len);
   int writeData(long long off, char* buf, int len);
   int doStat(Attrib*);
};

struct MadeDirectories {
   MadeDirectories(long long inID) {
      id = inID;
   }
   ~MadeDirectories() {
      Link *link;
      while((link=ll.get_head())) {
         ll.unchain(link);
         delete (MYDIRENTRY*)link->data;
         delete link;
      }
   }
   long long id;
   LinkList ll;
   void addEntry(MYDIRENTRY* d) {
      Link *link = new Link(d);
      ll.chainLast(link);
   }
};

#define MADEDIRSZ 128
class Dropbox {
   
   
   int dirsUsed;
   MadeDirectories *madeDirs[MADEDIRSZ];
   
  public:
  
   static Dropbox* dropbox;
  
   Dropbox() { dirsUsed = 0; dropbox = this; }
   ~Dropbox() {
      for(int i=0; i < dirsUsed; i++) {
         if (madeDirs[i]) delete madeDirs[i];
      }
   }
   
   MadeDirectories* getDirectories(long long inID) {
      for(int i=0; i < dirsUsed; i++) {
         if (madeDirs[i] && madeDirs[i]->id == inID) {
            return madeDirs[i];
         }
      }
      return NULL;
   }
   
   MadeDirectories* addDirectories(long long id) {
      MadeDirectories* ret = getDirectories(id);
      if (ret == NULL && dirsUsed < MADEDIRSZ) {
         ret =  madeDirs[dirsUsed++]=new MadeDirectories(id);
      }
      return ret;
   }
  
   MYFILE* openUpload(const char*);
   MYFILE* openDownload(const char*);
   MYDIR*  openDir(const char*);
   int     connect();
   int     doStat(char*, Attrib*);
   int     unlink(char*);
   int     mkdir(char*);
   int     rmdir(char*);
   
  // This returns 0 if false, 1 if true
   int     objectExists(char*);
   
   
};

char* cvt_realpath(const char*);

#endif
