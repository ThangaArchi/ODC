#ifndef JOE_SFTP_H
#define JOE_SFTP_H

struct Attrib;

/*
typedef enum {
   MYDIR_UNKNOWN,
   MYDIR_INBOX,
   MYDIR_OUTBOX,
   MYDIR_SANDBOX,
   MYDIR_PACKAGE,
} MYDIR_TYPES;

*/

#define GROUP_SCOPE_NONE    0
#define GROUP_SCOPE_OWNER   1
#define GROUP_SCOPE_MEMBER  5
#define GROUP_SCOPE_ALL     10

// All int returns are -1 for failure, >= 0 for success
#define RETURNRECEIPT_FLAG    0x80
#define SENDNOTIFICATION_FLAG 0x40
#define HIDDEN_FLAG           0x20
#define ITAR_FLAG             0x10

class StoragePool {
protected:
   long long poolid;
   int maxdays;
   int defdays;
   char* name;
   
public:

   StoragePool(long long p, const char* n, int md, int dd) {
      poolid  = p;
      name    = xstrdup(n);
      maxdays = md;
      defdays = dd;
   }
   
   ~StoragePool() {
      if (name) xfree(name);
   }
   
   long long   getPoolId()          { return poolid;  }
   const char* getPoolName()        { return name;    }
   int         getPoolMaxDays()     { return maxdays; }
   int         getPoolDefaultDays() { return defdays; }
};

class MYDIRBASE {

  protected:
   char* path;
   char* owner;
   char* company;
   char* desc;
   long long id;
   int  flags;
   long long poolid;
   
  public:   

   MYDIRBASE(const char* o, const char* p) {
      owner   = xstrdup(o);
      path    = xstrdup(p);
      company = xstrdup("");
      desc    = 0;
      id      = 0;
      flags = 0;
   }
   
   virtual ~MYDIRBASE();
   
   const char* getOwner()       { return owner;   }
   const char* getDirectory()   { return path;    }
   const char* getCompany()     { return company; }
   const char* getDescription() { return desc;    }
   
   void setPackageFlags(int v)  { flags = v;      }
   int  getPackageFlags()       { return flags;   }
   
   void setPackagePoolId(long long p) { poolid = p;    }
   long long getPackagePoolId()       { return poolid; }
   
   void setDescription(const char* d)  { 
      if (desc) xfree(desc);
      desc = xstrdup(d);
   }
   
   int isReturnReceipt()   { return (flags & RETURNRECEIPT_FLAG)    != 0; }
   int isSendNotify()      { return (flags & SENDNOTIFICATION_FLAG) != 0; }
   
   void setCompany(const char *n){ 
      if (company) xfree(company); 
      company = xstrdup(n); 
   }
   
   long long getId()   { return id; }
   void setId(long long tid) { id=tid; }
};


class MYDIRENTRY : public MYDIRBASE {

  protected:
   char* name;
   char* md5;
   long long pid;
   
   struct stat stats;
      
  public:
  
   MYDIRENTRY(const char* o, const char* p, 
              const char* n, struct stat s) : MYDIRBASE(o, p) {
      name    = xstrdup(n);
      md5     = 0;
      stats   = s;
      pid     = 0;
   }
   
   virtual ~MYDIRENTRY();
  
   const char* getName()      { return name;    }
   void setName(const char *n)   { 
      if (name) xfree(name);
      name = xstrdup(n); 
   }
   
   struct stat getStats()     { 
      return stats; 
   }
      
  // Not always set ... 
   long long _getPId()   { return pid; }
   void _setPId(long long tid) { pid=tid; }
   const char* _getMD5()      { return md5; }
   void _setMD5(const char* v) {
      if (md5) xfree(md5);
      md5 = xstrdup(v); 
   }
   
   char* ls_file();
};

class MYDIR : public MYDIRBASE {

  protected:
   LinkList *entries;
   
  public:
  
   MYDIR(const char* o, const char *p) : MYDIRBASE(o, p) {
      entries = new LinkList();
   }
   
   virtual ~MYDIR();
  
   int close() { return 0; }
   MYDIRENTRY* readDir();
   
   void addEntry(MYDIRENTRY* d) {
      addEntry(d, 0);
   }
   
   MYDIRENTRY* addEntry(MYDIRENTRY*, int uniqit);
   
   LinkList* getEntries() { return entries; }
};


#define MYFILE_UPLOAD      1
#define MYFILE_DOWNLOAD    2
#define MYFILE_DESC_UPLOAD 3
class MYFILE {

   char* owner;
   char* name;
   char* path;
   int   type;
   
   void* jobj;
   long long ofs;
   long long size;
   long long maxsize;
   long long pkgid;
   
   unsigned char* forceDownload;
   
  public:
  
   MYFILE(const char* o, const char* p, const char* n, void* obj, int t) {
      owner = xstrdup(o);
      path  = xstrdup(p);
      name  = xstrdup(n);
      type  = t;
      jobj = obj;
      ofs  = 0;
      size = 0;
      maxsize = 0x7fffffffffffffff;
      forceDownload=0;
      pkgid = 0;
   }
   
   ~MYFILE();
      
  // Used for Desc Upload
   void setMaxSize(long long sz)  { maxsize = sz; }
   long long getPackageId()       { return pkgid; }
   void setPackageId(long long l) { pkgid = l;    }
   
   
   void setSize(long long sz) { size = sz;    }
   void setOfs (long long of) { ofs = of;     }
   
   const char* getOwner()     { return owner; }
   const char* getDirectory() { return path;  }
   const char* getName()      { return name;  }
   
   void setForceDownload(void* v, int sz) { 
      if (sz > maxsize) sz = maxsize;
      if (forceDownload) xfree(forceDownload);
      forceDownload = new unsigned char[sz+1];
      memcpy(forceDownload, (unsigned char*)v, sz);
      forceDownload[sz] = 0;
      ofs  = 0;
      size = sz;
   }
   
   void appendForceDownload(void* v, int sz) { 
      if (forceDownload && size) {
         if (size >= maxsize) return;
         if (size + sz > maxsize) sz = maxsize - size;
         unsigned char* b = new unsigned char[sz+size+1];
         memcpy(b, forceDownload, size);
         memcpy(b+size, v, sz);
         size += sz;
         delete forceDownload;
         forceDownload = b;
         forceDownload[size] = 0;
      } else {
         setForceDownload(v, sz);
      }
   }
   
   int close();
   int readData(long long off, char* buf, int len);
   int writeData(long long off, char* buf, int len);
   int doStat(Attrib*);
};

struct MadeDirectories {
   MadeDirectories(long long inID) {
      id = inID;
   }
   ~MadeDirectories() {
      Link *link;
      while((link=ll.get_head())) {
         ll.unchain(link);
         delete (MYDIRENTRY*)link->data;
         delete link;
      }
   }
   long long id;
   LinkList ll;
   void addEntry(MYDIRENTRY* d) {
      Link *link = new Link(d);
      ll.chainLast(link);
   }
};

#define MADEDIRSZ 128
class Dropbox {
   
   
   int dirsUsed;
   MadeDirectories *madeDirs[MADEDIRSZ];
   
  public:
  
   static Dropbox* dropbox;
  
   Dropbox() { dirsUsed = 0; dropbox = this; }
   ~Dropbox() {
      for(int i=0; i < dirsUsed; i++) {
         if (madeDirs[i]) delete madeDirs[i];
      }
   }
   
   MadeDirectories* getDirectories(long long inID) {
      for(int i=0; i < dirsUsed; i++) {
         if (madeDirs[i] && madeDirs[i]->id == inID) {
            return madeDirs[i];
         }
      }
      return NULL;
   }
   
   MadeDirectories* addDirectories(long long id) {
      MadeDirectories* ret = getDirectories(id);
      if (ret == NULL && dirsUsed < MADEDIRSZ) {
         ret =  madeDirs[dirsUsed++]=new MadeDirectories(id);
      }
      return ret;
   }
  
   MYFILE* openUpload(const char*);
   MYFILE* openDownload(const char*);
   MYDIR*  openDir(const char*);
   int     connect();
   int     doStat(char*, Attrib*);
   int     unlink(char*);
   int     mkdir(char*);
   int     rmdir(char*);
   
  // This returns 0 if false, 1 if true
   int     objectExists(char*);
   
   
};

char* cvt_realpath(const char*);

#endif
