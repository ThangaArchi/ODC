#ifndef _LINK_H
#define _LINK_H


class Link {

public:
   void *data;
   Link *left, *right;

     Link(void* data);
     Link();
};

#endif
