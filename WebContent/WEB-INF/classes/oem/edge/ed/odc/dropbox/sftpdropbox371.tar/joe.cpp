/*
** HEY!! Look Here!! At Me!
**
** The 441 and 451 code is the same for now. I am releasing the expiration
**  code in 441 ... the 451 code has a dep on some PackageInfo changes that
**  are NOT in 441 ... and so, I have a little workaround below. When releasing
**  as 451 code, do NOT define is441!!!
*/
//#define is441
#define R711

extern "C" {
#include "includes.h"

#include "buffer.h"
#include "bufaux.h"
#include "getput.h"
#include "log.h"
#include "xmalloc.h"

#include "sftp.h"
#include "sftp-common.h"

#include <sys/timeb.h>
}

#include "LinkList.h"

#include "joe.h"

#include <jni.h>

#include "sftpDropbox.h"

// JMC
void logbytes(char* ptr, int len) {
   logit("Message[%d]:", len);
   char outline[80]; 
   sprintf(outline, "0000: %70s", "");
   int j=0;
   for (int i=0; i < len; i++) {
      sprintf(outline+6+(j*3), "%2.2x", ptr[i]);
      outline[8+(j*3)] = ' ';
      char toprint = ptr[i];
      if (toprint < ' ' || toprint > 127) {
         toprint='.';
      }
      outline[6+48+2+j] = toprint;
      j++;
      if (!(j % 16)) {
         logit(outline);
         sprintf(outline, "%4.4X: %70s", i, "");
         j=0;
      }
   }
   if ((j % 16)) {
      logit(outline);
   }
}


static unsigned long mylastms = 0;
void logtime(char id, unsigned long &lastms) {
   unsigned long thisms;
   
   struct timeval tv;
   gettimeofday(&tv, 0);
   
  /* JMC 1/6/99 - Save latest time */
   thisms = tv.tv_sec * 1000 + tv.tv_usec / 1000; 
   fprintf(stderr, "%c ms[%8.8lu] delta[%5.5lu]: ", id, thisms, 
                  (thisms-lastms));
   lastms=thisms;
}

#define TRACE				debug
#define debug logit

int doprotodebug = 0;

Dropbox *Dropbox::dropbox = NULL;

#define attrib_clear(a) memset((a), 0, sizeof(*a))

#define TRASH_N            1
#define INBOX_N            2
#define SENT_N             3
#define DRAFTS_N           4
#define GROUPS_N           5
#define OPTIONS_N          6
#define PROJECTS_N         7

#define OUTBOX_N           SENT_N

#define TRASH              "trash"
#define INBOX              "inbox"
#define OUTBOX             "sent"
#define DRAFTS             "drafts"
#define GROUPS             "groups"
#define EXPIRATION         "expiration"
#define CROSSCOMPANY       "aclcompanies"
#define OPTIONS            "options"
#define PROJECTS           "projects"

#define astar_suff         ".tar"
#define astgz_suff         ".tgz"
#define astargz_suff       ".tar.gz"
#define aszip_suff         ".zip"

#define astar_sufflen      4
#define astgz_sufflen      4
#define astargz_sufflen    7
#define aszip_sufflen      4

#define astar_encoding     "tar"
#define astgz_encoding     "tgz"
#define astargz_encoding   "tgz"
#define aszip_encoding     "zip"

#define ALL                "all"
#define MODIFIABLE         "modifiable"
#define OWNED              "owned"
#define ACCESSDIR          "#ACCESS#"
#define DONEVALUE          "#DONE#"
#define INFODIR            "#INFO#"
#define ITAR_SC            "#ITARCERTIFY#"
#define NOITAR_SC          "#NOITARCERTIFY#"
#define ITARCREATE_SC      "#ITARCREATE#"
#define NOITARCREATE_SC    "#NOITARCREATE#"
#define NOTIFY_SC          "#NOTIFY#"
#define NONOTIFY_SC        "#NONOTIFY#"
#define NOTIFICATION_SC    "#NOTIFICATION#"
#define NONOTIFICATION_SC  "#NONOTIFICATION#"
#define RECEIPT_SC         "#RECEIPT#"
#define NORECEIPT_SC       "#NORECEIPT#"
#define RETURNRECEIPT_SC   "#RETURNRECEIPT#"
#define NORETURNRECEIPT_SC "#NORETURNRECEIPT#"
#define SHOWHIDDEN_SC      "#SHOWHIDDEN#"
#define SHOWALL_SC         "#SHOWALL#"
#define SHOW_SC            "#SHOW#"
#define HIDEHIDDEN_SC      "#HIDEHIDDEN#"
#define NOHIDE_SC          "#NOHIDE#"
#define HIDE_SC            "#HIDE#"
#define NOTHIDDEN_SC       "#NOTHIDDEN#"
#define HIDDEN_SC          "#HIDDEN#"

#define FULLTRASH      "/trash"
#define FULLINBOX      "/inbox"
#define FULLOUTBOX     "/sent"
#define FULLDRAFTS     "/drafts"
#define FULLGROUPS     "/groups"
#define FULLOPTIONS    "/options"
#define FULLPROJECTS   "/projects"
#define MEMBERS      "members"
#define PROPERTIES   "properties"
#define GACCESS      "access"
#define LISTABILITY  "listability"
#define VISIBILITY   "visibility"
#define OWNER        "owner"
#define COMPANY      "company"
#define MEMBER       "members"
#define USERID       "userid"
#define ATTRIBUTES   "attributes"
#define DESCRIPTION  "description"
#define FILESMD5     "files.md5"

#define POPT_ITAR          "ITAR"
#define POPT_STORAGEPOOL   "StoragePool"
#define POPT_HIDDEN        "Hidden"
#define POPT_SENDNOTIFY    "SendNotification"
#define POPT_RETURNRECEIPT "ReturnReceipt"

#define OPT_ITARCERTIFIED           "ItarCertified"
#define OPT_ITARPACKAGECREATE       "ItarPackageCreate"
#define OPT_ITARSESSIONCERTIFIED    "ItarSessionCertified"
#define OPT_STORAGEPOOL             "StoragePoolDefault"
#define OPT_STORAGEPOOLS            "StoragePools"
#define OPT_SHOWHIDDEN              "ShowHidden"
#define OPT_SENDNOTIFICATIONDEFAULT "SendNotificationDefault"
#define OPT_RETURNRECEIPTDEFAULT    "ReturnReceiptDefault"

static char* userV    = 0;
static char* companyV = 0;

// 0 is the Public Pool (default)
#ifdef SOA
static int       itarPackageCreate    = 0;
#endif

static int       uploadbuffersz       = 2*1024*1024;
static int       downloadbuffersz     = 2*1024*1024;

static long long storagepoolForCreate = 0;

#define userName()    userV
#define companyName() companyV

//#define userName() getenv("LOGNAME")

char* dropboxToken = 0;
char* dropboxUrl   = 0;
char* dropboxHost  = 0;
int   dropboxPort  = -1;

#ifdef DOTESTING
static char testlogin_token[] = "37201022938028e53dcb4c2b3a37a055d6e4db104421435a8619ac4da632653ff9de8c0810058e82ec8657500f37f1f23c9378a9241035568caefb89b09c08de3d9988882dd7";
static char testhost[] = "iceland.fishkill.ibm.com";
static int  testport   = 5060;
#endif


/*-------------------------------------------------------------------------*\
**             Java Init Function/Statics 
\*-------------------------------------------------------------------------*/
      
JNIEnv* javaenv = 0;
JavaVM* jvm     = 0;
int     gotjvm  = 0;

#ifdef TUNNELCLIENTJAR
char* myclasspath = TUNNELCLIENTJAR;
#else
char* myclasspath = "";
#endif

// Common place to query exceptions and print them
int printexception = 1;
int exceptionOccurred() {
   int ret = (int)javaenv->ExceptionOccurred();
   if (ret && printexception) {
      logit("Exception: ");
      javaenv->ExceptionDescribe();
   }
   return ret;
}


// sftpDropbox
jclass                    jdropboxClass                   = 0;
jobject                   jdropbox                        = 0;
jmethodID                 threadMaker_methid              = 0;
static jmethodID          connect_methid                  = 0;
#ifdef SOA
static jmethodID          disconnect_methid               = 0;
#endif
static jmethodID          setDoSystemExit_methid          = 0;
static jmethodID          listInOutSandBox_methid         = 0;
static jmethodID          listInOutSandBoxName_methid     = 0;
static jmethodID          listPackageContents_methid      = 0;
static jmethodID          queryAcls_methid                = 0;
static jmethodID          deletePackage_methid            = 0;
static jmethodID          markPackage_methid              = 0;
static jmethodID          createPackage_methid            = 0;
static jmethodID          removeAcl_methid                = 0;
static jmethodID          addAcl_methid                   = 0; 
static jmethodID          commitPackage_methid            = 0; 
static jmethodID          deleteFileFromPackage_methid    = 0;
static jmethodID          uploadFile_methid               = 0;
static jmethodID          downloadFile_methid             = 0;
static jmethodID          downloadPackage_methid          = 0;
static jmethodID          readFileData_methid             = 0;
static jmethodID          writeFileData_methid            = 0;
static jmethodID          closeOperation_methid           = 0;
static jmethodID          login_methid                    = 0;
static jmethodID          getTokenUserCompany_methid      = 0;

#ifdef R711
static jmethodID          queryPackageAclCompanies_methid = 0;
#endif

static jmethodID          setMaxUploadTransferSize_methid   = 0;
static jmethodID          setMaxDownloadTransferSize_methid = 0;

static jmethodID          createGroup_methid              = 0;
static jmethodID          deleteGroup_methid              = 0;
static jmethodID          listGroups_methid               = 0;
static jmethodID          listGroup_methid                = 0;
static jmethodID          addGroupMemberAccess_methid     = 0;
static jmethodID          removeGroupMemberAccess_methid  = 0;
static jmethodID          setGroupAttributes_methid       = 0;
static jmethodID          setOption_methid                = 0;
static jmethodID          getOptions_methid               = 0;
static jmethodID          setPackageFlags_methid          = 0;
static jmethodID          setPackageExpiration_methid     = 0;
static jmethodID          getUserProjects_methid          = 0;
static jmethodID          getStoragePoolInstance_methid   = 0;
static jmethodID          queryStoragePoolInformation_methid     = 0;
static jmethodID          setPackageDescription_methid    = 0;

// Vector
static jclass             vectorClass                     = 0;
static jmethodID          Vec_contains_methid             = 0;
static jmethodID          Vec_elements_methid             = 0;

// Hashtable
static jclass             hashtableClass                  = 0;
static jmethodID          Hash_get_methid                 = 0;
static jmethodID          Hash_put_methid                 = 0;
static jmethodID          Hash_elements_methid            = 0;
static jmethodID          Hash_keys_methid                = 0;

// Enumeration
static jclass             enumerationClass                = 0;
static jmethodID          Enum_hasMoreElements_methid     = 0;
static jmethodID          Enum_nextElement_methid         = 0;

// Operation
static jclass             operationClass                  = 0;
static jmethodID          Operation_getToXfer_methid      = 0;

// PackageInfo
static jclass             packageInfoClass                = 0;
static jmethodID          PI_getPackageId_methid          = 0;
#ifdef SOA
static jmethodID          PI_getPackageDescription_methid = 0;
#endif
static jmethodID          PI_getPackageExpiration_methid  = 0;
static jmethodID          PI_getPackageCreation_methid    = 0;
static jmethodID          PI_getPackageCommitted_methid   = 0;
static jmethodID          PI_getPackageSize_methid        = 0;
static jmethodID          PI_getPackageName_methid        = 0;
static jmethodID          PI_getPackageOwner_methid       = 0;
static jmethodID          PI_getPackageCompany_methid     = 0;
static jmethodID          PI_getPackageFlags_methid       = 0;
static jmethodID          PI_getPackagePoolId_methid      = 0;

// PoolInfo
static jclass             poolInfoClass                   = 0;
static jmethodID          PL_getPoolId_methid             = 0;
static jmethodID          PL_getPoolName_methid           = 0;
static jmethodID          PL_getPoolMaxDays_methid        = 0;
static jmethodID          PL_getPoolDefaultDays_methid    = 0;


// GroupInfo
static jclass             groupInfoClass                  = 0;
static jmethodID          GI_getGroupName_methid          = 0;
static jmethodID          GI_getGroupCompany_methid       = 0;
static jmethodID          GI_getGroupOwner_methid         = 0;
static jmethodID          GI_getGroupVisibility_methid    = 0;
static jmethodID          GI_getGroupListability_methid   = 0;
static jmethodID          GI_getGroupMembersValid_methid  = 0;
static jmethodID          GI_getGroupAccessValid_methid   = 0;
static jmethodID          GI_getGroupMembers_methid       = 0;
static jmethodID          GI_getGroupAccess_methid        = 0;
static jmethodID          GI_getGroupCreated_methid       = 0;

// FileInfo
static jclass             fileInfoClass                   = 0;
static jmethodID          FI_getFileId_methid             = 0;
static jmethodID          FI_getFileExpiration_methid     = 0;
static jmethodID          FI_getFileCreation_methid       = 0;
static jmethodID          FI_getFileSize_methid           = 0;
static jmethodID          FI_getFileName_methid           = 0;
static jmethodID          FI_getFileStatus_methid         = 0;
static jmethodID          FI_getFileMD5_methid            = 0;

// Misc
static jclass             miscClass                       = 0;
static jmethodID          MISC_getConnectInfoG_methid     = 0;

// DebugPrint
static jclass             debugPrintClass                 = 0;
static jmethodID          DebugPrint_setLevel_methid      = 0;

// System
static jclass             systemClass                     = 0;
static jmethodID          System_setOut_methid            = 0;
static jobject            System_stdErr_Obj               = 0;

// User Info
static char* edgeuser = 0;
static char* company  = 0;

#define findclassVoid(cv, cn)               \
   (cv) = javaenv->FindClass((cn));         \
   if (!(cv)) {                             \
      error("Could not find %s class %d",   \
            (cn), __LINE__);                \
      return;                               \
   }
   
#define findclass(cv, cn)                   \
   (cv) = javaenv->FindClass((cn));         \
   if (!(cv)) {                             \
      error("Could not find %s class %d",   \
            (cn), __LINE__);                \
      return -1;                            \
   }
   
#define getstaticmethid(cv, mv, mn, ms)     \
   (mv) = javaenv->GetStaticMethodID((cv), (mn), (ms)); \
   if (!(mv)) {                             \
      error("Could not find %s(%s) static method", \
            (mn), (ms));                    \
      return -1;                            \
   }
   
#define getstaticobject(cv, ov, on, os)     { \
   jfieldID _lfid = javaenv->GetStaticFieldID((cv), (on), (os)); \
   (ov) = javaenv->GetStaticObjectField((cv), _lfid);            \
   if (!(ov)) {                             \
      error("Could not find %s(%s) static object", \
            (on), (os));                    \
      return -1;                            \
   }}
   
   
#define getmethid(cv, mv, mn, ms)           \
   (mv) = javaenv->GetMethodID((cv), (mn), (ms)); \
   if (!(mv)) {                             \
      error("Could not find %s(%s) method", \
            (mn), (ms));                    \
      return -1;                            \
   }

int javamethinit() {

  // sftpDropbox
#ifdef SOA
   findclass(jdropboxClass, "oem/edge/ed/odc/dropbox/client/sftpDropbox");
   
   getmethid(jdropboxClass, connect_methid, 
             "connect", "(Ljava/lang/String;)Z");
   getmethid(jdropboxClass, disconnect_methid, 
             "disconnect", "()V");
#else
   findclass(jdropboxClass, "oem/edge/ed/odc/dropbox/client/sftpDropbox");
   
   getmethid(jdropboxClass, connect_methid, 
             "connect", "(Ljava/lang/String;IZ)Z");
#endif
   getmethid(jdropboxClass, setDoSystemExit_methid, 
             "setDoSystemExit", "(Z)V");
   getmethid(jdropboxClass, login_methid, 
             "login", "(Ljava/lang/String;)Z");
   getmethid(jdropboxClass, getTokenUserCompany_methid, 
             "getTokenUserCompany", "(Z)Ljava/lang/String;");
   getmethid(jdropboxClass, listInOutSandBox_methid, 
             "listInOutSandBox", "(I)Ljava/util/Enumeration;");
   getmethid(jdropboxClass, listInOutSandBoxName_methid, 
             "listInOutSandBox", 
             "(ILjava/lang/String;)Ljava/util/Enumeration;");
   getmethid(jdropboxClass, listPackageContents_methid, 
             "listPackageContents", "(J)Ljava/util/Enumeration;");
   getmethid(jdropboxClass, queryAcls_methid, 
             "queryAcls", "(J)Ljava/util/Enumeration;");
   getmethid(jdropboxClass, deletePackage_methid,
             "deletePackage", "(J)Z");
   getmethid(jdropboxClass, markPackage_methid,
             "markPackage", "(JZ)Z");
   
#ifdef R711
   getmethid(jdropboxClass, queryPackageAclCompanies_methid, 
             "queryPackageAclCompanies", "(J)Ljava/util/Vector;");
#endif
   
#ifdef SOA
   getmethid(jdropboxClass, setMaxUploadTransferSize_methid,
             "setMaxUploadTransferSize", "(I)V");
   getmethid(jdropboxClass, setMaxDownloadTransferSize_methid,
             "setMaxDownloadTransferSize", "(I)V");
#endif
   
#ifdef SOA
   getmethid(jdropboxClass, createPackage_methid,
             "createPackage", "(Ljava/lang/String;JII)Z");
#else 
   getmethid(jdropboxClass, createPackage_methid,
             "createPackage", "(Ljava/lang/String;J)Z");
#endif
   getmethid(jdropboxClass, commitPackage_methid,
             "commitPackage", "(J)Z");
   getmethid(jdropboxClass, removeAcl_methid,
             "removeAcl",     "(JLjava/lang/String;)Z");
   getmethid(jdropboxClass, addAcl_methid,
             "addAcl",        "(JLjava/lang/String;)Z");
   getmethid(jdropboxClass, deleteFileFromPackage_methid,
             "deleteFileFromPackage",  "(JJ)Z");
             
#ifdef SOA
   getmethid(jdropboxClass, downloadFile_methid,
             "downloadFile", "(JJ)Loem/edge/ed/odc/dropbox/service/helper/Operation;");
   getmethid(jdropboxClass, uploadFile_methid,
             "uploadFile",   "(JLjava/lang/String;)Loem/edge/ed/odc/dropbox/service/helper/Operation;");
   getmethid(jdropboxClass, downloadPackage_methid,
             "downloadPackage", "(JLjava/lang/String;)Loem/edge/ed/odc/dropbox/service/helper/Operation;");
             
   getmethid(jdropboxClass, readFileData_methid,
             "readFileData",   "(Loem/edge/ed/odc/dropbox/service/helper/Operation;[BII)I");
   getmethid(jdropboxClass, writeFileData_methid,
             "writeFileData",  "(Loem/edge/ed/odc/dropbox/service/helper/Operation;[BII)V");
   getmethid(jdropboxClass, closeOperation_methid,
             "closeOperation", "(Loem/edge/ed/odc/dropbox/service/helper/Operation;)Z");
   getmethid(jdropboxClass, setPackageDescription_methid, 
             "setPackageDescription", "(JLjava/lang/String;)Z");
#else
   getmethid(jdropboxClass, downloadFile_methid,
             "downloadFile", "(JJ)Loem/edge/ed/odc/ftp/common/Operation;");
   getmethid(jdropboxClass, uploadFile_methid,
             "uploadFile",   "(JLjava/lang/String;)Loem/edge/ed/odc/ftp/common/Operation;");
   getmethid(jdropboxClass, downloadPackage_methid,
             "downloadPackage", "(JLjava/lang/String;)Loem/edge/ed/odc/ftp/common/Operation;");
             
   getmethid(jdropboxClass, readFileData_methid,
             "readFileData",   "(Loem/edge/ed/odc/dropbox/client/sftpDropbox$MyClientDownloadOperation;[BII)I");
   getmethid(jdropboxClass, writeFileData_methid,
             "writeFileData",  "(Loem/edge/ed/odc/dropbox/client/sftpDropbox$MyClientUploadOperation;[BII)V");
   getmethid(jdropboxClass, closeOperation_methid,
             "closeOperation", "(Loem/edge/ed/odc/ftp/common/Operation;)Z");
#endif
             
   getmethid(jdropboxClass, createGroup_methid,
             "createGroup",  "(Ljava/lang/String;)Z");
   getmethid(jdropboxClass, deleteGroup_methid,
             "deleteGroup",  "(Ljava/lang/String;)Z");
   getmethid(jdropboxClass, listGroups_methid,
             "listGroups",  "()Ljava/util/Hashtable;");
   getmethid(jdropboxClass, listGroup_methid,
             "listGroup",  "(Ljava/lang/String;)Loem/edge/ed/odc/dsmp/common/GroupInfo;");
   getmethid(jdropboxClass, addGroupMemberAccess_methid,
             "addGroupMemberAccess",  "(Ljava/lang/String;Ljava/lang/String;Z)Z");
   getmethid(jdropboxClass, removeGroupMemberAccess_methid,
             "removeGroupMemberAccess",  "(Ljava/lang/String;Ljava/lang/String;Z)Z");
   getmethid(jdropboxClass, setGroupAttributes_methid,
             "setGroupAttributes", "(Ljava/lang/String;BZ)Z");
             
   getmethid(jdropboxClass, setOption_methid,
             "setOption", "(Ljava/lang/String;Ljava/lang/String;)Z");
   getmethid(jdropboxClass, getOptions_methid,
             "getOptions", "()Ljava/util/Hashtable;");
   getmethid(jdropboxClass,     setPackageFlags_methid,
             "setPackageFlags", "(JII)Z");
   getmethid(jdropboxClass,     setPackageExpiration_methid,
             "setPackageExpiration", "(JJ)Z");
   getmethid(jdropboxClass,     getUserProjects_methid,
             "getUserProjects", "()Ljava/util/Vector;");
   getmethid(jdropboxClass,     getStoragePoolInstance_methid,
             "getStoragePoolInstance", "(J)Loem/edge/ed/odc/dropbox/common/PoolInfo;");
   getmethid(jdropboxClass,     queryStoragePoolInformation_methid,
             "queryStoragePoolInformation", "()Ljava/util/Vector;");
             
  // Operation
#ifdef SOA
   findclass(operationClass,  "oem/edge/ed/odc/dropbox/service/helper/Operation");
   getmethid(operationClass,  Operation_getToXfer_methid, 
             "getToXfer", "()J");
#else
   findclass(operationClass,  "oem/edge/ed/odc/ftp/common/Operation");
   getmethid(operationClass,  Operation_getToXfer_methid, 
             "getToXfer", "()J");
#endif
             
  // PackageInfo
   findclass(packageInfoClass,  "oem/edge/ed/odc/dropbox/common/PackageInfo");
   getmethid(packageInfoClass,  PI_getPackageName_methid, 
             "getPackageName", "()Ljava/lang/String;");
   getmethid(packageInfoClass,  PI_getPackageOwner_methid, 
             "getPackageOwner", "()Ljava/lang/String;");
   getmethid(packageInfoClass,  PI_getPackageCompany_methid, 
             "getPackageCompany", "()Ljava/lang/String;");
   getmethid(packageInfoClass,  PI_getPackageId_methid, 
             "getPackageId", "()J");
   getmethid(packageInfoClass,  PI_getPackageSize_methid, 
             "getPackageSize", "()J");
   getmethid(packageInfoClass,  PI_getPackageExpiration_methid, 
             "getPackageExpiration", "()J");
             
#ifdef SOA
   getmethid(packageInfoClass,  PI_getPackageDescription_methid, 
             "getPackageDescription", "()Ljava/lang/String;");
#endif
             
   getmethid(packageInfoClass,  PI_getPackageCreation_methid, 
             "getPackageCreation", "()J");
             
  // For 4.4.1, we don't have the Committed method avail ... just use
  //            created. Then the code is identical to 4.5.1 (for now ;-)
#ifdef is441
   getmethid(packageInfoClass,  PI_getPackageCommitted_methid, 
             "getPackageCreation", "()J");
#else
   getmethid(packageInfoClass,  PI_getPackageCommitted_methid, 
             "getPackageCommitted", "()J");
#endif
             
   getmethid(packageInfoClass,  PI_getPackageFlags_methid, 
             "getPackageFlags", "()B");
   
   getmethid(packageInfoClass,  PI_getPackagePoolId_methid, 
             "getPackagePoolId", "()J");
   
   
  // PoolInfo
   findclass(poolInfoClass,  "oem/edge/ed/odc/dropbox/common/PoolInfo");
   getmethid(poolInfoClass,  PL_getPoolName_methid, 
             "getPoolName", "()Ljava/lang/String;");
   getmethid(poolInfoClass,  PL_getPoolId_methid, 
             "getPoolId", "()J");
   getmethid(poolInfoClass,  PL_getPoolMaxDays_methid, 
             "getPoolMaxDays", "()I");
   getmethid(poolInfoClass,  PL_getPoolDefaultDays_methid, 
             "getPoolDefaultDays", "()I");
   
  // GroupInfo
   findclass(groupInfoClass,  "oem/edge/ed/odc/dsmp/common/GroupInfo");
   getmethid(groupInfoClass,  GI_getGroupName_methid, 
             "getGroupName", "()Ljava/lang/String;");
   getmethid(groupInfoClass,  GI_getGroupCompany_methid, 
             "getGroupCompany", "()Ljava/lang/String;");
   getmethid(groupInfoClass,  GI_getGroupOwner_methid, 
             "getGroupOwner", "()Ljava/lang/String;");
   getmethid(groupInfoClass,  GI_getGroupVisibility_methid, 
             "getGroupVisibility", "()B");
   getmethid(groupInfoClass,  GI_getGroupListability_methid, 
             "getGroupListability", "()B");
   getmethid(groupInfoClass,  GI_getGroupMembersValid_methid, 
             "getGroupMembersValid", "()Z");
   getmethid(groupInfoClass,  GI_getGroupAccessValid_methid, 
             "getGroupAccessValid", "()Z");
   getmethid(groupInfoClass,  GI_getGroupMembers_methid, 
             "getGroupMembers", "()Ljava/util/Vector;");
   getmethid(groupInfoClass,  GI_getGroupAccess_methid, 
             "getGroupAccess", "()Ljava/util/Vector;");
   getmethid(groupInfoClass,  GI_getGroupCreated_methid, 
             "getGroupCreated", "()J");
             
  // FileInfo
   findclass(fileInfoClass,     "oem/edge/ed/odc/dropbox/common/FileInfo");
   getmethid(fileInfoClass,  FI_getFileName_methid, 
             "getFileName", "()Ljava/lang/String;");
   getmethid(fileInfoClass,  FI_getFileId_methid, 
             "getFileId", "()J");
   getmethid(fileInfoClass,  FI_getFileSize_methid, 
             "getFileSize", "()J");
   getmethid(fileInfoClass,  FI_getFileStatus_methid, 
             "getFileStatus", "()B");
   getmethid(fileInfoClass,  FI_getFileExpiration_methid, 
             "getFileExpiration", "()J");
   getmethid(fileInfoClass,  FI_getFileCreation_methid, 
             "getFileCreation", "()J");
   getmethid(fileInfoClass,  FI_getFileMD5_methid, 
             "getFileMD5", "()Ljava/lang/String;");
   
   
  // Misc
   findclass(miscClass,        "oem/edge/ed/odc/tunnel/common/Misc");
   getstaticmethid(miscClass,  MISC_getConnectInfoG_methid, 
             "getConnectInfoGeneric", "(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;");
   
  // Vector
   findclass(vectorClass,       "java/util/Vector");
   getmethid(vectorClass, Vec_contains_methid, 
             "contains", "(Ljava/lang/Object;)Z");
   getmethid(vectorClass, Vec_elements_methid,
             "elements", "()Ljava/util/Enumeration;");
   
  // Hashtable
   findclass(hashtableClass,       "java/util/Hashtable");
   getmethid(hashtableClass, Hash_get_methid, 
             "get", "(Ljava/lang/Object;)Ljava/lang/Object;");
   getmethid(hashtableClass, Hash_put_methid, 
             "put", "(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;");
   getmethid(hashtableClass, Hash_elements_methid,
             "elements", "()Ljava/util/Enumeration;");
   getmethid(hashtableClass, Hash_keys_methid,
             "keys", "()Ljava/util/Enumeration;");
   
  // Enumeration
   findclass(enumerationClass,  "java/util/Enumeration");
   getmethid(enumerationClass, Enum_hasMoreElements_methid, 
             "hasMoreElements", "()Z");
   getmethid(enumerationClass, Enum_nextElement_methid,
             "nextElement", "()Ljava/lang/Object;");
             
  // DebugPrint
   findclass(debugPrintClass, "oem/edge/ed/odc/tunnel/common/DebugPrint");
   getstaticmethid(debugPrintClass,  DebugPrint_setLevel_methid,
                   "setLevel", "(I)V");
             
  // System
   findclass(systemClass, "java/lang/System");
   getstaticmethid(systemClass,  System_setOut_methid,
                   "setOut", "(Ljava/io/PrintStream;)V");
   getstaticobject(systemClass,  System_stdErr_Obj,
                   "err", "Ljava/io/PrintStream;");
                   
   return 0;
};

/*-------------------------------------------------------------------------*\
**             Misc Routines 
\*-------------------------------------------------------------------------*/

// Vals can be NULL
class Options {
   char** keys;
   char** vals;
   int num;
   
  public:
   
   Options() {
      keys = 0;
      vals = 0;
      num = 0;
   }
   ~Options() {
      if (keys) {
         for(int i=0; i < num; i++) {
            delete keys[i];
            if (vals[i]) delete vals[i];
         }
         delete keys;
         delete vals;
      }
   }
   
  // Use it as a Hash
   void put(const char* k, const char* v) {
      if (!keys) {
         keys = new char*[100];
         vals = new char*[100];
      }
   
      char* key = new char[strlen(k)+1]; strcpy(key, k);
      char* val = NULL;
      
      if (v) { val = new char[strlen(v)+1]; strcpy(val, v); }
      
      int i = 0;
      for(; i < num; i++) {
         if (!strcmp(keys[i], k)) {
            delete keys[i];
            delete vals[i];
            break;
         }
      }
      
      keys[i] = key;
      vals[i] = val;
      if (i == num) {
         num++;
      }
   }
   
  // Use it as a vector
   void add(const char* k, const char* v) {
      if (!keys) {
         keys = new char*[100];
         vals = new char*[100];
      }
   
      char* key = new char[strlen(k)+1]; strcpy(key, k);
      char* val = NULL;
      
      if (v) { val = new char[strlen(v)+1]; strcpy(val, v); }
      
      keys[num]   = key;
      vals[num++] = val;
   }

  // Use as Hash
   const char* get(const char* k) {
      if (keys) {
         int i = 0;
         for(; i < num; i++) {
            if (!strcmp(keys[i], k)) {
               return vals[i];
            }
         }
      }
      return 0;
   }
   
   const char* getKey(int i) {
      if (keys) {
         if (i < num && i >= 0) {
            return keys[i];
         }
      }
      return 0;
   }
   
   const char* getVal(int i) {
      if (keys) {
         if (i < num && i >= 0) {
            return vals[i];
         }
      }
      return 0;
   }
   
};

class Vector {
   void** vals;
   int num;
   int cap;
   
  public:
   
   Vector() {
      vals = 0;
      num = 0;
      cap = 0;
   }
   ~Vector() {
      if (vals) {
         delete vals;
      }
   }
   
   int size() { return num; }
   
   void addElement(void* p) {
      add(p);
   }
   void add(void* p) {
      if (!vals) {
         vals = new void*[cap=100];
      } else if (num == cap) {
         void** tv = vals;
         vals = new void*[cap += 40];
         memcpy(vals, tv, sizeof(void*)*num);
         delete tv;
      }
   
      vals[num++] = p;
   }

   void* removeElementAt(int i) {
      if (vals) {
         if (i < num && i >= 0) {
            void* ret = vals[i];
            if (i+1 < num) {
               memmove(vals+i, vals+i+1, sizeof(void*) * (num-i-1));
            }
            num--;
            return ret;
         }
      }
      return 0;
   }
   
   void* elementAt(int i) {
      if (vals) {
         if (i < num && i >= 0) {
            return vals[i];
         }
      }
      return 0;
   }
};


char* cvt_realpath(const char * ret) {
   char b[1024];
   int i = 0;
   int bi = 0;
   if (*ret != '/') b[bi++] = '/';
   while(ret[i]) {
      if        ((i==0 || ret[i-1] == '/') && 
                 ret[i] == '.' && ret[i+1] == '\0') {
         
//         printf("Skip . i=%d\n", i);
         i++; // skip it
         
      } else if ((i==0 || ret[i-1] == '/') && 
                 ret[i] == '/') {
         
//         printf("Skip double slash i=%d\n", i);
         i++; // skip it
         
         
      } else if ((i==0 || ret[i-1] == '/') && 
                 ret[i] == '.' && ret[i+1] == '/') {
//         printf("Skip . i=%d\n", i);
         i += 2;  // skip . and /
         
      } else if ((i==0 || ret[i-1] == '/') &&
                 !strncmp(ret+i, "..", 2)  && 
                 (ret[i+2] == '\0' || ret[i+2] == '/')) {
         
        // back up one level
         i += 2;
         
         b[bi-1] = '\0';
         char * newb = strrchr(b, '/');
         
//         printf("b=[%s] %X bi=%d  ret=[%s] i=%d newb[%s] %X\n", 
//                b, b, bi, ret+i, i, (newb?newb:NULL), newb);
                
         if (newb) {
            b[bi=newb-b] = '\0';
//            printf(">>> bi = %d\n", bi);
            if (bi == 0) b[bi++]='/';
         } else {
            b[0] = '/'; bi = 1;
         }
         
      } else {
//         printf("ccc bi = %d i=%d\n", bi, i);
         if (!bi || ret[i] != '/' || b[bi-1] != '/') {
            b[bi++] = ret[i++];
         } else {
            i++;
         }
      }
   }
   
  // Don't let it end in slash unless it is the only char
   if (bi > 1 && b[bi-1] == '/') bi--;
   
   b[bi] = '\0';
   
   
   debug("cvt from [%s] to [%s]\n", ret, b);
   return xstrdup(b);
}

char *
local_ls_file(MYDIRENTRY *dp) 
{
	int ulen, glen, sz = 0;
        struct stat stats = dp->getStats();
	struct tm *ltime = localtime(&stats.st_mtime);
	const char *user, *group;
	char buf[1024], mode[11+1], tbuf[12+1]; /* ubuf[11+1], gbuf[11+1];*/

        sprintf(mode, "%crw%c------ ", 
                (S_ISDIR(stats.st_mode)?'d':'-'), 
                (S_ISDIR(stats.st_mode)?'x':'-')); 
                
        user  = dp->getOwner();
        group = companyName();
        
	if (ltime != NULL) {
		if (time(NULL) - stats.st_mtime < (365*24*60*60)/2)
			sz = strftime(tbuf, sizeof tbuf, "%b %e %H:%M", ltime);
		else
			sz = strftime(tbuf, sizeof tbuf, "%b %e  %Y", ltime);
	}
	if (sz == 0)
		tbuf[0] = '\0';
	ulen = MAX(strlen(user), 8);
	glen = MAX(strlen(group), 8);
	snprintf(buf, sizeof buf, "%s %3d %-*s %-*s %8llu %s %s", mode,
	    stats.st_nlink, ulen, user, glen, group,
	    (unsigned long long)stats.st_size, tbuf, dp->getName());
            
        debug(buf);
	return xstrdup(buf);
}

struct PathInfo {
   int topdirnum;

   char topdir[1024];
   char pack[1024];
   char file[1024];
   int  isAccess;
   char access[1024];
   char fullpath[1024];
   
#define HSTRSIZE 128
#define HARRSIZE 10
   char hier[HARRSIZE][HSTRSIZE];
   int  hidx;
   
  // If it does not start with /, assume it does
   void parse(const char* s) {
      hidx = 0;
      topdir[0] = '\0';
      pack[0]   = '\0';
      file[0]   = '\0';
      access[0] = '\0';
      isAccess  = 0;
      
      debug("Start answer: %s\n", s);
      
      strcpy(fullpath, s);
      s = fullpath;
      
     // Reduce ALL multiple slashes to a single slash
     //  This copies starting from 2nd slash to the end, and covers the first,
     //  including the '\0'
      char* p;
      while((p = strstr(fullpath, "//"))) {
         memmove(p, p+1, strlen(fullpath)-(p-fullpath));
      }
      
     // Remove any trailing slash
      int tslash = strlen(fullpath);
      if (tslash > 0 && fullpath[tslash-1] == '/') {
         fullpath[tslash-1] = '\0';
      }
      
      debug("Total answer: %s\n", s);
      
      if (*s != '\0' && *s == '/') s++;
      
      int i = 0;
      while(*s != '\0' && *s != '/' && i < (int)sizeof(topdir)-1) 
         topdir[i++] = *s++;
      topdir[i] = '\0';
      
      if (*s != '\0' && *s == '/') s++;
      
      i = 0;
      while(*s != '\0' && *s != '/' && i < (int)sizeof(pack)-1) 
         pack[i++] = *s++;
      pack[i] = '\0';
      
      if (*s != '\0' && *s == '/') s++;
      
      i = 0;
      while(*s != '\0' && i < (int)sizeof(file)-1) 
         file[i++] = *s++;
      file[i] = '\0';
      
      topdirnum = 7;
      if (strcmp(topdir, PROJECTS)) {
         topdirnum--;
         if (strcmp(topdir, OPTIONS)) {
            topdirnum--;
            if (strcmp(topdir, GROUPS)) {
               topdirnum--;
               if (strcmp(topdir, DRAFTS)) {
                  topdirnum--;
                  if (strcmp(topdir, OUTBOX)) {
                     topdirnum--;
                     if (strcmp(topdir, INBOX)) {
                        topdirnum--;
                        if (strcmp(topdir, TRASH)) {
                           topdirnum--;
                        }
                     }
                  }
               }
            }
         } 
      }
      
     // Only outbox and drafts have access
      if (topdirnum == OUTBOX_N || topdirnum == DRAFTS_N) {
         int accesslen = strlen(ACCESSDIR);
         if (!strncmp(file, ACCESSDIR, accesslen)) {
            if ((int)strlen(file) == accesslen) {
               isAccess = 1;
            } else if (file[accesslen] == '/') {
               isAccess = 1;
               strcpy(access, file+accesslen+1);
               file[accesslen] = '\0';
            }
         }
      }

     // Fill out the hier array best can do
      strcpy(hier[0], topdir); 
      hidx++;
      if (pack[0]) {
         strcpy(hier[1], pack);
         hidx++;
      }
      
     // Ok, fill out hier array
      s = file;
      while(*s != '\0' && hidx < HARRSIZE) {
         i = 0;
         while(*s != '\0' && *s != '/' && i < (HSTRSIZE-1)) 
            hier[hidx][i++] = *s++;
         hier[hidx++][i] = '\0';
         if (*s != '\0' && *s == '/') s++;
      }
   }
};

struct EncodedPathInfo : public PathInfo {

   const char* encoding;
   char encodedPackname[1024];
   
   void parse(const char* s) {
      PathInfo::parse(s);
      
      encoding = NULL;
      
      encodedPackname[0] = '\0';
      
      if (hidx != 2) return;
      
      char pname[1024];
      strcpy(pname, hier[1]);
   
      int plen = strlen(pname);
      
      if        (plen >= astar_sufflen && 
                 !strcmp(pname+plen-astar_sufflen, astar_suff)) {
         encoding = astar_encoding;
         pname[plen-astar_sufflen] = '\0';
      } else if (plen >= astgz_sufflen && 
                 !strcmp(pname+plen-astgz_sufflen, astgz_suff)) {
         encoding = astgz_encoding;
         pname[plen-astgz_sufflen] = '\0';
      } else if (plen >= astargz_sufflen && 
                 !strcmp(pname+plen-astargz_sufflen, astargz_suff)) {
         encoding = astargz_encoding;
         pname[plen-astargz_sufflen] = '\0';
      } else if (plen >= aszip_sufflen && 
                 !strcmp(pname+plen-aszip_sufflen, aszip_suff)) {
         encoding = aszip_encoding;
         pname[plen-aszip_sufflen] = '\0';
      }
      
      if (encoding) {
         char tmps[1024];
         sprintf(tmps, "/%s/%s", hier[0], pname);
         strcpy(encodedPackname, hier[1]);
         PathInfo::parse(tmps);
      }
   }
};


// Make the attributes file contents given the DIRENTRY of the package
int makeAttrStringForAttributes(MYDIRENTRY* dp, char* pname, char* attrStr) {
   if (dp) {
      long long packid    = dp->getId();
      const char* owner   = dp->getOwner();
      const char* company = dp->getCompany();
      
     // ctime is expires, mtime is created
      struct stat st      = dp->getStats();
      
      char expiresStr[1024], createStr[1024];
            
      time_t t = st.st_ctime;
      ctime_r(&t, expiresStr);
      t = st.st_mtime;
      ctime_r(&t, createStr);
      
      sprintf(attrStr,
              "packagename=%s\n"
              "packageid=%lld\n"
              "packageowner=%s\n"
              "ownercompany=%s\n"
              "expires=%s"
              "created=%s"
              "expiressec70=%d\n"
              "createdsec70=%d\n",
              pname, packid,owner, company, expiresStr, createStr,  
              st.st_ctime, st.st_mtime);
      return strlen(attrStr);
   }
   return 0;
}

#ifdef SOA
// Make the description file contents given the DIRENTRY of the package
int makeAttrStringForDescription(MYDIRENTRY* dp, char* pname, char* attrStr) {
   if (dp && dp->getDescription()) {
      strncpy(attrStr, dp->getDescription(), 4095);
      attrStr[4095] = '\0';
      return strlen(attrStr);
   }
   return 0;
}
#endif

// Make the md5 string - Consumes the passed in directory!
int makeAttrStringForMD5(MYDIR* mydir, char*& attrStr) {
   int strsz = 65536;
   int strlength = 0;
   
   attrStr = new char[strsz];
   attrStr[0] = '\0';
   if (mydir) {
     // Search for all files
      MYDIRENTRY *dp = NULL;
      while((dp = mydir->readDir())) {
         if (dp->_getMD5()) {
           // Grow string if we are within 1k of capacity
            if ((strlength + 1024) > strsz) {
               strsz += 8192;
               char* newstr = new char[strsz];
               strcpy(newstr, attrStr);
               delete attrStr;
               attrStr = newstr;
            }
            sprintf(attrStr+strlength, "%s  %s\n", 
                    dp->_getMD5(), dp->getName());
            strlength = strlen(attrStr);
         }
         delete dp;
      }
      delete mydir;
   }

   return strlength;
}



/*-------------------------------------------------------------------------*\
**             Java Access functions
\*-------------------------------------------------------------------------*/

/* Storage Pool */

StoragePool* getStoragePoolFromJavaObject(jobject spJ) {
   StoragePool *ret = NULL;
   if (spJ) {
      jlong   id = javaenv->CallLongMethod  (spJ, PL_getPoolId_methid, 0);
      jint    md = javaenv->CallIntMethod   (spJ, PL_getPoolMaxDays_methid, 0);
      jint    dd = javaenv->CallIntMethod   (spJ, PL_getPoolDefaultDays_methid, 0);
      jstring nJ = (jstring)javaenv->CallObjectMethod(spJ, PL_getPoolName_methid, 0);
      
      jboolean z=false;
      const char* ln = javaenv->GetStringUTFChars(nJ, &z);
      
      ret = new StoragePool(id, ln, md, dd);
      
      javaenv->ReleaseStringUTFChars(nJ, ln);
      javaenv->DeleteLocalRef(nJ);
      
   }
   return ret;
}

void deleteStoragePoolVector(Vector *vec) {
   if (vec) {
      int num = vec->size();
      for(int i=0; i < num; i++) {
         StoragePool* sp = (StoragePool*)vec->removeElementAt(i);
         if (sp) {
            delete sp;
         }
      }
      delete vec;
   }
}

Vector* queryStoragePoolInformation() {

   Vector *vec = NULL;

   jobject vecJ = javaenv->CallObjectMethod(jdropbox, 
                                            queryStoragePoolInformation_methid, 
                                            0);
                                    
   if (vecJ) {
   
      jobject enumer = javaenv->CallObjectMethod(vecJ, Vec_elements_methid, 0); 
      
      if (enumer) {
      
         while(!exceptionOccurred() && 
               javaenv->CallBooleanMethod(enumer, 
                                          Enum_hasMoreElements_methid, 
                                          0)){
            jobject spJ = javaenv->CallObjectMethod(enumer, 
                                                    Enum_nextElement_methid, 
                                                    0);
            
            if (spJ) {
               StoragePool* sp = getStoragePoolFromJavaObject(spJ);
               if (sp) {
                  if (vec == NULL) vec = new Vector();
                  vec->addElement(sp);
               }
               javaenv->DeleteLocalRef(spJ);
            }
         }
         javaenv->DeleteLocalRef(enumer);
      }
      javaenv->DeleteLocalRef(vecJ);
   }
         
   return vec;
}

StoragePool* getStoragePoolByName(const char* s) {
   StoragePool* ret = NULL;
   Vector *vec = queryStoragePoolInformation();
   if (vec) {
      int num = vec->size();
      for(int i=0; i < num; i++) {
         StoragePool* sp = (StoragePool*)vec->elementAt(i);
         if (sp && !strcmp(sp->getPoolName(), s)) {
            ret = sp;
            vec->removeElementAt(i);
            break;
         }
      }
      deleteStoragePoolVector(vec);
   }
   
   return ret;
}

StoragePool* getStoragePoolById(long long id) {
   javaenv->ExceptionClear();
  
   jobject spJ = NULL;
   
   spJ = javaenv->CallObjectMethod(jdropbox, 
                                   getStoragePoolInstance_methid, 
                                   (jlong)id, 0);
                                   
   if (spJ == NULL) return NULL;
   
   StoragePool * sp = NULL;
   if (!exceptionOccurred()) {
      sp = getStoragePoolFromJavaObject(spJ);
   }
   
   javaenv->DeleteLocalRef(spJ);

   return sp;
}


/*
** Query Trash, Inbox, Outbox, Drafts
*/
MYDIR* myquerypackages(const char* dirowner, PathInfo *pinfo) {
   MYDIR *mydir = NULL;
    
   javaenv->ExceptionClear();
  
   jobject enumer = NULL;
   
  // If we have a packagename, hone the search 
   if (*pinfo->pack) {
     // We can only use up to any _id_  as duplicate names
     //  will come in here as name_id_123 and name_id_124 (etc). 
      char lpath[1024]; 
      strcpy(lpath, pinfo->pack);
      char* underbarp = strstr(lpath, "_id_");
      if (underbarp) *underbarp = '\0';
      jstring nameJ = javaenv->NewStringUTF(lpath);
      enumer = javaenv->CallObjectMethod(jdropbox, 
                                         listInOutSandBoxName_methid, 
                                         (jint)pinfo->topdirnum, nameJ, 0);
      javaenv->DeleteLocalRef(nameJ);
   } else {
      enumer = javaenv->CallObjectMethod(jdropbox, 
                                         listInOutSandBox_methid, 
                                         (jint)pinfo->topdirnum, 0);
   }
   
   if (!exceptionOccurred()) {
   
      char path[1024];
      sprintf(path, "/%s", pinfo->topdir);
      mydir = new MYDIR(dirowner, path);
      mydir->setCompany(companyName());      
      
     // Add . and ..  .. if we don't add these some sftp clients core dump!
      struct stat stats;
      memset(&stats, 0, sizeof stats);
                   
      struct timeb t;
      ftime(&t);
      stats.st_ctime  = t.time;
      stats.st_atime  = t.time;
      stats.st_mtime  = t.time;
      stats.st_size   = 555;
      stats.st_uid    = 1;
      stats.st_gid    = 1;
      stats.st_mode   = 0755 | _S_IFDIR;
                   
      MYDIRENTRY* mydirent = new MYDIRENTRY(dirowner, path, ".", stats);
      mydirent->setId(0L);
      mydirent->setCompany(company);
      mydir->addEntry(mydirent);
      
      mydirent = new MYDIRENTRY(dirowner, path, "..", stats);
      mydirent->setId(0L);
      mydirent->setCompany(company);
      mydir->addEntry(mydirent);
   
      if (enumer) {
      
            
         while(!exceptionOccurred() && 
               javaenv->CallBooleanMethod(enumer, 
                                          Enum_hasMoreElements_methid, 0)){
            
            jobject tobj = javaenv->CallObjectMethod(enumer, 
                                                     Enum_nextElement_methid, 
                                                     0);
            jstring nameJ  = (jstring)javaenv->CallObjectMethod(tobj,
                                                                PI_getPackageName_methid, 
                                                                0);
            jstring ownerJ = (jstring)javaenv->CallObjectMethod(tobj,
                                                                PI_getPackageOwner_methid, 
                                                                0);
            jstring companyJ = (jstring)javaenv->CallObjectMethod(tobj,
                                                                  PI_getPackageCompany_methid, 
                                                                  0);
#ifdef SOA
            jstring descJ = (jstring)javaenv->CallObjectMethod(tobj,
                                                               PI_getPackageDescription_methid, 
                                                               0);
#endif
            long long packid  = javaenv->CallLongMethod(tobj,
                                                        PI_getPackageId_methid, 
                                                        0);
            long long size  = javaenv->CallLongMethod(tobj, 
                                                      PI_getPackageSize_methid, 
                                                      0);
            long long expire = javaenv->CallLongMethod(tobj, 
                                                       PI_getPackageExpiration_methid, 
                                                       0);
            long long created= javaenv->CallLongMethod(tobj, 
                                                       PI_getPackageCreation_methid, 
                                                       0);
            long long committed= javaenv->CallLongMethod(tobj, 
                                                         PI_getPackageCommitted_methid, 
                                                         0);
            jbyte pflags = javaenv->CallByteMethod(tobj, 
                                                PI_getPackageFlags_methid, 
                                                0);
            
            long long poolid = javaenv->CallLongMethod(tobj, 
                                                         PI_getPackagePoolId_methid, 
                                                         0);
            jboolean z=false;
            const char* name    = javaenv->GetStringUTFChars(nameJ, &z);
            const char* owner   = javaenv->GetStringUTFChars(ownerJ, &z);
            const char* company = javaenv->GetStringUTFChars(companyJ, &z);
#ifdef SOA
            const char* desc    = javaenv->GetStringUTFChars(descJ, &z);
#endif
            
            memset(&stats, 0, sizeof stats);
            stats.st_size   = size;
            stats.st_ctime  = expire/1000;
            
           // Can't do expire time on dir, otherwise it won't refresh
           //  for some sftp clients (they use the m/a time to determine they
           //  already have the latest info)
           //
           // Actually, we have decided to do creation time on sent/inbox
           //  packages, and current time on all other dirs
#ifdef DOEXPIRETIME
            stats.st_atime  = expire/1000;
            stats.st_mtime  = stats.st_atime;
#else
            
           // If DRAFTS, dirs are all current time, 
            if (pinfo->topdirnum == DRAFTS_N) {
               stats.st_atime  = t.time;
               stats.st_mtime  = t.time;
            } else {
               
              // else, INBOX/SENT, package dir is Commit time
               stats.st_atime  = committed/1000;
               stats.st_mtime  = stats.st_atime;
            }
#endif
            stats.st_uid    = 1;
            stats.st_gid    = 1;
            stats.st_mode   = 0755 | _S_IFDIR;
            
            mydirent = new MYDIRENTRY(owner, path, name, stats);
            
            mydirent->setId(packid);
            mydirent->setPackageFlags(pflags);
            mydirent->setPackagePoolId(poolid);
            mydirent->setCompany(company);
#ifdef SOA
            mydirent->setDescription(desc);
#endif
            mydir->addEntry(mydirent);
            
            javaenv->ReleaseStringUTFChars(nameJ,    name);
            javaenv->ReleaseStringUTFChars(ownerJ,   owner);
            javaenv->ReleaseStringUTFChars(companyJ, company);
            
#ifdef SOA
            javaenv->ReleaseStringUTFChars(descJ, desc);
            javaenv->DeleteLocalRef(descJ);
#endif
            
            javaenv->DeleteLocalRef(companyJ);
            javaenv->DeleteLocalRef(ownerJ);
            javaenv->DeleteLocalRef(nameJ);
            javaenv->DeleteLocalRef(tobj);
         }
         
         javaenv->DeleteLocalRef(enumer);
      }
   }
      
   return mydir;
}

/*
** Query package contents
*/
MYDIRENTRY* myquerypackage(PathInfo *pinfo) {

   MYDIR *mydir = myquerypackages("dontcare", pinfo);
   
   if (exceptionOccurred() || !mydir) return NULL;
   
  // Search for our boy
   MYDIRENTRY *dp = NULL;
   while((dp = mydir->readDir())) {
      if (!strcmp(dp->getName(), pinfo->pack)) {
         break;
      }
      delete dp;
   }
   
   delete mydir;
   
   return dp;
}

#ifdef R711
/*
** Query package companies
**
** Returns MYDIR if worked (empty or otherwise), else null pointer if failed
*/
Vector* queryPackageCompanies(MYDIRENTRY* packageEnt) {

   Vector *ret = NULL;

   javaenv->ExceptionClear();
   
   jobject vecJ = javaenv->CallObjectMethod(jdropbox, 
                                            queryPackageAclCompanies_methid, 
                                            (jlong)packageEnt->getId(), 
                                            0);
                                              
   if (!exceptionOccurred()) {
   
      jobject enumer = javaenv->CallObjectMethod(vecJ, Vec_elements_methid, 0); 
      
      if (!exceptionOccurred() && enumer) {
      
         ret = new Vector();
      
         while(!exceptionOccurred() && 
               javaenv->CallBooleanMethod(enumer, 
                                          Enum_hasMoreElements_methid, 0)){
                                      
            jstring compJ = (jstring)javaenv->CallObjectMethod(enumer, 
                                                               Enum_nextElement_methid, 
                                                               0);
            jboolean z=false;
            const char* company = javaenv->GetStringUTFChars(compJ, &z);
                        
            char* retcomp = new char[strlen(company)+1];
            strcpy(retcomp, company);
            ret->add(retcomp);
            
            javaenv->ReleaseStringUTFChars(compJ, company);
            javaenv->DeleteLocalRef(compJ);
         }
         
         if (exceptionOccurred()) {
            delete ret;
            ret = NULL;
         }
         
         javaenv->DeleteLocalRef(enumer);
      }
      javaenv->DeleteLocalRef(vecJ);
   }
      
   return ret;
}
#endif


/*
** Query package contents
*/
MYDIR* myquerypackagecontents(PathInfo *pinfo, int dohierarchy) {

   MYDIRENTRY *dp = myquerypackage(pinfo);
   
   if (exceptionOccurred() || !dp) return NULL;
   
   char tn[1024];
   if (dohierarchy && *pinfo->file) {
      sprintf(tn, "/%s/%s/%s", pinfo->topdir, pinfo->pack, pinfo->file);
   } else {
      sprintf(tn, "/%s/%s", pinfo->topdir, pinfo->pack);
   }
   MYDIR* mydir = new MYDIR(dp->getOwner(), tn);
   mydir->setCompany(dp->getCompany());
   mydir->setPackageFlags(dp->getPackageFlags());
   mydir->setPackagePoolId(dp->getPackagePoolId());
   
   struct timeb t;
   ftime(&t);
   
   {
     // Add . and ..  .. if we don't add these some sftp clients core dump!
      struct stat stats;
      memset(&stats, 0, sizeof stats);
                   
      stats.st_ctime  = t.time;
      stats.st_atime  = t.time;
      stats.st_mtime  = t.time;
      stats.st_size   = 555;
      stats.st_uid    = 1;
      stats.st_gid    = 1;
      stats.st_mode   = 0755 | _S_IFDIR;
                   
      MYDIRENTRY* mydirent = new MYDIRENTRY(mydir->getOwner(), tn, ".", stats);
      mydirent->setCompany(dp->getCompany());
      mydirent->setId(dp->getId());
      mydirent->setPackageFlags(dp->getPackageFlags());
      mydirent->setPackagePoolId(dp->getPackagePoolId());
      
      mydir->addEntry(mydirent);
      
      if (dohierarchy && *pinfo->file) {
         mydirent = new MYDIRENTRY(mydir->getOwner(), tn, "..", stats);
         mydirent->setCompany(dp->getCompany());
         mydirent->setId(dp->getId());
         mydirent->setPackageFlags(dp->getPackageFlags());
         mydirent->setPackagePoolId(dp->getPackagePoolId());
         
      } else {
         mydirent = new MYDIRENTRY(userName(), tn, "..", stats);
         mydirent->setCompany(company);
         mydirent->setId(0L);
      }
      mydir->addEntry(mydirent);
   }
   
   
  /* Our answer is good ... if we are doing hier, then assume bad, unless
      we have no file portion specified, then since package exists, we are good
                                                      */
   int isOK = 1;
   if (dohierarchy && *pinfo->file) isOK = 0;
   
   if ((pinfo->topdirnum == SENT_N || pinfo->topdirnum == DRAFTS_N) &&
       (!dohierarchy || !*pinfo->file)) {
debug("mqpc: at top, adding ACCESS"); 
     // Add access directory
      struct stat stats = dp->getStats();
      stats.st_size = 0;
      
     // Tag access entry with current time
      stats.st_atime = t.time;
      stats.st_mtime = t.time;
      stats.st_ctime = t.time;
   
      MYDIRENTRY *accessEntry = new MYDIRENTRY(dp->getOwner(), tn,
                                               ACCESSDIR, stats);
      accessEntry->setCompany(dp->getCompany());
      accessEntry->setId(dp->getId());
      accessEntry->setPackageFlags(dp->getPackageFlags());
      accessEntry->setPackagePoolId(dp->getPackagePoolId());
      
      mydir->addEntry(accessEntry);
   }
   
  // Add #INFO# if we are in inbox, and are at the top
  // 5/5/04 - Now, also add for drafts and sent, but will have different 
  //          content
   if (pinfo->topdirnum >= TRASH_N && pinfo->topdirnum <= DRAFTS_N &&
       pinfo->hidx == 2) {
debug("mqpc: at top, adding INFO"); 
     // Add access directory
      struct stat stats = dp->getStats();
      stats.st_size = 0;
      
     // Tag access entry with current time
      stats.st_atime = t.time;
      stats.st_mtime = t.time;
      stats.st_ctime = t.time;
   
      MYDIRENTRY *infoEntry = new MYDIRENTRY(dp->getOwner(), tn,
                                             INFODIR, stats);
      infoEntry->setCompany(dp->getCompany());
      infoEntry->setId(dp->getId());
      infoEntry->setPackageFlags(dp->getPackageFlags());
      infoEntry->setPackagePoolId(dp->getPackagePoolId());
      
      mydir->addEntry(infoEntry);
   }
   
  // Make sure Directory knows its package id
   mydir->setId(dp->getId());
   mydir->setPackageFlags(dp->getPackageFlags());
   mydir->setPackagePoolId(dp->getPackagePoolId());

   
   jobject enumer = javaenv->CallObjectMethod(jdropbox, 
                                              listPackageContents_methid, 
                                              (jlong)dp->getId(), 0);
                                              
   int slenfile = strlen(pinfo->file);
   
   if (!exceptionOccurred() && enumer) {
      
      while(!exceptionOccurred() && 
            javaenv->CallBooleanMethod(enumer, 
                                      Enum_hasMoreElements_methid, 0)){
                                      
         jobject tobj = javaenv->CallObjectMethod(enumer, 
                                                  Enum_nextElement_methid, 
                                                  0);
         jstring nameJ  = (jstring)javaenv->CallObjectMethod(tobj,
                                                   FI_getFileName_methid, 
                                                   0);
         jboolean z=false;
         const char* name    = javaenv->GetStringUTFChars(nameJ, &z);
         const char* fname   = name;
         
        /*
        ** If we are doing hierarchy, only keep those which start with 
        **  pinfo->file, and which then have a slash. Keep only that next 
        **  segment. If its not a terminating segment, then its a file, 
        **  otherwise its a dir.
        */
         int includeit = 1;
         if (dohierarchy) {
debug("mqpc: doing hierarchy, check for match"); 
            includeit = 0;
            const char* nptr = 0;
            
           /* If at the package level, */
            if (!*pinfo->file) {
               nptr = name;
debug("mqpc: package level %s", tn); 
            } else if (!strncmp(pinfo->file, name, slenfile) && 
                       name[slenfile] == '/') {
               nptr = name + slenfile + 1;
debug("mqpc: lower level %s: %s", tn, nptr); 
            }
            
           /* If we have a match ... */
            if (nptr) {
            
              // At this point, we have validated that pinfo->file is good
               isOK = 1;
               
               char* slashptr = strchr(nptr, '/');
               if (!slashptr) {
                 // Its a file, include it
                  includeit = 1;
                  fname = nptr;
               } else {
                 // Its an interm path, include it as a dir
                  struct stat stats = dp->getStats();
                  stats.st_size = 0;
                  
                 // Tag pseduo dirs with current time if in DRAFTS
                  if (pinfo->topdirnum == DRAFTS_N) {
                     stats.st_atime = t.time;
                     stats.st_mtime = t.time;
                     stats.st_ctime = t.time;
                  }
                  
                  char subname[1024];
                  strncpy(subname, nptr, slashptr-nptr);
                  subname[slashptr-nptr] = '\0';
                  MYDIRENTRY* mydirent = new MYDIRENTRY(mydir->getOwner(), 
                                                        tn, subname, stats);
                  mydirent->setCompany(dp->getCompany());
                  mydir->addEntry(mydirent, 1);
debug("mqpc: Add dir %s: %s", tn, subname); 
               }
            }
         }
         
         if (includeit) {
            jstring md5J  = (jstring)javaenv->CallObjectMethod(tobj,
                                                   FI_getFileMD5_methid, 
                                                   0);
            const char* md5     = javaenv->GetStringUTFChars(md5J, &z);
         
            long long fileid  = javaenv->CallLongMethod(tobj,
                                                        FI_getFileId_methid, 
                                                        0);
            long long size  = javaenv->CallLongMethod(tobj, 
                                                      FI_getFileSize_methid, 
                                                      0);
            long long creation = javaenv->CallLongMethod(tobj, 
                                                    FI_getFileCreation_methid, 
                                                      0);
            unsigned char status = 
               javaenv->CallByteMethod(tobj, FI_getFileStatus_methid, 0);
            
            struct stat stats;
            stats = dp->getStats();
            stats.st_size   = size;
            
            int ugid = 1;
            if (status != 10) ugid = 2;
            stats.st_uid    = ugid;
            stats.st_gid    = ugid;
            stats.st_mode   = 0644 | _S_IFREG;
            
           // The ctime is set to the Expiration time of package always
            if (creation == 0) {
               stats.st_atime  = stats.st_ctime;
               stats.st_mtime  = stats.st_ctime;
            } else {
               stats.st_atime  = creation/1000;
               stats.st_mtime  = stats.st_atime;
            }
            
            MYDIRENTRY* mydirent = new MYDIRENTRY(mydir->getOwner(), tn, 
                                                  fname, stats);
            mydirent->setId(fileid);
            mydirent->_setPId(dp->getId());
            mydirent->_setMD5(md5);
            mydirent->setCompany(dp->getCompany());
            mydirent->setPackageFlags(dp->getPackageFlags());
            mydirent->setPackagePoolId(dp->getPackagePoolId());

            mydir->addEntry(mydirent);
            
            javaenv->ReleaseStringUTFChars(md5J,     md5);
            javaenv->DeleteLocalRef(md5J);
            
debug("mqpc: Add file %s: %s", tn, name); 
         }
            
         
         javaenv->ReleaseStringUTFChars(nameJ,    name);
            
         javaenv->DeleteLocalRef(nameJ);
         javaenv->DeleteLocalRef(tobj);
      }
   }
   
   if (enumer) javaenv->DeleteLocalRef(enumer);
      
      
  // Search for pretend directories which match this p->file ... add any
  //  pretend contents
   if (Dropbox::dropbox && dohierarchy) {
      
debug("mqpc: Add any MadeDirs %s", tn); 
      MadeDirectories *madeDirs = 
         Dropbox::dropbox->getDirectories(mydir->getId());
         
      Link *link = (Link*)((madeDirs)?madeDirs->ll.get_head():NULL);
      while(link) {
      
         MYDIRENTRY *dirent = (MYDIRENTRY*)link->data;
         
         char name[1024];
         *name = '\0';
         
        // It definitely has at least 2 slashes (/inbox/pack) ... skip them
         char* skipptr=strchr(strchr(dirent->getDirectory()+1, '/')+1, '/');
         if (skipptr) {
            strcpy(name, skipptr+1);
            strcat(name, "/");
         }
         strcat(name, dirent->getName());
         
        /*
        ** We are doing hierarchy, and looking for MadeDirectories which
        **  are appropriate for this query. Build the flat name for this 
        **  dirent, and compare to pinfo->file ... If its found, then we
        **  at least have a valid query. If its found, AND it has a child
        **  (ie. is followed by a slash), then collect that info for return.
        */
         const char* nptr = 0;
            
        /* If at the package level, */
         if (!*pinfo->file) {
            nptr = name;
         } else if (!strncmp(pinfo->file, name, slenfile)) {
            if (name[slenfile] == '/') {
               nptr = name + slenfile + 1;
            } else if (name[slenfile] == '\0') {
               isOK = 1;  // Its a match, but is a terminator
            }
         }
         
        /* If we have a match ... */
         if (nptr) {
            
           // At this point, we have validated that pinfo->file is good
            isOK = 1;
            
           // If no next slash, then its a terminating directory. 
           //  Has no children
            char* slashptr = strchr(nptr, '/');
           // Its an interm path, include it as a dir
            struct stat stats = dp->getStats();
            stats.st_size = 0;
            
            char subname[1024];
            if (slashptr) {
               strncpy(subname, nptr, slashptr-nptr);
               subname[slashptr-nptr] = '\0';
            } else {
               strcpy(subname, nptr);
            }
            
           // Tag pseduo dirs with current time if in DRAFTS
            if (pinfo->topdirnum == DRAFTS_N) {
               stats.st_atime = t.time;
               stats.st_mtime = t.time;
               stats.st_ctime = t.time;
            }
            
            MYDIRENTRY* mydirent = new MYDIRENTRY(mydir->getOwner(), 
                                                  tn, subname, stats);
            mydirent->setCompany(mydir->getCompany());
            mydir->addEntry(mydirent, 1);
debug("mqpc: Add MadeDir  %s: %s", tn, subname); 
         }
         
         link = link->right;
      }
   }
      
  // If path did not map to anything, no good.
   if (!isOK) {
      delete mydir;
      mydir = NULL;
   }
   
   delete dp;
   
   return mydir;
}

/*
** Query file in package
*/
MYDIRENTRY* myqueryfile(PathInfo *pinfo) {

   MYDIR *mydir = myquerypackagecontents(pinfo, 0);
   
   if (exceptionOccurred() || !mydir) return NULL;
   
  // Search for our boy
   MYDIRENTRY *dp = NULL;
   while((dp = mydir->readDir())) {
   
     /* If its a dead on name match, and its a file (not a made up direntry) */
      if (!strcmp(dp->getName(), pinfo->file) && 
          (dp->getStats().st_mode & _S_IFREG)) {
          
         break;
      }
      delete dp;
   }
   
  // Set the packageid in the file's dirent
   if (dp) dp->_setPId(mydir->getId());
   
   delete mydir;
   
   return dp;
}

/*
** Set Package Description
*/
int mysetdescription(long long packid, const char* desc) {

   javaenv->ExceptionClear();
   
   jstring descJ = javaenv->NewStringUTF(desc);
   
   jboolean ret = javaenv->CallBooleanMethod(jdropbox,
                                             setPackageDescription_methid, 
                                             (jlong)packid,
                                             descJ,
                                             0);
   javaenv->DeleteLocalRef(descJ);
                                              
   return (int)(ret && !exceptionOccurred())?0:-1;
}

/*
** Query Acls
*/
MYDIR* myqueryacls(PathInfo *pinfo, MYDIRENTRY* packageEnt) {

   MYDIR* ret = NULL;
   
   javaenv->ExceptionClear();
   
   jobject enumer = javaenv->CallObjectMethod(jdropbox, 
                                              queryAcls_methid, 
                                              (jlong)packageEnt->getId(), 
                                              0);
                                              
   char tn[1024];
   sprintf(tn, "/%s/%s/%s", pinfo->topdir, pinfo->pack, pinfo->file);
   
   if (!exceptionOccurred()) {
   
      ret = new MYDIR(packageEnt->getOwner(), tn);
      ret->setId(packageEnt->getId());
      ret->setCompany(packageEnt->getCompany());
      ret->setPackageFlags(packageEnt->getPackageFlags());
      ret->setPackagePoolId(packageEnt->getPackagePoolId());

      
      struct stat stats;
      stats = packageEnt->getStats();
      
      MYDIRENTRY *mydirent = new MYDIRENTRY(packageEnt->getOwner(), tn, ".", stats);
      mydirent->setId(packageEnt->getId());
      mydirent->setPackageFlags(packageEnt->getPackageFlags());
      mydirent->setPackagePoolId(packageEnt->getPackagePoolId());

      mydirent->setCompany(packageEnt->getCompany());
      ret->addEntry(mydirent);
      
      struct timeb t;
      ftime(&t);
      stats.st_atime  = t.time;
      stats.st_mtime  = t.time;
      stats.st_size   = 555;
      stats.st_uid    = 1;
      stats.st_gid    = 1;
      stats.st_mode   = 0755 | _S_IFDIR;
      
      mydirent = new MYDIRENTRY(userName(), tn, "..", stats);
      mydirent->setId(0L);
      mydirent->setCompany(companyName());
      ret->addEntry(mydirent);
      
      if (enumer) {
      
      
         while(!exceptionOccurred() && 
               javaenv->CallBooleanMethod(enumer, 
                                          Enum_hasMoreElements_methid, 0)){
                                      
            jstring aclJ = (jstring)javaenv->CallObjectMethod(enumer, 
                                                              Enum_nextElement_methid, 
                                                              0);
            jboolean z=false;
            const char* acl    = javaenv->GetStringUTFChars(aclJ, &z);
                        
            mydirent = new MYDIRENTRY(packageEnt->getOwner(), tn, acl, stats);
            mydirent->setId(packageEnt->getId());
            mydirent->setPackageFlags(packageEnt->getPackageFlags());
            mydirent->setPackagePoolId(packageEnt->getPackagePoolId());

            mydirent->setCompany(packageEnt->getCompany());
            ret->addEntry(mydirent);
                        
            javaenv->ReleaseStringUTFChars(aclJ,    acl);
            
            javaenv->DeleteLocalRef(aclJ);
         }
         
         javaenv->DeleteLocalRef(enumer);
      }
   }
      
   return ret;
}

/*
** Delete file from Package
*/
int mydeletefilefrompackage(long long packid, long long fileid) {

   javaenv->ExceptionClear();
   
   jboolean ret = javaenv->CallBooleanMethod(jdropbox, 
                                             deleteFileFromPackage_methid, 
                                             (jlong)packid,
                                             (jlong)fileid,
                                             0);
                                              
   return (int)(ret && !exceptionOccurred())?0:-1;
}

/*
** Add ACL to Package
*/
int myaddacl(long long packid, const char* acl) {

   javaenv->ExceptionClear();
   
   jstring aclJ = javaenv->NewStringUTF(acl);
   
   jboolean ret = javaenv->CallBooleanMethod(jdropbox, 
                                             addAcl_methid, 
                                             (jlong)packid,
                                             aclJ,
                                             0);
   javaenv->DeleteLocalRef(aclJ);
                                              
   return (int)(ret && !exceptionOccurred())?0:-1;
}

/*
** Remove ACL from Package
*/
int myremoveacl(long long packid, const char* acl) {

   javaenv->ExceptionClear();
   
   jstring aclJ = javaenv->NewStringUTF(acl);
   
   jboolean ret = javaenv->CallBooleanMethod(jdropbox, 
                                             removeAcl_methid, 
                                             (jlong)packid,
                                             aclJ,
                                             0);
   javaenv->DeleteLocalRef(aclJ);
                                              
   return (int)(ret && !exceptionOccurred())?0:-1;
}

/*
** Create a new package
*/
int mycreatepackage(const char* pack) {

   javaenv->ExceptionClear();
   
   jstring packJ = javaenv->NewStringUTF(pack);
   
   jboolean ret = javaenv->CallBooleanMethod(jdropbox, 
                                             createPackage_methid, 
                                             packJ,
                                             storagepoolForCreate,
#ifdef SOA
                                            // if itar on, set it
                                             itarPackageCreate?ITAR_FLAG:0,
                                             itarPackageCreate?ITAR_FLAG:0,
#endif
                                             0);
   javaenv->DeleteLocalRef(packJ);
                                              
   return (int)(ret && !exceptionOccurred())?0:-1;
}

/*
** Add ACL to Package
*/
int mycommitpackage(long long packid) {

   javaenv->ExceptionClear();
   
   jboolean ret = javaenv->CallBooleanMethod(jdropbox, 
                                             commitPackage_methid, 
                                             (jlong)packid,
                                             0);
   return (int)(ret && !exceptionOccurred())?0:-1;
}

/*
** Delete a package
*/
int mydeletepackage(long long packid) {

   javaenv->ExceptionClear();
   
   jboolean ret = javaenv->CallBooleanMethod(jdropbox, 
                                             deletePackage_methid, 
                                             (jlong)packid,
                                             0);
                                             
   return (int)(ret && !exceptionOccurred())?0:-1;
}

/*
** Mark a package
*/
int mymarkpackage(long long packid, int markOrUnmark) {

   javaenv->ExceptionClear();
   
   jboolean ret = javaenv->CallBooleanMethod(jdropbox, 
                                             markPackage_methid, 
                                             (jlong)packid,
                                             (jboolean)markOrUnmark,
                                             0);
                                             
   return (int)(ret && !exceptionOccurred())?0:-1;
}

/*
** Start upload of a file
*/
jobject mystartuploadfile(long long packid, const char* file) {

   javaenv->ExceptionClear();
   
   jstring fileJ = javaenv->NewStringUTF(file);
   
   jobject ret = javaenv->CallObjectMethod(jdropbox, 
                                           uploadFile_methid, 
                                           (jlong)packid,
                                           fileJ,
                                           0);
   javaenv->DeleteLocalRef(fileJ);
                                              
   return (jobject)(ret && !exceptionOccurred())?ret:NULL;
}

/*
** Start download of a file
*/
jobject mystartdownloadfile(long long packid, long long fileid) {

   javaenv->ExceptionClear();
   
   jobject ret = javaenv->CallObjectMethod(jdropbox, 
                                           downloadFile_methid, 
                                           (jlong)packid,
                                           (jlong)fileid,
                                           0);
                                              
   return (jobject)(ret && !exceptionOccurred())?ret:NULL;
}

/*
** Start download of a package
*/
jobject mystartdownloadpackage(long long packid, const char* encoding) {

   javaenv->ExceptionClear();
   
   jstring encodingJ = javaenv->NewStringUTF(encoding);
   
   jobject ret = javaenv->CallObjectMethod(jdropbox, 
                                           downloadPackage_methid, 
                                           (jlong)packid,
                                           encodingJ,
                                           0);
                                           
   javaenv->DeleteLocalRef(encodingJ);
                                              
   return (jobject)(ret && !exceptionOccurred())?ret:NULL;
}


/*
** Allow query of operation size
*/
long mygetoperationsize(jobject jobj) {

   TRACE("mygetopsize");
   
   javaenv->ExceptionClear();
   
   long ret = javaenv->CallLongMethod(jobj,
                                      Operation_getToXfer_methid, 
                                      jobj,
                                      0);
                                           
   TRACE("mygetopsize: returning");
   
   return (ret >= 0 && !exceptionOccurred())?ret:-1;
}

/*
** Download data from file
*/
int myfsread(jobject jobj, char* buf, int ofs, int len) {

   TRACE("myfsread: enter len=%d", len);
   javaenv->ExceptionClear();
   
   if (len > 50000) len = 50000;
   
   jbyteArray arrJ = javaenv->NewByteArray(len);
   
   TRACE("myfsread: calling java method");
   
   int ret = javaenv->CallIntMethod(jdropbox,
                                    readFileData_methid, 
                                    jobj,
                                    (jobject)arrJ,
                                    (jint)0,
                                    (jint)len,
                                    0);
   TRACE("myfsread: return from java method");
                                           
   javaenv->GetByteArrayRegion(arrJ, 0, len, (jbyte*)(buf+ofs));
   
   javaenv->DeleteLocalRef(arrJ);
                                              
   TRACE("myfsread: returning");
   
   return (ret >= 0 && !exceptionOccurred())?ret:-1;
}

/*
** Upload data to file
*/
int myfswrite(jobject jobj, char* buf, int ofs, int len) {

   javaenv->ExceptionClear();
   
   TRACE("myfswrite: enter len=%d", len);
   
   int inlen = len;
   
   int tlen = (len > 50000) ? 50000 : len;
   jbyteArray arrJ = javaenv->NewByteArray(tlen);
   
   while(len > 0) {
      tlen = (len > 50000) ? 50000 : len;
      debug("myfswrite: inlen=%d len=%d tlen=%d", inlen, len, tlen);
      javaenv->SetByteArrayRegion(arrJ, 0, tlen, (jbyte*)(buf+ofs));
      debug("myfswrite: calling Java");
      javaenv->CallVoidMethod(jdropbox,
                              writeFileData_methid, 
                              jobj,
                              (jobject)arrJ,
                              (jint)0,
                              (jint)tlen,
                              0);
      debug("myfswrite: back");
      if (exceptionOccurred()) break;
      len -= tlen;
      ofs += tlen;
   }
   
   int exOccurred = exceptionOccurred() != 0;
                                              
   javaenv->DeleteLocalRef(arrJ);
   
   TRACE("myfswrite: returning");
      
   return (!exOccurred)?inlen:-1;
}

/*
** Download data from file
*/
int myfsclose(jobject jobj) {

   javaenv->ExceptionClear();
   
   jboolean ret = javaenv->CallBooleanMethod(jdropbox,
                                             closeOperation_methid, 
                                             jobj,
                                             0);
                                           
   javaenv->DeleteLocalRef(jobj);
                                              
   return (ret && !exceptionOccurred())?0:-1;
}

/*
** Create Group
*/
int mycreategroup(const char* v) {

   javaenv->ExceptionClear();
   
   jstring grpnameJ = javaenv->NewStringUTF(v);
   
   javaenv->CallBooleanMethod(jdropbox, createGroup_methid, grpnameJ, 0);
                                           
   javaenv->DeleteLocalRef(grpnameJ);
                                              
   return !exceptionOccurred()?0:-1;
}

/*
** Remove Group
*/
int myremovegroup(const char* v) {

   javaenv->ExceptionClear();
   
   jstring grpnameJ = javaenv->NewStringUTF(v);
   
   javaenv->CallBooleanMethod(jdropbox, deleteGroup_methid, grpnameJ, 0);
                                           
   javaenv->DeleteLocalRef(grpnameJ);
                                              
   return !exceptionOccurred()?0:-1;
}

/*
** Add to Member/Access list of group
*/
int myaddmemberaccess(const char* g, const char* u, 
                      jboolean memberOrAccess) {

   javaenv->ExceptionClear();
   
   jstring grpnameJ  = javaenv->NewStringUTF(g);
   jstring usernameJ = javaenv->NewStringUTF(u);
   
   javaenv->CallBooleanMethod(jdropbox, addGroupMemberAccess_methid, 
                              grpnameJ, usernameJ, memberOrAccess, 0);
                                           
   javaenv->DeleteLocalRef(grpnameJ);
   javaenv->DeleteLocalRef(usernameJ);
                                              
   return !exceptionOccurred()?0:-1;
}

/*
** Add to Member/Access list of group
*/
int myremovememberaccess(const char* g, const char* u, 
                         jboolean memberOrAccess) {

   javaenv->ExceptionClear();
   
   jstring grpnameJ  = javaenv->NewStringUTF(g);
   jstring usernameJ = javaenv->NewStringUTF(u);
   
   javaenv->CallBooleanMethod(jdropbox, removeGroupMemberAccess_methid, 
                              grpnameJ, usernameJ,  memberOrAccess, 0);
                                           
   javaenv->DeleteLocalRef(grpnameJ);
   javaenv->DeleteLocalRef(usernameJ);
                                              
   return !exceptionOccurred()?0:-1;
}

/*
** Set Group Attrs
*/
int mysetgroupattributes(const char* g, const char* v, jboolean visOrList) {

   javaenv->ExceptionClear();
   
   jbyte jb = -1;
   jboolean doit = JNI_TRUE;
   
   if      (!strcmp(v, ALL))    jb   = GROUP_SCOPE_ALL;
   else if (!strcmp(v, MEMBER)) jb   = GROUP_SCOPE_MEMBER;
   else if (!strcmp(v, OWNER))  jb   = GROUP_SCOPE_OWNER;
   else                         doit = JNI_FALSE;
   
   if (doit) {
      jstring grpnameJ  = javaenv->NewStringUTF(g);
      javaenv->CallBooleanMethod(jdropbox, setGroupAttributes_methid, 
                                 grpnameJ, jb,  visOrList, 0);
                                           
      javaenv->DeleteLocalRef(grpnameJ);
                                              
      return !exceptionOccurred()?0:-1;
   }
   return -1;
}

/*
** Get global options
*/
Options* mygetoptions() {

   javaenv->ExceptionClear();
   
   Options *options = 0;
   
   jobject hashJ = javaenv->CallObjectMethod(jdropbox, getOptions_methid, 0);
   if (!exceptionOccurred() && hashJ != NULL) {
   
      options = new Options();
      
      jobject enumer = 
         javaenv->CallObjectMethod(hashJ,
                                   Hash_keys_methid, 0); 
      if (!exceptionOccurred() && enumer) {
                     
         while(!exceptionOccurred() && 
               javaenv->CallBooleanMethod(enumer, 
                                          Enum_hasMoreElements_methid, 
                                          0)){
            jstring keyJ = (jstring)
               javaenv->CallObjectMethod(enumer, 
                                         Enum_nextElement_methid, 
                                         0);
            jboolean z=false;
            const char* k = javaenv->GetStringUTFChars(keyJ, &z);
            
            jstring valJ = (jstring)
               javaenv->CallObjectMethod(hashJ, 
                                         Hash_get_methid, 
                                         keyJ,
                                         0);
            const char* v = javaenv->GetStringUTFChars(valJ, &z);
            
           // We don't support the filter options, so filter them out ;-)
            if (strcmp(k, "FilterComplete") && strcmp(k, "FilterMarked")) {
               options->put(k, v);
            }
            
            javaenv->ReleaseStringUTFChars(valJ, v);
            javaenv->ReleaseStringUTFChars(keyJ, k);
            javaenv->DeleteLocalRef(valJ);
            javaenv->DeleteLocalRef(keyJ);
         }
         javaenv->DeleteLocalRef(enumer);
      }
      
      javaenv->DeleteLocalRef(hashJ);
      
      StoragePool *sp = getStoragePoolById(storagepoolForCreate);
      if (sp != 0) {
         options->put(OPT_STORAGEPOOL, sp->getPoolName());
         delete sp;
      } else {
         options->put(OPT_STORAGEPOOL, "UnknownPool");
      }
      options->put(OPT_STORAGEPOOLS, NULL);
      
#ifdef SOA
      options->put(OPT_ITARPACKAGECREATE, 
                   (char*)(itarPackageCreate?"true":"false"));
#endif
      
   }
   return options;
}

/*
** Set global option
*/
int mysetoption(const char* k, const char* v) {

   javaenv->ExceptionClear();
   
   if (!strcmp(k, OPT_STORAGEPOOL)) {
      StoragePool *sp = getStoragePoolByName(v);
      if (sp == 0) return -1;
      
      storagepoolForCreate = sp->getPoolId();
      delete sp;
      
      return 0;
#ifdef SOA
   } else if (!strcmp(k, OPT_ITARPACKAGECREATE)) {
      char lcl[6];
      int i;
      
      if (v == 0 || strlen(v) > 5) return -1;
      for(i=0; v[i]; i++) {
         lcl[i] = tolower(v[i]);
      }
      lcl[i] = 0;
      
      if      (!strcmp(lcl, "true"))  itarPackageCreate = 1;
      else if (!strcmp(lcl, "false")) itarPackageCreate = 0;
      else if (!strcmp(lcl, "on"))    itarPackageCreate = 1;
      else if (!strcmp(lcl, "off"))   itarPackageCreate = 0;
      else {
         logit("itarpackagecreate value is incorrect: %s", lcl);
         return -1;
      }
      
      return 0;
         
#endif
   } else {
      jstring keyJ = javaenv->NewStringUTF(k);
      jstring valJ = javaenv->NewStringUTF(v);
      
      jboolean worked = javaenv->CallBooleanMethod(jdropbox, setOption_methid, 
                                                   keyJ, valJ, 0);
      
      javaenv->DeleteLocalRef(keyJ);
      javaenv->DeleteLocalRef(valJ);
   
      return (!exceptionOccurred() && worked) ? 0 : -1;
   }
}

int mysetpackageexpiration(long packid, int exp) {

   jboolean worked = javaenv->CallBooleanMethod(jdropbox, 
                                                setPackageExpiration_methid, 
                                                (jlong)packid, (jlong)exp, 0);
   
   return (!exceptionOccurred() && worked) ? 0 : -1;
}


/*
** Set package flag
*/
int mysetpackageflag(long pkgid, int mask, int setOrReset) {

   javaenv->ExceptionClear();
   
   jboolean worked = 
      javaenv->CallBooleanMethod(jdropbox, setPackageFlags_methid, 
                                 (jlong)pkgid, (jint)mask, 
                                 (jint)(setOrReset?mask:0));
                                             
   return (!exceptionOccurred()) && worked ? 0 : -1;
}


/*
** Stat group ... Returns MYDIRENT of matching item, or NULL if no item
*/
MYDIRENTRY* mystatgroup(PathInfo *pinfo) {

   if (pinfo->topdirnum != GROUPS_N) return NULL;
   
   MYDIRENTRY *ret = NULL;
   
   struct stat stats;
   memset(&stats, 0, sizeof stats);
   
   javaenv->ExceptionClear();

   struct timeb t;
   ftime(&t);
   stats.st_ctime  = t.time;
   stats.st_atime  = t.time;
   stats.st_mtime  = t.time;
   stats.st_size   = 555;
   stats.st_uid    = 1;
   stats.st_gid    = 1;
   stats.st_mode   = 0755 | _S_IFDIR;
   
   char path[1024];
   sprintf(path, "%s", pinfo->fullpath);
         
  // Remove the final segment
   *strrchr(path,'/') = '\0';
   
   
  // If stating /groups
   if (pinfo->hidx == 1) {
      ret = new MYDIRENTRY(userName(), path, pinfo->hier[0], stats);
      ret->setId(0L);
      ret->setCompany(companyName());
      return ret;
   }
   
   int amo = 0;
   if (strcmp(pinfo->hier[1], ALL)         &&  ++amo &&
       strcmp(pinfo->hier[1], MODIFIABLE)  &&  ++amo &&
       strcmp(pinfo->hier[1], OWNED)) {
      return NULL;
   }
   
  // If stating /groups/ALL, MODIFIABLE, or OWNED
   if (pinfo->hidx == 2) {
      ret = new MYDIRENTRY(userName(), path, pinfo->hier[1], stats);
      ret->setId(0L);
      ret->setCompany(companyName());
      return ret;
   }
   
  // Check if group exists for me
   jstring grpnameJ = javaenv->NewStringUTF(pinfo->hier[2]);
   jobject tobj = javaenv->CallObjectMethod(jdropbox, listGroup_methid, 
                                            grpnameJ, 0); 
   javaenv->DeleteLocalRef(grpnameJ);
   
  // Did I get it?
   if (!exceptionOccurred() && tobj != NULL) {
   
      jstring nameJ  = 
         (jstring)javaenv->CallObjectMethod(tobj,
                                            GI_getGroupName_methid, 
                                            0);
      jstring ownerJ = 
         (jstring)javaenv->CallObjectMethod(tobj,
                                            GI_getGroupOwner_methid, 
                                            0);
      jstring companyJ = 
         (jstring)javaenv->CallObjectMethod(tobj,
                                            GI_getGroupCompany_methid, 
                                            0);
      jbyte list  = javaenv->CallByteMethod(tobj,
                                            GI_getGroupListability_methid, 
                                            0);
      jbyte visibility = javaenv->CallByteMethod(tobj,
                                                 GI_getGroupVisibility_methid, 
                                                 0);
      jboolean membersValid = 
         javaenv->CallBooleanMethod(tobj,
                                    GI_getGroupMembersValid_methid, 
                                    0);
      jboolean accessValid = 
         javaenv->CallBooleanMethod(tobj,
                                    GI_getGroupAccessValid_methid, 
                                    0);
                                                
      jboolean z=false;
      const char* name    = javaenv->GetStringUTFChars(nameJ, &z);
      const char* owner   = javaenv->GetStringUTFChars(ownerJ, &z);
      const char* company = javaenv->GetStringUTFChars(companyJ, &z);
      
      int addit = 0;
      switch(amo) {
         case 0: // ALL
            addit=1;
            break;
         case 1: // MODIFIABLE
            if (list != GROUP_SCOPE_NONE) {
               addit=1;
            }
            break;
         case 2: // OWNED
            if (!strcmp(userName(), owner)) {
               addit=1;
            }
            break;
         default:
            break;
      }
               
      if (addit) {
         
        // If they are asking about the group level ... done
         if (pinfo->hidx == 3) {
            ret = new MYDIRENTRY(owner, path, name, stats);
            ret->setId(0L);
            ret->setCompany(company);
         } else if (!strcmp(pinfo->hier[3], MEMBERS)) {
            if (membersValid) {
               if (pinfo->hidx == 4) {
                  ret = new MYDIRENTRY(owner, path, 
                                       pinfo->hier[pinfo->hidx-1], 
                                       stats);
                  ret->setId(0L);
                  ret->setCompany(company);
               } else if (pinfo->hidx == 5) {
                  jobject vecObj = 
                     javaenv->CallObjectMethod(tobj, 
                                               GI_getGroupMembers_methid, 0); 
   
                  
                  jstring memnameJ = javaenv->NewStringUTF(pinfo->hier[4]);
                  
                  if (javaenv->CallBooleanMethod(vecObj, 
                                                 Vec_contains_methid, 
                                                 memnameJ,
                                                 0)) {
                     
                     ret = new MYDIRENTRY(owner, path, 
                                          pinfo->hier[pinfo->hidx-1], 
                                          stats);
                  }
                  javaenv->DeleteLocalRef(memnameJ);
                  javaenv->DeleteLocalRef(vecObj);
               }
            }
         } else if (!strcmp(pinfo->hier[3], PROPERTIES)) {
            if (pinfo->hidx == 4) {
               ret = new MYDIRENTRY(owner, path, 
                                    pinfo->hier[pinfo->hidx-1], 
                                    stats);
               ret->setId(0L);
               ret->setCompany(company);
            } else if (!strcmp(pinfo->hier[4], GACCESS)) {
               if (accessValid) {
                  
                  if (pinfo->hidx == 5) {
                     ret = new MYDIRENTRY(owner, path, 
                                          pinfo->hier[pinfo->hidx-1], 
                                          stats);
                     ret->setId(0L);
                     ret->setCompany(company);
                  } else if (pinfo->hidx == 6) {
                     jobject vecObj = 
                        javaenv->CallObjectMethod(tobj, 
                                                  GI_getGroupAccess_methid, 0); 
                     
                     
                     jstring accnameJ = javaenv->NewStringUTF(pinfo->hier[4]);
                     
                     if (javaenv->CallBooleanMethod(vecObj, 
                                                    Vec_contains_methid, 
                                                    accnameJ,
                                                    0)) {
                        
                        ret = new MYDIRENTRY(owner, path, 
                                             pinfo->hier[pinfo->hidx-1], 
                                             stats);
                     }
                     javaenv->DeleteLocalRef(accnameJ);
                     javaenv->DeleteLocalRef(vecObj);
                  }
               }
            } else if (!strcmp(pinfo->hier[4], LISTABILITY)) {
               if (accessValid) {
                  char* listStr = NULL;
                  switch(list) {
                     case GROUP_SCOPE_ALL:      listStr = ALL;    break;
                     case GROUP_SCOPE_MEMBER:   listStr = MEMBER; break;
                     case GROUP_SCOPE_OWNER:    listStr = OWNER;  break;
                     default: break;
                  }
                  if (pinfo->hidx == 5 ||
                      (pinfo->hidx == 6 && listStr != NULL && 
                       !strcmp(listStr, pinfo->hier[6-1]))) {
                     ret = new MYDIRENTRY(owner, path, 
                                          pinfo->hier[pinfo->hidx-1], 
                                          stats);
                     ret->setId(0L);
                     ret->setCompany(company);
                  }
               }
            } else if (!strcmp(pinfo->hier[4], VISIBILITY)) {
               if (accessValid) {
                  char* visStr = NULL;
                  switch(visibility) {
                     case GROUP_SCOPE_ALL:      visStr = ALL;    break;
                     case GROUP_SCOPE_MEMBER:   visStr = MEMBER; break;
                     case GROUP_SCOPE_OWNER:    visStr = OWNER;  break;
                     default: break;
                  }
                  if (pinfo->hidx == 5 ||
                      (pinfo->hidx == 6 && visStr != NULL && 
                       !strcmp(visStr, pinfo->hier[6-1]))) {
                     ret = new MYDIRENTRY(owner, path, 
                                          pinfo->hier[pinfo->hidx-1], 
                                          stats);
                     ret->setId(0L);
                     ret->setCompany(company);
                  }
               }
            } else if (!strcmp(pinfo->hier[4], OWNER)) {
               if (pinfo->hidx == 5) {
                  ret = new MYDIRENTRY(owner, path, 
                                       pinfo->hier[pinfo->hidx-1], 
                                       stats);
                  ret->setId(0L);
                  ret->setCompany(company);
               } else if (!strcmp(pinfo->hier[5], COMPANY)) {
                  if (pinfo->hidx == 6) {
                     ret = new MYDIRENTRY(owner, path, 
                                          pinfo->hier[pinfo->hidx-1], 
                                          stats);
                     ret->setId(0L);
                     ret->setCompany(company);
                  } else if (pinfo->hidx == 7 && 
                             !strcmp(company, pinfo->hier[7-1])) {
                     ret = new MYDIRENTRY(owner, path, 
                                          pinfo->hier[pinfo->hidx-1], 
                                          stats);
                     ret->setId(0L);
                     ret->setCompany(company);
                  }
               } else if (!strcmp(pinfo->hier[5], USERID)) {
                  if (pinfo->hidx == 6) {
                     ret = new MYDIRENTRY(owner, path, 
                                          pinfo->hier[pinfo->hidx-1], 
                                          stats);
                     ret->setId(0L);
                     ret->setCompany(company);
                  } else if (pinfo->hidx == 7 && 
                             !strcmp(owner, pinfo->hier[7-1])) {
                     ret = new MYDIRENTRY(owner, path, 
                                          pinfo->hier[pinfo->hidx-1], 
                                          stats);
                     ret->setId(0L);
                     ret->setCompany(company);
                  }
               }
            }
         }
      }
      
      javaenv->ReleaseStringUTFChars(nameJ,    name);
      javaenv->ReleaseStringUTFChars(ownerJ,   owner);
      javaenv->ReleaseStringUTFChars(companyJ, company);
      javaenv->DeleteLocalRef(companyJ);
      javaenv->DeleteLocalRef(ownerJ);
      javaenv->DeleteLocalRef(nameJ);
      javaenv->DeleteLocalRef(tobj);
   }
      
   return ret;
}

/*
** Query group ... called from myquerygroups only! Assumes hidx >= 3 
*/
MYDIR* myquerygroup(PathInfo *pinfo) {

   if (pinfo->topdirnum != GROUPS_N || pinfo->hidx < 3) return NULL;
   
   MYDIR *mydir = NULL;
   
   MYDIRENTRY* mydirent = NULL;
   
   struct stat stats;
   memset(&stats, 0, sizeof stats);
   
   javaenv->ExceptionClear();

   struct timeb t;
   ftime(&t);
   stats.st_ctime  = t.time;
   stats.st_atime  = t.time;
   stats.st_mtime  = t.time;
   stats.st_size   = 555;
   stats.st_uid    = 1;
   stats.st_gid    = 1;
   stats.st_mode   = 0755 | _S_IFDIR;
   
   int amo = 0;
   if (strcmp(pinfo->hier[1], ALL)         &&  ++amo &&
       strcmp(pinfo->hier[1], MODIFIABLE)  &&  ++amo &&
       strcmp(pinfo->hier[1], OWNED)) {
      return NULL;
   }
   
  // Check if group exists for me
   jstring grpnameJ = javaenv->NewStringUTF(pinfo->hier[2]);
   jobject tobj = javaenv->CallObjectMethod(jdropbox, listGroup_methid, 
                                            grpnameJ, 0); 
   javaenv->DeleteLocalRef(grpnameJ);
   
  // Did I get it?
   if (exceptionOccurred() || tobj == NULL) {
      return NULL;
   }
   
   
   jstring nameJ  = 
      (jstring)javaenv->CallObjectMethod(tobj,
                                         GI_getGroupName_methid, 
                                         0);
   jstring ownerJ = 
      (jstring)javaenv->CallObjectMethod(tobj,
                                         GI_getGroupOwner_methid, 
                                         0);
   jstring companyJ = 
      (jstring)javaenv->CallObjectMethod(tobj,
                                         GI_getGroupCompany_methid, 
                                         0);
   jbyte list  = javaenv->CallByteMethod(tobj,
                                         GI_getGroupListability_methid, 
                                         0);
   jbyte visibility = javaenv->CallByteMethod(tobj,
                                              GI_getGroupVisibility_methid, 
                                              0);
   jboolean membersValid = 
      javaenv->CallBooleanMethod(tobj,
                                 GI_getGroupMembersValid_methid, 
                                 0);
   jboolean accessValid = 
      javaenv->CallBooleanMethod(tobj,
                                 GI_getGroupAccessValid_methid, 
                                 0);
   
   jboolean z=false;
   const char* name    = javaenv->GetStringUTFChars(nameJ, &z);
   const char* owner   = javaenv->GetStringUTFChars(ownerJ, &z);
   const char* company = javaenv->GetStringUTFChars(companyJ, &z);
   
   int addit = 0;
   switch(amo) {
      case 0: // ALL
         addit=1;
         break;
      case 1: // MODIFIABLE
         if (list != GROUP_SCOPE_NONE) {
            addit=1;
         }
         break;
      case 2: // OWNED
         if (!strcmp(userName(), owner)) {
            addit=1;
         }
         break;
      default:
         break;
   }
   
   if (addit) {
      
     // If asking about toplevel group, 
      if (pinfo->hidx == 3) {
         mydir = new MYDIR(owner, pinfo->fullpath);
         mydir->setCompany(company);
         
         if (membersValid) {
            mydirent = new MYDIRENTRY(owner, pinfo->fullpath, 
                                      MEMBERS, stats);
            mydirent->setId(0L);
            mydirent->setCompany(company);
            mydir->addEntry(mydirent);
         }
         
         mydirent = new MYDIRENTRY(owner, pinfo->fullpath, 
                                   PROPERTIES, stats);
         mydirent->setId(0L);
         mydirent->setCompany(company);
         mydir->addEntry(mydirent);
      } else if (!strcmp(pinfo->hier[3], MEMBERS)) {
         if (membersValid) {
            if (pinfo->hidx == 4 || pinfo->hidx == 5) {
            
              // Get members vector
               jobject vecObj = 
                  javaenv->CallObjectMethod(tobj, 
                                            GI_getGroupMembers_methid, 0); 
                                            
              // If specific member, just check that its there. Its contents
              //  will be . and .. added below
               if (pinfo->hidx == 5) {
                  jstring memnameJ = javaenv->NewStringUTF(pinfo->hier[4]);
                  
                  if (javaenv->CallBooleanMethod(vecObj, 
                                                 Vec_contains_methid, 
                                                 memnameJ,
                                                 0)) {
                     
                     mydir = new MYDIR(owner, pinfo->fullpath);
                     mydir->setCompany(company);
                  }
                  javaenv->DeleteLocalRef(memnameJ);
               } else {
                 // list the members
                  mydir = new MYDIR(owner, pinfo->fullpath);
                  mydir->setCompany(company);
                  
                  jobject enumer = 
                     javaenv->CallObjectMethod(vecObj,
                                               Vec_elements_methid, 0); 
                  if (enumer) {
                     
                     while(!exceptionOccurred() && 
                           javaenv->CallBooleanMethod(enumer, 
                                                  Enum_hasMoreElements_methid, 
                                                      0)){
                        jstring memberJ = (jstring)
                           javaenv->CallObjectMethod(enumer, 
                                                     Enum_nextElement_methid, 
                                                     0);
                        jboolean z=false;
                        const char* v = javaenv->GetStringUTFChars(memberJ,
                                                                   &z);
                        
                        mydirent = new MYDIRENTRY(owner, pinfo->fullpath, 
                                                  v, stats);
                        mydirent->setId(0L);
                        mydirent->setCompany(company);
                        mydir->addEntry(mydirent);
                        
                        javaenv->ReleaseStringUTFChars(memberJ, v);
                        javaenv->DeleteLocalRef(memberJ);
                     }
                     javaenv->DeleteLocalRef(enumer);
                  }
               }
               javaenv->DeleteLocalRef(vecObj);
            }
         }
      } else if (!strcmp(pinfo->hier[3], PROPERTIES)) {
         if (pinfo->hidx == 4) {
         
           // list the members
            mydir = new MYDIR(owner, pinfo->fullpath);
            mydir->setCompany(company);
            
            mydirent = new MYDIRENTRY(owner, pinfo->fullpath,
                                 OWNER, stats);
            mydirent->setId(0L);
            mydirent->setCompany(company);
            mydir->addEntry(mydirent);
            
            if (accessValid) {
               mydirent = new MYDIRENTRY(owner, pinfo->fullpath, 
                                         GACCESS, stats);
               mydirent->setId(0L);
               mydirent->setCompany(company);
               mydir->addEntry(mydirent);
               
               mydirent = new MYDIRENTRY(owner, pinfo->fullpath, 
                                         LISTABILITY, stats);
               mydirent->setId(0L);
               mydirent->setCompany(company);
               mydir->addEntry(mydirent);
               
               mydirent = new MYDIRENTRY(owner, pinfo->fullpath, 
                                         VISIBILITY, stats);
               mydirent->setId(0L);
               mydirent->setCompany(company);
               mydir->addEntry(mydirent);
               
            }
         } else if (!strcmp(pinfo->hier[4], GACCESS)) {
            if (accessValid && (pinfo->hidx == 5 || pinfo->hidx == 6)) {
            
              // Get Access vector
               jobject vecObj = 
                  javaenv->CallObjectMethod(tobj, 
                                            GI_getGroupAccess_methid, 0); 
                                            
              // If specific member, just check that its there. Its contents
              //  will be . and .. added below
               if (pinfo->hidx == 6) {
                  jstring accnameJ = javaenv->NewStringUTF(pinfo->hier[5]);
                  
                  if (javaenv->CallBooleanMethod(vecObj, 
                                                 Vec_contains_methid, 
                                                 accnameJ,
                                                 0)) {
                     
                     mydir = new MYDIR(owner, pinfo->fullpath);
                     mydir->setCompany(company);
                  }
                  javaenv->DeleteLocalRef(accnameJ);
               } else {
                 // list the accessers
                  mydir = new MYDIR(owner, pinfo->fullpath);
                  mydir->setCompany(company);
                  
                  jobject enumer = 
                     javaenv->CallObjectMethod(vecObj,
                                               Vec_elements_methid, 0); 
                  if (enumer) {
                     
                     while(!exceptionOccurred() && 
                           javaenv->CallBooleanMethod(enumer, 
                                                  Enum_hasMoreElements_methid, 
                                                      0)){
                        jstring accessJ = (jstring)
                           javaenv->CallObjectMethod(enumer, 
                                                     Enum_nextElement_methid, 
                                                     0);
                        jboolean z=false;
                        const char* v = javaenv->GetStringUTFChars(accessJ,
                                                                   &z);
                        
                        mydirent = new MYDIRENTRY(owner, pinfo->fullpath, 
                                                  v, stats);
                        mydirent->setId(0L);
                        mydirent->setCompany(company);
                        mydir->addEntry(mydirent);
                        
                        javaenv->ReleaseStringUTFChars(accessJ, v);
                        javaenv->DeleteLocalRef(accessJ);
                     }
                     javaenv->DeleteLocalRef(enumer);
                  }
               }
               javaenv->DeleteLocalRef(vecObj);
            }
         } else if (!strcmp(pinfo->hier[4], LISTABILITY)) {
            if (accessValid) {
               char* listStr = NULL;
               switch(list) {
                  case GROUP_SCOPE_ALL:      listStr = ALL;    break;
                  case GROUP_SCOPE_MEMBER:   listStr = MEMBER; break;
                  case GROUP_SCOPE_OWNER:    listStr = OWNER;  break;
                  default: break;
               }
               if (pinfo->hidx == 5 ||
                   (pinfo->hidx == 6 && listStr != NULL && 
                    !strcmp(listStr, pinfo->hier[6-1]))) {
                  
                  mydir = new MYDIR(owner, pinfo->fullpath);
                  mydir->setCompany(company);
                  
                 // If listing listability dir
                  if (pinfo->hidx == 5) {
                     mydirent = new MYDIRENTRY(owner, pinfo->fullpath,
                                               listStr, stats);
                     mydirent->setId(0L);
                     mydirent->setCompany(company);
                     mydir->addEntry(mydirent);                     
                  }
               }
            }
         } else if (!strcmp(pinfo->hier[4], VISIBILITY)) {
            if (accessValid) {
               char* visStr = NULL;
               switch(visibility) {
                  case GROUP_SCOPE_ALL:      visStr = ALL;    break;
                  case GROUP_SCOPE_MEMBER:   visStr = MEMBER; break;
                  case GROUP_SCOPE_OWNER:    visStr = OWNER;  break;
                  default: break;
               }
               if (pinfo->hidx == 5 ||
                   (pinfo->hidx == 6 && visStr != NULL && 
                    !strcmp(visStr, pinfo->hier[6-1]))) {
                    
                  mydir = new MYDIR(owner, pinfo->fullpath);
                  mydir->setCompany(company);
                  
                 // If listing visibility dir
                  if (pinfo->hidx == 5) {
                     mydirent = new MYDIRENTRY(owner, pinfo->fullpath,
                                               visStr, stats);
                     mydirent->setId(0L);
                     mydirent->setCompany(company);
                     mydir->addEntry(mydirent);
                  }
               }
            }
         } else if (!strcmp(pinfo->hier[4], OWNER)) {
            if (pinfo->hidx == 5) {
               mydir = new MYDIR(owner, pinfo->fullpath);
               mydir->setCompany(company);
                  
               mydirent = new MYDIRENTRY(owner, pinfo->fullpath,
                                         COMPANY, stats);
               mydirent->setId(0L);
               mydirent->setCompany(company);
               mydir->addEntry(mydirent);               
               
               mydirent = new MYDIRENTRY(owner, pinfo->fullpath,
                                         USERID, stats);
               mydirent->setId(0L);
               mydirent->setCompany(company);
               mydir->addEntry(mydirent);
               
            } else if (!strcmp(pinfo->hier[5], COMPANY)) {
               if (pinfo->hidx == 6) {
                  mydir = new MYDIR(owner, pinfo->fullpath);
                  mydir->setCompany(company);
                  
                  mydirent = new MYDIRENTRY(owner, pinfo->fullpath,
                                            company, stats);
                  mydirent->setId(0L);
                  mydirent->setCompany(company);
                  mydir->addEntry(mydirent);               
               } else if (pinfo->hidx == 7 && 
                          !strcmp(company, pinfo->hier[7-1])) {
                 // Just stating specific company
                  mydir = new MYDIR(owner, pinfo->fullpath);
                  mydir->setCompany(company);
               }
            } else if (!strcmp(pinfo->hier[5], USERID)) {
               if (pinfo->hidx == 6) {
                  mydir = new MYDIR(owner, pinfo->fullpath);
                  mydir->setCompany(company);
                  
                  mydirent = new MYDIRENTRY(owner, pinfo->fullpath,
                                            owner, stats);
                  mydirent->setId(0L);
                  mydirent->setCompany(company);
                  mydir->addEntry(mydirent);               
               } else if (pinfo->hidx == 7 && 
                          !strcmp(owner, pinfo->hier[7-1])) {
                 // Just stating specific owner
                  mydir = new MYDIR(owner, pinfo->fullpath);
                  mydir->setCompany(company);
               }
            }
         }
      }
   }
   
   javaenv->ReleaseStringUTFChars(nameJ,    name);
   javaenv->ReleaseStringUTFChars(ownerJ,   owner);
   javaenv->ReleaseStringUTFChars(companyJ, company);
   javaenv->DeleteLocalRef(companyJ);
   javaenv->DeleteLocalRef(ownerJ);
   javaenv->DeleteLocalRef(nameJ);
   javaenv->DeleteLocalRef(tobj);

  // Add in . and ..
   if (mydir != NULL) {
      
      mydirent = new MYDIRENTRY(mydir->getOwner(),
                                mydir->getDirectory(),
                                ".", stats);
      mydirent->setId(0L);
      mydirent->setCompany(mydir->getCompany());
      mydir->addEntry(mydirent);
      
      mydirent = new MYDIRENTRY((pinfo->hidx==3?userName():mydir->getOwner()), 
                                mydir->getDirectory(), "..", stats);
      mydirent->setId(0L);
      mydirent->setCompany((pinfo->hidx==3?companyName():mydir->getCompany()));
      mydir->addEntry(mydirent);
   }
      
   return mydir;
}

/*
** Query groups ... called for opendir only
*/
MYDIR* myquerygroups(PathInfo *pinfo) {

   if (pinfo->topdirnum != GROUPS_N) return NULL;

   MYDIR *mydir = NULL;
   MYDIRENTRY *de;
    
   javaenv->ExceptionClear();
   
   struct stat stats;
   memset(&stats, 0, sizeof stats);
   
   struct timeb t;
   ftime(&t);
   stats.st_ctime  = t.time;
   stats.st_atime  = t.time;
   stats.st_mtime  = t.time;
   stats.st_size   = 555;
   stats.st_uid    = 1;
   stats.st_gid    = 1;
   stats.st_mode   = 0755 | _S_IFDIR;
   
   if (pinfo->hidx == 1) {
      mydir = new MYDIR(userName(), FULLGROUPS);
      mydir->setCompany(companyName());
      
      de = new MYDIRENTRY(mydir->getOwner(), "/", ALL,   stats);
      de->setCompany(companyName());
      mydir->addEntry(de);
      
      de = new MYDIRENTRY(mydir->getOwner(), "/", MODIFIABLE,   stats);
      de->setCompany(companyName());
      mydir->addEntry(de);
      
      de = new MYDIRENTRY(mydir->getOwner(), "/", OWNED,   stats);
      de->setCompany(companyName());
      mydir->addEntry(de);
      
      de = new MYDIRENTRY(mydir->getOwner(), "/", ".",   stats);
      de->setCompany(companyName());
      mydir->addEntry(de);
      
      de = new MYDIRENTRY(mydir->getOwner(), "/", "..",  stats);
      de->setCompany(companyName());
      mydir->addEntry(de);
      return mydir;
   }
   
  // If not a valid selection, return error
   int amo = 0;
   if (strcmp(pinfo->hier[1], ALL)         &&  ++amo &&
       strcmp(pinfo->hier[1], MODIFIABLE)  &&  ++amo &&
       strcmp(pinfo->hier[1], OWNED)) {
      return NULL;
   }
   
  // now amo has 0 if ALL, 1 of MODIFIABLE, and 2 if OWNED
   
  // If we are doing a toplevel query
   if (pinfo->hidx == 2) {
      jobject hasht = javaenv->CallObjectMethod(jdropbox, listGroups_methid, 
                                                0); 
      if (!exceptionOccurred()) {
   
         jobject enumer = javaenv->CallObjectMethod(hasht,
                                                    Hash_elements_methid, 0); 
         char path[1024];
         sprintf(path, "/%s", pinfo->topdir);
         mydir = new MYDIR(userName(), path);
         mydir->setCompany(companyName());      
         
         MYDIRENTRY* mydirent = new MYDIRENTRY(userName(), path, ".", stats);
         mydirent->setId(0L);
         mydirent->setCompany(companyName());
         mydir->addEntry(mydirent);
         
         mydirent = new MYDIRENTRY(userName(), path, "..", stats);
         mydirent->setId(0L);
         mydirent->setCompany(companyName());
         mydir->addEntry(mydirent);
         
         if (enumer) {
      
            while(!exceptionOccurred() && 
                  javaenv->CallBooleanMethod(enumer, 
                                             Enum_hasMoreElements_methid, 0)) {
            
               jobject tobj = javaenv->CallObjectMethod(enumer, 
                                                      Enum_nextElement_methid, 
                                                        0);
               jstring nameJ = 
                  (jstring)javaenv->CallObjectMethod(tobj,
                                                     GI_getGroupName_methid, 
                                                     0);
               jstring ownerJ = 
                  (jstring)javaenv->CallObjectMethod(tobj,
                                                     GI_getGroupOwner_methid, 
                                                     0);
               jstring companyJ =
                  (jstring)javaenv->CallObjectMethod(tobj,
                                                    GI_getGroupCompany_methid, 
                                                     0);
               jbyte list =
                  javaenv->CallByteMethod(tobj,
                                          GI_getGroupListability_methid, 
                                          0);
               jbyte visibility = 
                  javaenv->CallByteMethod(tobj,
                                          GI_getGroupVisibility_methid, 
                                          0);
               
               jboolean z=false;
               const char* name    = javaenv->GetStringUTFChars(nameJ, &z);
               const char* owner   = javaenv->GetStringUTFChars(ownerJ, &z);
               const char* company = javaenv->GetStringUTFChars(companyJ, &z);
               
               int addit = 0;
               switch(amo) {
                  case 0: // ALL
                     addit=1;
                     break;
                  case 1: // MODIFIABLE
                     if (list != GROUP_SCOPE_NONE) {
                        addit=1;
                     }
                     break;
                  case 2: // OWNED
                     if (!strcmp(userName(), owner)) {
                        addit=1;
                     }
                     break;
                  default:
                     break;
               }
               
               if (addit) {
                  mydirent = new MYDIRENTRY(owner, path, name, stats);
                  mydirent->setId(0L);
                  mydirent->setCompany(company);
                  mydir->addEntry(mydirent);
               }
               
               javaenv->ReleaseStringUTFChars(nameJ,    name);
               javaenv->ReleaseStringUTFChars(ownerJ,   owner);
               javaenv->ReleaseStringUTFChars(companyJ, company);
               
               javaenv->DeleteLocalRef(companyJ);
               javaenv->DeleteLocalRef(ownerJ);
               javaenv->DeleteLocalRef(nameJ);
               javaenv->DeleteLocalRef(tobj);
            }
            
            javaenv->DeleteLocalRef(enumer);
         }
         javaenv->DeleteLocalRef(hasht);
      }
   } else {
      mydir = myquerygroup(pinfo);
   }
      
   return mydir;
}

/*
** Query all projects
*/
MYDIR* myqueryprojects() {

   MYDIR *mydir = NULL;
   MYDIRENTRY *de;
    
   javaenv->ExceptionClear();
   
   struct stat stats;
   memset(&stats, 0, sizeof stats);
   
   struct timeb t;
   ftime(&t);
   stats.st_ctime  = t.time;
   stats.st_atime  = t.time;
   stats.st_mtime  = t.time;
   stats.st_size   = 555;
   stats.st_uid    = 1;
   stats.st_gid    = 1;
   stats.st_mode   = 0755 | _S_IFDIR;
   
   mydir = new MYDIR(userName(), FULLPROJECTS);
   mydir->setCompany(companyName());
   
   de = new MYDIRENTRY(mydir->getOwner(), FULLPROJECTS, ".",   stats);
   de->setCompany(companyName());
   mydir->addEntry(de);
   
   de = new MYDIRENTRY(mydir->getOwner(), FULLPROJECTS, "..",  stats);
   de->setCompany(companyName());
   mydir->addEntry(de);
   
  // Model the projects as files
   stats.st_size   = 0;
   stats.st_uid    = 1;
   stats.st_gid    = 1;
   stats.st_mode   = 0444 | _S_IFREG;
   
   jobject vectt = javaenv->CallObjectMethod(jdropbox, getUserProjects_methid, 
                                             0); 
   if (!exceptionOccurred() && vectt) {
      
      jobject enumer = javaenv->CallObjectMethod(vectt,
                                                 Vec_elements_methid, 0); 
      if (enumer) {
         
         while(!exceptionOccurred() && 
               javaenv->CallBooleanMethod(enumer, 
                                          Enum_hasMoreElements_methid, 0)) {
            
            jobject tobj = javaenv->CallObjectMethod(enumer, 
                                                     Enum_nextElement_methid, 
                                                     0);
            jstring tstrJ = (jstring)tobj;
            
            jboolean z=false;
            const char* pname = javaenv->GetStringUTFChars(tstrJ, &z);
            
            de = new MYDIRENTRY(mydir->getOwner(), FULLPROJECTS, 
                                pname,  stats);
                                
            de->setCompany(companyName());
            mydir->addEntry(de);
            
            javaenv->ReleaseStringUTFChars(tstrJ, pname);
            javaenv->DeleteLocalRef(tobj);
         }                                                    
         
         javaenv->DeleteLocalRef(enumer);
      }
      javaenv->DeleteLocalRef(vectt);
   }
   return mydir;
}   

/*
** Login to dropbox
*/
int mylogin(char* token) {
   int ret = -1;
   
   javaenv->ExceptionClear();
      
   
   if (token) {
      jstring tokstrJ = javaenv->NewStringUTF(token);
      
      jboolean rc = javaenv->CallBooleanMethod(jdropbox, login_methid, 
                                               tokstrJ, 0);
      if (!exceptionOccurred() && rc) ret =  0;
      
      logit("mylogin, rc = %d ret = %d", rc, ret);
      
      javaenv->DeleteLocalRef(tokstrJ);
      
      javaenv->ExceptionClear();
      
      jstring uJ = 
         (jstring)javaenv->CallObjectMethod(jdropbox, 
                                            getTokenUserCompany_methid, 
                                            JNI_TRUE, 0);
      if (uJ != NULL) {
         jboolean iscopy;
         const char* strV = javaenv->GetStringUTFChars(uJ, &iscopy);
         if (strV) {
            userV =  xstrdup(strV);
            javaenv->ReleaseStringUTFChars(uJ, strV);
            
         }
      }
      javaenv->DeleteLocalRef(uJ);
      
      jstring cJ = 
         (jstring)javaenv->CallObjectMethod(jdropbox, 
                                            getTokenUserCompany_methid, 
                                            JNI_FALSE, 0);
      if (cJ != NULL) {
         jboolean iscopy;
         const char* strV = javaenv->GetStringUTFChars(cJ, &iscopy);
         if (strV) {
            companyV =  xstrdup(strV);
            javaenv->ReleaseStringUTFChars(cJ, strV);
            
         }
      }
      javaenv->DeleteLocalRef(cJ);
   } else {
      logit("No token provided to login method");
   }
      
   return ret;
}

#ifdef SOA

// Called from atexit routine to ensure we are closed down
extern "C" void forceSessionClose() {
   if (jdropbox) {
     // Make sure we don't have any re-entry call
      javaenv->CallVoidMethod(jdropbox, setDoSystemExit_methid, JNI_FALSE, NULL);
      javaenv->CallVoidMethod(jdropbox, disconnect_methid, NULL);
   }
}

int myconnect(char* url) {

   int ret = -1;
         
   if (!jdropbox) {
      error("myconnect, error instancing sftpDropbox");
      return -1;
   }
      
   jstring urlstr = javaenv->NewStringUTF(url);
   
   jboolean rc = javaenv->CallBooleanMethod(jdropbox, connect_methid, 
                                            urlstr, NULL);
   if (!exceptionOccurred() && rc) ret =  0;
   logit("myconnect, url %s rc = %d ret = %d", (char*)(url?url:"null"), rc, ret);

   javaenv->DeleteLocalRef(urlstr);
   
  // Set sftpDropbox to call System Exit if we become disconnected
   javaenv->CallVoidMethod(jdropbox, setDoSystemExit_methid, JNI_TRUE, NULL);
      
  // Add in at exit handler to call disconnect to ensure cleanup
   atexit(forceSessionClose);
      
  // Set transfer sizes
   javaenv->CallVoidMethod(jdropbox, setMaxUploadTransferSize_methid, 
                           (jint)uploadbuffersz, NULL);
   javaenv->CallVoidMethod(jdropbox, setMaxDownloadTransferSize_methid, 
                           (jint)downloadbuffersz, NULL);
      
   return ret;
}
#else
/*
** Load JVM and connect to Dropbox
*/
int myconnect(char* host, int port, int secureMode) {

   int ret = -1;
         
   if (!jdropbox) {
      error("myconnect, error instancing sftpDropbox");
      return -1;
   }
      
   jstring hoststr = javaenv->NewStringUTF(host);
   
   jboolean rc = javaenv->CallBooleanMethod(jdropbox, connect_methid, 
                                            hoststr, (jint)port, 
                                            (jboolean)secureMode != 0, NULL);
   if (!exceptionOccurred() && rc) ret =  0;
   debug("myconnect, rc = %d", rc);

   javaenv->DeleteLocalRef(hoststr);
   
  // Set sftpDropbox to call System Exit if we become disconnected
   javaenv->CallVoidMethod(jdropbox, setDoSystemExit_methid, JNI_TRUE, NULL);
      
   return ret;
}
#endif

// We won't come back from here ... instead, we will get a new thread calling
//  into the giveMeAJavaThread method below. Apparent bug in Java 1.3.1 on AIX
//  4.3.3 where Monitors do not want to work correctly prevents me from using
//  a 'native' thread.
extern "C" void java_initialize();
void java_initialize() {
   logit("In java initialize");
   
   if (!gotjvm) {
   
     /* Java 131 restrictions ... these MUST be set
      AIXTHREAD_SCOPE=S
      AIXTHREAD_MUTEX_DEBUG=OFF
      AIXTHREAD_RWLOCK_DEBUG=OFF
      AIXTHREAD_COND_DEBUG=OFF
     */
      putenv("AIXTHREAD_SCOPE=S");
      putenv("AIXTHREAD_MUTEX_DEBUG=OFF");
      putenv("AIXTHREAD_RWLOCK_DEBUG=OFF");
      putenv("AIXTHREAD_COND_DEBUG=OFF");
     
     /* This CAN be set to hel palleviate problems
      JITC_COMPILEOPT=NSCC_CACHE
     */
      putenv("JITC_COMPILEOPT=NSCC_CACHE");
     /*
       Pgm must be linked with -bM:UR 
      */
   
#ifndef JNI_VERSION_1_2
      JDK1_1InitArgs vm_args;
      
      vm_args.version = JNI_VERSION_1_1;
      
      JNI_GetDefaultJavaVMInitArgs(&vm_args);
      
      char* envclasspath=getenv("CLASSPATH");
      
      int cplen = 0;
      if (envclasspath) cplen = strlen(envclasspath)+1;
      
      char* newclasspath = (char*)malloc(strlen(vm_args.classpath) + 
                                         strlen(myclasspath) + cplen + 1);
      strcpy(newclasspath, myclasspath);
      strcat(newclasspath, vm_args.classpath);
      if (newclasspath) {
         strcat(newclasspath, ":");
         strcat(newclasspath, envclasspath);
      }
      
      vm_args.classpath = newclasspath;
      
      logit("New classpath[%s]", newclasspath);
#else
      JavaVMInitArgs vm_args;
      vm_args.version = JNI_VERSION_1_2;
      vm_args.ignoreUnrecognized = JNI_FALSE;
      
      char* envclasspath=getenv("CLASSPATH");
      
      vm_args.nOptions = 0;
      vm_args.options  = (JavaVMOption*)malloc(sizeof(JavaVMOption)*20);
      
      if (envclasspath) {
         char* cp = (char*)malloc(strlen(envclasspath) + strlen(myclasspath) +
                                  1 + 1 + 20);
         strcpy(cp, "-Djava.class.path=");
         strcat(cp, envclasspath);
         if (myclasspath && *myclasspath) {
            strcat(cp, ":");
            strcat(cp, myclasspath);
         }
         vm_args.options[vm_args.nOptions++].optionString  = cp;
         
         logit("Adding classpath arg[%s]", cp);
      }
      
      {
         char* libp=getenv("LIBPATH");
         if (libp) logit("LIBPATH=[%s]", libp);
         libp=getenv("LD_LIBRARY_PATH");
         if (libp) logit("LD_LIBRARY_PATH=[%s]", libp);
         
         char* ksfile = getenv("KEYSTOREFILE");
         char* kspw   = getenv("KEYSTOREPASSWORD");
         char* tsfile = getenv("TRUSTSTOREFILE");
         char* tspw   = getenv("TRUSTSTOREPASSWORD");
         char* debugssl = getenv("DEBUGSSL");
         
         
        // JMC 2/5/07 - Allow setting of upload buffer size
         char* uploadbuffersz_S = getenv("DROPBOX_UPLOADBUFFERSIZE");
         if (uploadbuffersz_S != 0) {
            int lsz = atoi(uploadbuffersz_S);
            if (lsz < 128*1024) lsz = 128*1024;
            uploadbuffersz = lsz;
            logit("Setting UploadBufferSize to %d", lsz);
         }
         
        // JMC 2/5/07 - Allow setting of upload buffer size
         char* downloadbuffersz_S = getenv("DROPBOX_DOWNLOADBUFFERSIZE");
         if (downloadbuffersz_S != 0) {
            int lsz = atoi(downloadbuffersz_S);
            if (lsz < 128*1024) lsz = 128*1024;
            downloadbuffersz = lsz;
            logit("Setting DownloadBufferSize to %d", lsz);
         }
         
        // JMC 2/5/07 - add ability to inject JRE parms
         char envname[20];
         int loopcnt=1;
         do {
            sprintf(envname, "DROPBOXJREPARM%d", loopcnt++);
            char* jreparm = getenv(envname);
            logit("Env var [%s] = [%s]\n", envname, (char*)(jreparm?jreparm:""));
            if (jreparm == 0 || *jreparm == '\0') break;
            logit("Adding %s", jreparm);
            vm_args.options[vm_args.nOptions++].optionString = jreparm;            
         } while (1);
         
         if (ksfile != NULL) {
            char* dv="-Djavax.net.ssl.keyStore=";
            char* v = (char*)malloc(strlen(ksfile)+strlen(dv)+1);
            strcpy(v, dv);
            strcat(v, ksfile);
            logit("Adding %s", v);
            vm_args.options[vm_args.nOptions++].optionString = v;            
         }
         if (kspw != NULL) {
            char* dv="-Djavax.net.ssl.keyStorePassword=";
            char* v = (char*)malloc(strlen(kspw)+strlen(dv)+1);
            strcpy(v, dv);
            strcat(v, kspw);
            logit("Adding kspw");
            vm_args.options[vm_args.nOptions++].optionString = v;            
         }
         if (tsfile != NULL) {
            char* dv="-Djavax.net.ssl.trustStore=";
            char* v = (char*)malloc(strlen(tsfile)+strlen(dv)+1);
            strcpy(v, dv);
            strcat(v, tsfile);
            logit("Adding %s", v);
            vm_args.options[vm_args.nOptions++].optionString = v;            
         }
         if (tspw != NULL) {
            char* dv="-Djavax.net.ssl.trustStorePassword=";
            char* v = (char*)malloc(strlen(tspw)+strlen(dv)+1);
            strcpy(v, dv);
            strcat(v, tspw);
            logit("Adding tspw");
            vm_args.options[vm_args.nOptions++].optionString = v;            
         }
         if (debugssl != NULL) {
            char* dv="-Djavax.net.debug=true";
            char* v = (char*)malloc(strlen(dv)+1);
            strcpy(v, dv);
            logit("Adding %s", v);
            vm_args.options[vm_args.nOptions++].optionString = v;            
         }
      }
      
#endif

      if (JNI_CreateJavaVM(&jvm, (void**)&javaenv, &vm_args) < 0) {
         error("Error creating JVM");
         return;
      }
      
      
      if (javamethinit()) return;
      
      javaenv->CallStaticVoidMethod(systemClass, System_setOut_methid,
                                    System_stdErr_Obj, NULL);
      
      gotjvm = 1;
      
      javaenv->ExceptionClear();
   }
}


extern "C" char* jmc_authpassword(const char* url, const char* user, 
                                  const char* password);
#ifndef DOITINLINE
char* jmc_authpassword(const char* url, const char* user, 
                       const char* password) {
   char* debuglevS = getenv("DEBUGLEV");
   char* ret = NULL;
   int debuglev = atoi((debuglevS?debuglevS:"0"));
   java_initialize();
   
   javaenv->ExceptionClear();
   if (debuglev) {
      javaenv->CallStaticVoidMethod(debugPrintClass, 
                                    DebugPrint_setLevel_methid,
                                    (jint)debuglev, NULL);
   }
   
   if (!url || !user || !password) return 0;
   
   jstring userJ  = javaenv->NewStringUTF(user);
   jstring pwJ    = javaenv->NewStringUTF(password);
   jstring opJ    = javaenv->NewStringUTF("XFR");
   jstring scopeJ = javaenv->NewStringUTF("");
   jstring urlJ   = javaenv->NewStringUTF(url);
   jstring sftpJ  = javaenv->NewStringUTF("sftp=true");
   
   debug("Calling getConnInfo");
   jstring strJ = (jstring)
      javaenv->CallStaticObjectMethod(miscClass, MISC_getConnectInfoG_methid, 
                                      userJ, pwJ, opJ, scopeJ, urlJ, sftpJ,
                                      NULL);
   
   debug("back strJ=%x", strJ);
   if (!exceptionOccurred() && strJ) {
      jboolean iscopy = JNI_FALSE;
      const char* token = javaenv->GetStringUTFChars(strJ, &iscopy);
      if (token) {
         ret =  xstrdup(token);
         javaenv->ReleaseStringUTFChars(strJ, token);         
      }
   }
   
   javaenv->DeleteLocalRef(userJ);
   javaenv->DeleteLocalRef(pwJ);
   javaenv->DeleteLocalRef(opJ);
   javaenv->DeleteLocalRef(scopeJ);
   javaenv->DeleteLocalRef(urlJ);
   javaenv->DeleteLocalRef(sftpJ);
   if (strJ) {
      javaenv->DeleteLocalRef(strJ);
   }
   
   return ret;
}
#else
// Geeze, do it it its own JVM
char* jmc_authpassword(const char* url, const char* user,
                       const char* password) {
   char* ret = NULL;
   int p1[2];   // Send TO   new pgm
   int p2[2];   // Get  From new pgm
   logit("Calling pipe");
   if (!pipe(p1) && !pipe(p2)) {
      int pid = fork();
      if (pid == 0) {
      
         logit("Duping stdinout");
         dup2(p1[0], 0);
         dup2(p2[1], 1);
         
         close (p1[0]);
         close (p1[1]);
         close (p2[0]);
         close (p2[1]);
         
         execl("/afs/eda/u/crichton/projects/openssh-3.6.1p1/ccauthpasswd", "ccauthpasswd", (char *)0);
//         execl("/tmp/ccauthpasswd", "ccauthpasswd", (char *)0);
         exit(errno);
      } else if (pid != -1) {
      
         char buf[1024];
         
         close (p1[0]);
         close (p2[1]);
         
         sprintf(buf, "%s\n%s\n", user, password);
         logit("writing BUF[%s]", buf);
         int totwrite = strlen(buf)+1;
         int written = 0;
         while(written < totwrite) {
            int w = write(p1[1], buf+written, totwrite-written);
            if (w < 0) {
               if (errno != EINTR && errno != EAGAIN) {
                  logit("error write = %d", errno);
                  break;
               }
            } else {
               written += w;
            }
         }
         logit("totwrite = %d written = %d", totwrite, written);
         if (written == totwrite) {
            int totread = 0;
            int sz = 0;
            while(1) {
               int r = read(p2[0], buf, sizeof(buf));
               if (r == 0) break;
               if (r < 0) {
                  if (errno != EINTR && errno != EAGAIN) {
                     logit("error read = %d", errno);
                     break;
                  }
               } else {
                  ret = (char*)xrealloc(ret, totread+1+r);
                  memcpy(ret+totread, buf, r);
                  
                  totread += r;
                  
                  if (totread > 65*1024*1024) {
                     xfree(ret);
                     ret = 0;
                     break;
                  }
               }   
            }
         }
         
         
         int status;
         while(waitpid(pid, &status, 0) != pid && WIFEXITED(status));
         
         if (WEXITSTATUS(status) != 0) {
            logit("exit status = %d", WEXITSTATUS(status));
            if (ret) xfree(ret);
            ret = 0;
         } else {
            if (ret) {
               int doit = 0;
               const char* toks=strstr(ret, "TOKEN[");
               if (toks) {
                  toks += 6;
                  char* toke = strstr(toks, "]\n");
                  if (toke) {
                     memmove(ret, toks, toke-toks);
                     ret[toke-toks] = '\0';
                     doit = 1;
                  }
               }
               
               logit("Token is -%s-", ret);
               
               if (!doit) {
                  xfree(ret);
                  ret = 0;
               }
            }
         }
      }
      
      close (p2[0]);      
      close (p1[1]);
   }
   return ret;
}


#endif
// Wanted to reuse joe.cpp from sshd, so had to play some games with where
//  things lived. 
int java_sftp_init2() {

#ifdef SOA
   findclass(jdropboxClass, "oem/edge/ed/odc/dropbox/client/sftpDropbox");
#else
   findclass(jdropboxClass, "oem/edge/ed/odc/dropbox/client/sftpDropbox");
#endif
   jmethodID constructID = javaenv->GetMethodID(jdropboxClass, 
                                                "<init>", 
                                                "(Z)V");
   if (!constructID) {
      error("myconnect, methid for constructor == 0");
      return -1;
   }
   
   jdropbox = javaenv->NewObject(jdropboxClass, constructID, 
                                 (jboolean)(doprotodebug?JNI_TRUE:JNI_FALSE), 0);
   
   threadMaker_methid = javaenv->GetMethodID(jdropboxClass, 
                                             "getMeAJavaThread", 
                                             "()V");
                                                       
   if (!threadMaker_methid) {
      error("java_initialize, methid for threadMaker == 0");
      return -1;
   }
   return 0;
}


/*-------------------------------------------------------------------------*\
**             DROPBOX 
\*-------------------------------------------------------------------------*/
MYFILE* Dropbox::openUpload(const char* s) {
   debug("Dropbox:openUpload: %s\n", s);
   
   PathInfo p;
   p.parse(s);
   
   MYFILE* ret = NULL;
   
   if (p.topdirnum == DRAFTS_N && !p.isAccess && *p.pack && *p.file && 
       strcmp(p.hier[2], INFODIR)) {
      MYDIRENTRY *dp =  myquerypackage(&p);
      
      if (dp) {
         long long packid = dp->getId();
         
         jobject jobj = mystartuploadfile(packid, p.file);
         if (jobj) {
            char packpath[1024];
            sprintf(packpath, "/%s/%s", p.topdir, p.pack);
            ret = new MYFILE(dp->getOwner(), packpath, p.file, 
                             jobj, MYFILE_UPLOAD);
         }
         delete dp;
      }
#ifdef SOA
   } else if (p.hidx == 4 && !strcmp(p.hier[3], DESCRIPTION) && 
              !strcmp(p.hier[2], INFODIR)) {
      MYDIRENTRY *dp =  myquerypackage(&p);
      if (dp) {
      
         char packpath[1024];
         sprintf(packpath, "/%s/%s", p.topdir, p.pack);
         ret = new MYFILE(dp->getOwner(), packpath, p.file, 
                          NULL, MYFILE_DESC_UPLOAD);
         ret->setPackageId(dp->getId());
         ret->setMaxSize(1024);
         
         delete dp;
      }
#endif
   }
   
   
   return ret;
}
MYFILE* Dropbox::openDownload(const char* s) {
   debug("Dropbox:openDownload: %s\n", s);
   PathInfo p;
   p.parse(s);
   
   MYFILE* ret = NULL;
   
   if ((p.topdirnum >= TRASH_N && p.topdirnum <= DRAFTS_N) && 
       !p.isAccess && *p.pack) {
   
      if (p.hidx == 4 && !strcmp(p.hier[3], ATTRIBUTES) && 
          !strcmp(p.hier[2], INFODIR)) {
         MYDIRENTRY *dp =  myquerypackage(&p);
         if (dp) {
            char attrStr[2048];
            int sz = makeAttrStringForAttributes(dp, p.hier[1], attrStr); 
            
            ret = new MYFILE(dp->getOwner(), dp->getDirectory(), 
                             p.hier[3], 0, MYFILE_DOWNLOAD);
            
            ret->setForceDownload(attrStr, sz);
            
            delete dp;
         }
         
#ifdef SOA
      } else if (p.hidx == 4 && !strcmp(p.hier[3], DESCRIPTION) && 
                 !strcmp(p.hier[2], INFODIR)) {
         MYDIRENTRY *dp =  myquerypackage(&p);
         if (dp) {
            char attrStr[4096];
            int sz = makeAttrStringForDescription(dp, p.hier[1], attrStr); 
            
            ret = new MYFILE(dp->getOwner(), dp->getDirectory(), 
                             p.hier[3], 0, MYFILE_DOWNLOAD);
            
            ret->setForceDownload(attrStr, sz);
            
            delete dp;
         }
#endif
      } else if (p.hidx == 4 && 
                 !strcmp(p.hier[3], FILESMD5) && 
                 !strcmp(p.hier[2], INFODIR)) {
         MYDIR *mydir =  myquerypackagecontents (&p, false);
         if (mydir) {
            char tstr[2048];
            sprintf(tstr, "/%s/%s/%s", p.topdir, p.pack, INFODIR);
            
            ret = new MYFILE(mydir->getOwner(), tstr,
                             p.hier[3], 0, MYFILE_DOWNLOAD);
                             
           // This function consumes and deletes mydir
            char* attrStr = 0;
            int sz = makeAttrStringForMD5(mydir, attrStr); 
            ret->setForceDownload(attrStr, sz);
            delete attrStr;
         }
      } else if (p.topdirnum != DRAFTS_N && p.hidx == 2) {
      
        // Download encoded package
         
         EncodedPathInfo ep;
         ep.parse(p.fullpath);
            
        // If we have found an encoding suffix ... search for package
         if (ep.encoding) {
            MYDIRENTRY* dp =  myquerypackage(&ep);
            if (dp) {
            
               long long packid = dp->getId();
            
               jobject jobj = mystartdownloadpackage(packid, ep.encoding);
               if (jobj) {
                  ret = new MYFILE(dp->getOwner(), dp->getDirectory(), 
                                   ep.encodedPackname, jobj, MYFILE_DOWNLOAD);
                  ret->setSize(dp->getStats().st_size);
                  
                 // Mark the size as ENORMOUS! Since we don't know what it is
                 // ret->setSize(0x7fffffffffffffffLL);
               }
            }
            
            delete dp;
         }
         
      } else {
         MYDIRENTRY *dp =  myqueryfile(&p);
      
         if (dp) {
            long long packid = dp->_getPId();
            
            jobject jobj = mystartdownloadfile(packid, dp->getId());
            if (jobj) {
               ret = new MYFILE(dp->getOwner(), dp->getDirectory(), 
                                p.file, jobj, MYFILE_DOWNLOAD);
               ret->setSize(dp->getStats().st_size);
            }
            delete dp;
         }
      }
   }
   
   return ret;
}
MYDIR* Dropbox::openDir(const char* s) {
   debug("Dropbox:openDir: %s\n", s);
   
   MYDIR* ret = NULL;
   
   PathInfo p;
   p.parse(s);
   
   struct stat stats;
   memset(&stats, 0, sizeof(stats));
   stats.st_size  = 555;
   stats.st_mode = 0755 | _S_IFDIR;
   stats.st_uid = 1;
   stats.st_gid = 1;
   
   struct timeb t;
   ftime(&t);
   
   stats.st_atime = t.time;
   stats.st_mtime = t.time;
   stats.st_ctime = t.time;
   
  // If it is one of our known address ...
   if (!*p.topdir) {
      
      ret = new MYDIR(userName(), "/");
      ret->setCompany(companyName());
      
      MYDIRENTRY *de;
      
      de = new MYDIRENTRY(ret->getOwner(), "/", DRAFTS,  stats);
      de->setCompany(companyName());
      ret->addEntry(de);
      
      de = new MYDIRENTRY(ret->getOwner(), "/", GROUPS,  stats);
      de->setCompany(companyName());
      ret->addEntry(de);
      
      de = new MYDIRENTRY(ret->getOwner(), "/", INBOX,   stats);
      de->setCompany(companyName());
      ret->addEntry(de);
      
      de = new MYDIRENTRY(ret->getOwner(), "/", OUTBOX,  stats);
      de->setCompany(companyName());
      ret->addEntry(de);
            
      de = new MYDIRENTRY(ret->getOwner(), "/", OPTIONS, stats);
      de->setCompany(companyName());
      ret->addEntry(de);
      
      de = new MYDIRENTRY(ret->getOwner(), "/", PROJECTS, stats);
      de->setCompany(companyName());
      ret->addEntry(de);
      
      de = new MYDIRENTRY(ret->getOwner(), "/", TRASH,   stats);
      de->setCompany(companyName());
      ret->addEntry(de);
      
      de = new MYDIRENTRY(ret->getOwner(), "/", ".",     stats);
      de->setCompany(companyName());
      ret->addEntry(de);
      
      de = new MYDIRENTRY(ret->getOwner(), "/", "..",    stats);
      de->setCompany(companyName());
      ret->addEntry(de);
      
   } else if (!p.topdirnum) {
      ret = NULL;
   } else if (p.topdirnum == GROUPS_N) {
   
     // GROUPS
      ret = myquerygroups(&p);
   
   } else if (p.topdirnum == PROJECTS_N) {
   
     // Projects ... contains projects as files
      if (p.hidx == 1) {
         ret = myqueryprojects();
      }
   
   } else if (p.topdirnum == OPTIONS_N) {
   
     // Options
      Options *options = mygetoptions();
      
      MYDIRENTRY *de;
      if (options) {
      
         const char* k;
         const char* v;
         char tbuf[1024];
         
        // If toplevel options
         if (p.hidx == 1) {
            ret = new MYDIR(userName(), FULLOPTIONS);
            ret->setCompany(companyName());
            
            for(int i=0; (k=options->getKey(i)); i++) {
               de = new MYDIRENTRY(ret->getOwner(), ret->getDirectory(), 
                                   k, stats);
               de->setCompany(companyName());
               ret->addEntry(de);
            }
         
         } else if (p.hidx >= 2 && p.hidx <= 3 && 
                    (v=options->get(p.hier[1]))) {
                    
           // If specific option
            if (p.hidx == 2) {
               sprintf(tbuf, "/%s/%s", OPTIONS, p.hier[1]);
               ret = new MYDIR(userName(), tbuf);
               ret->setCompany(companyName());
               
               de = new MYDIRENTRY(ret->getOwner(), ret->getDirectory(), 
                                   v, stats);
               de->setCompany(companyName());
               ret->addEntry(de);
               
            } else if (!strcmp(v, p.hier[2])) {
              // Value dir .. must match, then just . and ..
               sprintf(tbuf, "/%s/%s/%s", OPTIONS, p.hier[1], v);
               ret = new MYDIR(userName(), tbuf);
               ret->setCompany(companyName());
            }
            
         } else if (p.hidx >= 2 && p.hidx <= 3 && 
                    !strcmp(p.hier[1], OPT_STORAGEPOOLS)) {
                    
           // If we are listing storagepools, treat that special
           // They are not really options, but stuffing them here anyway
           
            if (p.hidx == 2) {
            
               sprintf(tbuf, "/%s/%s", OPTIONS, p.hier[1]);
               ret = new MYDIR(userName(), tbuf);
               ret->setCompany(companyName());
               
               Vector *vec = queryStoragePoolInformation();
               if (vec) {
                  int num = vec->size();
                  for(int i=0; i < num; i++) {
                     StoragePool* sp = (StoragePool*)vec->elementAt(i);
                     if (sp) {
                        
                        de = new MYDIRENTRY(ret->getOwner(), ret->getDirectory(), 
                                            sp->getPoolName(), stats);
                        de->setCompany(companyName());
                        ret->addEntry(de);
                     }
                  }
                  deleteStoragePoolVector(vec);
               }
            } else {
               StoragePool* sp = getStoragePoolByName(p.hier[2]);
               if (sp) {
                 // Value dir .. must match, then just . and ..
                  sprintf(tbuf, "/%s/%s/%s", OPTIONS, p.hier[1], p.hier[2]);
                  ret = new MYDIR(userName(), tbuf);
                  ret->setCompany(companyName());
                  delete sp;
               }
            }
         }
         
         if (ret) {
            de = new MYDIRENTRY(ret->getOwner(), "/", ".",   stats);
            de->setCompany(companyName());
            ret->addEntry(de);
         
            de = new MYDIRENTRY(ret->getOwner(), "/", "..",  stats);
            de->setCompany(companyName());
            ret->addEntry(de);
         }      
         
         delete options;
      }
   } else if (!*p.pack) {
      ret = myquerypackages(userName(), &p);
   } else if (p.isAccess) {
      MYDIRENTRY *dp =  myquerypackage(&p);
      if (dp) {
        // If the Access directory AND not an Access dir entry
         if (!*p.access) {
            ret = myqueryacls(&p, dp);
         } else {
           // otherwise, just . and .. ... needed to keep some sftp clients from crashing ;-(
           
            char tn[1024];
            sprintf(tn, "/%s/%s/%s/%s", p.topdir, p.pack, p.file, p.access);
            
            ret = new MYDIR(dp->getOwner(), tn);
            ret->setId(dp->getId());
            ret->setPackageFlags(dp->getPackageFlags());
            ret->setPackagePoolId(dp->getPackagePoolId());
            ret->setCompany(dp->getCompany());
            
            
            stats = dp->getStats();
            stats.st_atime  = t.time;
            stats.st_mtime  = t.time;
            stats.st_size   = 555;
            stats.st_uid    = 1;
            stats.st_gid    = 1;
            stats.st_mode   = 0755 | _S_IFDIR;
            
            MYDIRENTRY *mydirent = new MYDIRENTRY(dp->getOwner(), tn, ".", stats);
            mydirent->setId(dp->getId());
            mydirent->setPackageFlags(dp->getPackageFlags());            
            mydirent->setPackagePoolId(dp->getPackagePoolId());
            mydirent->setCompany(dp->getCompany());
            ret->addEntry(mydirent);
            
            mydirent = new MYDIRENTRY(dp->getOwner(), tn, "..", stats);
            mydirent->setId(dp->getId());
            mydirent->setPackageFlags(dp->getPackageFlags());            
            mydirent->setPackagePoolId(dp->getPackagePoolId());           
            mydirent->setCompany(dp->getCompany());
            ret->addEntry(mydirent);
         }
         delete dp;
      }
   } else if (p.topdirnum >= TRASH_N && p.topdirnum <= DRAFTS_N  && 
              p.hidx >= 3 && !strcmp(p.hier[2], INFODIR)) {
   
     // #INFO# dir for inbox, drafts or sent
      MYDIRENTRY* dp = myquerypackage(&p);
      
      if (dp != 0) {
      
        // 3 = #INFO#, 4 = OPTIONS       5 = specific option 6 = value
        //             4 = EXPIRATION
        //             4 = CROSSCOMPANY  5 = Company names  (only on Sent/Drafts)
         if (p.hidx == 3                                                      || 
#ifdef R711
             (p.hidx >= 4 && !strcmp(p.hier[3], CROSSCOMPANY) && 
                                     p.hidx <= 5 && p.topdirnum > INBOX_N)    ||
#endif
             (p.hidx == 4 && !strcmp(p.hier[3], EXPIRATION))                  ||
             (p.hidx >= 4 && !strcmp(p.hier[3], OPTIONS)      && 
                                     p.hidx <= 6)){
            
            char tn[1024];
            sprintf(tn, "/%s/%s/%s", p.topdir, p.pack, p.file);
         
            ret = new MYDIR(dp->getOwner(), tn);
            ret->setId(dp->getId());
            ret->setPackageFlags(dp->getPackageFlags());
            ret->setPackagePoolId(dp->getPackagePoolId());

            ret->setCompany(dp->getCompany());
            
            stats = dp->getStats();
            stats.st_size   = 555;
            stats.st_uid    = 1;
            stats.st_gid    = 1;
            stats.st_mode   = 0755 | _S_IFDIR;
         
            MYDIRENTRY *mydirent = new MYDIRENTRY(dp->getOwner(), tn, ".", 
                                                  stats);
            mydirent->setId(dp->getId());
            mydirent->setPackageFlags(dp->getPackageFlags());
            mydirent->setPackagePoolId(dp->getPackagePoolId());
            mydirent->setCompany(dp->getCompany());
            ret->addEntry(mydirent);
            
            mydirent = new MYDIRENTRY(dp->getOwner(), tn, "..", stats);
            mydirent->setId(dp->getId());
            mydirent->setPackageFlags(dp->getPackageFlags());
            mydirent->setPackagePoolId(dp->getPackagePoolId());            
            mydirent->setCompany(dp->getCompany());
            ret->addEntry(mydirent);
            
           // If #INFO# level
            if (p.hidx == 3) {
            
              // ALL (trash, inbox, drafts, sent) show hash attributes,
              //  description and files.md5
               char attrStr[4096];
               int sz = makeAttrStringForAttributes(dp, p.hier[1],
                                                    attrStr); 
               
               stats = dp->getStats();
               stats.st_size   = sz;
               stats.st_uid    = 1;
               stats.st_gid    = 1;
               stats.st_mode   = 0644 | _S_IFREG;
               mydirent = new MYDIRENTRY(dp->getOwner(), tn, ATTRIBUTES, 
                                         stats);
               mydirent->setId(dp->getId());
               mydirent->setPackageFlags(dp->getPackageFlags());
               mydirent->setPackagePoolId(dp->getPackagePoolId());
               mydirent->setCompany(dp->getCompany());
               ret->addEntry(mydirent);
               
#ifdef SOA
               sz = makeAttrStringForDescription(dp, p.hier[1],
                                                 attrStr); 
               
               stats = dp->getStats();
               stats.st_size   = sz;
               stats.st_uid    = 1;
               stats.st_gid    = 1;
               stats.st_mode   = 0644 | _S_IFREG;
               mydirent = new MYDIRENTRY(dp->getOwner(), tn, DESCRIPTION, 
                                         stats);
               mydirent->setId(dp->getId());
               mydirent->setPackageFlags(dp->getPackageFlags());
               mydirent->setPackagePoolId(dp->getPackagePoolId());
               mydirent->setCompany(dp->getCompany());
               ret->addEntry(mydirent);
#endif
               
               MYDIR *mydir =  myquerypackagecontents (&p, false);
               if (mydir) {
                  
                  char* myAttrStr = 0;
                  
                 // This function consumes and deletes mydir
                  sz = makeAttrStringForMD5(mydir, myAttrStr); 
                  
                  delete myAttrStr;
                  
                  stats.st_size   = sz;
                  stats.st_mode   = 0644 | _S_IFREG;
                  
                  mydirent = new MYDIRENTRY(dp->getOwner(), tn, FILESMD5, 
                                            stats);
                  mydirent->setId(dp->getId());
                  mydirent->setPackageFlags(dp->getPackageFlags());
                  mydirent->setPackagePoolId(dp->getPackagePoolId());
                  mydirent->setCompany(dp->getCompany());
                  ret->addEntry(mydirent);
               }
                  
              // Expiration
               stats = dp->getStats();
               stats.st_size   = 555;
               
              // Set time to expire time
               stats.st_atime = stats.st_ctime;               
               stats.st_mtime = stats.st_ctime;               
               mydirent = new MYDIRENTRY(dp->getOwner(), tn, EXPIRATION, 
                                         stats);
               mydirent->setId(dp->getId());
               mydirent->setPackageFlags(dp->getPackageFlags());
               mydirent->setPackagePoolId(dp->getPackagePoolId());
               mydirent->setCompany(dp->getCompany());
               ret->addEntry(mydirent);
                  
              // Options
               stats = dp->getStats();
               stats.st_size   = 555;
               mydirent = new MYDIRENTRY(dp->getOwner(), tn, OPTIONS, 
                                         stats);
               mydirent->setId(dp->getId());
               mydirent->setPackageFlags(dp->getPackageFlags());
               mydirent->setPackagePoolId(dp->getPackagePoolId());
               mydirent->setCompany(dp->getCompany());
               ret->addEntry(mydirent);
               
#ifdef R711
              // Only show cross company if drafts/sent
               if (p.topdirnum > INBOX_N) {
                 // Cross Company
                  stats = dp->getStats();
                  stats.st_size   = 555;
                  mydirent = new MYDIRENTRY(dp->getOwner(), tn, CROSSCOMPANY,
                                            stats);
                  mydirent->setId(dp->getId());
                  mydirent->setPackageFlags(dp->getPackageFlags());
                  mydirent->setPackagePoolId(dp->getPackagePoolId());
                  mydirent->setCompany(dp->getCompany());
                  ret->addEntry(mydirent);
               }
#endif
            } else if (!strcmp(p.hier[3], EXPIRATION)) {
               ;  // Nothing to add here
               
#ifdef R711
            } else if (p.topdirnum > INBOX_N && !strcmp(p.hier[3], CROSSCOMPANY)) {
            
               Vector *v = queryPackageCompanies(dp);
               if (v) {
                  if (p.hidx == 4) {
                     for(int ii = 0; ii < v->size(); ii++) {
                        char* comp = (char*)v->elementAt(ii);
                        mydirent = new MYDIRENTRY(dp->getOwner(), tn, comp, stats);
                        mydirent->setId(dp->getId());
                        mydirent->setPackageFlags(dp->getPackageFlags());
                        mydirent->setPackagePoolId(dp->getPackagePoolId());
                        mydirent->setCompany(dp->getCompany());
                        ret->addEntry(mydirent);
                     }
                  } else {
                     int found = 0;
                     for(int ii = 0; ii < v->size(); ii++) {
                        char* comp = (char*)v->elementAt(ii);
                        if (!strcmp(comp, p.hier[4])) {
                           found = 1;
                           break;
                        }
                     }
                     
                     if (!found) {
                        delete v;
                        v = 0;
                     }
                  }
               }
               
               if (!v) {
                  delete ret;
                  ret = 0;
               } else {
                 // Not positive if this really will correctly delete the string. SHOULD
                  delete v;
               }
#endif
            } else if (p.topdirnum >= INBOX_N && !strcmp(p.hier[3], OPTIONS)) {
               
               if (p.hidx == 4) {
                  mydirent = new MYDIRENTRY(dp->getOwner(), tn, 
                                            POPT_HIDDEN, stats);
                  mydirent->setId(dp->getId());
                  mydirent->setPackageFlags(dp->getPackageFlags());
                  mydirent->setPackagePoolId(dp->getPackagePoolId());
                  mydirent->setCompany(dp->getCompany());
                  ret->addEntry(mydirent);

#ifdef SOA
                  mydirent = new MYDIRENTRY(dp->getOwner(), tn, 
                                            POPT_ITAR, stats);
                  mydirent->setId(dp->getId());
                  mydirent->setPackageFlags(dp->getPackageFlags());
                  mydirent->setPackagePoolId(dp->getPackagePoolId());
                  mydirent->setCompany(dp->getCompany());
                  ret->addEntry(mydirent);
#endif

                  mydirent = new MYDIRENTRY(dp->getOwner(), tn, 
                                            POPT_SENDNOTIFY, stats);
                  mydirent->setId(dp->getId());
                  mydirent->setPackageFlags(dp->getPackageFlags());
                  mydirent->setPackagePoolId(dp->getPackagePoolId());
                  mydirent->setCompany(dp->getCompany());
                  ret->addEntry(mydirent);
                  
                  mydirent = new MYDIRENTRY(dp->getOwner(), tn, 
                                            POPT_RETURNRECEIPT, stats);
                  mydirent->setId(dp->getId());
                  mydirent->setPackageFlags(dp->getPackageFlags());
                  mydirent->setPackagePoolId(dp->getPackagePoolId());
                  mydirent->setCompany(dp->getCompany());
                  ret->addEntry(mydirent);
                  
                  mydirent = new MYDIRENTRY(dp->getOwner(), tn, 
                                            POPT_STORAGEPOOL, stats);
                  mydirent->setId(dp->getId());
                  mydirent->setPackageFlags(dp->getPackageFlags());
                  mydirent->setPackagePoolId(dp->getPackagePoolId());
                  mydirent->setCompany(dp->getCompany());
                  ret->addEntry(mydirent);
                  
               } else if (!strcmp(p.hier[4], POPT_HIDDEN)) {
               
                  char* val = "false";
                  if ((dp->getPackageFlags() & HIDDEN_FLAG)) {
                     val = "true";
                  }
                  if (p.hidx == 5) {
                     mydirent = new MYDIRENTRY(dp->getOwner(), tn, val, stats);
                     mydirent->setId(dp->getId());
                     mydirent->setPackageFlags(dp->getPackageFlags());
                     mydirent->setPackagePoolId(dp->getPackagePoolId());
                     mydirent->setCompany(dp->getCompany());
                     ret->addEntry(mydirent);
                  } else if (!strcmp(p.hier[5], val)) {
                    // The . and .. is just fine
                     ;
                  } else {
                     delete ret;
                     ret = 0;
                  }
#ifdef SOA
               } else if (!strcmp(p.hier[4], POPT_ITAR)) {
               
                  char* val = "false";
                  if ((dp->getPackageFlags() & ITAR_FLAG)) {
                     val = "true";
                  }
                  if (p.hidx == 5) {
                     mydirent = new MYDIRENTRY(dp->getOwner(), tn, val, stats);
                     mydirent->setId(dp->getId());
                     mydirent->setPackageFlags(dp->getPackageFlags());
                     mydirent->setPackagePoolId(dp->getPackagePoolId());
                     mydirent->setCompany(dp->getCompany());
                     ret->addEntry(mydirent);
                  } else if (!strcmp(p.hier[5], val)) {
                    // The . and .. is just fine
                     ;
                  } else {
                     delete ret;
                     ret = 0;
                  }
#endif
               } else if (!strcmp(p.hier[4], POPT_SENDNOTIFY)) {
               
                  char* val = "false";
                  if ((dp->getPackageFlags() & SENDNOTIFICATION_FLAG)) {
                     val = "true";
                  }
                  if (p.hidx == 5) {
                     mydirent = new MYDIRENTRY(dp->getOwner(), tn, val, stats);
                     mydirent->setId(dp->getId());
                     mydirent->setPackageFlags(dp->getPackageFlags());
                     mydirent->setPackagePoolId(dp->getPackagePoolId());
                     mydirent->setCompany(dp->getCompany());
                     ret->addEntry(mydirent);
                  } else if (!strcmp(p.hier[5], val)) {
                    // The . and .. is just fine
                     ;
                  } else {
                     delete ret;
                     ret = 0;
                  }
               } else if (!strcmp(p.hier[4], POPT_RETURNRECEIPT)) {
               
                  char* val = "false";
                  if ((dp->getPackageFlags() & RETURNRECEIPT_FLAG)) {
                     val = "true";
                  }
                  if (p.hidx == 5) {
                     mydirent = new MYDIRENTRY(dp->getOwner(), tn, val, stats);
                     mydirent->setId(dp->getId());
                     mydirent->setPackageFlags(dp->getPackageFlags());
                     mydirent->setPackagePoolId(dp->getPackagePoolId());
                     mydirent->setCompany(dp->getCompany());
                     ret->addEntry(mydirent);
                  } else if (!strcmp(p.hier[5], val)) {
                    // The . and .. is just fine
                     ;
                  } else {
                     delete ret;
                     ret = 0;
                  }
                  
               } else if (!strcmp(p.hier[4], POPT_STORAGEPOOL)) {
               
                  StoragePool *sp = getStoragePoolById(dp->getPackagePoolId());
                  if (sp != NULL) {
                     const char* val = sp->getPoolName();
                     if (p.hidx == 5) {
                        mydirent = new MYDIRENTRY(dp->getOwner(), tn, val, stats);
                        mydirent->setId(dp->getId());
                        mydirent->setPackageFlags(dp->getPackageFlags());
                        mydirent->setPackagePoolId(dp->getPackagePoolId());
                        mydirent->setCompany(dp->getCompany());
                        ret->addEntry(mydirent);
                     } else if (!strcmp(p.hier[5], val)) {
                       // The . and .. is just fine
                        ;
                     } else {
                        delete ret;
                        ret = 0;
                     }
                     
                     delete sp;
                  } else {
                     delete ret;
                     ret = 0;
                  }
               } else {
                  delete ret;
                  ret = 0;
               }
            } else {
              // If inbox, OR, not options nogo
               delete ret;
               ret = 0;
            }
         }
      }
      
      if (dp) delete dp;
      
   } else {
   
     /*
     ** Package contents may contain a mix of real things (files and ACCESS 
     **  dir) and ficticious things (mkdir's inside a package to create
     **  hierarchy which last only for that sftp session unless a file is
     **  created at that level)
     */
      ret = myquerypackagecontents(&p, 1);
      
     /*
     ** We need to return the right 'stuff' for the request level or hierarchy
     **
     ** For a package level query, return all items with NO hierarchy, and the
     **  first segment (uniqized). For all others, return the correct segment
     **  which matches to that level.
     **
     ** If there are collisions where there are DIR parts and FILE parts with 
     **  the same name at the same level, return the FILE part. This is NOT 
     **  great ... TODO, just make the DIR part uniq, and then manage that 
     **  everywhere that is needed.
     **
     ** myquerypackagecontents passing 1 takes care of this stuff
     */
   }
   return ret;
}

int Dropbox::connect() {
   debug("Dropbox:connect\n");
   
#ifdef SOA
   if (!myconnect(dropboxUrl) && !mylogin(dropboxToken)) {
      return 0;
   }
#else
   char* secure = getenv("SECUREMODE");
   if (secure != 0) {
   
      for(int i=0; secure[i]; i++) {
         secure[i] = tolower(secure[i]);
      }
      
      if (!strcmp(secure, "yes")  ||
          !strcmp(secure, "true") ||
          !strcmp(secure, "1")) {
         ;
      } else {
         secure = 0;
      }
   }
   if (!myconnect(dropboxHost, dropboxPort, secure != 0) && 
       !mylogin(dropboxToken)) {
      return 0;
   }
#endif
   return -1;
}

int     Dropbox::doStat(char* s, Attrib* a) {
   debug("Dropbox:doStat: %s\n", s);
   
  // If it is one of our known addresses ...
   PathInfo p;
   p.parse(s);
   
  // If this is NOT a good topdir, just return error
   if (*p.topdir && !p.topdirnum) {
      return -1;
   }
   
   struct timeb t;
   ftime(&t);
   
  // Set up for the default return of good dir
   attrib_clear(a);
   a->flags = 0;
   a->flags |= SSH2_FILEXFER_ATTR_SIZE;
   a->size = 555;
   a->flags |= SSH2_FILEXFER_ATTR_UIDGID;
   a->uid = 1;
   a->gid = 1;
   a->flags |= SSH2_FILEXFER_ATTR_PERMISSIONS;
   a->perm = _S_IFDIR | 0755;
   a->flags |= SSH2_FILEXFER_ATTR_ACMODTIME;
   a->atime = t.time;
   a->mtime = t.time;
   
  // If no package (NO all/modifiable/owned if GROUPS, or No option if OPTIONS
  //                or no project if Projects)
   if (!*p.pack) {
      return 0;
   } else if (p.topdirnum == PROJECTS_N) {
     // Projects
     // Lookup the the specified project ... 
      
     // If they are testing the waters with a project name ...
      if (p.hidx == 2) {
         MYDIR* mydir = myqueryprojects();
         if (mydir) {
            
            MYDIRENTRY* mydirent = 0;
            while((mydirent = mydir->readDir())) {
               if (!strcmp(mydirent->getName(), p.hier[1])) {
                  struct stat stats = mydirent->getStats();
                  
                  a->size  = stats.st_size;
                  a->atime = stats.st_atime;
                  a->mtime = stats.st_mtime;
                  a->perm  = _S_IFREG | 0444;
                  
                  delete mydirent;
                  delete mydir;
                  return 0;
               }
               delete mydirent;
            }
            delete mydir;
         }
      }
   } else if (p.topdirnum == GROUPS_N) {
     // GROUPS
     // Lookup the the specified group ... works if specified path valid, 
      MYDIRENTRY* mydirent = mystatgroup(&p);
      if (mydirent) {
         struct stat stats = mydirent->getStats();
         
         a->size = stats.st_size;
         a->atime = stats.st_atime;
         a->mtime = stats.st_mtime;
         delete mydirent;
         return 0;
      }

   } else if (p.topdirnum == OPTIONS_N) {
     // OPTIONS - We know that there is at least a specified option, validate
      Options *options = mygetoptions();
      if (options) {
         
         if (p.hidx >= 2 && p.hidx <= 3) {
         
            const char* val = options->get(p.hier[1]);
            
            if (val) {
               if ((p.hidx == 2 || (p.hidx == 3 && !strcmp(val, p.hier[2])))) {
                  delete options;
                  return 0;
               }
            } else if (!strcmp(p.hier[1], OPT_STORAGEPOOLS)) {
               if (p.hidx == 2) {
                  delete options;
                  return 0;
               } else {
                  StoragePool* sp = getStoragePoolByName(p.hier[2]);
                  if (sp) {
                     delete sp;
                     delete options;
                     return 0;
                  }
               }
            }
         }
         delete options;
      }
      
   } else if (!*p.file) {
      
      
      EncodedPathInfo ep;
      ep.parse(s);
      
      MYDIRENTRY* mydirent = myquerypackage(&p);
      
      if (!mydirent && ep.encoding) {
         mydirent = myquerypackage(&ep);
      } else {
         ep.encoding = NULL;  // Turn encoding off for use below
      }
      
      if (mydirent) {
         struct stat stats = mydirent->getStats();
         
         a->size = stats.st_size;
         a->atime = stats.st_atime;
         a->mtime = stats.st_mtime;
         
        // If we are stating the encoded 'file' ... say so
         if (ep.encoding) {
            a->perm = _S_IFREG | 0644;
         }
         
         delete mydirent;
         return 0;
      }
   } else if (p.isAccess) {
      MYDIRENTRY * mydirent = myquerypackage(&p);
      if (mydirent) {
         if (!*p.access) {
           // If the Access directory
           
            delete mydirent;
            return 0;
         } else {
            MYDIR* mydir = myqueryacls(&p, mydirent);
            delete mydirent;
            if (mydir) {
               
               while((mydirent = mydir->readDir())) {
                  if (!strcmp(mydirent->getName(), p.access)) {
                     struct stat stats = mydirent->getStats();
                     
                     a->size = stats.st_size;
                     a->atime = stats.st_atime;
                     a->mtime = stats.st_mtime;
                     
                     delete mydirent;
                     delete mydir;
                     return 0;
                  }
                  delete mydirent;
               }
               delete mydir;
            }
         }
      }
   } else if (p.topdirnum >= TRASH_N && p.topdirnum <= DRAFTS_N  && 
              p.hidx >= 3 && !strcmp(p.hier[2], INFODIR)) {
   
     // #INFO# dir
      MYDIRENTRY* mydirent = myquerypackage(&p);
      
      if (mydirent == NULL) return 0;
      
      if (p.hidx == 3) {
         a->atime = mydirent->getStats().st_mtime;
         a->mtime = mydirent->getStats().st_mtime;
         
         delete mydirent;
         return 0;
      } else if (p.hidx == 4 && !strcmp(p.hier[3], ATTRIBUTES)) {
         
         char attrStr[2048];
         int sz = makeAttrStringForAttributes(mydirent, p.hier[1], attrStr); 
         
         a->size = sz;
         a->perm = _S_IFREG | 0644;
         a->atime = mydirent->getStats().st_mtime;
         a->mtime = mydirent->getStats().st_mtime;
         
         delete mydirent;
         return 0;
#ifdef SOA
      } else if (p.hidx == 4 && !strcmp(p.hier[3], DESCRIPTION)) {
         
         char attrStr[2048];
         int sz = makeAttrStringForDescription(mydirent, p.hier[1], attrStr); 
         
         a->size = sz;
         a->perm = _S_IFREG | 0644;
         a->atime = mydirent->getStats().st_mtime;
         a->mtime = mydirent->getStats().st_mtime;
         
         delete mydirent;
         return 0;
#endif
      } else if (p.hidx == 4 && !strcmp(p.hier[3], FILESMD5)) {
         
         MYDIR *mydir =  myquerypackagecontents (&p, false);
         if (mydir) {
            char *attrStr = 0;
            
           // This function consumes and deletes mydir
            int sz = makeAttrStringForMD5(mydir, attrStr); 
            
            delete attrStr;
         
            a->size = sz;
            a->perm = _S_IFREG | 0644;
            a->atime = mydirent->getStats().st_mtime;
            a->mtime = mydirent->getStats().st_mtime;
         
            delete mydirent;
            return 0;
         }
      } else if (p.hidx == 4 && !strcmp(p.hier[3], EXPIRATION)) {
         
        // Set expiration time
         a->atime = mydirent->getStats().st_ctime;
         a->mtime = mydirent->getStats().st_ctime;
         
         delete mydirent;
         return 0;
         
#ifdef R711
      } else if (p.topdirnum > INBOX_N && !strcmp(p.hier[3], CROSSCOMPANY)) {
         Vector *v = queryPackageCompanies(mydirent);
         if (v) {
            if (p.hidx == 4) {
               a->atime = mydirent->getStats().st_mtime;
               a->mtime = mydirent->getStats().st_mtime;
               
               delete mydirent;
               delete v;
               return 0;
               
            } else {
               for(int ii = 0; ii < v->size(); ii++) {
                  char* comp = (char*)v->elementAt(ii);
                  if (!strcmp(comp, p.hier[4])) {
                     a->atime = mydirent->getStats().st_mtime;
                     a->mtime = mydirent->getStats().st_mtime;
                     
                     delete mydirent;
                     delete v;
                     return 0;
                  }
               }
            }
            delete v;
         }
         
         delete mydirent;
#endif
      } else if (p.topdirnum >= INBOX_N && !strcmp(p.hier[3], OPTIONS)) {
         if (p.hidx == 4) {
            a->atime = mydirent->getStats().st_mtime;
            a->mtime = mydirent->getStats().st_mtime;
            
            delete mydirent;
            return 0;
         } else if (!strcmp(p.hier[4], POPT_HIDDEN)) {
            
            char* val = "false";
            if ((mydirent->getPackageFlags() & HIDDEN_FLAG)) {
               val = "true";
            }
            
            if (p.hidx == 5 || !strcmp(p.hier[5], val)) {
               a->atime = mydirent->getStats().st_mtime;
               a->mtime = mydirent->getStats().st_mtime;
               
               delete mydirent;
               return 0;
            }
#ifdef SOA
         } else if (!strcmp(p.hier[4], POPT_ITAR)) {
            
            char* val = "false";
            if ((mydirent->getPackageFlags() & ITAR_FLAG)) {
               val = "true";
            }
            
            if (p.hidx == 5 || !strcmp(p.hier[5], val)) {
               a->atime = mydirent->getStats().st_mtime;
               a->mtime = mydirent->getStats().st_mtime;
               
               delete mydirent;
               return 0;
            }
#endif
         } else if (!strcmp(p.hier[4], POPT_SENDNOTIFY)) {
            
            char* val = "false";
            if ((mydirent->getPackageFlags() & SENDNOTIFICATION_FLAG)) {
               val = "true";
            }
            
            if (p.hidx == 5 || !strcmp(p.hier[5], val)) {
               a->atime = mydirent->getStats().st_mtime;
               a->mtime = mydirent->getStats().st_mtime;
               
               delete mydirent;
               return 0;
            }
         } else if (!strcmp(p.hier[4], POPT_RETURNRECEIPT)) {
            
            char* val = "false";
            if ((mydirent->getPackageFlags() & RETURNRECEIPT_FLAG)) {
               val = "true";
            }
            
            if (p.hidx == 5 || !strcmp(p.hier[5], val)) {
               a->atime = mydirent->getStats().st_mtime;
               a->mtime = mydirent->getStats().st_mtime;
               
               delete mydirent;
               return 0;
            }
         } else if (!strcmp(p.hier[4], POPT_STORAGEPOOL)) {
            
            StoragePool *sp = getStoragePoolById(mydirent->getPackagePoolId());
            
            if (sp != 0) {
               if (p.hidx == 5 || !strcmp(p.hier[5], sp->getPoolName())) {
                  a->atime = mydirent->getStats().st_mtime;
                  a->mtime = mydirent->getStats().st_mtime;
                  
                  delete mydirent;
                  delete sp;
                  return 0;
               }
               delete sp;
            }
         }
      }
      
      delete mydirent;
      
   } else {
   
      char news[1024];
      strcpy(news, p.fullpath);
      
      char* fname = strrchr(news, '/');
      *fname++ = '\0';
      
      PathInfo ap;
      ap.parse(news);
      
      MYDIR * mydir = myquerypackagecontents(&ap, 1);
      if (mydir) {
         MYDIRENTRY *mydirent;
         while((mydirent = mydir->readDir())) {
            
            if (!strcmp(mydirent->getName(), fname)) {
               struct stat stats = mydirent->getStats();
               
               a->size = stats.st_size;
               if (S_ISDIR(stats.st_mode)) {
                  a->perm = _S_IFDIR | 0755;
               } else {
                  a->perm = _S_IFREG | 0644;
               }
               a->atime = stats.st_atime;
               a->mtime = stats.st_mtime;
               delete mydirent;
               delete mydir;
               return 0;
            }
            delete mydirent;
         }
         delete mydir;
      }
   }
   
   return -1;
}

int     Dropbox::unlink(char* s) {
   debug("Dropbox:unlink: %s\n", s);
   
   PathInfo p;
   p.parse(s);
   
  // If its NOT a fixed thing that can't possible be deleted as a file
   if ((p.topdirnum == SENT_N || p.topdirnum == DRAFTS_N) &&
       *p.file && !p.isAccess) {
   
      MYDIR * mydir = myquerypackagecontents(&p, 0);
      if (mydir) {
         MYDIRENTRY *mydirent;
         
         while((mydirent = mydir->readDir())) {
            if (!strcmp(mydirent->getName(), p.file) && 
                (mydirent->getStats().st_mode & _S_IFREG)) {

               int ret = mydeletefilefrompackage(mydir->getId(), 
                                                 mydirent->getId());
               delete mydirent;
               delete mydir;
               return ret;
            }
            delete mydirent;
         }
         delete mydir;
      }
   }

   return -1;
}

int     Dropbox::mkdir(char* s) {
   debug("Dropbox:mkdir: %s\n", s);
   
   PathInfo p;
   p.parse(s);
   
   int chooser = 0;
   int ret = -1;
   
   if (p.isAccess && *p.access) {
      MYDIRENTRY *dp = myquerypackage(&p);
      if (dp) {
         long long packid = dp->getId();
         delete dp;
         ret = myaddacl(packid, p.access);
      }
   } else if (p.topdirnum == PROJECTS_N) {
   
     // Nada
     
   } else if (p.topdirnum == GROUPS_N) {
     // GROUPS
      if (p.hidx == 3) {
         if ((!strcmp(p.hier[1], ALL)        ||
              !strcmp(p.hier[1], MODIFIABLE) ||
              !strcmp(p.hier[1], OWNED))) {
            ret = mycreategroup(p.hier[2]);
         }
      } else {
         if (p.hidx == 5) {
           //    /groups/allModOwner/grp/members/val
            if (!strcmp(p.hier[3], MEMBERS)) {
               ret = myaddmemberaccess(p.hier[2], p.hier[4], JNI_TRUE);
            }
         } else if (p.hidx == 6 && !strcmp(p.hier[3], PROPERTIES)) {
            
            if (!strcmp(p.hier[4], LISTABILITY)) {
              //    /groups/allModOwner/grp/properties/listability/val
               ret = mysetgroupattributes(p.hier[2], p.hier[5], JNI_FALSE);
            } else if (!strcmp(p.hier[4], VISIBILITY)) {
              //    /groups/allModOwner/grp/properties/visibility/val
               ret = mysetgroupattributes(p.hier[2], p.hier[5], JNI_TRUE);
            } else if (!strcmp(p.hier[4], GACCESS)) {
              //    /groups/allModOwner/grp/properties/access/val
               ret = myaddmemberaccess(p.hier[2], p.hier[5], JNI_FALSE);
            }
         }         
      }
   } else if (p.topdirnum == OPTIONS_N) {
     // OPTIONS
      
     // Handle shortcuts first
      if (!strcmp(p.hier[p.hidx-1], NOTIFY_SC) ||
          !strcmp(p.hier[p.hidx-1], NOTIFICATION_SC)) {
         ret = mysetoption(OPT_SENDNOTIFICATIONDEFAULT, "true");
      } else if (!strcmp(p.hier[p.hidx-1], NONOTIFY_SC) ||
                 !strcmp(p.hier[p.hidx-1], NONOTIFICATION_SC)) {
         ret = mysetoption(OPT_SENDNOTIFICATIONDEFAULT, "false");
      } else if (!strcmp(p.hier[p.hidx-1], RECEIPT_SC) ||
                 !strcmp(p.hier[p.hidx-1], RETURNRECEIPT_SC)) {
         ret = mysetoption(OPT_RETURNRECEIPTDEFAULT, "true");
      } else if (!strcmp(p.hier[p.hidx-1], NORECEIPT_SC) ||
                 !strcmp(p.hier[p.hidx-1], NORETURNRECEIPT_SC)) {
         ret = mysetoption(OPT_RETURNRECEIPTDEFAULT, "false");
      } else if (!strcmp(p.hier[p.hidx-1], SHOWHIDDEN_SC) ||
                 !strcmp(p.hier[p.hidx-1], SHOW_SC)       ||
                 !strcmp(p.hier[p.hidx-1], SHOWALL_SC)) {
         ret = mysetoption(OPT_SHOWHIDDEN, "true");
      } else if (!strcmp(p.hier[p.hidx-1], HIDEHIDDEN_SC) ||
                 !strcmp(p.hier[p.hidx-1], HIDE_SC)) {
         ret = mysetoption(OPT_SHOWHIDDEN, "false");
#ifdef SOA
      } else if (!strcmp(p.hier[p.hidx-1], ITAR_SC)) {
         ret = mysetoption(OPT_ITARSESSIONCERTIFIED, "true");
      } else if (!strcmp(p.hier[p.hidx-1], NOITAR_SC)) {
         ret = mysetoption(OPT_ITARSESSIONCERTIFIED, "false");
      } else if (!strcmp(p.hier[p.hidx-1], ITARCREATE_SC)) {
         ret = mysetoption(OPT_ITARPACKAGECREATE, "true");
      } else if (!strcmp(p.hier[p.hidx-1], NOITARCREATE_SC)) {
         ret = mysetoption(OPT_ITARPACKAGECREATE, "false");
#endif
      } else {
         
        // /options/SpecificOption/value
         if (p.hidx == 3) {
            ret = mysetoption(p.hier[1], p.hier[2]);
         }
      }
   } else if ((p.topdirnum == SENT_N || p.topdirnum == DRAFTS_N) && *p.pack &&
              ((++chooser > 0 && (!strcmp(p.hier[p.hidx-1], NOTIFICATION_SC) ||
                                  !strcmp(p.hier[p.hidx-1], NOTIFY_SC)))     ||
                
               (++chooser > 0 && (!strcmp(p.hier[p.hidx-1], 
                                          NONOTIFICATION_SC)                 ||
                                  !strcmp(p.hier[p.hidx-1], NONOTIFY_SC)))   ||
                
               (++chooser > 0 && (!strcmp(p.hier[p.hidx-1], 
                                          RETURNRECEIPT_SC)                  ||
                                  !strcmp(p.hier[p.hidx-1], RECEIPT_SC)))    ||
                
               (++chooser > 0 && (!strcmp(p.hier[p.hidx-1], 
                                          NORETURNRECEIPT_SC)                ||
                                  !strcmp(p.hier[p.hidx-1], NORECEIPT_SC)))  ||

               (++chooser > 0 && (!strcmp(p.hier[p.hidx-1], HIDE_SC)         ||
                                  !strcmp(p.hier[p.hidx-1], HIDDEN_SC)))     ||
                
               (++chooser > 0 && (!strcmp(p.hier[p.hidx-1], NOTHIDDEN_SC)    ||
                                  !strcmp(p.hier[p.hidx-1], NOHIDE_SC)       ||
                                  !strcmp(p.hier[p.hidx-1], SHOW_SC))))) {
              
     //  Shortcut for package option 
      MYDIRENTRY *dp = myquerypackage(&p);
      if (dp) {
         long long packid = dp->getId();
         delete dp;
         int val = (chooser & 1) != 0?1:0;
         if (chooser <= 2) {
            ret = mysetpackageflag(packid, SENDNOTIFICATION_FLAG, val);
         } else if (chooser <= 4) {
            ret = mysetpackageflag(packid, RETURNRECEIPT_FLAG,    val);
         } else {
            ret = mysetpackageflag(packid, HIDDEN_FLAG,    val);
         }
         
        // ITAR does not go here, cause it cannot be set
        
      }
   } else if ((p.topdirnum == SENT_N || p.topdirnum == DRAFTS_N) && *p.pack && 
              p.hidx >= 3 && !strcmp(p.hier[2], INFODIR)) {
              
     // Allow them to change package options
      if (p.hidx == 6 && !strcmp(p.hier[3], OPTIONS)) {
         MYDIRENTRY *dp = myquerypackage(&p);
         if (dp) {
            long long packid = dp->getId();
            delete dp;
            
            int setOrReset = 0;
            int flg        = 1;
            
            if (!strcmp(p.hier[5],"off")   || !strcmp(p.hier[5],"OFF") ||
                !strcmp(p.hier[5],"false") || !strcmp(p.hier[5],"FALSE")) {
               setOrReset = 0;
            } else if (!strcmp(p.hier[5],"on")   || !strcmp(p.hier[5],"ON") ||
                       !strcmp(p.hier[5],"true") || !strcmp(p.hier[5],"TRUE")){
               setOrReset = 1;
            } else {
               flg = 0;
            }
            
           // ITAR does not go here cause cannot set it
            if (flg) {
               if (!strcmp(p.hier[4], POPT_SENDNOTIFY)) {
                  ret = mysetpackageflag(packid, SENDNOTIFICATION_FLAG, 
                                         setOrReset);
               } else if (!strcmp(p.hier[4], POPT_RETURNRECEIPT)) {
                  ret = mysetpackageflag(packid, RETURNRECEIPT_FLAG, 
                                         setOrReset);
               } else if (!strcmp(p.hier[4], POPT_HIDDEN)) {
                  ret = mysetpackageflag(packid, HIDDEN_FLAG, 
                                         setOrReset);
               }
            }
         }
         
      } else if (p.hidx == 5 && !strcmp(p.hier[3], EXPIRATION)) {
      
        // Allow them to change package expiration
         MYDIRENTRY *dp = myquerypackage(&p);
         if (dp) {
            long long packid = dp->getId();
            delete dp;
            
            int newexpiration;
            if (sscanf(p.hier[4], "%d", &newexpiration) == 1 &&
                newexpiration >= 0) {
                
               ret = mysetpackageexpiration(packid, newexpiration);
            }
         }
      }
   } else if (p.topdirnum == DRAFTS_N && *p.pack && !*p.file) {
      ret = mycreatepackage(p.pack);
   } else if (p.topdirnum == DRAFTS_N && *p.pack && 
              !strcmp(p.file, DONEVALUE)) {
      MYDIRENTRY *dp = myquerypackage(&p);
      if (dp) {
         long long packid = dp->getId();
         delete dp;
         ret = mycommitpackage(packid);
      }
   } else if (p.topdirnum == DRAFTS_N && *p.pack && *p.file) {
     // If someone is making some hierarchy
      
     // Make sure it doesn't already exist
     
     // remove final segment (query parent dir), make new PathInfo
      char news[1024];
      strcpy(news, p.fullpath);
      char* fname = strrchr(news, '/');
      *fname++ = '\0';
      
      PathInfo ap;
      ap.parse(news);
      
      MYDIR * mydir = myquerypackagecontents(&ap, 1);
      if (mydir) {
      
         MYDIRENTRY *mydirent=NULL;
         while((mydirent = mydir->readDir())) {
            
            if (!strcmp(mydirent->getName(), fname)) {
               delete mydirent;
               break;
            }
            delete mydirent;
         }
         if (!mydirent) {
            MadeDirectories *madedirs = addDirectories(mydir->getId());
            if (madedirs) {
               struct stat stats;
               struct timeb t;
               
               ftime(&t);
               stats.st_atime  = t.time;
               stats.st_mtime  = t.time;
               stats.st_size   = 555;
               stats.st_uid    = 1;
               stats.st_gid    = 1;
               stats.st_mode   = 0755 | _S_IFDIR;
               
               mydirent = new MYDIRENTRY(mydir->getOwner(), 
                                         news, fname, stats);
               mydirent->setId(mydir->getId());
               mydirent->setPackageFlags(mydir->getPackageFlags());
               mydirent->setPackagePoolId(mydir->getPackagePoolId());
               mydirent->setCompany(mydir->getCompany());
               madedirs->addEntry(mydirent);
               ret = 0;
            }
         }
         delete mydir;
      }
   }
   return ret;
}
int     Dropbox::rmdir(char* s) {
   debug("Dropbox:rmdir: %s\n", s);
   
   PathInfo p;
   p.parse(s);
   
   int ret = -1;
   
   if (p.isAccess && *p.access) {
      MYDIRENTRY * dp = myquerypackage(&p);
      if (dp) {
         long long packid = dp->getId();
         delete dp;
         ret = myremoveacl(packid, p.access);
      }
   } else if (p.topdirnum == GROUPS_N) {
     // GROUPS
      if (p.hidx == 3) {
         if ((!strcmp(p.hier[1], ALL)        ||
              !strcmp(p.hier[1], MODIFIABLE) ||
              !strcmp(p.hier[1], OWNED))) {
            ret = myremovegroup(p.hier[2]);
         }
      } else {
         if (p.hidx == 5) {
           //    /groups/allModOwner/grp/members/val
            if (!strcmp(p.hier[3], MEMBERS)) {
               ret = myremovememberaccess(p.hier[2], p.hier[4], JNI_TRUE);
            }
         } else if (p.hidx == 6 && !strcmp(p.hier[3], PROPERTIES)) {
            
            if (!strcmp(p.hier[4], GACCESS)) {
              //    /groups/allModOwner/grp/properties/access/val
               ret = myremovememberaccess(p.hier[2], p.hier[5], JNI_FALSE);
            }
         }         
      }
      
   } else if (p.topdirnum == PROJECTS_N) {
      ;
   } else if (p.topdirnum == OPTIONS_N) {
      ;
   } else if ((p.topdirnum == TRASH_N || p.topdirnum == INBOX_N) &&
              *p.pack && !*p.file) {
     // Deleting from TRASH/INBOX just cause mark/unmark to occur
      MYDIRENTRY* dp = myquerypackage(&p);
      if (dp) {
         long long packid = dp->getId();
         delete dp;
         
        // Mark/unmark the package ... Marking if going from inbox -> trash
         ret = mymarkpackage(packid, p.topdirnum == INBOX_N);
      }
   } else if (p.topdirnum > INBOX_N && *p.pack && !*p.file) {
     // Can only delete from Outbox and Drafts
      MYDIRENTRY* dp = myquerypackage(&p);
      if (dp) {
         long long packid = dp->getId();
         delete dp;
         ret = mydeletepackage(packid);
      }
   } else if (p.topdirnum == DRAFTS_N && *p.pack && *p.file) {
     // If someone is making some hierarchy
      
     // Make sure it doesn't already exist
     
     // remove final segment (query parent dir), make new PathInfo
      char news[1024];
      strcpy(news, p.fullpath);
      char* fname = strrchr(news, '/');
      *fname++ = '\0';
      
     // Query actual directory for children
      MYDIR * mydir = myquerypackagecontents(&p, 1);
      
     // If we have a directory
      if (mydir) {
      
        // If that dir is empty (then we know we know its in MadeDirectories
         MYDIRENTRY *mydirent=NULL;
         if (!(mydirent = mydir->readDir())) {
         
            LinkList *ll = &(getDirectories(mydir->getId())->ll);
            Link *link   = ll->get_head();
            while(link) {
               mydirent = (MYDIRENTRY*)link->data;
               if (!strcmp(mydirent->getName(), fname) && 
                   !strcmp(mydirent->getDirectory(), news)) {
                  ll->unchain(link);
                  debug("About to rmdir DIRENTRY");
                  delete mydirent;
                  delete link;
                  ret = 0;
                  break;
               }
               link = link->right;
            }
         } else {
            delete mydirent;
         }
         delete mydir;
      }
   }
   return ret;
}

int     Dropbox::objectExists(char* s) {
   debug("Dropbox:objectExists: %s\n", s);
   
   Attrib a;
   return !doStat(s, &a);
}

/*-------------------------------------------------------------------------*\
**             MYFILE
\*-------------------------------------------------------------------------*/
MYFILE::~MYFILE() {
   
  // If we have an operation in progress ... abort it, and forget the ref
  //  This works for operations which have already completed as well
   if (jobj) {
      myfsclose((jobject)jobj);
   }
   if (owner) xfree(owner);
   if (path)  xfree(path);
   if (name)  xfree(name);
   
   if (forceDownload) delete forceDownload;
}

int     MYFILE::close() {
   debug("MYFILE:close: %s", name);
   
   int ret = -1;
   
   if (jobj) {
      ret = myfsclose((jobject)jobj);
      jobj = NULL;
   } else if (type == MYFILE_DESC_UPLOAD) {
      ret = mysetdescription(pkgid, (char*)forceDownload);
   } else if (forceDownload) {
      ret = 0;
   }
   
   return ret;
}

//#define TOTALHACK

int     MYFILE::readData(long long off, char* buf, int len) {
   debug("MYFILE:readData: %s ofs=%lld off=%lld len=%d", name, ofs, off, len);
   int ret = -1;
   
#ifdef TOTALHACK
   return len;
#endif
   
   if (type == MYFILE_DOWNLOAD && jobj) {
      if (off == ofs) {
         ret = 0;
         while(len > 0) {
            int num = myfsread((jobject)jobj, buf+ret, 0, len);
            
            if (num == 0) {
               break;
            }
            
            if (num <= 0) {
               if (ret == 0) ret = -1;
               break;
            }
            
            ofs += num;
            ret += num;
            len -= num;
         }
      } else if (off > size) {
        // If we have reached EOF, don't complain in a bad way
         ret = 0;
      } else {
        // Try updating the operation size and checking one last time
        // The size MAY have been wrong (like when we are doing on the fly 
        //  zips)
         size = mygetoperationsize((jobject)jobj);
         if (size != -1 && off > size) {
            ret = 0;
         }
      }
   } else if (type == MYFILE_DOWNLOAD && forceDownload) {
     // If this is some static data that we are downloading
      if (off >= size) {
        // If we have reached EOF, don't complain in a bad way
         ret = 0;
      } else if (off >= 0) {
         int tocopy = size-off;
         if (tocopy > len) tocopy = len;
         memcpy(buf, forceDownload+off, tocopy);
         ret = tocopy;
         ofs = off + tocopy;
      }
   }
   debug("MYFILE:readData: ret=%d ofs=%lld", ret, ofs);
   return ret;
}
int     MYFILE::writeData(long long off, char* buf, int len) {
   debug("MYFILE:writeData: %s off=%lld len=%d", name, off, len);
   int ret = -1;
   
#ifdef TOTALHACK
   return len;
#endif
   
   if (type == MYFILE_UPLOAD && off == ofs && jobj) {
      ret = myfswrite((jobject)jobj, buf, 0, len);
      if (ret > 0) {
         ofs += ret;
         size += ret;
      }
   } else if (type == MYFILE_DESC_UPLOAD && off == ofs) {
      appendForceDownload(buf, len);
      ofs += len;
      ret = len;
   }
   
   debug("MYFILE:writeData: return");
   return ret;
}
int     MYFILE::doStat(Attrib* a) {
   debug("MYFILE:doStat: %s\n", name);
   attrib_clear(a);
   a->flags = 0;
   a->flags |= SSH2_FILEXFER_ATTR_SIZE;
   a->size = size;
   a->flags |= SSH2_FILEXFER_ATTR_UIDGID;
   a->uid = 1;
   a->gid = 1;
   a->flags |= SSH2_FILEXFER_ATTR_PERMISSIONS;
   
   a->perm = _S_IFREG | 0644;
   a->flags |= SSH2_FILEXFER_ATTR_ACMODTIME;
   
   struct timeb t;
   ftime(&t);
   
   a->atime = t.time;
   a->mtime = t.time;
   return 0;
}

/*-------------------------------------------------------------------------*\
**             MYDIR
\*-------------------------------------------------------------------------*/

MYDIR::~MYDIR() {
   debug("In DIR destructor this=%X", this);
   Link *link;
   while((link=entries->get_head())) {
      entries->unchain(link);
   debug("About to delete DIRENTRY");
      delete (MYDIRENTRY*)link->data;
      delete link;
   }
   delete entries;
   debug("Done DIR destructor this=%X", this);
}

// Entry is owned by MYDIR now
MYDIRENTRY* MYDIR::addEntry(MYDIRENTRY* entry, int uniq) {
   debug("MYDIR:addEntry: %X\n", entry);
   
   Link *link = new Link(entry);
   
  // Make the names uniq ... If have same name, then name it with packid/fileid
  //  This could STILL be non-uniq, but much more remote ... and I'm tired
   Link *tl = entries->get_head();
   while(tl) {
      MYDIRENTRY *tle = (MYDIRENTRY*)tl->data;
      if (!strcmp(tle->getName(), entry->getName())) {
         if (uniq) {
            delete link;
            link = NULL;
            entry = NULL;
            break;
         } else {
            char newname[1024];
            
            struct stat s1, s2;
            s1 = tle->getStats();
            s2 = entry->getStats();
            
           // atime for package is commit time (if pack is committed)
           // If they are the same ... them take whichever has > PId ...
           //  else, the default of entry.
            MYDIRENTRY *tp2 = entry;
            if        (s1.st_atime > s2.st_atime) {
               tp2 = entry;
            } else if (s2.st_atime > s1.st_atime) {
               tp2 = tle;
            } else if (entry->_getPId() > tle->_getPId()) {
               tp2 = tle;
            }
            sprintf(newname, "%s_id_%lld", tp2->getName(),tp2->getId());
            tp2->setName(newname);
            break;
         }
      }
      tl = tl->right;
   }
   if (link) entries->chainLast(link);
   return entry;
}

// Entry is given to caller
MYDIRENTRY* MYDIR::readDir() {
   debug("MYDIR:readDir: %s\n", path);
   
   MYDIRENTRY* ret = NULL;
   
   Link* link = entries->get_head();
   if (link) {
      entries->unchain(link);
      ret = (MYDIRENTRY*)link->data;
      delete link;
   }
   return ret;
}

/*-------------------------------------------------------------------------*\
**             MYDIRENTRY
\*-------------------------------------------------------------------------*/
MYDIRENTRY::~MYDIRENTRY() {
   debug("In MYDIRENTRY destructor this=%X", this);
   if (name)    xfree(name);
}
char*       MYDIRENTRY::ls_file() {
   debug("MYDIRENTRY:ls_file: %s\n", name);
   return local_ls_file(this);
}

/*-------------------------------------------------------------------------*\
**             MYDIRBASE
\*-------------------------------------------------------------------------*/
MYDIRBASE::~MYDIRBASE() {
   debug("In MYDIRBASE destructor this=%X", this);
   debug("In MYDIRBASE owner=%X %s", owner, owner);
   if (owner)   xfree(owner);
   debug("In MYDIRBASE path=%X %s", path, path);
   if (path)    xfree(path);
   debug("In MYDIRBASE company=%X %s", company, company);
   if (company) xfree(company);
   if (desc) xfree(desc);
   debug("Done MYDIRBASE destructor this=%X", this);
}
